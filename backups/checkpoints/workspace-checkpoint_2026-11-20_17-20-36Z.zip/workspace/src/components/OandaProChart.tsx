import { BollingerStudy } from './BollingerStudy';
import { detectAutoTrendlines, type AutoTrendline } from '../services/autoTrendlines';
import { buildIntradayPullbackSignals, intradayPullbackChartRecords } from '../services/intradayPullback';
import { tradeToMt5Signal } from '../services/mt5Automation';
import { buildScalpChartDisplays, scalpDisplayOutcome, scalpHistoryFillDisplays, scalpOutcomeExpired, scalpPositionSignal, type ScalpChartDisplay, type ScalpDisplayOutcome } from '../services/scalpChartDisplay';
import type { ScalpOneToOneChartFill } from '../services/scalpOneToOne';
import { buildPullbackChartSetups, chartSignalFromRecord, chartSignalFromHistoryFill, belongsToPullbackSetup, type PullbackChartSetup } from '../services/pullbackChartSetup';
import { pullbackTelegramAlerts } from '../services/pullbackTelegram';
import { chartExecutionStatus, chartPullbackState, confirmedPullbackFill, currentPullbackDisplay, filledPullbackLegs, groupPullbackTableSignals, scalpReplayTableSignals, type PullbackFillEvidence, type PullbackTableSignal } from '../services/pullbackEntryDisplay';
import { LatestWorkerTask } from '../services/latestWorkerTask';
export { detectAutoTrendlines } from '../services/autoTrendlines';
import { TrendlineStudy } from './TrendlineStudy';
import { VolumeEngulfingStudy } from './VolumeEngulfingStudy';
import { Mt5CapitalPanel } from './Mt5CapitalPanel';
import { bestTrendlineSetupRank, collectStudySupport, measureStudySupportDistance, preEntryTrendlineMarks, studyClosedCandles, studyTimeframes, trendlineSupportsBuy, type EntryArrowStudyEntry } from '../services/trendlineStudy';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import type { UserRole } from '../services/authTypes';
import { userStorage } from '../services/userStorage';
import {
  CandlestickSeries,
  ColorType,
  CrosshairMode,
  HistogramSeries,
  LineStyle,
  type Time,
  type TickMarkType,
  UTCTimestamp,
  createChart,
  createSeriesMarkers,
} from 'lightweight-charts';
import {
  AlertTriangle,
  CheckCircle2,
  Crosshair,
  Maximize2,
  RefreshCw,
  Wifi,
  WifiOff,
} from 'lucide-react';
import {
  analyzeMarketStructure,
  detectEngulfingPatternAt,
  applyTradeableZoneEngulfingFallback,
  DISABLED_HIGHER_TIMEFRAME_CONFIRMATION,
  getGoldZoneTapState,
  isZoneEligibleForEngulfingEntry,
  isGoldZoneEntryBlocked,
  isGoldZoneOpportunityExpired,
  StructureLine,
  StructureZone,
} from '../services/marketStructure';
import { findReplayIndexAtOrBefore } from '../services/replay';
import { buildAlternatingSwingFibs, buildOneHourSwingFibs, SwingFibMove } from '../services/swingFib';
import { ChartTimeZone, formatChartTick, formatChartTime } from '../services/chartTime';
import { matchingChartCandles, structureSnapshotsMatch, type ChartCandleSnapshot,
  type PreparedStructureAnalysis, type StructureAnalysisTask } from '../services/structureAnalysis';
import { buildDayFibs, selectDayFibForTime, nepalDayStartUtc, DayFibMove } from '../services/dayFib';
import { applyPostChochH1SwingFibConfluence, applySwingFibConfluence } from '../services/swingFibConfluence';
import { applyDayFibConfluence } from '../services/dayFibConfluence';
import { INDICATOR_FIB_LEVELS, indicatorFibPrice } from '../services/indicatorFib';
import {
  MTF_MAPPINGS,
  buildGoldIntradayMtfHistoryRows,
  buildGoldIntradayMtfRows,
  buildGoldScalpingMtfHistoryRows,
  buildGoldScalpingMtfRows,
  buildMtfHistoryRows,
  buildMtfRows,
  getSavedMtfEntryQualification,
  mtfChochSequenceLabel,
  type MtfGranularity,
  type MtfRow,
} from '../services/mtf';
import {
  findGoldScalpingCandleSignal,
  goldScalpingCandleTimeframe,
  goldScalpingChochTradeRule,
  goldScalpingTradeRule,
  goldScalpingZoneWidthPips,
  goldIntradayMtfTradeRule,
  isGoldIntradayCandleRoute,
  isGoldScalpingZone,
} from '../services/goldScalping';
import {
  assessEngulfingVolumeLogic,
  applyOppositePositionRewardRisk,
  calculateTradeLevels,
  formatTradeTimeframe,
  getDirectTradeRule,
  getMtfTradeRule,
  getEngulfingVolumeStatus,
  isDaySwingFibEntryTimeframe,
  isZoneEngulfingFibQualified,
  isDeepDiscountTradeSignal,
  isUnfilledDirectSetupQualified,
  inspectZoneEntryEvidence,
  measureTradeableFibZone,
  resolveDirectEntryPolicy,
  resolveZoneEngulfingSignal,
  timeframeWindowCutoff,
  type EngulfingTradeSignal,
  type DirectEntryPolicyDecision,
  type TradeLevels,
  type TradeResult,
  type TradeRule,
  type TradeTimeframe,
  type ZoneEntryEvidence,
} from '../services/tradeLevels';
import { applyOneMinuteGenesisQml, executionZoneName } from '../services/oneMinuteGenesis';
import {
  DEFAULT_TRADE_RECORD_FILTERS,
  buildCanonicalTradeRecords,
  tradeSignalMatchesCandles,
  filterAccuracyTradeRecords,
  tradeRecordOutsideTradingTime,
  selectTradeChartRecords,
  selectTwoMonthAccuracyRecords,
  selectTwoMonthJournalRecords,
  twoMonthAccuracyWindow,
  tradeRecordDatePeriodKey,
  tradeRecordPeriodLabel,
  type TradeRecordFilters,
} from '../services/tradeRecordFilters';
import { deduplicateTradeRecords } from '../services/tradeRecordDeduplication';
import { isNepalTradingTime } from '../services/tradingTime';
import {
  OANDA_MARKET_SYMBOLS,
  normalizeOandaMarketSymbol,
  oandaMarketSymbolConfig,
  type OandaMarketSymbol,
} from '../services/marketSymbols';
import {
  hasIdentifiedDirectZoneLabel,
  isDirectTradeOverlay,
  directZoneTableGroupKey,
  groupDirectZoneTableRows,
  type ZoneTableConfirmation,
  isTradeOverlayTerminated,
  isTradeOverlayVisibleOnTimeframe,
  liveMtfPositionMatchesChartRow,
  retainedDirectTradeHasSource,
  chartSignalMatchesLoadedCandles,
  resolveTradeOverlaySetupKey,
  tradeOverlayEntryEventKey,
  tradeOverlayExecutionKey,
  tradeOverlaySetupEntryKey,
  tradeOverlayZoneLabel,
  tradeOverlayZoneOriginKey,
} from '../services/tradeOverlayIdentity';
import {
  consolidateZonesForDisplay,
  displayZoneMembers,
  redundantStandaloneLiquidityZoneIds,
  selectLtfChochContext,
  selectRecentComparisonZones,
  selectExtremeAPlusTjl2Zones,
  tappedZoneDrawingEndIndex,
  type DisplayStructureZone,
} from '../services/zoneConfluence';
import {
  TradeJournal,
  renderHistoricalTradeSnapshot,
  type JournalTradeRecord,
} from './TradeJournal';
import { TradeMultiSelect, TradeStrategyCheckboxes } from './TradeMultiSelect';
import { matchesTradeStrategies, TRADE_STRATEGIES, type TradeStrategy } from '../services/tradeRecordFilters';
import {
  findEarlierZoneEntry,
  confirmedBrokerZoneEntry,
  findMissedZoneEntry,
  isSameZoneEntryConfirmation,
  tradeZoneExecutionKey,
  type ZoneTradeRecord,
  MT5_DEFAULT_ENABLED_TIMEFRAMES,
  MT5_ENTRY_TIMEFRAME_OPTIONS,
  MT5_RISK_PERCENT_OPTIONS,
  mt5StrategyRiskPercent,
  SCALP_ONE_TO_ONE_RISK_OPTIONS,
  goldM1BuyCountertrendBlocked,
  goldM5ScalpingBuyCountertrendBlocked,
  goldOpposingZoneBeforeOneR,
  prepareGoldOpposingZones,
  goldOpposingZoneBlockLabel,
  isTradeStyleEnabled,
  mt5SignalDisabledReason,
  MT5_FIB_EXIT_TIMEFRAMES,
  type Mt5AutomationStatus,
  type Mt5StoredSignal,
  type Mt5SignalInput,
} from '../services/mt5Automation';

type OandaGranularity = 'M1' | 'M5' | 'M15' | 'M30' | 'H1' | 'H4' | 'D' | 'W';
type MarketGranularity = OandaGranularity | 'W' | 'MO';
type LiveChartDataSource = 'MT5' | 'OANDA';
type FibVisibilityKey = 'tjl1' | 'tjl2' | 'choch' | 'intChoch' | 'intTjl1' | 'intTjl2'
  | 'doubleChoch' | 'intDoubleChoch' | 'iss' | 'swing' | 'h1Swing' | 'day';
type ChochFibVisibility = [boolean, boolean, boolean, boolean];
type ChartDrawingTool = 'rectangle' | 'fib' | 'measure' | 'note' | 'path' | 'trend';
type ChartDrawingVisibility = 'all' | 'current-only' | 'current-and-above' | 'current-and-below';

// Scrolling can fire every frame; rebuilding all zone DOM at that rate stalls
// the chart. Keep data/setting redraws immediate and limit scroll redraws.
const SCROLL_OVERLAY_REDRAW_INTERVAL_MS = 32;
const DRAWING_REDRAW_INTERVAL_MS = 80;

interface ChartDrawingPoint {
  time: number;
  price: number;
}

interface ChartDrawing {
  id: string;
  scope: string;
  tool: ChartDrawingTool;
  points: ChartDrawingPoint[];
  text?: string;
  color?: string;
  visibilityTimeframe?: OandaGranularity;
  visibility?: ChartDrawingVisibility;
  hidden?: boolean;
}

interface ChartDrawingDraft {
  tool: ChartDrawingTool;
  points: ChartDrawingPoint[];
  hover?: ChartDrawingPoint;
}

interface ChartDrawingDrag {
  drawingId: string;
  pointIndex?: number;
  rectangleCorner?: {
    timePointIndex: number;
    pricePointIndex: number;
  };
  start: ChartDrawingPoint;
  originalPoints: ChartDrawingPoint[];
}

interface ChartDrawingTextEditor {
  drawingId: string;
  value: string;
}

const CHART_DRAWINGS_STORAGE_KEY = 'oanda-dashboard-chart-drawings-v1';
const MARKET_SYMBOL_STORAGE_KEY = 'oanda-dashboard-market-symbol-v1';
const TRENDLINE_TIMEFRAMES_STORAGE_KEY = 'oanda-dashboard-trendline-timeframes-v1';
const CHART_DRAWING_COLORS = ['#2563eb', '#dc2626', '#16a34a', '#d97706', '#7c3aed', '#0f172a'] as const;

const CHART_DRAWING_TOOLS: Array<{
  tool: ChartDrawingTool;
  label: string;
  hint: string;
}> = [
  { tool: 'rectangle', label: 'RECTANGLE', hint: 'Mark a price and time area' },
  { tool: 'fib', label: 'FIB MARKING', hint: 'Draw Fibonacci retracement levels' },
  { tool: 'measure', label: 'SCALE / MEASURE', hint: 'Measure bars and price movement' },
  { tool: 'note', label: 'NOTE TEXT', hint: 'Attach a written note to a price' },
  { tool: 'path', label: 'PATH', hint: 'Draw connected custom segments' },
  { tool: 'trend', label: 'TREND LINE', hint: 'Connect two chart points' },
];

function loadStoredChartDrawings(): ChartDrawing[] {
  try {
    const parsed = JSON.parse(userStorage.getItem(CHART_DRAWINGS_STORAGE_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((drawing): drawing is ChartDrawing => (
      drawing && typeof drawing.id === 'string' && typeof drawing.scope === 'string'
      && CHART_DRAWING_TOOLS.some(({ tool }) => tool === drawing.tool)
      && Array.isArray(drawing.points)
      && drawing.points.every((point: ChartDrawingPoint) => (
        Number.isFinite(point?.time) && Number.isFinite(point?.price)
      ))
    )).map((drawing) => {
      const [sourceScope, storedSymbolOrTimeframe, legacyTimeframe] = drawing.scope.split(':');
      const storedSymbol = normalizeOandaMarketSymbol(storedSymbolOrTimeframe);
      return {
        ...drawing,
        scope: `${sourceScope}:${storedSymbol ?? 'XAUUSD'}`,
        visibilityTimeframe: drawing.visibilityTimeframe
          ?? (DRAWING_TIMEFRAME_ORDER.includes((legacyTimeframe ?? storedSymbolOrTimeframe) as OandaGranularity)
            ? (legacyTimeframe ?? storedSymbolOrTimeframe) as OandaGranularity
            : 'M15'),
        visibility: drawing.visibility ?? 'all',
        hidden: drawing.hidden ?? false,
      };
    });
  } catch {
    return [];
  }
}

function loadStoredMarketSymbol(): OandaMarketSymbol {
  try {
    return normalizeOandaMarketSymbol(userStorage.getItem(MARKET_SYMBOL_STORAGE_KEY)) ?? 'XAUUSD';
  } catch {
    return 'XAUUSD';
  }
}

const DEFAULT_CHOCH_FIB_VISIBILITY: ChochFibVisibility = [false, false, false, false];

export const DEFAULT_FIB_VISIBILITY: Record<FibVisibilityKey, boolean> = {
  tjl1: false,
  tjl2: false,
  choch: false,
  intChoch: false,
  intDoubleChoch: false,
  intTjl1: false,
  intTjl2: false,
  doubleChoch: false,
  iss: false,
  swing: false,
  h1Swing: false,
  day: false,
};

const FIB_VISIBILITY_OPTIONS: Array<{ key: FibVisibilityKey; label: string }> = [
  { key: 'tjl1', label: 'TJL1 MARKING' },
  { key: 'tjl2', label: 'TJL2 MARKING' },
  { key: 'choch', label: 'CHoCH MARKING' },
  { key: 'doubleChoch', label: 'D CHoCH MARKING' },
  { key: 'iss', label: 'ISS MARKING' },
  { key: 'swing', label: 'SWING MARKING' },
  { key: 'h1Swing', label: '1H SWING MARKING' },
  { key: 'day', label: 'DAY FIB' },
];

export const INTERNAL_FIB_VISIBILITY_OPTIONS: Array<{ key: FibVisibilityKey; label: string }> = [
  { key: 'intChoch', label: 'Int CHoCH MARKING' },
  { key: 'intDoubleChoch', label: 'Int DOUBLE CHoCH MARKING' },
  { key: 'intTjl1', label: 'Int TJL1 MARKING' },
  { key: 'intTjl2', label: 'Int TJL2 MARKING' },
];

const ALL_FIB_VISIBILITY_OPTIONS = [
  ...FIB_VISIBILITY_OPTIONS,
  ...INTERNAL_FIB_VISIBILITY_OPTIONS,
];

function isSingleFibMarkingKey(key: FibVisibilityKey): boolean {
  return key === 'tjl1' || key === 'tjl2' || key === 'intTjl1' || key === 'intTjl2'
    || key === 'doubleChoch' || key === 'intDoubleChoch' || key === 'iss'
    || key === 'day';
}

interface OandaCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  complete: boolean;
}

interface HigherTimeframeTrendline {
  id: string;
  timeframe: OandaGranularity;
  sourceCandles: OandaCandle[];
  line: AutoTrendline;
  currentPrice: number;
}

function trendlinePriceAtTime(
  line: AutoTrendline,
  candles: OandaCandle[],
  timeframe: OandaGranularity,
  time: number,
): number {
  let low = 0;
  let high = candles.length;
  while (low < high) {
    const middle = (low + high) >> 1;
    if (candles[middle].time <= time) low = middle + 1;
    else high = middle;
  }
  const index = Math.max(0, low - 1);
  const nextTime = candles[index + 1]?.time ?? marketCandleCloseTime(candles[index].time, timeframe);
  const barSeconds = Math.max(1, nextTime - candles[index].time);
  return line.firstPrice + line.slope * (
    index + (time - candles[index].time) / barSeconds - line.firstIndex
  );
}

interface MarketDataResponse {
  ok: boolean;
  source?: string;
  symbol?: OandaMarketSymbol;
  granularity?: MarketGranularity;
  fetchedAt?: string;
  candles?: OandaCandle[];
  error?: string;
}

interface TrackedDirectTradeSetup {
  scope: string;
  zone: StructureZone;
  signal: EngulfingTradeSignal;
  rule: TradeRule;
}

interface DirectZoneEntryDecision {
  policy: DirectEntryPolicyDecision;
  trade?: TradeLevels;
  previewTrade?: TradeLevels;
  usedZoneTrade?: TradeLevels;
  trades?: TradeLevels[];
  oppositePositionOpen: boolean;
  opposingZoneBlock?: NonNullable<ReturnType<typeof goldOpposingZoneBeforeOneR>>;
}

interface TradeOverlay {
  pullbackSetup?: PullbackChartSetup;
  chartFilled?: boolean;
  alwaysVisible?: boolean;
  displayOffset?: number;
  id: string;
  symbol?: OandaMarketSymbol;
  setupId?: string;
  trade: TradeLevels;
  label?: string;
  fibLabels?: string[];
  chartTimeframe?: OandaGranularity;
  zoneTimeframe?: TradeTimeframe;
  referenceOnly?: boolean;
}

interface DirectZoneTableRow {
  overlay: TradeOverlay;
  sourceZoneId?: string;
  sourceZone?: StructureZone;
  sourceTimeframe?: TradeTimeframe;
  trade: TradeLevels;
  confirmedAt: number;
  tapCount?: number;
}

/** Resolve display labels without changing saved trades or their execution rules. */
export function resolveArrowTradeZones(
  record: JournalTradeRecord,
  signals: readonly Partial<Mt5StoredSignal>[],
  recover: (id: string) => MtfRow | undefined,
): { mainZone?: string; entryZone: string } {
  if (record.source !== 'MTF') return { mainZone: record.zoneName, entryZone: record.zoneName };
  const matches = signals.filter((signal) => (
    signal.symbol === (record.symbol ?? 'XAUUSD')
    && signal.signalAt === record.signalAt && signal.signalTimeframe === record.signalTimeframe
    && signal.zoneTimeframe === record.zoneTimeframe
    && signal.direction === (record.direction === 'bullish' ? 'BUY' : 'SELL')
  ));
  const exact = matches.filter((signal) => record.id === `MT5:${signal.id}`
    || (record.brokerTicket !== undefined
      && (record.brokerTicket === signal.brokerTicket || record.brokerTicket === signal.brokerPosition)));
  const signal = exact.length === 1 ? exact[0] : matches.length === 1 ? matches[0] : undefined;
  let context = record.mtfContext ?? signal?.journalContext?.mtfContext;
  const savedZone = record.zoneId?.match(/^(.+)-\d{9,}-.+$/)?.[1]
    ?? signal?.zoneId?.match(/^(.+)-\d{9,}-.+$/)?.[1];
  if (!context && !savedZone && record.signalAt !== undefined) {
    const ids = new Set<string>();
    for (const id of [record.id, record.setupId, signal?.setupId]) {
      if (!id?.startsWith('MTF:')) continue;
      const rowId = id.split(':')[1];
      const candidates = /^\w+-\w+-choch-\d+$/.test(rowId)
        ? [rowId.replace('-choch-', '-external-choch-'), rowId.replace('-choch-', '-internal-choch-')]
        : [rowId];
      for (const candidate of candidates) ids.add(`MTF:${candidate}:${record.signalAt}:${record.entry}`);
    }
    const recovered = [...ids].map(recover).filter((row): row is MtfRow => (
      row !== undefined && row.higherTimeframe === record.zoneTimeframe
      && row.lowerTimeframe === record.signalTimeframe && row.direction === record.direction
      && row.engulfingTime === record.signalAt && row.engulfingType === record.engulfingType
    ));
    if (new Set(recovered.map((row) => row.higherTimeframeZoneId)).size === 1) context = recovered[0];
  }
  return {
    mainZone: context?.higherTimeframeZone ?? savedZone,
    entryZone: context?.entryZone?.name ?? context?.tappedZone ?? record.zoneName,
  };
}

interface EntryHover {
  pullbackSetup?: PullbackChartSetup;
  display?: ScalpChartDisplay;
  id: string;
  candleTime: number;
  high: number;
  low: number;
  trade: TradeLevels;
  source: string;
  zone: string;
  fib: string;
  style: string;
  tradingTimeBlocked: boolean;
}

const RETAINED_CHART_TRADES_STORAGE_KEY = 'oanda-dashboard-retained-chart-trades-v1';

function loadStoredRetainedChartTrades(storageKey = RETAINED_CHART_TRADES_STORAGE_KEY): Map<string, TradeOverlay> {
  try {
    const parsed = JSON.parse(
      userStorage.getItem(storageKey) || '[]',
    );
    if (!Array.isArray(parsed)) return new Map();
    const entries = parsed.filter((overlay): overlay is TradeOverlay => (
      overlay && typeof overlay.id === 'string'
      && DRAWING_TIMEFRAME_ORDER.includes(overlay.chartTimeframe as OandaGranularity)
      && overlay.trade && Number.isFinite(overlay.trade.entry)
      && Number.isFinite(overlay.trade.stopLoss) && Number.isFinite(overlay.trade.takeProfit)
      && Number.isFinite(overlay.trade.calculatedAt) && overlay.trade.result === undefined
      && overlay.trade.signal
      && (overlay.trade.signal.direction === 'bullish' || overlay.trade.signal.direction === 'bearish')
      && hasIdentifiedDirectZoneLabel(overlay.id, overlay.setupId, overlay.label)
    )).map((overlay) => [overlay.id, {
      ...overlay,
      // Migrate older saved drawings that used the source-zone chart instead
      // of the timeframe where the engulfing entry actually formed.
      zoneTimeframe: overlay.zoneTimeframe ?? (overlay.chartTimeframe !== overlay.trade.signal.timeframe ? overlay.chartTimeframe as TradeTimeframe : undefined),
      chartTimeframe: overlay.trade.signal.timeframe,
    }] as const);
    return new Map(entries);
  } catch {
    return new Map();
  }
}

function tradeOverlaySetupKey(overlay: TradeOverlay): string {
  return resolveTradeOverlaySetupKey(overlay.id, overlay.setupId);
}

function directTradeOverlayZoneId(overlay: TradeOverlay): string | undefined {
  const setupKey = tradeOverlaySetupKey(overlay);
  return setupKey.startsWith('DIRECT:') ? setupKey.slice('DIRECT:'.length).replace(/:P(?:10|25)$/, '') : undefined;
}

function retainedLiquidityTradeDuplicatesConfluence(
  overlay: TradeOverlay,
  zones: readonly DisplayStructureZone[],
  candles: readonly OandaCandle[],
): boolean {
  const zoneLabel = tradeOverlayZoneLabel(overlay.label);
  if (zoneLabel !== 'DB' && zoneLabel !== 'DT') return false;
  const expectedInternal = zoneLabel === 'DB' ? 'Internal DB' : 'Internal DT';
  const bullish = overlay.trade.signal.direction === 'bullish';
  const finalIndex = candles.findIndex((candle) => candle.time === overlay.trade.signal.time);
  if (finalIndex < 0) return false;
  const firstIndex = Math.max(0, finalIndex - overlay.trade.signal.candleCount + 1);
  const signalCandles = candles.slice(firstIndex, finalIndex + 1);

  return zones.some((zone) => {
    const members = displayZoneMembers(zone);
    const tjl2 = members.find((member) => member.name === 'TJL2');
    const internal = members.find((member) => member.name === expectedInternal);
    if (!tjl2 || !internal || zone.isBuy !== bullish
      || overlay.trade.signal.time < Math.max(tjl2.startTime, internal.startTime)) return false;
    return signalCandles.some((candle) => candle.high >= zone.bottom && candle.low <= zone.top);
  });
}

type AccuracyTradeRecord = JournalTradeRecord;
type LiveMt5Position = Mt5AutomationStatus['positions'][number];

interface LiveMt5TableTrade {
  position: LiveMt5Position;
  trade: TradeLevels;
  signal?: Mt5StoredSignal;
}

const TIMEFRAMES: Array<{ value: OandaGranularity; label: string }> = [
  { value: 'M1', label: '1m' },
  { value: 'M5', label: '5m' },
  { value: 'M15', label: '15m' },
  { value: 'M30', label: '30m' },
  { value: 'H1', label: '1h' },
  { value: 'H4', label: '4h' },
  { value: 'D', label: 'D' },
  { value: 'W', label: '1W' },
];
const DRAWING_TIMEFRAME_ORDER: OandaGranularity[] = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D', 'W'];

function loadStoredTrendlineTimeframes(granularity: OandaGranularity): Set<OandaGranularity> {
  try {
    const raw = userStorage.getItem(TRENDLINE_TIMEFRAMES_STORAGE_KEY);
    if (raw !== null) {
      const saved: unknown = JSON.parse(raw);
      if (Array.isArray(saved) && saved.every(timeframe => DRAWING_TIMEFRAME_ORDER.includes(timeframe))) {
        // An empty array means the user deliberately unchecked every timeframe.
        return new Set(saved as OandaGranularity[]);
      }
    }
  } catch { /* Missing/unavailable storage or invalid data uses the normal defaults. */ }
  return new Set(DRAWING_TIMEFRAME_ORDER.filter(timeframe => TIMEFRAME_SECONDS[timeframe] >= TIMEFRAME_SECONDS[granularity]));
}

const TREND_TABLE_GRANULARITIES: OandaGranularity[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D'];
const AUTOMATION_GRANULARITIES: TradeTimeframe[] = ['M1', 'M5', 'M15', 'M30', 'H1'];
const MT5_CHART_GRANULARITIES: OandaGranularity[] = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D'];

const ACCURACY_ZONE_ROWS = [
  'TJL1', 'TJL2', 'QML', 'QML(A+)', 'QML(A++)', 'SBR', 'RBS', 'DB', 'DT', 'DBD', 'DTD',
  'Internal QML A+', 'Internal QML A++', 'Internal DBD', 'Internal DTD',
  'Internal QML', 'Internal SBR', 'Internal RBS', 'ISS L3', 'ISS L4',
];

const TREND_TABLE_LABELS: Record<OandaGranularity, string> = {
  M1: '1 MIN', M5: '5 MIN', M15: '15 MIN', M30: '30 MIN', H1: '1 HOUR', H4: '4 HOUR', D: '1 DAY', W: '1 WEEK',
};

const TIMEFRAME_SECONDS: Record<MarketGranularity, number> = {
  M1: 60, M5: 300, M15: 900, M30: 1800, H1: 3600, H4: 14400, D: 86400, W: 604800,
  MO: 31 * 86400,
};

const PRESENT_VIEW_BAR_SPACING = 8.5;
const PRESENT_VIEW_RIGHT_GAP_RATIO = 0.34;
const PRESENT_VIEW_PRICE_SCALE_WIDTH = 80;

const TJL1_CONFIRMATION_SECONDS: Partial<Record<MarketGranularity, number>> = {
  M1: 300,
  M5: 900,
  M15: 3600,
  M30: 3600,
  H1: 14400,
  H4: 86400,
  D: 604800,
  W: 4 * 604800,
};

const VIP_SUPPORT_GRANULARITIES: Record<OandaGranularity, MarketGranularity[]> = {
  // A fresh valid zone from either mapped timeframe can qualify VIP CHoCH.
  M1: ['M5', 'M15'],
  M5: ['H1'],
  M15: ['H1', 'H4'],
  M30: ['H1', 'H4'],
  H1: ['H4', 'D'],
  H4: ['D', 'W'],
  D: ['W', 'MO'],
  W: ['MO'],
};

const DIRECT_ENGULFING_FALLBACKS: Partial<Record<OandaGranularity, OandaGranularity[]>> = {
  M1: ['M5'],
  M15: ['M30'],
  H1: ['M15', 'M30'],
};

const GRANULARITY_LABELS: Record<MarketGranularity, string> = {
  M1: '1m', M5: '5m', M15: '15m', M30: '30m', H1: '1h', H4: '4h', D: '1D', W: '1W', MO: '1M',
};

function marketCandleCloseTime(time: number, granularity: MarketGranularity): number {
  if (granularity !== 'MO') return time + TIMEFRAME_SECONDS[granularity];
  const start = new Date(time * 1000);
  return Date.UTC(
    start.getUTCFullYear(), start.getUTCMonth() + 1, start.getUTCDate(),
    start.getUTCHours(), start.getUTCMinutes(), start.getUTCSeconds(),
  ) / 1000;
}

function resolveRuleForDirectEntry(options: {
  zoneTimeframe: TradeTimeframe;
  signal: EngulfingTradeSignal;
  sourceCandles: OandaCandle[];
  baseRule: TradeRule;
}): TradeRule | undefined {
  const { zoneTimeframe, signal, sourceCandles, baseRule } = options;
  return resolveDirectEntryPolicy({
    zoneTimeframe,
    signal,
    sourceCandles,
    baseRule,
  }).rule;
}

const TJL1_CONFIRMATION_LABELS: Record<OandaGranularity, string> = {
  M1: '5m', M5: '15m', M15: '1h', M30: '1h', H1: '4h', H4: '1D', D: '1W', W: '4W',
};

// Number#toLocaleString constructs an ICU formatter on every call. These
// labels are redrawn during every drag frame, so keep the formatters alive.
const priceFormatters = {
  3: new Intl.NumberFormat(undefined, { minimumFractionDigits: 3, maximumFractionDigits: 3 }),
  5: new Intl.NumberFormat(undefined, { minimumFractionDigits: 5, maximumFractionDigits: 5 }),
};
const zonePipsFormatter = new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 });

function formatPrice(value: number | undefined): string {
  const precision = Number.isFinite(value) && Math.abs(Number(value)) < 10 ? 5 : 3;
  return Number.isFinite(value) ? priceFormatters[precision].format(Number(value)) : '—';
}

function candleSnapshotsMatch(first: OandaCandle[], second: OandaCandle[]): boolean {
  if (first === second) return true;
  if (first.length !== second.length) return false;
  if (first.length === 0) return true;
  const start = Math.max(0, first.length - 2);
  for (let index = start; index < first.length; index += 1) {
    const left = first[index];
    const right = second[index];
    if (!right || left.time !== right.time || left.open !== right.open
      || left.high !== right.high || left.low !== right.low || left.close !== right.close
      || left.volume !== right.volume || left.complete !== right.complete) return false;
  }
  return true;
}

function mt5StatusRenderSignature(status: Mt5AutomationStatus): string {
  const { lastHeartbeatAt: _heartbeat, ...bridge } = status.bridge;
  return JSON.stringify({
    config: status.config,
    bridge,
    positions: status.positions,
    marketData: status.marketData,
    counts: status.counts,
    recentSignals: status.recentSignals,
    entryChecks: status.entryChecks,
    newsCalendar: status.newsCalendar,
  });
}

export function internalSbrTableSourceVisible(
  zoneName: string | undefined,
  sourceZoneId: string | undefined,
  zones: readonly Pick<StructureZone, 'id' | 'name' | 'active' | 'status'>[],
  showInternal: boolean,
): boolean {
  if (zoneName !== 'Internal SBR') return true;
  return showInternal && zones.some((zone) => (
    zone.id === sourceZoneId && zone.name === 'Internal SBR'
    && zone.active && zone.status === 'valid'
  ));
}

function tradeStatusLabel(trade: TradeLevels): string {
  if (trade.status === 'pending') return 'CHART PENDING';
  if (trade.status === 'active') return trade.riskFreeEnabled === false
    ? 'CHART ACTIVE' : `CHART ACTIVE · 1R AT ${formatPrice(trade.riskFree)}`;
  if (trade.status === 'risk-free') return trade.result === 'rf' ? 'RF' : '1R HIT · RF ACTIVE';
  if (trade.status === 'tp-hit') return 'TP HIT';
  return 'SL HIT';
}

const TradeStatusText: React.FC<{ trade: TradeLevels }> = ({ trade }) => {
  const riskFreePrice = (
    <span className="tabular-nums text-[9px] font-semibold text-slate-700">
      {formatPrice(trade.riskFree)}
    </span>
  );

  if (trade.status === 'active') return trade.riskFreeEnabled === false
    ? <>CHART ACTIVE</> : <>CHART ACTIVE · 1R AT {riskFreePrice}</>;
  if (trade.status === 'risk-free') {
    return trade.result === 'rf' ? <>RF</> : <>1R HIT · RF ACTIVE</>;
  }
  if (trade.status === 'tp-hit') return <>TP HIT</>;
  if (trade.status === 'sl-hit') return <>SL HIT</>;
  return <>{tradeStatusLabel(trade)}</>;
};

function mt5SignalStatusLabel(signal: Mt5StoredSignal): string {
  if (signal.status === 'QUEUED') return 'MT5 QUEUED';
  if (signal.status === 'CLAIMED' || signal.status === 'PLACED') return 'MT5 PROCESSING';
  if (signal.status === 'ACTIVE') return signal.tradeStyle === 'SCALPING'
    ? `MT5 ACTIVE · 1R AT ${formatPrice(signal.riskFree)}` : 'MT5 ACTIVE';
  if (signal.status === 'RISK_FREE') return 'MT5 1R HIT · RF ACTIVE';
  if (signal.status === 'RF') return 'MT5 RF';
  if (signal.status === 'TP') {
    return signal.tradeStyle === 'SCALPING' && signal.rewardRisk === 1
      ? `TP HIT · RF ${formatPrice(signal.riskFree)}`
      : 'TP HIT';
  }
  if (signal.status === 'SL') return 'SL HIT';
  if (signal.status === 'CANCELLED') return 'MT5 CANCELLED';
  if (signal.status === 'EXPIRED') return signal.entryQualifiedAt ? 'ENTRY MISSED' : 'MT5 EXPIRED';
  if (signal.status === 'SIMULATED') return 'MT5 SIMULATED';
  if (signal.status === 'REJECTED' && signal.message?.startsWith('STRONG OPPOSITE')) {
    return 'STRONG OPPOSITE SETUP · TRADE SKIPPED';
  }
  if (signal.status === 'REJECTED' && signal.message?.startsWith('WEAK OPPOSITE')) {
    return 'WEAK OPPOSITE SETUP · TRADE SKIPPED';
  }
  if (signal.message?.includes('daily loss')) return 'MT5 REJECTED · DAILY LOSS LIMIT';
  if (signal.message?.includes('open trades')) return 'MT5 REJECTED · OPEN TRADE LIMIT';
  if (signal.message?.toLowerCase().includes('spread')) return 'MT5 REJECTED · SPREAD LIMIT';
  if (signal.message) return `ORDER REJECTED — ${signal.message.length > 65 ? `${signal.message.slice(0, 62)}…` : signal.message}`;
  return 'MT5 REJECTED · NO TRADE';
}

function mt5SignalStatusClassName(signal: Mt5StoredSignal): string {
  if (signal.status === 'SL' || signal.status === 'REJECTED'
    || signal.status === 'CANCELLED' || signal.status === 'EXPIRED') return 'text-rose-700';
  if (signal.status === 'QUEUED' || signal.status === 'CLAIMED'
    || signal.status === 'PLACED') return 'text-amber-700';
  return 'text-emerald-700';
}

function isCompletedTrade(trade: TradeLevels | undefined): boolean {
  return trade?.result !== undefined;
}

export function resolveRetainedTrade(trade: TradeLevels, candles: OandaCandle[]): TradeLevels {
  if (trade.result || trade.filledAt === undefined) return trade;
  const isBuy = trade.signal.direction === 'bullish';
  let reachedRiskFree = false;
  for (const candle of candles) {
    if (candle.time < trade.filledAt) continue;
    const tpHit = isBuy ? candle.high >= trade.takeProfit : candle.low <= trade.takeProfit;
    const riskFreeHit = isBuy ? candle.high >= trade.riskFree : candle.low <= trade.riskFree;
    const slHit = isBuy ? candle.low <= trade.stopLoss : candle.high >= trade.stopLoss;
    if (tpHit) {
      return { ...trade, status: 'tp-hit', result: 'tp', resolvedAt: candle.time };
    }
    reachedRiskFree = trade.riskFreeEnabled !== false && (reachedRiskFree || riskFreeHit);
    if (slHit) {
      return {
        ...trade,
        status: reachedRiskFree ? 'risk-free' : 'sl-hit',
        result: reachedRiskFree ? 'rf' : 'sl',
        resolvedAt: candle.time,
      };
    }
  }
  return { ...trade, status: reachedRiskFree ? 'risk-free' : 'active' };
}

export const EntryFillTick: React.FC<{ filled: boolean }> = ({ filled }) => filled
  ? <span className="ml-0.5 text-[8px] text-emerald-600" role="img" aria-label="Entry filled">✓</span> : null;

export const TradeDetailsRow: React.FC<{
  trade: TradeLevels;
  colSpan: number;
  mtf?: boolean;
  oppositePositionOpen?: boolean;
  mt5Signal?: Mt5StoredSignal;
  referenceOnly?: boolean;
  hideReferenceStatus?: boolean;
  intradayReference?: boolean;
  entryCandles?: readonly OandaCandle[];
  zoneTimeframe?: TradeTimeframe;
  fillEvidence?: PullbackFillEvidence;
}> = ({ trade, colSpan, mtf = false, oppositePositionOpen = false, mt5Signal, referenceOnly = false, hideReferenceStatus = false, intradayReference = false, entryCandles = [], zoneTimeframe, fillEvidence }) => {
  if (isSlTpTradeDisplayFinished(mt5Signal) || isSlTpTradeDisplayFinished(trade)) return null;
  if (!mt5Signal && (intradayReference || trade.intradayReference)) {
    const base = tradeToMt5Signal({ source: mtf ? 'MTF' : 'ENGULFING', setupId: 'ENTRY_ROW_PREVIEW',
      zoneName: 'Entry details', zoneTimeframe: zoneTimeframe ?? trade.signal.timeframe,
      trade, now: trade.calculatedAt, pendingExpiryMinutes: 15 });
    const entries = buildIntradayPullbackSignals({ ...base, tradeStyle: 'INTRADAY' }, entryCandles);
    const filled = fillEvidence?.replay ? filledPullbackLegs({ ...base, tradeStyle: 'INTRADAY' }, fillEvidence) : new Set<number>();
    return (
      <tr className="border-t border-indigo-100 bg-indigo-50/70"><td colSpan={colSpan} className="px-2 py-1">
        <div className="flex flex-nowrap items-baseline gap-x-3 whitespace-nowrap text-[9px] font-black text-slate-700">
          {([10, 25] as const).map((leg, index) => {
            const entry = entries.find(candidate => candidate.intradayEntry?.leg === leg);
            const chartFilled = !!entry && !!fillEvidence && chartPullbackState(entry, entryCandles, fillEvidence.asOf).status === 'filled';
            return <React.Fragment key={leg}>
              {index > 0 && <span aria-hidden="true">|</span>}
              <span className="text-blue-700">{index === 0 ? '1st' : '2nd'} ENTRY<EntryFillTick filled={!referenceOnly && (chartFilled || filled.has(leg))} /> <span className="tabular-nums font-bold text-slate-700">{entry ? formatPrice(entry.entry) : '—'}</span></span>
              <span className="tabular-nums">SL {entry ? entry.riskPips.toFixed(2) : '—'} PIPS</span>
            </React.Fragment>;
          })}
          <span aria-hidden="true">|</span><span className="text-rose-700">SL <span className="tabular-nums font-bold text-slate-700">{formatPrice(trade.stopLoss)}</span></span>
          <span aria-hidden="true">|</span><span className="text-emerald-700">TP <span className="tabular-nums font-bold text-slate-700">{formatPrice(trade.takeProfit)}</span></span>
        </div>
      </td></tr>
    );
  }
  return (
  <tr className="border-t border-indigo-100 bg-indigo-50/70">
    <td colSpan={colSpan} className="px-2 py-1">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 whitespace-nowrap text-[9px] font-black text-slate-700">
        {mtf && <span className="rounded bg-indigo-100 px-1 py-0.5 text-indigo-700">MTF</span>}
        {mt5Signal?.intradayEntry && <span>{mt5Signal.intradayEntry.leg}% PULLBACK · {mt5Signal.intradayEntry.riskShare * 100}% SETUP RISK · ORIGINAL EXITS FIXED</span>}
        {oppositePositionOpen && (
          <span className="rounded bg-amber-100 px-1 py-0.5 text-amber-800">OPPOSITE MT5 POSITION · 1:1</span>
        )}
        <span className="text-blue-700">{mt5Signal?.intradayEntry || mt5Signal?.scalpEntry
          ? (mt5Signal.intradayEntry ?? mt5Signal.scalpEntry)!.leg === 10 ? '1st ENTRY' : '2nd ENTRY' : 'ENTRY'}
          <EntryFillTick filled={!referenceOnly && !!mt5Signal && !!(mt5Signal.intradayEntry || mt5Signal.scalpEntry)
            && chartPullbackState(mt5Signal, entryCandles, fillEvidence?.asOf ?? Date.now() / 1000).status === 'filled'} /> <span className="tabular-nums font-bold text-slate-700">{formatPrice(trade.entry)}</span></span>
        <span className="text-rose-700">SL <span className="tabular-nums font-bold text-slate-700">{formatPrice(trade.stopLoss)}</span></span>
        <span className="text-emerald-700">TP <span className="tabular-nums font-bold text-slate-700">{formatPrice(trade.takeProfit)}</span></span>
        <span>R:R 1:{trade.rewardRisk}</span>
        <span>SL {trade.riskPips} PIPS</span>
        {!(referenceOnly && hideReferenceStatus) && <span className={referenceOnly ? 'text-rose-700' : mt5Signal
          ? mt5SignalStatusClassName(mt5Signal)
          : trade.status === 'sl-hit'
            ? 'text-rose-700'
            : trade.status === 'pending'
              ? 'text-amber-700'
              : 'text-emerald-700'}>
          {referenceOnly ? 'OUTSIDE TRADING TIME · NO TRADE'
            : mt5Signal ? mt5SignalStatusLabel(mt5Signal) : <TradeStatusText trade={trade} />}
        </span>}
      </div>
    </td>
  </tr>
  );
};

export const ScalpOutcomeRow: React.FC<{ outcome: ScalpDisplayOutcome; signal: Mt5StoredSignal }> = ({ outcome, signal }) => (
  <tr className="border-t border-cyan-200 bg-cyan-50/80">
    <td className="px-2 py-1 font-black text-cyan-800">SCALP 1:1 · M15</td>
    <td className={`px-2 py-1 font-bold ${signal.direction === 'BUY' ? 'text-emerald-700' : 'text-rose-700'}`}>{signal.direction}</td>
    <td className="px-2 py-1 font-bold text-blue-700">{formatPrice(signal.executionPrice ?? signal.entry)}</td>
    <td className="px-2 py-1 text-center font-black">{signal.engulfingType}</td>
    <td className={`px-2 py-1 text-right font-black ${outcome.level === 'tp' ? 'text-emerald-700' : 'text-rose-700'}`}>
      {outcome.label}
    </td>
  </tr>
);

/** Match source identity before combining display rows from different stores. */
export function findZoneTablePullbackSetup(setups: readonly PullbackChartSetup[], options: {
  zoneIds: readonly string[]; symbol: string; zoneTimeframe: string;
  direction: TradeLevels['signal']['direction']; trade?: TradeLevels;
}): PullbackChartSetup | undefined {
  return setups.find(setup => {
    const key = resolveTradeOverlaySetupKey(setup.id, setup.setupId);
    const zoneId = key.startsWith('DIRECT:') ? key.slice(7).replace(/:P(?:10|25)$/, '') : undefined;
    return setup.style === 'INTRADAY' && setup.symbol === options.symbol
      && setup.zoneTimeframe === options.zoneTimeframe && setup.trade.signal.direction === options.direction
      && zoneId !== undefined && options.zoneIds.some(id => tradeOverlayZoneOriginKey(id) === tradeOverlayZoneOriginKey(zoneId))
      && (!options.trade || belongsToPullbackSetup(setup, options.trade, 'INTRADAY'));
  });
}

function pullbackSetupTooltip(setup: PullbackChartSetup): string {
  return [
    `CHART: ${setup.legs.some(leg => leg.chartConfirmed) ? 'Filled' : 'Waiting / unconfirmed'} · MT5: ${setup.legs.some(leg => leg.executed) ? 'Executed' : 'Not executed'}`,
    ...setup.legs.flatMap(leg => [
      `${leg.leg === 10 ? '1st' : '2nd'} Entry: ${formatPrice(leg.entry)} — ${setup.secondOnly && leg.leg === 10 ? 'Skipped — split lot below minimum'
        : leg.chartOutcome ? `${leg.chartOutcome.toUpperCase()} HIT` : leg.chartConfirmed ? '✓ Filled' : leg.uncertain ? 'Fill uncertain' : 'Waiting'}`,
      `SL: ${leg.riskPips.toFixed(2)} pips · MT5: ${leg.executed ? 'Executed' : 'Not executed'}`,
    ]),
    `Fixed SL: ${formatPrice(setup.trade.stopLoss)}`,
    `Fixed TP: ${formatPrice(setup.trade.takeProfit)}`,
  ].join('\n');
}

export const ZonePullbackTradeStatus: React.FC<{ setup: PullbackChartSetup }> = ({ setup }) => (
  <span title={pullbackSetupTooltip(setup)} className="cursor-help text-[10px] font-bold">
    {zoneTableCompletedStatus(setup.trade) ?? (setup.chartFilled
      ? setup.alwaysVisible ? 'ACTIVE TRADE' : 'OUTCOME UNCONFIRMED'
      : setup.drawing ? 'WAITING ENTRY' : 'ENTRY EXPIRED')}
  </span>
);

export const ZonePullbackDetailsRow: React.FC<{ setup: PullbackChartSetup }> = ({ setup }) => {
  if (isSlTpTradeDisplayFinished(setup.trade)) return null;
  return <tr className="border-t border-indigo-100 bg-indigo-50/70"><td colSpan={5} className="px-2 py-1">
    <div className="flex flex-nowrap items-baseline gap-x-3 whitespace-nowrap text-[9px] font-black text-slate-700">
      {setup.legs.map((leg, index) => <React.Fragment key={leg.leg}>
        {index > 0 && <span aria-hidden="true">|</span>}
        <span className="text-blue-700">{leg.leg === 10 ? '1st' : '2nd'} ENTRY
          <EntryFillTick filled={leg.chartConfirmed === true && !(setup.secondOnly && leg.leg === 10)} />{' '}
          <span className="tabular-nums font-bold text-slate-700">{setup.secondOnly && leg.leg === 10 ? 'SKIPPED' : formatPrice(leg.entry)}</span>
        </span>
        {!(setup.secondOnly && leg.leg === 10) && <span className="tabular-nums">SL {leg.riskPips.toFixed(2)} PIPS</span>}
      </React.Fragment>)}
      <span aria-hidden="true">|</span><span className="text-rose-700">SL <span className="tabular-nums font-bold text-slate-700">{formatPrice(setup.trade.stopLoss)}</span></span>
      <span aria-hidden="true">|</span><span className="text-emerald-700">TP <span className="tabular-nums font-bold text-slate-700">{formatPrice(setup.trade.takeProfit)}</span></span>
    </div>
  </td></tr>;
};

export const PullbackSetupRows: React.FC<{
  signals: readonly PullbackTableSignal[];
  style: 'SCALP_1_1' | 'INTRADAY';
  asOf: number;
  entryCandles: Partial<Record<TradeTimeframe, readonly OandaCandle[]>>;
  positions?: Mt5AutomationStatus['positions'];
  connection?: Pick<Mt5StoredSignal, 'account' | 'server' | 'brokerSymbol'>;
  timeZone: ChartTimeZone;
  limit?: number;
  representedSetups?: readonly PullbackChartSetup[];
  replay?: boolean;
}> = ({ signals, style, asOf, entryCandles, positions = [], connection = {}, timeZone, limit = 8, representedSetups = [], replay = false }) => {
  const groups = groupPullbackTableSignals(signals.filter(signal => signal.signalAt <= asOf)
    .map(signal => currentPullbackDisplay(signal, asOf, positions)), connection);
  return <>{groups.flatMap(group => {
    if (style === 'INTRADAY' && representedSetups.some(setup => group.entries.some(entry =>
      setup.trade.signal.time === entry.signalAt && (setup.memberIds.includes(entry.id)
        || entry.setupId !== undefined && setup.memberIds.includes(entry.setupId))))) return [];
    const signal = group.entries[0], candles = entryCandles[signal.signalTimeframe] ?? [];
    const secondOnly = group.entries.some(entry => entry.pullbackFallback === 'SECOND_ONLY');
    const states = group.entries.map(entry => {
      const open = !entry.preview && positions.some(position => scalpPositionSignal(position, [entry], connection) !== undefined);
      const chart = chartPullbackState(entry, candles, asOf);
      if (replay && entry.simulatedFill && (entry.openedAt ?? Infinity) <= asOf) {
        chart.status = 'filled';
        chart.filledAt = entry.openedAt;
        chart.beforeEntryExit = undefined;
        if ((entry.status === 'TP' || entry.status === 'SL') && (entry.closedAt ?? Infinity) <= asOf)
          chart.outcome = { level: entry.status === 'TP' ? 'tp' : 'sl', at: entry.closedAt! };
      }
      const chartExit = chart.outcome ?? chart.beforeEntryExit;
      const outcome = chartExit ? { ...chartExit, label: `${chartExit.level === 'both' ? 'SL/TP' : chartExit.level.toUpperCase()} ${chart.outcome ? 'HIT' : 'REACHED BEFORE ENTRY'}`,
        noFill: chart.outcome === undefined } : ['TP', 'SL'].includes(entry.status) ? scalpDisplayOutcome(entry, candles, asOf, open) : undefined;
      const executed = confirmedPullbackFill(entry, asOf, positions);
      const filled = !(entry.pullbackFallback === 'SECOND_ONLY' && (entry.intradayEntry ?? entry.scalpEntry)?.leg === 10)
        && (chart.status === 'filled' || entry.simulatedFill === true && (entry.openedAt ?? Infinity) <= asOf);
      return { signal: entry, outcome, filled, chart, executed };
    });
    const completed = states.every(state => state.outcome !== undefined);
    if (completed && states.every(state => scalpOutcomeExpired(state.outcome!, candles, signal.signalTimeframe, asOf))) return [];
    const entryName = (entry: PullbackTableSignal) => (entry.intradayEntry ?? entry.scalpEntry)?.leg === 25 ? '2nd' : '1st';
    const status = (state: typeof states[number]) => secondOnly && (state.signal.intradayEntry ?? state.signal.scalpEntry)?.leg === 10
      ? 'Skipped — split lot below minimum' : state.signal.displayPlan?.error
      ? replay ? 'REPLAY: Entry outside limits' : 'CHART: Entry outside limits · MT5: Not executed'
      : chartExecutionStatus(state.chart, state.executed, state.signal.status, replay);
    const labels = states.map(status);
    const summary = labels.every(label => label === labels[0]) ? labels[0]
      : states.map(state => `${entryName(state.signal)}: ${status(state)}`).join(' · ');
    const leg = signal.intradayEntry ?? signal.scalpEntry;
    const stop = signal.initialStopLoss ?? signal.stopLoss;
    const slots = leg ? [10, 25] as const : [0] as const;
    const planPrices = states.filter(state => state.signal.displayPlan && !state.signal.displayPlan.error).map(state => state.signal.entry);
    return [<React.Fragment key={group.key}>
      <tr className={`border-t ${style === 'SCALP_1_1' ? 'border-cyan-200 bg-cyan-50/80' : 'border-indigo-200 bg-indigo-50/80'}`}>
        <td className={`px-2 py-1 font-black ${style === 'SCALP_1_1' ? 'text-cyan-800' : 'text-indigo-800'}`}>
          <div>{style === 'SCALP_1_1' ? 'SCALP 1:1' : 'INTRADAY'} · {signal.signalTimeframe}</div>
          <div className="text-[8px] font-semibold text-slate-500">{formatAccuracyTradeTime(signal.calculatedAt, timeZone)}</div>
        </td>
        <td className={`px-2 py-1 font-bold ${signal.direction === 'BUY' ? 'text-emerald-700' : 'text-rose-700'}`}>{signal.direction}</td>
        <td className="px-2 py-1 font-bold text-blue-700">{planPrices.length > 0
          ? `${formatPrice(Math.min(...planPrices))} – ${formatPrice(Math.max(...planPrices))}`
          : signal.displayPlan ? '—' : formatPrice(leg?.referenceEntry ?? signal.executionPrice ?? signal.entry)}</td>
        <td className="px-2 py-1 text-center font-black">{signal.engulfingType}</td>
        <td title={states.map(state => `${entryName(state.signal)}: ${status(state)}${state.signal.displayPlan ? `\nOriginal entry: ${formatPrice(state.signal.displayPlan.previousEntry)}\nOriginal order: ${mt5SignalStatusLabel(state.signal)}` : ''}`).join('\n')}
          className={`max-w-[380px] truncate px-2 py-1 text-right text-[10px] font-bold ${completed && states.every(state => state.outcome?.level === 'tp')
            ? 'text-emerald-700' : states.some(state => state.signal.status === 'REJECTED' || state.outcome?.level === 'sl')
              ? 'text-rose-700' : mt5SignalStatusClassName(signal)}`}>{summary}</td>
      </tr>
      {!completed && <tr className="border-t border-indigo-100 bg-indigo-50/70"><td colSpan={5} className="px-2 py-1">
        <div className="flex flex-nowrap items-baseline gap-x-3 whitespace-nowrap text-[9px] font-black text-slate-700">
          {slots.map((slot, index) => {
            const state = states.find(candidate => (candidate.signal.intradayEntry ?? candidate.signal.scalpEntry)?.leg === slot
              || slot === 0 && !(candidate.signal.intradayEntry ?? candidate.signal.scalpEntry));
            const price = state ? state.signal.executionPrice ?? state.signal.entry : undefined;
            return <React.Fragment key={slot}>
              {index > 0 && <span aria-hidden="true">|</span>}
              <span className="text-blue-700">{slot === 10 ? '1st ENTRY' : slot === 25 ? '2nd ENTRY' : 'ENTRY'}
                <EntryFillTick filled={state?.filled === true && !state.outcome} />{' '}
                <span className="tabular-nums font-bold text-slate-700">{secondOnly && slot === 10 ? 'SKIPPED' : state?.outcome ? state.outcome.label : state?.signal.displayPlan?.error ? 'OUTSIDE LIMITS' : price !== undefined ? formatPrice(price) : '—'}</span>
              </span>
              {state && !state.outcome && !state.signal.displayPlan?.error && price !== undefined && <span className="tabular-nums">SL {(Math.round(Math.abs(price - stop) * 1000 + 1e-7) / 100).toFixed(2)} PIPS</span>}
            </React.Fragment>;
          })}
          <span aria-hidden="true">|</span><span className="text-rose-700">SL <span className="tabular-nums font-bold text-slate-700">{formatPrice(stop)}</span></span>
          {secondOnly && <span>2nd entry: 100% setup risk</span>}
          <span aria-hidden="true">|</span><span className="text-emerald-700">TP <span className="tabular-nums font-bold text-slate-700">{formatPrice(signal.takeProfit)}</span></span>
        </div>
      </td></tr>}
    </React.Fragment>];
  }).slice(0, limit)}</>;
};

function displayZoneName(
  name: string,
  oneMinuteGenesisQml?: StructureZone['oneMinuteGenesisQml'],
): string {
  if (oneMinuteGenesisQml) return '1MG QML';
  return name.startsWith('Internal ') ? `Int ${name.slice('Internal '.length)}` : name;
}

function isDefaultDeepDiscountZoneName(name: string | undefined): boolean {
  return name === 'DB' || name === 'DT';
}

export function isDeepDiscountZoneDisplay(
  zone: StructureZone,
  signal?: EngulfingTradeSignal,
): boolean {
  if (isDefaultDeepDiscountZoneName(zone.name)) return true;
  if (signal) return isDeepDiscountTradeSignal(zone, signal);
  return (zone.fibStatus === 'a-plus' && (zone.fibBand === 'deep' || zone.fibBand === '0.71-0.79'))
    || (zone.swingFibStatus === 'a-plus' && zone.swingFibBand === '0.71-0.79')
    || (zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand === '0.71-0.79')
    || (zone.dayFibStatus === 'a-plus' && zone.dayFibBand === '0.71-0.79');
}

function displayConfluenceZoneName(
  zone: DisplayStructureZone,
  uppercaseSecondary = false,
): string {
  const primary = displayZoneName(zone.name, zone.oneMinuteGenesisQml);
  const secondary = displayZoneMembers(zone)
    .filter((member) => member.id !== zone.id)
    .map((member) => displayZoneName(member.name, member.oneMinuteGenesisQml))
    .map((name) => uppercaseSecondary ? name.toUpperCase() : name);
  return Array.from(new Set([primary, ...secondary])).join(' + ');
}

function confluenceBadgeLabels(zone: DisplayStructureZone): string[] {
  const labels: string[] = [];
  for (const member of displayZoneMembers(zone).filter((candidate) => candidate.id !== zone.id)) {
    if (member.chochClass === 'vip') {
      labels.push(member.category === 'internal' ? 'INT VIP' : 'VIP');
    }
    if (member.vipSupportTimeframe && member.vipSupportZone) {
      labels.push(
        `${formatTradeTimeframe(member.vipSupportTimeframe)} ${displayZoneName(member.vipSupportZone)}`,
      );
    }
    if (member.majorLiquidity) labels.push('MAJOR LIQUIDITY');
  }
  return Array.from(new Set(labels));
}

function confluenceMapValue<T>(
  zone: DisplayStructureZone,
  values: ReadonlyMap<string, T>,
): T | undefined {
  for (const member of displayZoneMembers(zone)) {
    const value = values.get(member.id);
    if (value !== undefined) return value;
  }
  return undefined;
}

function confluenceFirstValue<T>(
  zone: DisplayStructureZone,
  resolve: (member: StructureZone) => T | undefined,
): T | undefined {
  for (const member of displayZoneMembers(zone)) {
    const value = resolve(member);
    if (value !== undefined) return value;
  }
  return undefined;
}

function confluenceTapBarsAgo(zone: DisplayStructureZone): number | undefined {
  const values = displayZoneMembers(zone)
    .map((member) => member.lastTapBarsAgo ?? member.tapBarsAgo)
    .filter((value): value is number => value !== undefined);
  return values.length > 0 ? Math.min(...values) : undefined;
}

/** Table age restarts on each visit and counts actual candles, including in replay. */
export function latestZoneTapBarsAgo(
  zone: DisplayStructureZone, candles: readonly { time: number }[] = [],
): number | undefined {
  const members = displayZoneMembers(zone);
  if (candles.length) {
    const asOf = candles[candles.length - 1].time;
    const times = members.flatMap(member => [member.lastTapTime, member.tapTime])
      .filter((time): time is number => time !== undefined && Number.isFinite(time) && time <= asOf);
    if (!times.length) return undefined;
    const latestTouch = Math.max(...times);
    return candles.filter(candle => candle.time > latestTouch && candle.time <= asOf).length;
  }
  return confluenceTapBarsAgo(zone);
}

export const ZoneTableTapAge: React.FC<{ barsAgo?: number; children: React.ReactNode }> = ({ barsAgo, children }) => (
  <>{barsAgo !== undefined && Number.isFinite(barsAgo) && <span className="text-[8px] font-bold">{Math.max(0, barsAgo)} {barsAgo === 1 ? 'bar' : 'bars'} · </span>}{children}</>
);

/** Display age stays anchored to the first visit; later visits never restart it. */
export function firstZoneTapBarsAgo(
  zone: DisplayStructureZone, candles: readonly { time: number }[] = [],
): number | undefined {
  const members = displayZoneMembers(zone);
  if (candles.length) {
    const asOf = candles[candles.length - 1].time;
    const times = members.map(member => member.tapTime)
      .filter((time): time is number => time !== undefined && Number.isFinite(time) && time <= asOf);
    if (!times.length) return undefined;
    const firstTouch = Math.min(...times);
    return candles.filter(candle => candle.time > firstTouch && candle.time <= asOf).length;
  }
  const ages = members.map(member => member.tapBarsAgo)
    .filter((age): age is number => age !== undefined && Number.isFinite(age) && age >= 0);
  return ages.length ? Math.max(...ages) : undefined;
}

function confluenceLatestTap(zone: DisplayStructureZone): { time: number; count: number } | undefined {
  const taps = displayZoneMembers(zone)
    .map((member) => ({ time: member.lastTapTime ?? member.tapTime, count: member.tapCount ?? 1 }))
    .filter((tap): tap is { time: number; count: number } => tap.time !== undefined);
  return taps.sort((a, b) => b.time - a.time)[0];
}

function confluenceEngulfingLabel(zone: DisplayStructureZone, chartTimeframe?: TradeTimeframe): string | undefined {
  const labels = displayZoneMembers(zone)
    .map(member => displayEngulfingLabel(member, chartTimeframe))
    .filter((label): label is string => Boolean(label));
  return Array.from(new Set(labels)).join(' / ') || undefined;
}

function confluenceIsTradeable(zone: DisplayStructureZone): boolean {
  return displayZoneMembers(zone).some((member) => member.tradeable !== false);
}

function directEntryPolicyLabel(policy: DirectEntryPolicyDecision): string {
  if (policy.reason === 'zone-used') return 'ZONE ALREADY USED';
  if (policy.reason === 'outside-trading-time') return 'OUTSIDE TRADING TIME';
  if (policy.reason === 'volume-confirmed') return 'VOLUME PASSED';
  if (policy.reason === 'volume-unavailable') return 'VOLUME UNAVAILABLE';
  if (policy.reason === 'volume-not-applicable') return 'NO M1 VOLUME RULE';
  if (policy.reason === 'volume-failed') return 'VOLUME FAILED';
  return 'ENTRY VALID';
}

export interface ZoneEntryReadiness {
  mode: 'WAIT' | 'BLOCKED' | 'DISABLED' | 'SIMULATION' | 'READY';
  label: string;
  title: string;
  reasons: string[];
  context?: string;
  explanations?: Array<{ reason: string; detail: string }>;
  heading?: string;
  narrative?: string[];
}

function zoneEntryStory(options: Parameters<typeof explainZoneEntry>[0],
  entries: Array<{ reason: string; detail: string }>): Pick<ZoneEntryReadiness, 'heading' | 'narrative'> {
  const { zone, timeframe, now } = options;
  const timeframeName = ({ M1: '1-minute', M5: '5-minute', M15: '15-minute', M30: '30-minute',
    H1: '1-hour', H4: '4-hour', D: 'daily' } as Record<string, string>)[timeframe] ?? timeframe;
  const side = zone.isBuy ? 'buy' : 'sell';
  const narrative = [`This is a ${timeframeName} ${side} zone, between ${formatPrice(zone.bottom)} and ${formatPrice(zone.top)}.`];
  const fib: string[] = [];
  if (zone.fibStatus === 'a-plus' && zone.fibBand) fib.push(`A+ Fib ${zone.fibBand}`);
  if (zone.swingFibStatus === 'a-plus' && zone.swingFibBand) fib.push(`Swing Fib ${zone.swingFibBand}`);
  if (zone.dayFibStatus === 'a-plus' && zone.dayFibBand) fib.push(`Day Fib ${zone.dayFibBand}`);
  if (zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand) fib.push(`1-hour Swing Fib ${zone.h1SwingFibBand}`);
  const broker = !options.replay && options.brokerSignal && options.automation
    && options.brokerSignal.account === options.automation.bridge.account
    && options.brokerSignal.server === options.automation.bridge.server
    && options.brokerSignal.brokerSymbol === options.automation.bridge.brokerSymbol
    && tradeZoneExecutionKey(options.brokerSignal) === tradeZoneExecutionKey({ symbol: options.symbol ?? 'XAUUSD',
      zoneTimeframe: timeframe, zoneId: zone.id }) ? options.brokerSignal : undefined;
  const brokerFilled = broker && confirmedBrokerZoneEntry(broker) && broker.openedAt! <= now ? broker : undefined;
  const recorded = options.recordedTrade ?? options.trade;
  const chartFilled = recorded?.filledAt !== undefined && recorded.filledAt <= now ? recorded : undefined;
  if (brokerFilled || chartFilled) {
    const source = brokerFilled ? 'MT5 trade' : options.replay ? 'replay entry' : 'chart entry';
    const entrySide = brokerFilled ? brokerFilled.direction.toLowerCase() : chartFilled!.signal.direction === 'bullish' ? 'buy' : 'sell';
    narrative.push(`A ${entrySide} ${source} was recorded from this zone${brokerFilled?.brokerTicket ? ` (ticket ${brokerFilled.brokerTicket})` : ''}.`);
    const context = brokerFilled?.journalContext;
    if (context?.fibSource && context.fibBand) narrative.push(`The recorded entry used ${context.fibSource} alignment in the ${context.fibBand} band.`);
    if (fib.length) narrative.push(`The chart currently shows ${fib.join(' and ')} alignment for this zone.`);
    const pattern = brokerFilled?.engulfingType ?? chartFilled?.signal.type;
    const patternFrame = brokerFilled?.signalTimeframe ?? chartFilled?.signal.timeframe;
    if (pattern) narrative.push(`The recorded confirmation was a ${pattern} ${entrySide} engulfing${patternFrame ? ` on the ${formatTradeTimeframe(patternFrame)} chart` : ''}.`
      + (brokerFilled?.entryQualifiedAt ? ' The automatic entry checks passed before this trade was sent to MT5.' : ''));
    if (brokerFilled && context) {
      const candles = context.entrySnapshotCandles ?? [];
      const end = candles.findIndex(candle => candle.time === brokerFilled.signalAt);
      const pattern = end >= 1 ? detectEngulfingPatternAt(candles, end) : undefined;
      const fib50 = context.fibLevels?.find(level => level.label === '0.5')?.price;
      if (pattern?.type === brokerFilled.engulfingType
        && pattern.direction === (brokerFilled.direction === 'BUY' ? 'bullish' : 'bearish')
        && fib50 !== undefined && candles.slice(pattern.startIndex, pattern.endIndex + 1)
          .some(candle => candle.low <= fib50 && candle.high >= fib50)) {
        narrative.push(`Its recorded engulfing candles touched Fib 0.5 at ${formatPrice(fib50)}.`);
      }
    }
    const entry = brokerFilled ? brokerFilled.executionPrice ?? brokerFilled.entry : chartFilled!.entry;
    const stop = brokerFilled?.stopLoss ?? chartFilled!.stopLoss;
    const target = brokerFilled?.takeProfit ?? chartFilled!.takeProfit;
    narrative.push(`The recorded entry price is ${formatPrice(entry)}, with a stop loss at ${formatPrice(stop)} and a take profit at ${formatPrice(target)}.`);
    const closed = brokerFilled && (brokerFilled.closedAt ?? brokerFilled.updatedAt) <= now
      && ['TP', 'SL', 'RF', 'CANCELLED'].includes(brokerFilled.status);
    const result = brokerFilled ? closed ? brokerFilled.status : 'ACTIVE'
      : chartFilled!.resolvedAt !== undefined && chartFilled!.resolvedAt > now ? 'active' : chartFilled!.status;
    if (result === 'TP' || result === 'tp-hit') narrative.push(`This ${source} reached its take profit${brokerFilled ? brokerFilled.closePrice !== undefined ? ` and closed at ${formatPrice(brokerFilled.closePrice)}` : '' : ` at ${formatPrice(target)}`}.`);
    else if (result === 'SL' || result === 'sl-hit') narrative.push(`This ${source} hit its stop loss${brokerFilled ? brokerFilled.closePrice !== undefined ? ` and closed at ${formatPrice(brokerFilled.closePrice)}` : '' : ` at ${formatPrice(stop)}`}.`);
    else if (result === 'RF' || result === 'risk-free' && chartFilled?.result === 'rf') narrative.push(`This ${source} has closed with a recorded risk-free result.`);
    else if (brokerFilled?.status === 'RISK_FREE' || result === 'risk-free') narrative.push(`This ${source} reached its risk-free stage and is still open.`);
    else if (closed) narrative.push(`This ${source} has closed${brokerFilled?.closePrice !== undefined ? ` at ${formatPrice(brokerFilled.closePrice)}` : ''}. Its record does not confirm a stop-loss or take-profit result.`);
    else narrative.push(`This ${source} is still open.`);
    if (brokerFilled) narrative.push('This zone has already provided an MT5 entry, so another entry from the same zone is blocked.');
    else if (!options.replay) narrative.push('This is a chart record. It does not confirm that an order opened in MT5.');
    return { heading: 'What happened to this entry?', narrative };
  }
  if (fib.length) narrative.push(entries.some(entry => entry.reason === 'A+ FIB ALIGNMENT')
    ? `The chart shows ${fib.join(' and ')} alignment, but this entry route has not yet confirmed the required numerical Fib conditions.`
    : `This zone has ${fib.join(' and ')} alignment. ${fib.length === 1 ? 'That alignment condition has' : 'Those alignment conditions have'} passed.`);
  if (options.barsAgo !== undefined && Number.isFinite(options.barsAgo) && zone.tapTime !== undefined && zone.tapTime <= now) {
    const windowRule = (options.symbol ?? 'XAUUSD') === 'XAUUSD'
      ? 'Each new tap restarts the table window: 50 bars for Tap 1 and 10 bars for Tap 2 and later taps.'
      : "Each new tap restarts the table's 50-bar window.";
    narrative.push(`Price last touched this zone ${options.barsAgo} ${options.barsAgo === 1 ? 'bar' : 'bars'} ago. ${windowRule} Touching the zone alone does not open a trade.`);
  }
  const signal = options.evidence.signal;
  if (signal && signal.time + TIMEFRAME_SECONDS[signal.timeframe] <= now) {
    narrative.push(`A completed ${signal.type} ${side} engulfing has qualified on the ${formatTradeTimeframe(signal.timeframe)} chart. The remaining entry checks still need to pass before an order can open.`);
  }
  if (broker && ['QUEUED', 'CLAIMED', 'PLACED'].includes(broker.status)) narrative.push('The entry has been sent for processing, but an MT5 fill has not been confirmed yet.');
  const plain: Record<string, string> = {
    'A+ FIB ALIGNMENT': 'The required A+ Fib alignment is still missing. An engulfing on its own cannot give an entry while this condition is missing.',
    'ENGULFING': `No completed ${side} engulfing has qualified here yet. We are waiting for a qualifying pattern while this zone remains eligible.`,
    'FIB 0.5 TOUCH': `An engulfing appeared, but its candles did not touch the required Fib 0.5 level${zone.fibLevel50 !== undefined ? ` at ${formatPrice(zone.fibLevel50)}` : ''}. That is why this pattern did not give an entry. A new engulfing must touch that level and meet the other conditions while the zone remains valid.`,
    'OPPORTUNITY EXPIRED': 'Price has already moved far enough away from this zone to reach its allowed entry limit. Entry from this opportunity is now blocked. Another engulfing alone will not remove that block.',
    'ENTRY MISSED': 'This setup met the required entry conditions, but the trade did not open within the allowed time. That entry was missed. We will not open a late trade or take another entry from this same zone.',
    'CANDLE CLOSE': `A possible ${side} engulfing is forming, but its last candle is still open. We need to wait for that candle to close before it can confirm an entry.`,
  };
  for (const entry of entries) {
    const confirmation = entry.reason.match(/^(.*?) CLOSE (ABOVE|BELOW)$/);
    if (confirmation) narrative.push(`This ${timeframeName} CHoCH is still waiting for confirmation from the ${confirmation[1]} candle. That candle must close ${confirmation[2].toLowerCase()} the required confirmation level. Moving past the level before the candle closes is not enough.`);
    else narrative.push(plain[entry.reason] ?? entry.detail.replace(/\n\nCheck details: /g, '\n\n'));
  }
  if (!entries.length) narrative.push('The available entry checks have passed. The broker must still accept the order after the final live price and risk checks.');
  return { heading: 'What is happening at this zone?', narrative };
}

/** Display wording only: the entry checks remain the source of every reason. */
function entryReasonExplanation(reason: string, detail: string, zone: StructureZone,
  automation?: Mt5AutomationStatus): string {
  const explanations: Record<string, string> = {
    'OPPORTUNITY EXPIRED': 'Price has already moved far enough away from the zone to reach its allowed entry limit. The code now blocks entry from this opportunity. Another engulfing does not remove this expiry block.',
    'ENTRY MISSED': 'All required entry conditions passed, but the trade did not open within the allowed entry time. That entry was missed. The code will not chase the price or allow another entry from this same zone.',
    'SIGNAL EXPIRED': 'The signal is older than the allowed execution time. The code will not open a late trade using this signal. A fully qualified missed entry cannot be replaced by another entry from the same zone.',
    'ZONE INVALIDATED': 'This zone no longer meets the structure rules for a valid entry. A new engulfing cannot make this invalid zone usable. A different valid setup is needed.',
    'ZONE ALREADY USED': 'The entry checks have marked this zone as already used. Another trade from the same zone is blocked. A visible candle pattern alone does not count as a valid entry.',
    'HIGHER EXTREME A+ ZONE': 'Another qualifying A+ zone is farther out at the structure extreme and has priority. This zone is blocked by that selection rule; an engulfing here alone cannot allow entry.',
    'HTF CONFIRMATION ROUTE': 'The higher-timeframe confirmation route for this zone is disabled. This route cannot open a trade while that restriction applies.',
    'STRUCTURE NOT TRADEABLE': 'This zone has not met the structure and CHoCH classification rules needed for entry. Fib alignment or an engulfing alone is not enough to qualify it.',
    'A+ FIB ALIGNMENT': 'This zone does not currently have a qualifying A+ Fib alignment. The code needs an approved numerical Fib alignment for this entry route. An engulfing alone cannot trigger entry while this requirement is missing.',
    'FIB 0.5 TOUCH': `An engulfing is visible, but its candles did not touch the required Fib 0.5 level${zone.fibLevel50 === undefined ? '' : ` at ${formatPrice(zone.fibLevel50)}`}. This pattern cannot give an entry. While the zone remains valid and within its entry limits, a new engulfing can qualify if it touches that level and passes the other conditions.`,
    'FIB 0.5 DATA': 'The code cannot verify the required Fib 0.5 price yet. It must have that price before it can check whether the engulfing touched it. Entry stays paused until the data is available and the conditions pass.',
    'ZONE TOUCH': `No completed candle has revisited this zone after it became active. Price must return to the zone at ${formatPrice(zone.bottom)}–${formatPrice(zone.top)}, and the required entry pattern must also qualify. Touching the zone by itself does not open a trade.`,
    'ENGULFING': `No completed ${zone.isBuy ? 'bullish' : 'bearish'} engulfing pattern has qualified at this zone. The code is waiting for an approved pattern in the required direction. It must also pass the applicable Fib and other entry conditions.`,
    'QUALIFYING ENGULFING': 'A candle pattern is visible, but it has not passed the strategy checks for entry. Seeing an engulfing on the chart does not mean a trade is ready. Entry remains paused while the required checks are incomplete.',
    'QUALIFYING ENTRY SIGNAL': 'There is no fully qualified entry signal yet. The zone can remain available while its validity and entry limits hold, but all required conditions must pass before a trade can open.',
    'CANDLE CLOSE': 'The candle forming the observed engulfing is still open. Its shape can change before it closes, so it cannot confirm entry yet. The code will check it again after it closes.',
    'CANDLE DATA': 'The code does not have the source candles needed to check this setup. It must receive usable candle data before it can confirm a pattern or allow entry.',
    'TRADING HOURS': 'This entry falls outside the enabled trading hours. The setup must form and execute inside the allowed hours. An old outside-hours pattern will not automatically become an entry when the session opens.',
    'VOLUME DATA': 'The candle volume needed for this entry rule is missing. The code cannot confirm the required volume relationship, so entry stays paused until it can verify the data.',
    'VOLUME CONFIRMATION': 'The engulfing did not pass its required candle-volume comparison. This pattern cannot give an entry. A later pattern must meet the volume rule and all other conditions while the zone remains eligible.',
    'NO M1 VOLUME RULE': 'This one-minute pattern has no approved volume rule for entry. The code therefore blocks this pattern instead of assuming that its volume is acceptable.',
    '15M + 1H TREND ALIGNMENT': 'The 15-minute and 1-hour trends do not currently meet the direction rule for this trade. Entry remains paused while that trend condition fails. Passing Fib and engulfing checks alone is not enough.',
    'TREND ALIGNMENT': 'The current trends do not meet this entry route’s direction rule. The code is waiting for the required trend agreement. All other conditions must still pass before entry can become possible.',
    'OPPOSING ZONE CLEARANCE': 'A qualifying zone in the opposite direction is too close to the planned entry. There is not enough room to reach the required 1:1 reward compared with the stop-loss distance. Entry is paused while this obstacle remains.',
    'VOLATILITY TO SETTLE': 'A recent one-minute candle is unusually large compared with normal candles and the planned stop distance. The fast-move check is pausing entry. The setup must pass this check and the other entry rules before execution.',
    'NEW 15M CHoCH AFTER SL': 'An earlier trade in this price area hit its stop loss. The code needs a new completed 15-minute CHoCH in the required direction before another setup in this area can qualify. Another engulfing alone is not enough.',
    'ENTRY PRICE': 'The setup has a planned entry price, but price has not filled that entry yet. The code waits for the planned price while the order and setup remain valid. It does not assume that seeing the signal means a trade has opened.',
    'ENTRY CANDLE / PRICE': 'A qualified pattern has been found, but the available candles and entry price have not produced a usable trade yet. The code must verify the entry before sending an order; this message does not mean that a trade is already open.',
    'CANDLE TIME SYNCHRONIZATION': 'The signal time is ahead of the current verified time. The candle feeds must line up before the code can safely treat this as a completed entry signal.',
    'MT5 STATUS': 'The dashboard is waiting for the MT5 status. It needs to check the connection, account and execution conditions before it can say that automatic entry is ready.',
    'AUTO ENTRY OFF': 'Automatic entry is switched off. The chart can still show zones and patterns, but this setting prevents the code from opening a trade. Turning it on does not make an old missed signal eligible again.',
    'STRATEGY': 'This entry strategy is switched off in the MT5 settings. It cannot open a trade while disabled. Enabling it still requires a currently eligible setup that passes every entry check.',
    'TIMEFRAME': 'The timeframe required by this entry route is disabled in the MT5 settings. Entry from this route stays disabled until the required timeframe is enabled and a valid setup qualifies.',
    'MT5 CONNECTION': 'The dashboard does not have a working connection to the MT5 terminal. It cannot send this trade until the connection is restored and the live entry checks pass. A signal that expires in the meantime is not chased.',
    'BROKER SYMBOL SELECTION': 'MT5 has not confirmed the correct broker symbol for this market. The code must identify and select that symbol before it can send an order.',
    'FRESH MT5 DATA': 'The latest broker data is missing or too old. Entry is paused because the code cannot verify the current market conditions. Fresh MT5 data is required before execution can be checked again.',
    'DAILY RISK DATA': 'The code cannot verify how much daily risk is still available on this account. New entries stay paused until MT5 supplies usable risk information.',
    'DAILY RISK LIMIT': 'The account has no usable daily risk allowance left for a new entry. This can include losses and risk already reserved by existing trades. A valid chart setup cannot override the account’s risk limit.',
    'EXISTING POSITION STOP LOSS': 'An existing automated position has no usable stop loss, so its risk cannot be measured. New entries stay paused until that risk can be verified.',
    'OPEN TRADE LIMIT': `The account has reached its configured limit${automation ? ` of ${automation.config.maximumOpenTrades} open trade${automation.config.maximumOpenTrades === 1 ? '' : 's'}` : ''}. Another trade cannot open while this limit is reached. A space becoming available does not allow an already missed entry to be reused.`,
    'NEWS CALENDAR DATA': 'The news calendar could not be verified. The code pauses automatic entry because it cannot check whether an important news event is too close. It needs usable calendar data before this check can pass.',
    'NEWS WINDOW': 'Automatic entry is paused around a high-impact US-dollar news event. The pause must end before an eligible trade can open. A signal that has already expired is not automatically reused after the pause.',
    'LIVE ORDERS OFF': 'MT5 is in simulation mode. The code can show and test signals, but this setting prevents real orders from being placed.',
  };
  const explanation = reason.match(/CLOSE (ABOVE|BELOW)$/)
    ? `The ${reason.replace(/ CLOSE .*$/, '')} candle has not yet confirmed the required close ${zone.isBuy ? 'above' : 'below'} the CHoCH confirmation level. Moving past the level while that candle is still open is not enough. Confirmation stays pending until a completed candle meets the rule.`
    : explanations[reason];
  if (!explanation) return `${detail}\n\nThe execution check has not passed. Entry remains paused while this condition applies; the setup must still pass all other entry checks.`;
  return detail !== reason && !explanation.includes(detail) ? `${explanation}\n\nCheck details: ${detail}` : explanation;
}

/** Read-only explanation of the same setup and execution gates; never creates an order. */
export function explainZoneEntry(options: {
  zone: StructureZone; timeframe: OandaGranularity; evidence: ZoneEntryEvidence;
  confirmationLabel: string; trade?: TradeLevels; decision?: DirectZoneEntryDecision;
  opportunityExpired?: boolean; zoneUsed?: boolean; extremeBlocked?: boolean;
  outsideHours?: boolean; countertrendBlocked?: boolean; replay?: boolean;
  automationSupported?: boolean; automation?: Mt5AutomationStatus; now: number;
  scalping?: boolean; symbol?: string;
  barsAgo?: number; recordedTrade?: TradeLevels; brokerSignal?: Mt5StoredSignal;
}): ZoneEntryReadiness {
  const { zone, timeframe, evidence, trade, decision } = options;
  const entries: Array<{ mode: ZoneEntryReadiness['mode']; reason: string; detail: string }> = [];
  const add = (mode: ZoneEntryReadiness['mode'], reason: string, detail = reason) => {
    if (!entries.some(entry => entry.reason === reason)) entries.push({ mode, reason,
      detail: entryReasonExplanation(reason, detail, zone, options.automation) });
  };
  if (!zone.active || ['invalidated', 'rejected', 'superseded'].includes(zone.status)) {
    add('BLOCKED', 'ZONE INVALIDATED', `Zone status: ${zone.status}.`);
  }
  if (options.zoneUsed || decision?.policy.reason === 'zone-used') add('BLOCKED', 'ZONE ALREADY USED');
  if (options.opportunityExpired) add('BLOCKED', 'OPPORTUNITY EXPIRED', 'The allowed move away from this zone has already been reached.');
  if (options.extremeBlocked) add('BLOCKED', 'HIGHER EXTREME A+ ZONE');
  if (zone.confirmationRouteDisabled) add('DISABLED', 'HTF CONFIRMATION ROUTE');
  if (zone.status === 'pending' || zone.chochClass === 'pending' || zone.m15H1ChochClosePending
    || zone.doubleChochStatus === 'pending') {
    add('WAIT', `${options.confirmationLabel} CLOSE ${zone.isBuy ? 'ABOVE' : 'BELOW'}`,
      'A completed higher-timeframe candle must satisfy the confirmation rule; a forming candle cannot confirm it.');
  } else if (!isZoneEligibleForEngulfingEntry(zone)) {
    add('BLOCKED', 'STRUCTURE NOT TRADEABLE', 'This structure does not meet its CHoCH entry classification rules.');
  }
  for (let i = 0; i < evidence.waiting.length; i++) add('WAIT', evidence.waiting[i], evidence.details[i] ?? evidence.waiting[i]);
  const signal = trade?.signal ?? evidence.signal;
  if (options.outsideHours || decision?.policy.reason === 'outside-trading-time') {
    add('WAIT', 'TRADING HOURS', 'Entry must form and execute inside the enabled trading hours. An old outside-hours signal is not automatically reused.');
  }
  if (decision?.policy.reason === 'volume-unavailable') add('WAIT', 'VOLUME DATA');
  if (decision?.policy.reason === 'volume-failed') add('WAIT', 'VOLUME CONFIRMATION', 'The native M1 volume relationship failed; a fresh qualifying signal is required.');
  if (decision?.policy.reason === 'volume-not-applicable') add('BLOCKED', 'NO M1 VOLUME RULE', 'This pattern has no approved native M1 volume entry rule.');
  if (options.countertrendBlocked) add('WAIT', '15M + 1H TREND ALIGNMENT');
  if (decision?.opposingZoneBlock) add('WAIT', 'OPPOSING ZONE CLEARANCE', goldOpposingZoneBlockLabel(decision.opposingZoneBlock));
  if (trade?.status === 'pending') add('WAIT', 'ENTRY PRICE', `The planned entry at ${formatPrice(trade.entry)} has not filled.`);
  if (signal && !trade && decision?.policy.allowed && !decision.opposingZoneBlock) {
    add('WAIT', 'ENTRY CANDLE / PRICE', 'The qualified signal has not produced a currently usable entry. Waiting for executable candle data or a fresh setup.');
  }
  if (!options.replay && options.automationSupported) {
    const status = options.automation;
    if (!status) add('WAIT', 'MT5 STATUS');
    else {
      if (findMissedZoneEntry({ symbol: options.symbol ?? 'XAUUSD', zoneTimeframe: timeframe as TradeTimeframe,
        zoneId: zone.id }, status.missedEntries ?? status.recentSignals, status.bridge)) {
        add('BLOCKED', 'ENTRY MISSED', 'A fully qualified entry was missed. This zone cannot produce another entry.');
      }
      if (!status.config.enabled) add('DISABLED', 'AUTO ENTRY OFF');
      const disabled = mt5SignalDisabledReason(status.config, {
        zoneTimeframe: timeframe as TradeTimeframe, signalTimeframe: signal?.timeframe ?? timeframe as TradeTimeframe,
        tradeStyle: options.scalping ? 'SCALPING' : 'INTRADAY', source: 'ENGULFING',
      });
      if (disabled) add('DISABLED', disabled.includes('Scalping') || disabled.includes('Intraday') ? 'STRATEGY' : 'TIMEFRAME', disabled);
      if (signal) {
        const key = tradeZoneExecutionKey({ symbol: options.symbol ?? 'XAUUSD', zoneTimeframe: timeframe, zoneId: zone.id });
        const check = status.entryChecks?.find(item => item.account === status.bridge.account
          && item.server === status.bridge.server && item.brokerSymbol === status.bridge.brokerSymbol
          && item.symbol === (options.symbol ?? 'XAUUSD') && item.signalAt === signal.time
          && item.direction === (signal.direction === 'bullish' ? 'BUY' : 'SELL')
          && options.now - item.checkedAt >= 0 && options.now - item.checkedAt <= 30
          && key !== undefined && tradeZoneExecutionKey(item) === key);
        for (const reason of check?.reasons ?? []) add(check!.mode, reason);
      }
      if (!status.bridge.connected || status.bridge.terminalConnected === false) add('WAIT', 'MT5 CONNECTION');
      else {
        if (status.bridge.symbolResolved === false) add('WAIT', 'BROKER SYMBOL SELECTION');
        if (!status.marketData?.fresh) add('WAIT', 'FRESH MT5 DATA');
        const risk = status.bridge.dailyRisk;
        if (!risk || risk.available === false) add('WAIT', 'DAILY RISK DATA', risk?.available === false ? risk.error : 'Waiting for MT5 daily risk verification.');
        else if (risk.limitReached || risk.usedMoney >= risk.limitMoney || risk.availableRiskMoney <= 1e-8) add('BLOCKED', 'DAILY RISK LIMIT');
        else if (risk.riskUnbounded) add('WAIT', 'EXISTING POSITION STOP LOSS', 'Daily entry risk cannot be verified while an existing automated trade has no stop loss.');
        if (status.positions.filter(position => position.symbol === status.bridge.brokerSymbol).length >= status.config.maximumOpenTrades) {
          add('WAIT', 'OPEN TRADE LIMIT');
        }
        const news = status.newsCalendar;
        if (news?.available === false) add('WAIT', 'NEWS CALENDAR DATA', news.error ?? 'The automatic scanner pauses while the news calendar is unavailable.');
        else if (news?.pausedUntil !== undefined && news.pausedUntil > options.now) add('WAIT', 'NEWS WINDOW', 'Automatic entries are paused around a high-impact USD event.');
      }
      if (status.config.dryRun) add('SIMULATION', 'LIVE ORDERS OFF');
    }
  }
  // Readiness requires a strategy-qualified signal, not merely a visible candle pattern.
  if (!signal && !entries.some(entry => entry.mode === 'WAIT' || entry.mode === 'BLOCKED')) add('WAIT', 'QUALIFYING ENTRY SIGNAL');
  const priority = { BLOCKED: 0, DISABLED: 1, WAIT: 2, SIMULATION: 3, READY: 4 };
  entries.sort((a, b) => priority[a.mode] - priority[b.mode]);
  const story = zoneEntryStory(options, entries);
  if (!entries.length) return { mode: 'READY', label: 'ENTRY READY', reasons: [],
    ...story,
    title: 'Chart conditions and the available execution checks pass. Broker acceptance and live price/risk checks still occur when the order is sent.' };
  const first = entries[0];
  const sameMode = entries.filter(entry => entry.mode === first.mode);
  const text = sameMode.slice(0, 2).map(entry => entry.reason).join(' · ');
  const shown = text.length > 85 ? `${text.slice(0, 82)}…` : text;
  const hidden = entries.length - Math.min(2, sameMode.length);
  return { mode: first.mode, label: `${first.mode} — ${shown}${hidden > 0 ? ` · +${hidden}` : ''}`,
    ...story,
    title: entries.map(entry => `${entry.mode} — ${entry.reason}: ${entry.detail}`).join('\n'),
    context: `${displayZoneName(zone.name, zone.oneMinuteGenesisQml)} · ${formatTradeTimeframe(timeframe as TradeTimeframe)} · ${zone.isBuy ? 'BUY' : 'SELL'} · ${formatPrice(zone.bottom)}–${formatPrice(zone.top)}`,
    explanations: entries.map(({ reason, detail }) => ({ reason, detail })),
    reasons: entries.map(entry => entry.reason) };
}

export const ZoneEntryReasonDetails: React.FC<{ readiness: ZoneEntryReadiness }> = ({ readiness }) => (
  <div className="space-y-3 text-left text-[11px] font-normal leading-relaxed normal-case text-slate-700">
    <div>
      <div className="font-semibold text-slate-900">{readiness.heading ?? 'Entry details'}</div>
      {readiness.context && <div className="mt-1 text-[10px] text-slate-500">{readiness.context}</div>}
    </div>
    {readiness.narrative?.length ? readiness.narrative.map((paragraph, index) => <p key={index} className="whitespace-pre-line">{paragraph}</p>) : readiness.explanations?.length ? readiness.explanations.map((entry, index) => (
      <div key={entry.reason}>
        <div className="mb-1 font-semibold text-slate-900">{index + 1}. {entry.reason}</div>
        <div className="whitespace-pre-line">{entry.detail}</div>
      </div>
    )) : <div className="whitespace-pre-line">{readiness.title}</div>}
  </div>
);

/** Compact chart wording only; never used to decide whether an order may execute. */
export function compactZoneTableStatus(readiness: ZoneEntryReadiness, barsAgo?: number, tradeable = true): string {
  const confirmation = readiness.reasons.find(reason => / CLOSE (ABOVE|BELOW)$/.test(reason));
  if (confirmation && readiness.mode !== 'BLOCKED') return `WAIT ${confirmation.replace(' CLOSE ', ' ')}`;
  if (readiness.reasons.includes('ENTRY MISSED')) return 'ENTRY MISSED';
  const permitted = tradeable && readiness.mode !== 'BLOCKED'
    && !readiness.reasons.includes('TRADING HOURS');
  const age = barsAgo !== undefined && Number.isFinite(barsAgo) ? `${Math.max(0, barsAgo)} ${barsAgo === 1 ? 'bar' : 'bars'} · ` : '';
  return `${age}${permitted ? 'TRADE' : 'NO TRADE'}`;
}

export const ZoneEntryReadinessText: React.FC<{
  readiness: ZoneEntryReadiness; compactLabel?: React.ReactNode;
}> = ({ readiness, compactLabel }) => {
  const compactColor = typeof compactLabel !== 'string' ? undefined
    : compactLabel === 'SL HIT' || compactLabel === 'ENTRY MISSED' || compactLabel.includes('NO TRADE') ? 'text-rose-700'
    : compactLabel === 'TP HIT' || compactLabel.endsWith('TRADE') ? 'text-emerald-700'
    : compactLabel.startsWith('WAIT ') ? 'text-amber-700' : undefined;
  const anchor = useRef<HTMLSpanElement>(null);
  const tooltip = useRef<HTMLDivElement>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const tooltipId = React.useId();
  const [position, setPosition] = useState<{ left: number; top: number; width: number; maxHeight: number }>();
  const keepOpen = () => { clearTimeout(closeTimer.current); };
  const closeSoon = () => { keepOpen(); closeTimer.current = setTimeout(() => setPosition(undefined), 180); };
  const place = useCallback(() => {
    const rect = anchor.current?.getBoundingClientRect();
    if (!rect) return;
    const gap = 8;
    const width = Math.min(380, window.innerWidth - 2 * gap);
    const below = window.innerHeight - rect.bottom - 2 * gap;
    const above = rect.top - 2 * gap;
    const useBelow = below >= Math.min(320, above);
    const maxHeight = Math.max(40, Math.min(400, useBelow ? below : above));
    setPosition({ left: Math.max(gap, Math.min(rect.right - width, window.innerWidth - width - gap)),
      top: useBelow ? rect.bottom + gap : Math.max(gap, rect.top - gap - maxHeight), width, maxHeight });
  }, []);
  useEffect(() => {
    if (!position) return;
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') setPosition(undefined); };
    const outsideClick = (event: PointerEvent) => {
      if (event.target instanceof Node && !anchor.current?.contains(event.target)
        && !tooltip.current?.contains(event.target)) setPosition(undefined);
    };
    const scroll = (event: Event) => {
      if (!(event.target instanceof Node && tooltip.current?.contains(event.target))) place();
    };
    window.addEventListener('resize', place);
    window.addEventListener('keydown', escape);
    window.addEventListener('pointerdown', outsideClick);
    window.addEventListener('scroll', scroll, true);
    return () => {
      window.removeEventListener('resize', place); window.removeEventListener('keydown', escape);
      window.removeEventListener('pointerdown', outsideClick); window.removeEventListener('scroll', scroll, true);
    };
  }, [!!position, place]);
  useEffect(() => () => clearTimeout(closeTimer.current), []);
  return <>
  <span ref={anchor} role="status" tabIndex={0} aria-label={`${typeof compactLabel === 'string' ? compactLabel : readiness.label}. Hover or focus for all entry reasons.`}
    aria-describedby={position ? tooltipId : undefined}
    onMouseEnter={() => { keepOpen(); place(); }} onMouseLeave={closeSoon}
    onFocus={() => { keepOpen(); place(); }} onBlur={closeSoon}
    onClick={() => { keepOpen(); place(); }}
    className={`inline-block max-w-[260px] cursor-help whitespace-normal text-right outline-offset-2 ${
    compactColor ?? (readiness.mode === 'READY' ? 'text-emerald-700' : readiness.mode === 'BLOCKED' ? 'text-rose-700'
      : readiness.mode === 'DISABLED' || readiness.mode === 'SIMULATION' ? 'text-slate-600' : 'text-amber-700'
    )}`}>{compactLabel ?? readiness.label}</span>
  {position && createPortal(<div ref={tooltip} id={tooltipId} role="tooltip" onMouseEnter={keepOpen} onMouseLeave={closeSoon}
    className="fixed z-[10000] overflow-y-auto overscroll-contain rounded-lg border border-slate-200 bg-white p-3 shadow-xl"
    style={position}>
    {compactLabel !== undefined && readiness.heading !== 'What happened to this entry?' && <div className="mb-3 text-[11px] font-normal leading-relaxed text-slate-600">
      The table shows the chart status. “TRADE” does not mean an MT5 order has opened. The entry checks below still apply.
    </div>}
    <ZoneEntryReasonDetails readiness={readiness} />
  </div>, document.body)}
  </>;
};

function displayFibLabel(zone: StructureZone): string {
  if (zone.fibBand === 'deep') {
    return 'FIB DEEP DISCOUNT';
  }
  return `A+ FIB ${zone.fibBand}`;
}

function tradeZoneFibLabels(zone: StructureZone): string[] {
  const labels: string[] = [];
  if (zone.fibStatus === 'a-plus' && zone.fibBand && zone.fibBand !== 'DB/DT') {
    labels.push(displayFibLabel(zone));
  }
  if (zone.swingFibStatus === 'a-plus' && zone.swingFibBand) {
    labels.push(`SWING A+ FIB ${zone.swingFibBand}`);
  }
  if (zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand) {
    labels.push(`1H SWING FIB ALIGNED ${zone.h1SwingFibBand}`);
  }
  if (zone.dayFibStatus === 'a-plus' && zone.dayFibBand) {
    labels.push(`DAY FIB A+ ${zone.dayFibBand}`);
  }
  return labels;
}

function formatZonePips(pips: number): string {
  return zonePipsFormatter.format(pips);
}

function measureListedZone(zone: StructureZone, pipSize: number) {
  const qualifiedMeasurement = measureTradeableFibZone(zone, pipSize);
  if (qualifiedMeasurement) return qualifiedMeasurement;
  const width = Math.abs(zone.top - zone.bottom);
  if (!Number.isFinite(width) || width === 0 || !Number.isFinite(pipSize) || pipSize <= 0) {
    return undefined;
  }
  return {
    pips: Math.round((width / pipSize) * 100) / 100,
    midline: (zone.top + zone.bottom) / 2,
  };
}

export function displayEngulfingLabel(zone: StructureZone, chartTimeframe?: TradeTimeframe): string | undefined {
  if (chartTimeframe === 'H1') {
    const signal = resolveZoneEngulfingSignal(zone, chartTimeframe);
    return signal && isGoldIntradayCandleRoute('H1', signal.timeframe)
      ? `${formatTradeTimeframe(signal.timeframe)} ${signal.type} ${zone.isBuy ? 'BULL' : 'BEAR'}`
      : undefined;
  }
  const labels = [
    isZoneEngulfingFibQualified(zone, 'structure') ? zone.engulfingType : undefined,
    isZoneEngulfingFibQualified(zone, 'swing') && zone.swingEngulfingType
      ? `SW ${zone.swingEngulfingType}` : undefined,
    isZoneEngulfingFibQualified(zone, 'h1Swing') && zone.h1SwingEngulfingType
      ? `1H SW ${zone.h1SwingEngulfingType}` : undefined,
    isZoneEngulfingFibQualified(zone, 'day') && zone.dayEngulfingType
      ? `DAY ${zone.dayEngulfingType}` : undefined,
  ].filter((label): label is string => label !== undefined);
  if (labels.length > 0) return `${labels.join(' / ')} ${zone.isBuy ? 'BULL' : 'BEAR'}`;
  return isZoneEngulfingFibQualified(zone, 'structure')
    && zone.fallbackEngulfingType && zone.fallbackEngulfingTimeframe
    ? `${formatTradeTimeframe(zone.fallbackEngulfingTimeframe)} ${zone.fallbackEngulfingType} ${zone.isBuy ? 'BULL' : 'BEAR'}`
    : undefined;
}

export function fibVisibilityKey(zone: StructureZone): FibVisibilityKey {
  if (zone.category === 'iss') return 'iss';
  if (zone.category === 'internal') {
    if (zone.doubleChochTime !== undefined || zone.doubleChochStatus !== undefined) return 'intDoubleChoch';
    if (zone.name === 'Internal TJL1') return 'intTjl1';
    if (zone.name === 'Internal TJL2') return 'intTjl2';
    return 'intChoch';
  }
  if (zone.doubleChochTime !== undefined || zone.doubleChochStatus !== undefined) return 'doubleChoch';
  if (zone.chochTime !== undefined || zone.chochClass !== undefined) return 'choch';
  if (zone.name === 'TJL1') return 'tjl1';
  if (zone.name === 'TJL2') return 'tjl2';
  return 'swing';
}

export function isFibMarkingVisible(
  zone: StructureZone,
  showFib: boolean,
  visibility: Record<FibVisibilityKey, boolean>,
  previousVisibility: Record<FibVisibilityKey, boolean>,
  chochVisibility: ChochFibVisibility,
): boolean {
  const key = fibVisibilityKey(zone);
  if (key === 'choch') return showFib && chochVisibility.some(Boolean);
  if (key === 'tjl1' || key === 'tjl2' || key === 'intTjl1' || key === 'intTjl2'
    || key === 'doubleChoch' || key === 'intDoubleChoch' || key === 'iss') {
    return showFib && visibility[key];
  }
  return showFib && (visibility[key] || previousVisibility[key]);
}

function formatCandleCountdown(secondsRemaining: number): string {
  const total = Math.max(0, Math.floor(secondsRemaining));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  return hours > 0
    ? `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
    : `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function candleCountdownSeconds(
  closesAt: number | undefined,
  granularity: OandaGranularity,
  nowSeconds: number,
): number {
  const duration = TIMEFRAME_SECONDS[granularity];
  if (closesAt === undefined) {
    const elapsedInCandle = ((nowSeconds % duration) + duration) % duration;
    return duration - elapsedInCandle;
  }
  if (closesAt > nowSeconds) return closesAt - nowSeconds;
  const elapsedAfterClose = nowSeconds - closesAt;
  return duration - (elapsedAfterClose % duration);
}

interface TrendTableRow {
  granularity: OandaGranularity;
  label: string;
  trend: ReturnType<typeof analyzeMarketStructure>['trend'];
  closesAt?: number;
}

const MultiTimeframeTrendTable: React.FC<{ rows: TrendTableRow[]; replayActive: boolean }> = ({
  rows,
  replayActive,
}) => {
  const [expanded, setExpanded] = useState(true);
  const [nowSeconds, setNowSeconds] = useState(() => Date.now() / 1000);

  useEffect(() => {
    if (!expanded || replayActive) return undefined;
    const updateClock = () => setNowSeconds(Date.now() / 1000);
    updateClock();
    const timer = window.setInterval(updateClock, 1000);
    return () => window.clearInterval(timer);
  }, [expanded, replayActive]);

  return (
    <div data-journal-exclude="true" className={`pointer-events-auto absolute bottom-3 right-3 sm:right-20 z-20 max-h-[calc(100%_-_24px)] max-w-[calc(100%_-_24px)] overflow-auto rounded-md border border-slate-300 bg-white/95 shadow-sm ${expanded ? 'w-[238px]' : 'w-auto'}`}>
      <div className="flex items-center justify-between gap-2 border-b border-slate-300 bg-slate-100 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-slate-600">
        <span>{expanded ? 'Trend table' : 'Trend table minimized'}</span>
        <button
          type="button"
          onClick={() => setExpanded((visible) => !visible)}
          className="rounded border border-slate-300 bg-white px-1 py-0.5 text-[7px] font-black text-slate-600 hover:bg-slate-200"
          title={expanded ? 'Minimize trend table' : 'Show trend table'}
        >
          {expanded ? '− MINIMIZE' : '+ SHOW TABLE'}
        </button>
      </div>
      {expanded && (
        <table className="w-full border-collapse text-center text-[9px]">
          <thead className="bg-slate-500 text-[8px] uppercase text-white">
            <tr>
              <th className="border-r border-slate-400 px-1 py-0.5 font-bold">Timeframe</th>
              <th className="border-r border-slate-400 px-1 py-0.5 font-bold">Trend</th>
              <th className="px-1 py-0.5 font-bold">Time left</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const isBullish = row.trend === 'bullish';
              const isBearish = row.trend === 'bearish';
              return (
                <tr key={row.granularity} className="border-t border-slate-300 text-slate-700">
                  <td className="border-r border-slate-300 px-1 py-0.5 font-medium">{row.label}</td>
                  <td className={`border-r border-slate-300 px-1 py-0.5 font-bold ${
                    isBullish ? 'text-emerald-600' : isBearish ? 'text-rose-600' : 'text-slate-500'
                  }`}>
                    {isBullish ? '▲ BULLISH' : isBearish ? '▼ BEARISH' : '— NEUTRAL'}
                  </td>
                  <td className="px-1 py-0.5 font-medium tabular-nums text-slate-600">
                    {replayActive
                      ? '—'
                      : formatCandleCountdown(candleCountdownSeconds(
                        row.closesAt,
                        row.granularity,
                        nowSeconds,
                      ))}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
};

const MTF_TABLE_LABELS: Record<MtfGranularity, string> = {
  M1: '1m', M5: '5m', M15: '15m', H1: '1H', H4: '4H', D: '1D',
};

function mtfZoneLabel(name: StructureZone['name'], majorLiquidity = false): string {
  const label = name.startsWith('Internal ') ? name.slice('Internal '.length) : name;
  return majorLiquidity ? `${label} · Major Liquidity` : label;
}

function mtfSignalLabel(row: DisplayMtfRow, trade: TradeLevels | undefined): string {
  if (row.opposingZoneBlock) return goldOpposingZoneBlockLabel(row.opposingZoneBlock);
  if ((row.chochSequence ?? 1) > 1) return mtfChochSequenceLabel(row.chochSequence!);
  if (row.sourcePairOverlapsHigherZone === false) {
    return 'CHOCH OBSERVED · SOURCE OUTSIDE ZONE · NO ENTRY';
  }
  if (row.tradingTimeBlocked) return trade
    ? `ENTRY ${formatPrice(trade.entry)} · OUTSIDE TRADING TIME · NO TRADE`
    : 'OUTSIDE TRADING TIME · NO TRADE';
  if (isCompletedTrade(trade)) return tradeStatusLabel(trade);
  if (!row.tappedZone) return 'Waiting for zone tap';
  if (!row.engulfingType) return 'Waiting';
  const type = row.engulfingType.replace('T', 'Type ');
  return `${row.goldScalping && trade ? 'SCALP ' : ''}${type} ${row.direction === 'bullish' ? 'BUY' : 'SELL'} ${
    trade ? 'MTF ENTRY' : 'CONFIRMED'
  }`;
}

type DisplayMtfRow = MtfRow & {
  setupId: string;
  trade?: TradeLevels;
  previewTrade?: TradeLevels;
  tradeBarsAgo?: number;
  tradingTimeBlocked?: boolean;
  opposingZoneBlock?: NonNullable<ReturnType<typeof goldOpposingZoneBeforeOneR>>;
};

/** Stored chart context is a snapshot, not proof that its source setup exists. */
export function validateRecordedMtfTrade(
  record: JournalTradeRecord,
  candles: readonly OandaCandle[] | undefined,
  qualify: (entry: Parameters<typeof getSavedMtfEntryQualification>[1]) => ReturnType<typeof getSavedMtfEntryQualification>,
): JournalTradeRecord | undefined {
  // An actual broker execution remains a fact even when chart feeds differ.
  if (record.mt5Managed || record.brokerTicket !== undefined) return record;
  if (record.signalAt === undefined
    || !candles?.some(candle => candle.time === record.signalAt && candle.complete !== false)
    || !tradeSignalMatchesCandles(record, candles)
    || !['T1', 'T2', 'T3', 'T4'].includes(record.engulfingType)) return undefined;
  const qualification = qualify({
    id: record.id.startsWith('MTF:') ? record.id
      : `${record.setupId}:${record.signalAt}:${record.entry}`,
    signalTime: record.signalAt, direction: record.direction,
    engulfingType: record.engulfingType as EngulfingTradeSignal['type'],
    zoneName: record.zoneName as StructureZone['name'],
    goldScalping: record.tradeStyle === 'SCALPING',
  });
  return qualification?.context ? { ...record, mtfContext: qualification.context } : undefined;
}

export function zoneTableMtfStatus(
  zones: readonly StructureZone[], timeframe: MtfRow['lowerTimeframe'],
  rows: readonly (MtfRow & { trade?: TradeLevels; tradingTimeBlocked?: boolean })[],
): { label: string; confirmed: boolean } | undefined {
  const matches = rows.filter(row => row.lowerTimeframe === timeframe
    && row.confirmationKind === 'choch' && row.sourcePairOverlapsHigherZone === true
    && (row.chochSequence ?? 1) === 1
    && zones.some(zone => zone.active && (zone.status === 'pending' || zone.status === 'valid')
      && zone.invalidatedAt === undefined && zone.supersededAt === undefined
      && zone.chochTime === row.confirmationTime
      && (zone.category === 'internal' ? 'internal' : 'external') === row.structureScope
      && zone.isBuy === (row.direction === 'bullish')
      && (row.entryZone ? row.entryZone.id === zone.id
        : row.tappedZone === zone.name && row.tapTime !== undefined
          && (row.tapTime === zone.tapTime || row.tapTime === zone.lastTapTime))));
  const confirmed = matches.find(row => row.trade && !row.trade.result
    && !row.tradingTimeBlocked && row.engulfingType !== undefined
    && row.engulfingTime !== undefined && row.entryZone !== undefined);
  if (confirmed) return {
    label: `MTF ENTRY CONFIRMED · ${confirmed.higherTimeframe} → ${confirmed.lowerTimeframe}`,
    confirmed: true,
  };
  const waiting = matches.find(row => !row.trade && !row.tradingTimeBlocked
    && row.engulfingType === undefined);
  return waiting ? { label: 'MTF SETUP · WAITING FOR ENTRY', confirmed: false } : undefined;
}

export function isSlTpTradeDisplayFinished(trade: { result?: string; status?: string } | undefined): boolean {
  return trade?.result === 'sl' || trade?.result === 'tp'
    || trade?.status === 'sl-hit' || trade?.status === 'tp-hit'
    || trade?.status === 'SL' || trade?.status === 'TP';
}

export function zoneTableCompletedStatus(
  trade: TradeDisplayState | undefined, mt5Signal?: TradeDisplayState,
): string | undefined {
  const completed = isSlTpTradeDisplayFinished(mt5Signal) ? mt5Signal : trade;
  if (!isSlTpTradeDisplayFinished(completed)) return undefined;
  return completed?.result === 'tp' || completed?.status === 'tp-hit' || completed?.status === 'TP'
    ? 'TP HIT' : 'SL HIT';
}

/** One pending confirmation level per CHoCH: bullish RBS or bearish SBR. */
export function selectChochStatusTableZones(
  zones: readonly DisplayStructureZone[], candles: readonly OandaCandle[],
  listedIds: ReadonlySet<string> = new Set(),
): DisplayStructureZone[] {
  const now = candles[candles.length - 1]?.time;
  if (now === undefined) return [];
  return zones.filter(zone => zone.active && (zone.status === 'valid' || zone.status === 'pending')
    && zone.chochClass === 'pending' && zone.chochTime !== undefined && zone.chochTime <= now
    && (zone.isBuy ? zone.name === 'RBS' || zone.name === 'Internal RBS'
      : zone.name === 'SBR' || zone.name === 'Internal SBR')
    && zone.doubleChochStatus === undefined
    && !displayZoneMembers(zone).some(member => listedIds.has(member.id)))
    .sort((a, b) => b.chochTime! - a.chochTime! || a.id.localeCompare(b.id))
    .filter((zone, index, ordered) => ordered.findIndex(candidate => (
      candidate.chochTime === zone.chochTime && candidate.isBuy === zone.isBuy
      && candidate.category === zone.category
    )) === index)
    .slice(0, 8);
}

export const ChochStatusTableRow: React.FC<{
  zone: DisplayStructureZone; timeframe: OandaGranularity;
}> = ({ zone, timeframe }) => {
  if (zone.chochClass !== 'pending' || (zone.isBuy
    ? zone.name !== 'RBS' && zone.name !== 'Internal RBS'
    : zone.name !== 'SBR' && zone.name !== 'Internal SBR')) return null;
  const status = `WAIT ${TJL1_CONFIRMATION_LABELS[timeframe].toUpperCase()} ${zone.isBuy ? 'ABOVE' : 'BELOW'}`;
  const readiness = explainZoneEntry({ zone, timeframe, evidence: { waiting: [], details: [] },
    confirmationLabel: TJL1_CONFIRMATION_LABELS[timeframe].toUpperCase(), now: 0 });
  return <tr className="border-t border-slate-100 bg-violet-50/50 text-slate-700">
    <td className="px-2 py-1 font-black text-slate-800">
      CHoCH · {displayConfluenceZoneName(zone)}<ZoneSourceTimeframeLabel timeframe={timeframe} />
    </td>
    <td className={`px-2 py-1 font-bold ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
      {zone.isBuy ? 'BUY' : 'SELL'}
    </td>
    <td className="whitespace-nowrap px-2 py-1">{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</td>
    <td className="px-2 py-1 text-center text-slate-400">—</td>
    <td className="whitespace-nowrap px-2 py-1 text-right font-black text-violet-700">
      <ZoneEntryReadinessText readiness={readiness} compactLabel={status} />
    </td>
  </tr>;
};

export const ManualTradeTimeframeControl: React.FC<{
  position: Mt5AutomationStatus['positions'][number]; disabled?: boolean;
  onChange: (timeframe: string) => void;
}> = ({ position, disabled, onChange }) => (
  <label className="mt-2 block rounded border border-slate-200 bg-white p-2 text-[10px] text-slate-700">
    <span className="font-bold">Manual #{position.ticket} · {position.direction} {position.volume} lot</span>
    <span className="mt-1 block">Trade timeframe</span>
    <select aria-label={`Manual trade ${position.ticket} timeframe`}
      value={position.fibExitTimeframe ?? ''} disabled={disabled}
      onChange={event => onChange(event.target.value)}
      className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1 disabled:opacity-50">
      <option value="">Not set — Fib exits paused</option>
      {MT5_FIB_EXIT_TIMEFRAMES.map(timeframe => (
        <option key={timeframe} value={timeframe}>{ZONE_SOURCE_TIMEFRAME_LABELS[timeframe]}</option>
      ))}
    </select>
    <span className="mt-1 block text-[9px] text-slate-500">
      {position.fibExitTimeframe
        ? `Opposing Fib exits: ${ZONE_SOURCE_TIMEFRAME_LABELS[position.fibExitTimeframe]} and higher only.`
        : 'Select the timeframe used for this trade to enable opposing Fib exits.'}
      {' '}Broker SL and TP remain active.
    </span>
  </label>
);

export function ZoneTableEngulfingConfirmations({ confirmations }: { confirmations: readonly ZoneTableConfirmation[] }) {
  if (!confirmations.length) return null;
  return <span className="ml-1 inline-flex flex-wrap gap-1 align-middle text-[8px] font-semibold text-slate-500" aria-label="Additional engulfing confirmations">
    {confirmations.map(c => <span key={`${c.signal.timeframe}:${c.signal.type}`}
      title="Additional confirmation only. The original entry and trade result stay unchanged.">
      {formatTradeTimeframe(c.signal.timeframe as TradeTimeframe).toLowerCase()} {c.signal.type}
    </span>)}
  </span>;
}

const ZONE_SOURCE_TIMEFRAME_LABELS: Record<string, string> = {
  M1: '1m', M5: '5m', M15: '15m', M30: '30m', H1: '1Hr', H4: '4Hr', D: '1D', W: '1W', MO: '1Mo',
};

export function resolveZoneTableSourceTimeframe(options: {
  stored?: TradeTimeframe; recorded?: TradeTimeframe; setup?: TradeTimeframe; inferred?: readonly TradeTimeframe[];
}): TradeTimeframe | undefined {
  const explicit = options.stored ?? options.recorded ?? options.setup;
  if (explicit) return explicit;
  const unique = [...new Set(options.inferred ?? [])];
  return unique.length === 1 ? unique[0] : undefined;
}

export function ZoneSourceTimeframeLabel({ timeframe }: { timeframe?: string }) {
  const label = timeframe ? ZONE_SOURCE_TIMEFRAME_LABELS[timeframe] : undefined;
  return label ? <span className="ml-1 whitespace-nowrap align-baseline text-[7px] font-semibold normal-case text-slate-500"
    title="Zone source timeframe" aria-label={`Zone source timeframe: ${label}`}>{label}</span> : null;
}

export const ZoneTableEntryPrice: React.FC<{
  trade: TradeLevels; mt5Signal?: Mt5StoredSignal;
  zone?: Pick<StructureZone, 'bottom' | 'top'>; pipSize?: number;
}> = ({ trade, mt5Signal, zone, pipSize }) => {
  if (!zoneTableCompletedStatus(trade, mt5Signal)) return <>ENTRY {formatPrice(trade.entry)}</>;
  if (!zone || !Number.isFinite(zone.bottom) || !Number.isFinite(zone.top)) return <>—</>;
  const pips = pipSize !== undefined && Number.isFinite(pipSize) && pipSize > 0
    ? Math.abs(zone.top - zone.bottom) / pipSize : undefined;
  return <>
    <div>{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</div>
    {pips !== undefined && <div className="text-[8px] font-black text-slate-600">
      {formatZonePips(pips)} PIPS
    </div>}
  </>;
};

/** Reconcile display state with the same saved execution that supplies historical arrows. */
export function resolveZoneTableTrade(
  trade: TradeLevels | undefined, records: readonly JournalTradeRecord[], asOf: number,
  zoneIds: readonly string[] = [], zoneNames: readonly string[] = [],
): TradeLevels | undefined {
  if (!trade) return trade;
  // Feed recalculation changes the price suffix, while zone type and origin stay stable.
  const identities = new Set(zoneIds.map(tradeOverlayZoneOriginKey));
  const matches = records.filter(record => (record.result === 'sl' || record.result === 'tp')
    && record.completedAt <= asOf && record.signalAt === trade.signal.time
    && record.signalTimeframe === trade.signal.timeframe && record.direction === trade.signal.direction
    && record.engulfingType === trade.signal.type
    && (record.zoneId ? identities.has(tradeOverlayZoneOriginKey(record.zoneId))
      : zoneNames.includes(record.zoneName)
        || tradeOverlayExecutionKey(tradeDrawingFromRecord(record)) === tradeOverlayExecutionKey(trade)));
  const record = matches[0];
  if (!record || matches.some(candidate => candidate.result !== record.result)) return trade;
  return { ...trade, status: record.result === 'tp' ? 'tp-hit' : 'sl-hit',
    result: record.result as 'sl' | 'tp', resolvedAt: record.closedAt ?? record.completedAt };
}

export function mtfTableHitExpired(
  hitAt: number | undefined, candles: readonly OandaCandle[], asOf: number, timeframe: TradeTimeframe,
): boolean {
  if (hitAt === undefined || hitAt > asOf) return false;
  let bars = 0;
  for (const candle of candles) {
    if (candle.time > hitAt && candle.complete !== false
      && candle.time + TIMEFRAME_SECONDS[timeframe] <= asOf && ++bars >= 5) return true;
  }
  return false;
}

type TradeDisplayState = {
  status?: string; result?: string; resolvedAt?: number; closedAt?: number; completedAt?: number;
  partialClosedAt?: number; updatedAt?: number; signalTimeframe?: TradeTimeframe;
  signal?: { timeframe: TradeTimeframe; direction: 'bullish' | 'bearish'; time?: number };
  direction?: string; filledAt?: number; openedAt?: number; calculatedAt?: number; signalAt?: number;
  riskFree?: number; entry?: number; stopLoss?: number;
};

export function completedTradeLabel(
  trade: TradeDisplayState | undefined, candles: readonly OandaCandle[], asOf: number,
): string | undefined {
  if (!isSlTpTradeDisplayFinished(trade)) return undefined;
  const label = trade!.result === 'tp' || trade!.status === 'tp-hit' || trade!.status === 'TP'
    ? 'TP HIT' : 'SL HIT';
  const hitAt = trade!.resolvedAt ?? trade!.closedAt ?? trade!.completedAt ?? trade!.updatedAt;
  if (hitAt === undefined || hitAt > asOf || candles.length === 0) return label;
  // Count actual bars since the exit, not since the zone tap or entry.
  const bars = candles.filter(candle => candle.time > hitAt && candle.time <= asOf).length;
  return `${label} · ${bars} ${bars === 1 ? 'bar' : 'bars'} ago`;
}

export const CompletedTradeRow: React.FC<{
  name: string; trade: TradeDisplayState; candles: readonly OandaCandle[]; asOf: number; colSpan: number;
}> = ({ name, trade, candles, asOf, colSpan }) => (
  <tr className="border-t border-slate-200 bg-slate-50">
    <td className="px-2 py-1 font-black text-slate-700">{name}</td>
    <td colSpan={colSpan - 1} className={`whitespace-nowrap px-2 py-1 text-right font-black ${
      trade.result === 'tp' || trade.status === 'tp-hit' || trade.status === 'TP'
        ? 'text-emerald-700' : 'text-rose-700'
    }`}>
      {completedTradeLabel(trade, candles, asOf)}
    </td>
  </tr>
);

/** Display only: retain a hit for five completed candles of its entry timeframe. */
export function tradeDisplayExpired(
  trade: TradeDisplayState | undefined, candles: readonly OandaCandle[], asOf: number,
): boolean {
  if (!trade) return false;
  const timeframe = trade.signal?.timeframe ?? trade.signalTimeframe;
  if (!timeframe) return false;
  let hitAt: number | undefined;
  if (isSlTpTradeDisplayFinished(trade)) {
    hitAt = trade.resolvedAt ?? trade.closedAt ?? trade.completedAt ?? trade.updatedAt;
  } else if (trade.partialClosedAt !== undefined || trade.result === 'rf'
    || ['risk-free', 'RISK_FREE', 'RF'].includes(trade.status ?? '') || trade.result === 'risk-free') {
    hitAt = trade.partialClosedAt;
    if (hitAt === undefined) {
      const bullish = (trade.signal?.direction ?? trade.direction) === 'bullish' || trade.direction === 'BUY';
      const level = trade.riskFree ?? (trade.entry !== undefined && trade.stopLoss !== undefined
        ? trade.entry + (bullish ? 1 : -1) * Math.abs(trade.entry - trade.stopLoss) : undefined);
      hitAt = level === undefined ? undefined : candles.find(candle => (
        candle.time >= (trade.filledAt ?? trade.openedAt ?? trade.calculatedAt ?? trade.signalAt ?? Infinity)
        && candle.time <= asOf && (trade.resolvedAt === undefined || candle.time <= trade.resolvedAt)
        && (bullish ? candle.high >= level : candle.low <= level)
      ))?.time;
      hitAt ??= trade.resolvedAt ?? trade.closedAt ?? (trade.result === 'rf' ? trade.completedAt : undefined) ?? trade.updatedAt;
    }
  }
  return mtfTableHitExpired(hitAt, candles, asOf, timeframe);
}

/** Zone rows use tap age, independently of the five-candle drawing expiry. */
export function zoneTableTapBarLimit(tapCount = 1, symbol = 'XAUUSD'): number {
  return symbol === 'XAUUSD' && tapCount > 1 ? 10 : 50;
}

export function zoneTableTradeExpired(
  trade: TradeDisplayState | undefined, tapBarsAgo: number,
  candles: readonly OandaCandle[], asOf: number,
  tapCount = 1, symbol = 'XAUUSD',
): boolean {
  const limit = zoneTableTapBarLimit(tapCount, symbol);
  if (limit === 10 && tapBarsAgo > limit) return true;
  return isSlTpTradeDisplayFinished(trade) ? tapBarsAgo > limit : tradeDisplayExpired(trade, candles, asOf);
}

/** Drawings stay through partial RF; count five candles only after the final exit. */
export function tradeDrawingExpired(
  trade: TradeDisplayState | undefined, candles: readonly OandaCandle[], asOf: number,
): boolean {
  const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
  if (!trade || !timeframe) return false;
  // A final RF result means the remaining position closed at its stop after RF.
  // RISK_FREE/risk-free without a final result is still an open position.
  const closed = isSlTpTradeDisplayFinished(trade) || trade.result === 'rf' || trade.status === 'RF';
  if (!closed) return false;
  return mtfTableHitExpired(trade.resolvedAt ?? trade.closedAt ?? trade.completedAt ?? trade.updatedAt,
    candles, asOf, timeframe);
}

export function tradeDrawingFromRecord(record: JournalTradeRecord): TradeLevels & { partialClosedAt?: number } {
  const bullish = record.direction === 'bullish';
  return {
    entry: record.entry, stopLoss: record.stopLoss, takeProfit: record.takeProfit,
    riskFree: record.entry + (bullish ? 1 : -1) * Math.abs(record.entry - record.stopLoss),
    riskFreeEnabled: record.tradeStyle === 'SCALPING', riskPips: record.riskPips, rewardRisk: record.rewardRisk,
    status: record.result === 'tp' ? 'tp-hit' : record.result === 'sl' ? 'sl-hit' : 'risk-free',
    result: ['tp', 'sl', 'rf'].includes(record.result) ? record.result as 'tp' | 'sl' | 'rf' : undefined,
    resolvedAt: ['tp', 'sl', 'rf'].includes(record.result) ? record.closedAt ?? record.completedAt : undefined,
    partialClosedAt: record.partialClosedAt, filledAt: record.openedAt, pendingAtCreation: false,
    calculatedAt: (record.signalAt ?? record.openedAt ?? record.completedAt) + TIMEFRAME_SECONDS[record.signalTimeframe],
    signal: { type: record.engulfingType as EngulfingTradeSignal['type'], direction: record.direction,
      timeframe: record.signalTimeframe, time: record.signalAt ?? record.openedAt ?? record.completedAt,
      candleCount: record.engulfingCandleCount ?? (record.engulfingType === 'T1' ? 2 : 3) },
  };
}

export function reconcileSavedMtfTrade(
  record: JournalTradeRecord, candles: readonly OandaCandle[], asOf: number,
): { record: JournalTradeRecord; verified: boolean } {
  if (record.intradayEntry) return { record, verified: true }; // Layered replay owns its intrabar fill ordering.
  if (record.source !== 'MTF' || !['open', 'risk-free'].includes(record.result)) {
    return { record, verified: true };
  }
  // Broker executions are resolved by the existing MT5 journal lifecycle, never by chart prices.
  if (record.mt5Managed || record.brokerTicket !== undefined || record.mt5SignalId
    || record.id.startsWith('MT5:')) return { record, verified: false };
  const seconds = TIMEFRAME_SECONDS[record.signalTimeframe];
  const openedAt = record.openedAt;
  if (openedAt === undefined || openedAt > asOf) return { record, verified: false };
  const completed = candles.filter(candle => candle.complete !== false
    && candle.time + seconds <= asOf).sort((a, b) => a.time - b.time);
  const start = completed.findIndex(candle => candle.time <= openedAt && openedAt < candle.time + seconds);
  // An entry inside a candle needs finer data to separate pre-entry and post-entry extremes.
  if (start < 0 || completed[start].time !== openedAt) return { record, verified: false };
  const execution = completed.slice(start);
  // Missing history cannot establish the first exit or prove that a trade remained open.
  for (let i = 1; i < execution.length; i++) {
    if (execution[i].time !== execution[i - 1].time + seconds) {
      execution.length = i;
      break;
    }
  }
  const trade = resolveRetainedTrade({ ...tradeDrawingFromRecord(record),
    filledAt: execution[0].time }, execution);
  if (trade.result && trade.resolvedAt !== undefined) {
    const closedAt = trade.resolvedAt + seconds;
    return { verified: true, record: { ...record, result: trade.result,
      completedAt: closedAt, closedAt, lifecycleStatus: 'closed' } };
  }
  const fresh = execution[execution.length - 1].time + seconds >= asOf - seconds;
  return { record, verified: fresh };
}

// Reset only when content appears or disappears, preserving manual toggles between transitions.
function useAutoExpandedTable(hasContent: boolean): [boolean, () => void] {
  const [state, setState] = useState(() => ({ hasContent, expanded: hasContent }));
  if (state.hasContent !== hasContent) {
    setState({ hasContent, expanded: hasContent });
  }
  return [state.expanded, () => setState(current => ({ ...current, expanded: !current.expanded }))];
}

export const MultiTimeframeEntryTable: React.FC<{
  rows: DisplayMtfRow[];
  liveTrades: LiveMt5TableTrade[];
  records: JournalTradeRecord[];
  timeZone: ChartTimeZone;
  entryCandles: Partial<Record<TradeTimeframe, readonly OandaCandle[]>>;
  asOf: number;
  requiredTimeframes?: readonly TradeTimeframe[];
  candleErrors?: Partial<Record<TradeTimeframe, string>>;
  onRetry?: () => void;
  intradayPullbacks?: boolean;
  fillEvidence?: PullbackFillEvidence;
}> = ({ rows, liveTrades, records, timeZone, entryCandles, asOf,
  requiredTimeframes = [], candleErrors = {}, onRetry, intradayPullbacks = false, fillEvidence }) => {
  const reconciledRecords = records.map(record => reconcileSavedMtfTrade(
    record, entryCandles[record.signalTimeframe] ?? [], asOf));
  records = reconciledRecords.map(resolved => resolved.record);
  const needsExpiryData = (trade: TradeDisplayState | undefined) => (
    isSlTpTradeDisplayFinished(trade) || trade?.result === 'rf' || trade?.status === 'RF'
  );
  const hasExpiryData = (trade: TradeDisplayState | undefined) => {
    if (!needsExpiryData(trade)) return true;
    const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
    return timeframe !== undefined && (entryCandles[timeframe]?.length ?? 0) > 0;
  };
  const missingTimeframes = new Set(requiredTimeframes.filter(timeframe => !entryCandles[timeframe]?.length));
  for (const trade of [...records, ...rows.map(row => row.trade ?? row.previewTrade)]) {
    if (hasExpiryData(trade)) continue;
    const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
    if (timeframe) missingTimeframes.add(timeframe);
  }
  const waitingForExpiryData = missingTimeframes.size > 0;
  const failedTimeframes = [...missingTimeframes].filter(timeframe => candleErrors[timeframe]);
  const expired = (trade: TradeDisplayState | undefined) => tradeDisplayExpired(trade,
    entryCandles[trade?.signal?.timeframe ?? trade?.signalTimeframe ?? 'M1'] ?? [], asOf);
  const visibleLiveTrades = liveTrades.filter(({ signal, trade, position }) => {
    const recorded = records.find(record => record.brokerTicket === position.ticket
      || record.setupId !== undefined && record.setupId === position.setupId);
    return !expired(recorded && ['sl', 'tp', 'rf', 'risk-free'].includes(recorded.result) ? recorded : { ...trade, ...signal,
      status: signal?.status ?? position.signalStatus ?? trade.status });
  });
  const savedRows = records.filter(record => hasExpiryData(record) && !expired(record) && !liveTrades.some(({ position }) => (
    position.ticket === record.brokerTicket || position.setupId === record.setupId && record.setupId !== undefined
  )));
  const displayRows = rows.filter((row) => hasExpiryData(row.trade ?? row.previewTrade)
    && !expired(row.trade ?? row.previewTrade) && !liveTrades.some(({ position }) => (
    liveMtfPositionMatchesChartRow(position, row)
  )) && !records.some(record => (
    record.setupId === `MTF:${row.id}` || record.signalAt === row.engulfingTime
      && record.zoneTimeframe === row.higherTimeframe
      && record.signalTimeframe === row.lowerTimeframe && record.direction === row.direction
  )));
  const hasContent = displayRows.length > 0 || visibleLiveTrades.length > 0
    || savedRows.length > 0 || waitingForExpiryData;
  const [expanded, toggleExpanded] = useAutoExpandedTable(hasContent);
  return (
    <div data-journal-exclude="true" className={`pointer-events-auto absolute right-3 top-3 z-20 flex max-h-[calc(100%_-_24px)] max-w-[calc(100%_-_24px)] flex-col overflow-hidden rounded-md border border-slate-300 bg-white/95 shadow-sm ${expanded ? 'w-fit' : 'w-auto'}`}>
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-slate-200 bg-indigo-50 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-indigo-700">
        <span>{expanded ? 'MTF table' : 'MTF table minimized'}</span>
        <button
          type="button"
          onClick={toggleExpanded}
          aria-expanded={expanded}
          className="rounded border border-indigo-200 bg-white px-1.5 py-0.5 text-[8px] font-black text-indigo-700 hover:bg-indigo-100"
          title={expanded ? 'Minimize MTF table' : 'Show MTF table'}
        >
          {expanded ? '− MINIMIZE' : '+ SHOW TABLE'}
        </button>
      </div>
      {expanded && (
        <div className="min-h-0 max-h-[50vh] overflow-auto">
        <table className="table-auto border-collapse text-left text-[9px]">
          <thead className="bg-slate-100 text-[9px] uppercase text-slate-500">
            <tr>
              <th className="whitespace-nowrap px-2 py-1 font-bold">ID</th>
              <th className="whitespace-nowrap px-2 py-1 font-bold">MTF</th>
              <th className="whitespace-nowrap px-2 py-1 font-bold">Setup</th>
              <th className="whitespace-nowrap px-2 py-1 font-bold">HTF Zone Tapped</th>
              <th className="whitespace-nowrap px-2 py-1 font-bold">LTF Zone Tapped</th>
              <th className="whitespace-nowrap px-2 py-1 font-bold">Signal</th>
              <th className="whitespace-nowrap px-2 py-1 text-right font-bold">Entry Time / Bars</th>
            </tr>
          </thead>
          <tbody>
            {visibleLiveTrades.map(({ position, trade, signal }) => {
              const bullish = position.direction === 'BUY';
              return (
                <React.Fragment key={`live-mt5-${position.ticket}`}>
                  <tr className={`border-t ${bullish ? 'border-emerald-200 bg-emerald-50' : 'border-rose-200 bg-rose-50'}`}>
                    <td className="whitespace-nowrap px-2 py-1 font-black text-indigo-700">
                      MT5 #{position.ticket}
                    </td>
                    <td className="whitespace-nowrap px-2 py-1 font-black text-slate-700">
                      {position.zoneTimeframe ? formatTradeTimeframe(position.zoneTimeframe) : '?'} →{' '}
                      {position.signalTimeframe ? formatTradeTimeframe(position.signalTimeframe) : '?'}
                    </td>
                    <td className={`whitespace-nowrap px-2 py-1 font-black ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {signal?.tradeStyle === 'SCALPING' ? 'SCALP · ' : ''}{bullish ? 'Bullish' : 'Bearish'} · MT5 OPEN
                    </td>
                    <td className={`whitespace-nowrap px-2 py-1 font-black ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {position.zoneTimeframe ? formatTradeTimeframe(position.zoneTimeframe) : '?'}{' '}
                      {signal?.journalContext?.mtfContext?.higherTimeframeZone
                        ?? signal?.zoneId?.replace(/-\d{9,}-.+$/, '') ?? 'Recorded HTF zone'}
                    </td>
                    <td className="whitespace-nowrap px-2 py-1 font-bold text-slate-500">
                      {position.signalTimeframe} {signal?.journalContext?.mtfContext?.entryZone?.name ?? position.zoneName}
                    </td>
                    <td className={`whitespace-nowrap px-2 py-1 font-black ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {signal ? mt5SignalStatusLabel(signal) : `MT5 ACTIVE ${position.direction}`}
                    </td>
                    <td className="whitespace-nowrap px-2 py-1 text-right font-bold text-slate-500">
                      {formatChartTime(position.openedAt, timeZone)}
                    </td>
                  </tr>
                  <TradeDetailsRow trade={trade} colSpan={7} mtf mt5Signal={signal} fillEvidence={fillEvidence}
                    entryCandles={entryCandles[trade.signal.timeframe]} />
                </React.Fragment>
              );
            })}
            {displayRows.map((row) => {
              const bullish = row.direction === 'bullish';
              const entry = row.engulfingType !== undefined;
              const trade = row.trade ?? row.previewTrade;
              if (isSlTpTradeDisplayFinished(trade)) return <CompletedTradeRow key={row.id}
                name={`${MTF_TABLE_LABELS[row.higherTimeframe]} ${row.higherTimeframeZone}`}
                trade={trade!} candles={entryCandles[row.lowerTimeframe] ?? []} asOf={asOf} colSpan={7} />;
              return (
                <React.Fragment key={row.id}>
                <tr className={`border-t ${bullish ? 'border-emerald-100 bg-emerald-50/50' : 'border-rose-100 bg-rose-50/50'}`}>
                  <td className="px-2 py-1 font-black whitespace-nowrap text-indigo-700">
                    {row.setupId}
                  </td>
                  <td className="px-2 py-1 font-black whitespace-nowrap text-slate-700">
                    {MTF_TABLE_LABELS[row.higherTimeframe]} → {MTF_TABLE_LABELS[row.lowerTimeframe]}
                  </td>
                  <td className={`px-2 py-1 font-black whitespace-nowrap ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {row.goldScalping ? 'SCALP · ' : ''}{bullish ? 'Bullish' : 'Bearish'} {row.confirmationKind === 'choch' ? 'CHOCH' : 'ISS'}
                  </td>
                  <td className={`px-2 py-1 font-black whitespace-nowrap ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                    <div>{MTF_TABLE_LABELS[row.higherTimeframe]} {mtfZoneLabel(
                      row.higherTimeframeZone,
                      row.higherTimeframeMajorLiquidity,
                    )}</div>
                    <div className="text-[7px] font-bold leading-tight text-slate-400">
                      {row.higherTimeframeTapBarsAgo} {row.higherTimeframeTapBarsAgo === 1 ? 'bar' : 'bars'} ago
                    </div>
                  </td>
                  <td className={`px-2 py-1 font-bold whitespace-nowrap ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {row.tappedZone
                      ? `${MTF_TABLE_LABELS[row.lowerTimeframe]} ${mtfZoneLabel(row.tappedZone)}`
                      : '—'}
                  </td>
                  <td className={`whitespace-nowrap px-2 py-1 font-black ${
                    row.trade?.status === 'sl-hit'
                      ? 'text-rose-700'
                      : entry ? bullish ? 'text-emerald-700' : 'text-rose-700' : 'text-slate-600'
                  }`}>
                    {mtfSignalLabel(row, row.trade ?? row.previewTrade)}
                  </td>
                  <td className="px-2 py-1 text-right font-bold whitespace-nowrap text-slate-500">
                    {row.tradeBarsAgo === undefined ? '—' : `${row.tradeBarsAgo} bars`}
                  </td>
                </tr>
                {(row.trade ?? row.previewTrade)
                  && <TradeDetailsRow trade={(row.trade ?? row.previewTrade)!} colSpan={7} mtf
                    fillEvidence={fillEvidence}
                    zoneTimeframe={row.higherTimeframe} entryCandles={entryCandles[row.lowerTimeframe]}
                    referenceOnly={row.tradingTimeBlocked} intradayReference={intradayPullbacks && !row.goldScalping} />}
                </React.Fragment>
              );
            })}
            {savedRows.map(record => isSlTpTradeDisplayFinished(record) ? (
              <CompletedTradeRow key={record.id} name={`${formatTradeTimeframe(record.zoneTimeframe)} ${record.zoneName}`}
                trade={record} candles={entryCandles[record.signalTimeframe] ?? []} asOf={asOf} colSpan={7} />
            ) : (
              <React.Fragment key={record.id}>
                <tr className="border-t border-slate-200 bg-slate-50">
                  <td className="px-2 py-1 font-bold">{record.brokerTicket ? `MT5 #${record.brokerTicket}` : 'MTF TRADE'}</td>
                  <td className="px-2 py-1 font-bold">{formatTradeTimeframe(record.zoneTimeframe)} → {formatTradeTimeframe(record.signalTimeframe)}</td>
                  <td className="px-2 py-1">{record.direction === 'bullish' ? 'BUY' : 'SELL'} · {record.engulfingType}</td>
                  <td className="px-2 py-1">{record.mtfContext?.higherTimeframeZone ?? record.zoneId?.replace(/-\d{9,}-.+$/, '') ?? 'Recorded HTF zone'}</td>
                  <td className="px-2 py-1">{record.signalTimeframe} {record.mtfContext?.entryZone?.name ?? record.zoneName}</td>
                  <td className="px-2 py-1 font-bold">{reconciledRecords.find(resolved => resolved.record.id === record.id)?.verified === false
                    ? 'STATUS UNKNOWN'
                    : record.result === 'sl' ? 'SL HIT' : record.result === 'tp' ? 'TP HIT' : record.result === 'rf' ? 'RISK FREE CLOSED' : record.result === 'risk-free' ? 'RISK FREE' : 'OPEN'}</td>
                  <td className="px-2 py-1">{formatChartTime(record.openedAt ?? record.signalAt ?? record.completedAt, timeZone)}</td>
                </tr>
                <tr className="border-b border-slate-200 bg-white">
                  <td colSpan={7} className="px-2 py-1">
                    ENTRY {formatPrice(record.entry)} · SL {formatPrice(record.stopLoss)} · TP {formatPrice(record.takeProfit)}
                    {!record.mtfContext?.entryZone && ' · Original entry-zone drawing not saved'}
                  </td>
                </tr>
              </React.Fragment>
            ))}
            {waitingForExpiryData && (
              <tr>
                <td colSpan={7} className="px-2 py-2 text-center text-slate-500" role="status">
                  {failedTimeframes.length > 0
                    ? `Unable to load MTF candle data (${failedTimeframes.join(', ')}).`
                    : 'Loading MTF data…'}
                  {failedTimeframes.length > 0 && onRetry && (
                    <button type="button" onClick={onRetry}
                      className="ml-2 rounded border border-slate-300 px-2 py-0.5 font-bold text-indigo-700">Retry</button>
                  )}
                </td>
              </tr>
            )}
            {!waitingForExpiryData && displayRows.length === 0 && visibleLiveTrades.length === 0 && savedRows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-2 py-2 text-center text-slate-400">No active MTF setup</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
      )}
    </div>
  );
};

function accuracyCounts(records: AccuracyTradeRecord[]) {
  return records.reduce((counts, record) => ({
    sl: counts.sl + (record.result === 'sl' ? 1 : 0),
    rf: counts.rf + (record.result === 'rf' ? 1 : 0),
    tp: counts.tp + (record.result === 'tp' ? 1 : 0),
  }), { sl: 0, rf: 0, tp: 0 });
}

type AccuracyTradingTimeFilter = 'ALL' | 'TRADING' | 'NON_TRADING';

function matchesAccuracyTradingTime(
  record: AccuracyTradeRecord,
  filter: AccuracyTradingTimeFilter,
): boolean {
  if (filter === 'ALL') return true;
  return tradeRecordOutsideTradingTime(record) === (filter === 'NON_TRADING');
}

function accuracyRecordOutsideTradingTime(record: AccuracyTradeRecord): boolean {
  return tradeRecordOutsideTradingTime(record);
}

function formatAccuracyTradeTime(time: number, timeZone: ChartTimeZone): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone,
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(time * 1000)).replace(',', '');
}

const JOURNAL_SCREENSHOT_PREFIX = 'trade-journal-screenshot:';

async function resizeJournalScreenshot(dataUrl: string, maximumWidth = 1200): Promise<string> {
  const image = new Image();
  image.src = dataUrl;
  await new Promise<void>((resolve, reject) => {
    image.onload = () => resolve();
    image.onerror = () => reject(new Error('Unable to prepare the journal screenshot.'));
  });
  if (image.width <= maximumWidth) return dataUrl;
  const scale = maximumWidth / image.width;
  const canvas = document.createElement('canvas');
  canvas.width = maximumWidth;
  canvas.height = Math.max(1, Math.round(image.height * scale));
  const context = canvas.getContext('2d');
  if (!context) return dataUrl;
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.76);
}

function readPendingJournalScreenshot(tradeId: string): string | undefined {
  try {
    return userStorage.getItem(`${JOURNAL_SCREENSHOT_PREFIX}${tradeId}`) || undefined;
  } catch {
    return undefined;
  }
}

function journalFibMetadata(
  zone: StructureZone,
  signal: EngulfingTradeSignal,
): Pick<JournalTradeRecord, 'fibSource' | 'fibBand' | 'fibLevels'> {
  let fibSource = zone.majorLiquidity ? 'MAJOR LIQUIDITY' : 'ZONE FIB';
  let fibBand = zone.fibBand;
  if (signal.time === zone.h1SwingEngulfingTime && signal.type === zone.h1SwingEngulfingType) {
    fibSource = '1H SWING FIB';
    fibBand = zone.h1SwingFibBand;
  } else if (signal.time === zone.swingEngulfingTime && signal.type === zone.swingEngulfingType) {
    fibSource = '4H SWING FIB';
    fibBand = zone.swingFibBand;
  } else if (signal.time === zone.dayEngulfingTime && signal.type === zone.dayEngulfingType) {
    fibSource = 'DAY FIB';
    fibBand = zone.dayFibBand;
  }
  const sourcePrice = fibSource === '1H SWING FIB' ? zone.h1SwingSourcePrice : zone.fibSourcePrice;
  const zeroPrice = fibSource === '1H SWING FIB' ? zone.h1SwingZeroPrice : zone.fibZeroPrice;
  const fibLevels = sourcePrice !== undefined && zeroPrice !== undefined
    ? [0.5, 0.618, 0.71, 0.79].map((level) => ({
      label: String(level),
      price: zeroPrice + (sourcePrice - zeroPrice) * level,
    }))
    : undefined;
  return { fibSource, fibBand, fibLevels };
}

function journalVolumeMetadata(
  candles: OandaCandle[],
  signal: EngulfingTradeSignal,
): Pick<JournalTradeRecord, 'volumeLogicStatus' | 'volume1' | 'volume2' | 'volume3'> {
  const assessment = assessEngulfingVolumeLogic(candles, signal);
  return {
    volumeLogicStatus: getEngulfingVolumeStatus(assessment, signal.type),
    volume1: assessment.firstVolume,
    volume2: assessment.secondVolume,
    volume3: assessment.thirdVolume,
  };
}

const EngulfingAccuracyTable: React.FC<{
  records: AccuracyTradeRecord[];
  allRecords: AccuracyTradeRecord[];
  mt5Records: AccuracyTradeRecord[];
  canViewMt5?: boolean;
  timeframe: OandaGranularity;
  showAllTrades: boolean;
  historyAsOf: number;
  timeZone: ChartTimeZone;
  marketSymbol: OandaMarketSymbol;
  entryArrowsVisible: boolean;
  onClose: () => void;
  selectedStrategies: TradeStrategy[];
  onStrategiesChange: (selected: TradeStrategy[]) => void;
}> = ({ records, allRecords, mt5Records, canViewMt5 = false, timeframe, showAllTrades, historyAsOf, timeZone, marketSymbol, entryArrowsVisible, onClose, selectedStrategies, onStrategiesChange }) => {
  const [activeTab, setActiveTab] = useState<'SETUPS' | 'MT5'>('SETUPS');
  const [filters, setFilters] = useState<TradeRecordFilters>(() => ({
    ...DEFAULT_TRADE_RECORD_FILTERS,
    timeframes: [timeframe],
  }));
  useEffect(() => {
    setFilters((current) => ({ ...current, timeframes: [timeframe] }));
  }, [timeframe]);
  const [tradingTimeFilter, setTradingTimeFilter] = useState<AccuracyTradingTimeFilter>('ALL');
  const historyWindow = twoMonthAccuracyWindow(historyAsOf);
  const formatHistoryDate = (time: number) => new Date(time * 1000).toLocaleDateString('en-GB', {
    timeZone, day: '2-digit', month: 'short', year: 'numeric',
  });
  const filteredAllRecords = useMemo(
    () => filterAccuracyTradeRecords<AccuracyTradeRecord>(
      activeTab === 'MT5'
        ? selectTwoMonthJournalRecords(mt5Records, historyAsOf)
        : selectTwoMonthAccuracyRecords(allRecords, historyAsOf),
      { ...filters, tradeStyle: selectedStrategies }, timeZone, marketSymbol)
      .filter((record) => matchesAccuracyTradingTime(record, tradingTimeFilter)),
    [activeTab, allRecords, mt5Records, filters, timeZone, tradingTimeFilter, selectedStrategies, historyAsOf, marketSymbol],
  );
  const summaryRecords = useMemo(() => filteredAllRecords.filter((record) => (
    record.result === 'tp' || record.result === 'sl' || record.result === 'rf'
  )), [filteredAllRecords]);
  const visibleChartIds = useMemo(() => {
    const selectedIds = new Set(summaryRecords.map((record) => record.id));
    return new Set(records.filter((record) => selectedIds.has(record.id)).map((record) => record.id));
  }, [records, summaryRecords]);
  const timeframeCounts = accuracyCounts(summaryRecords);
  const availableTimeframes = useMemo(() => Array.from(new Set<TradeTimeframe>(
    [...TIMEFRAMES.map(({ value }) => value),
      ...allRecords.map((record) => record.signalTimeframe),
      ...mt5Records.map((record) => record.signalTimeframe)],
  )).sort((first, second) => TIMEFRAME_SECONDS[first] - TIMEFRAME_SECONDS[second]), [allRecords, mt5Records]);
  const availableZones = useMemo(() => Array.from(new Set(
    [...allRecords, ...mt5Records].map((record) => record.zoneName),
  )).sort(), [allRecords, mt5Records]);
  const extraZoneRows: string[] = Array.from(new Set<string>(
    summaryRecords.map((record) => record.zoneName),
  ))
    .filter((zoneName) => !ACCURACY_ZONE_ROWS.includes(zoneName));
  const zoneRows = [...ACCURACY_ZONE_ROWS, ...extraZoneRows];
  const resultRow = (title: string, counts: ReturnType<typeof accuracyCounts>) => {
    const total = counts.sl + counts.rf + counts.tp;
    const accuracy = total > 0 ? `${Math.round((counts.tp * 10_000) / total) / 100}%` : '—';
    return (
      <tr key={title} className="border-t border-slate-200 bg-white/95">
        <td className="whitespace-nowrap px-1.5 py-0.5 text-left font-bold text-slate-700">{title}</td>
        <td className="px-1.5 py-0.5 font-black text-rose-700">{counts.sl}</td>
        <td className="px-1.5 py-0.5 font-black text-amber-600">{counts.rf}</td>
        <td className="px-1.5 py-0.5 font-black text-emerald-700">{counts.tp}</td>
        <td className="px-1.5 py-0.5 font-bold text-slate-700">{total}</td>
        <td className="px-1.5 py-0.5 font-black text-indigo-700">{accuracy}</td>
      </tr>
    );
  };
  const header = (firstColumn: string) => (
    <tr className="bg-slate-500 text-[8px] uppercase text-white">
      <th className="whitespace-nowrap px-1.5 py-0.5 text-left">{firstColumn}</th>
      <th className="px-1.5 py-0.5">SL</th>
      <th className="px-1.5 py-0.5">RF</th>
      <th className="px-1.5 py-0.5">TP</th>
      <th className="px-1.5 py-0.5">Total</th>
      <th className="whitespace-nowrap px-1.5 py-0.5">Accuracy%</th>
    </tr>
  );
  const showTradeRows = showAllTrades || activeTab === 'MT5';

  return (
    <div data-journal-exclude="true" className={`pointer-events-auto absolute z-30 overflow-hidden rounded-md border border-slate-300 bg-white/95 shadow-md ${
      showTradeRows
        ? 'bottom-3 left-3 top-3 flex w-fit max-w-[calc(100%_-_24px)] flex-col'
        : 'left-3 top-1/2 flex max-h-[calc(100%_-_24px)] max-w-[calc(100%_-_24px)] -translate-y-1/2 flex-col'
    }`}>
      <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-slate-300 bg-indigo-50 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-indigo-700">
        <span>
          {marketSymbol} trade accuracy · {entryArrowsVisible ? visibleChartIds.size : 0} arrow{visibleChartIds.size === 1 && entryArrowsVisible ? '' : 's'}
        </span>
        <TradeMultiSelect
          allLabel="ALL TIMEFRAMES"
          emptyLabel="NO TIMEFRAMES"
          selected={filters.timeframes}
          options={availableTimeframes.map((value) => ({ value, label: formatTradeTimeframe(value) }))}
          onChange={(timeframes) => setFilters((current) => ({
            ...current,
            timeframes: timeframes as TradeRecordFilters['timeframes'],
          }))}
        />
        <select
          value={tradingTimeFilter}
          onChange={(event) => setTradingTimeFilter(event.target.value as AccuracyTradingTimeFilter)}
          className="rounded border border-indigo-200 bg-white px-1.5 py-0.5 text-[9px] font-bold text-indigo-700"
          aria-label="Filter accuracy by trading time"
          title="Classify by Nepal trading sessions at entry time"
        >
          <option value="ALL">ALL TIMES</option>
          <option value="TRADING">TRADING TIME</option>
          <option value="NON_TRADING">NON-TRADING TIME</option>
        </select>
        <TradeStrategyCheckboxes label="Accuracy strategies" selected={selectedStrategies} onChange={onStrategiesChange} />
        <button
          type="button"
          onClick={onClose}
          className="ml-auto grid h-5 w-5 place-items-center rounded-full border border-indigo-200 bg-white text-[10px] font-black leading-none text-slate-500 hover:bg-slate-100 hover:text-slate-800"
          title="Close accuracy table"
          aria-label="Close accuracy table"
        >
          ×
        </button>
      </div>
      <div className="shrink-0 border-b border-indigo-100 bg-white px-2 py-1 text-[9px] font-bold text-indigo-700">
        {formatHistoryDate(historyWindow.from)} – {formatHistoryDate(historyWindow.to)}
      </div>
      <div className="flex shrink-0 items-center gap-1 border-b border-indigo-100 bg-white px-2 py-1 text-[9px] font-bold">
        <button type="button" onClick={() => {
          setActiveTab('SETUPS');
          setFilters((current) => ({ ...current, timeframes: [timeframe] }));
        }}
          aria-pressed={activeTab === 'SETUPS'}
          className={`rounded px-2 py-1 ${activeTab === 'SETUPS' ? 'bg-indigo-600 text-white' : 'text-indigo-700 hover:bg-indigo-50'}`}>
          ALL SETUPS
        </button>
        {canViewMt5 && <button type="button" onClick={() => {
          setActiveTab('MT5');
          setFilters((current) => ({ ...current, timeframes: 'ALL' }));
        }}
          aria-pressed={activeTab === 'MT5'}
          className={`rounded px-2 py-1 ${activeTab === 'MT5' ? 'bg-indigo-600 text-white' : 'text-indigo-700 hover:bg-indigo-50'}`}>
          EXECUTED IN MT5
        </button>}
        {activeTab === 'MT5' && <span className="ml-1 text-slate-500">
          {summaryRecords.length} closed · {filteredAllRecords.length - summaryRecords.length} open · accuracy uses closed trades
        </span>}
      </div>
      <div className={showTradeRows ? 'flex min-h-0 flex-1' : 'min-h-0 overflow-auto'}>
        <div className={showTradeRows ? 'w-[290px] shrink-0 overflow-auto border-r border-slate-300' : ''}>
          <table className="w-full border-collapse text-center text-[9px]">
            <thead>{header('Timeframe')}</thead>
            <tbody>
              {resultRow(filters.timeframes === 'ALL'
                ? 'ALL'
                : filters.timeframes.map((value) => GRANULARITY_LABELS[value].toUpperCase()).join(', ') || 'NONE', timeframeCounts)}
              {marketSymbol === 'XAUUSD' && <>
                {header('Trade style')}
                {resultRow('INTRADAY ENTRIES', accuracyCounts(summaryRecords.filter((record) => record.tradeStyle === 'INTRADAY')))}
                {resultRow('SCALPING', accuracyCounts(summaryRecords.filter((record) => record.tradeStyle === 'SCALPING')))}
                {resultRow('SCALP 1:1 ENTRIES', accuracyCounts(summaryRecords.filter((record) => record.tradeStyle === 'SCALP_1_1')))}
                {resultRow('BB M5 CHART STUDY', accuracyCounts(summaryRecords.filter(record => record.tradeStyle === 'BOLLINGER_M5' && !record.mt5Managed && record.brokerTicket === undefined)))}
                {resultRow('BB M5 MT5 FILLS', accuracyCounts(summaryRecords.filter(record => record.tradeStyle === 'BOLLINGER_M5' && (record.mt5Managed || record.brokerTicket !== undefined))))}
              </>}
              {header('Trade source')}
              {resultRow('ENGULFING', accuracyCounts(
                summaryRecords.filter((record) => record.source === 'ENGULFING'),
              ))}
              {resultRow('MTF', accuracyCounts(
                summaryRecords.filter((record) => record.source === 'MTF'),
              ))}
              {header('Zone type')}
              {zoneRows.map((zoneName) => resultRow(
                zoneName,
                accuracyCounts(summaryRecords.filter((record) => record.zoneName === zoneName)),
              ))}
            </tbody>
          </table>
        </div>
        {showTradeRows && (
          <div className="min-w-0 max-w-[calc(100vw-338px)] flex-1 overflow-auto">
            <div className="sticky left-0 top-0 z-20 border-b border-indigo-200 bg-indigo-50">
              <div className="bg-indigo-100 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-indigo-800">
                {activeTab === 'MT5' ? 'MT5 broker executions' : 'All completed setups'} · {filteredAllRecords.length}/{activeTab === 'MT5' ? mt5Records.length : allRecords.length} shown · {entryArrowsVisible ? visibleChartIds.size : 0} chart arrows · newest first
              </div>
              <div className="flex flex-wrap items-center gap-1 border-t border-indigo-100 px-1.5 py-1">
                <select value={filters.datePeriod} onChange={(event) => setFilters((current) => ({
                  ...current,
                  datePeriod: event.target.value as TradeRecordFilters['datePeriod'],
                }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-bold">
                  <option value="DAY">DAILY</option><option value="WEEK">WEEKLY</option><option value="MONTH">MONTHLY</option>
                </select>
                <input type="date" value={filters.date === 'ALL' ? '' : filters.date} onChange={(event) => setFilters((current) => ({
                  ...current, date: event.target.value || 'ALL',
                }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-bold" title="Choose any date" />
                {filters.date !== 'ALL' && filters.datePeriod !== 'DAY' && (
                  <span className="whitespace-nowrap text-[8px] font-bold text-indigo-700">
                    {tradeRecordPeriodLabel(tradeRecordDatePeriodKey(filters.date, filters.datePeriod), filters.datePeriod)}
                  </span>
                )}
                {filters.date !== 'ALL' && <button type="button" onClick={() => setFilters((current) => ({ ...current, date: 'ALL' }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-black text-slate-500">ALL DATES</button>}
                <select value={filters.source} onChange={(event) => setFilters((current) => ({ ...current, source: event.target.value as TradeRecordFilters['source'] }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-bold">
                  <option value="ALL">ALL SOURCES</option><option value="ENGULFING">ENGULFING</option><option value="MTF">MTF</option><option value="BOLLINGER">BOLLINGER</option>
                </select>
                <select value={filters.side} onChange={(event) => setFilters((current) => ({ ...current, side: event.target.value as TradeRecordFilters['side'] }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-bold">
                  <option value="ALL">ALL SIDES</option><option value="BUY">BUY</option><option value="SELL">SELL</option>
                </select>
                <select value={filters.result} onChange={(event) => setFilters((current) => ({ ...current, result: event.target.value as TradeRecordFilters['result'] }))} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-bold">
                  <option value="ALL">ALL RESULTS</option><option value="tp">TP</option><option value="sl">SL</option><option value="rf">RF</option>
                </select>
                <TradeMultiSelect
                  allLabel="ALL ZONES"
                  emptyLabel="NO ZONES"
                  selected={filters.zones}
                  options={availableZones.map((value) => ({ value, label: value }))}
                  onChange={(zones) => setFilters((current) => ({ ...current, zones }))}
                />
                <button type="button" onClick={() => {
                  setFilters({ ...DEFAULT_TRADE_RECORD_FILTERS, timeframes: [timeframe] });
                  setTradingTimeFilter('ALL');
                  onStrategiesChange([...TRADE_STRATEGIES]);
                }} className="rounded border border-slate-200 bg-white px-1.5 py-1 text-[8px] font-black text-slate-600 hover:bg-slate-100">RESET</button>
              </div>
            </div>
            <table className="min-w-[1010px] border-collapse text-center text-[9px]">
              <thead className="sticky top-[55px] z-10 bg-slate-600 uppercase text-white">
              <tr>
                <th className="px-1.5 py-1">#</th>
                <th className="whitespace-nowrap px-1.5 py-1 text-left">{activeTab === 'MT5' ? 'Closed / opened' : 'Completed'}</th>
                <th className="whitespace-nowrap px-1.5 py-1 text-left">Entered</th>
                <th className="px-1.5 py-1">On chart</th>
                <th className="whitespace-nowrap px-1.5 py-1">Trading time</th>
                <th className="px-1.5 py-1">TF</th>
                <th className="px-1.5 py-1">Source</th>
                <th className="px-1.5 py-1">Style</th>
                <th className="whitespace-nowrap px-1.5 py-1 text-left">Zone</th>
                <th className="px-1.5 py-1">Side</th>
                <th className="px-1.5 py-1">Result</th>
                <th className="px-1.5 py-1">Entry</th>
                <th className="px-1.5 py-1">SL</th>
                <th className="px-1.5 py-1">TP</th>
                <th className="px-1.5 py-1">R:R</th>
                {activeTab === 'MT5' && <>
                  <th className="px-1.5 py-1">MT5 ticket</th>
                  <th className="px-1.5 py-1">Lots</th>
                  <th className="px-1.5 py-1">Broker P/L</th>
                </>}
              </tr>
              </thead>
              <tbody>
              {filteredAllRecords.map((record, index) => (
                  <tr key={record.id} title={`Trade ID: ${record.id}`} className="border-t border-slate-200 odd:bg-white even:bg-slate-50">
                  <td className="px-1.5 py-1 text-slate-500">{index + 1}</td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-left text-slate-600">
                    {activeTab === 'MT5' && (record.result === 'open' || record.result === 'risk-free')
                      ? 'OPEN' : formatAccuracyTradeTime(record.completedAt, timeZone)}
                  </td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-left text-slate-600">
                    {record.openedAt !== undefined
                      ? formatAccuracyTradeTime(record.openedAt, timeZone)
                      : record.signalAt !== undefined
                        ? formatAccuracyTradeTime(record.signalAt + TIMEFRAME_SECONDS[record.signalTimeframe], timeZone)
                        : '—'}
                  </td>
                  <td className={`px-1.5 py-1 font-black ${entryArrowsVisible && visibleChartIds.has(record.id) ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {entryArrowsVisible && visibleChartIds.has(record.id) ? 'ARROW' : '—'}
                  </td>
                  <td className={`whitespace-nowrap px-1.5 py-1 font-bold ${accuracyRecordOutsideTradingTime(record) ? 'text-rose-700' : 'text-emerald-700'}`}>
                    {accuracyRecordOutsideTradingTime(record) ? 'OUTSIDE TIME' : 'IN SESSION'}
                  </td>
                  <td className="px-1.5 py-1 font-bold text-slate-700">
                    {formatTradeTimeframe(record.signalTimeframe)}
                  </td>
                  <td className="px-1.5 py-1 font-bold text-slate-600">{record.source}</td>
                  <td className="px-1.5 py-1 font-bold text-indigo-700">{record.tradeStyle === 'BOLLINGER_M5' ? 'BOLLINGER M5' : record.tradeStyle === 'SCALP_1_1' ? 'SCALP 1:1' : record.tradeStyle ?? '—'}</td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-left font-bold text-slate-700">
                    {record.zoneName}
                    {(record.tradeStyle === 'SCALP_1_1' || record.tradeStyle === 'BOLLINGER_M5') && <div className="text-[8px] text-slate-500">
                      {record.mt5Managed || record.brokerTicket !== undefined ? 'MT5' : 'CHART ONLY'}
                      {record.scalpEntry && ` · ${record.scalpEntry.leg}% pullback / ${Math.round(record.scalpEntry.riskShare * 100)}% risk`}
                    </div>}
                  </td>
                  <td className={`px-1.5 py-1 font-black ${
                    record.direction === 'bullish' ? 'text-emerald-700' : 'text-rose-700'
                  }`}>
                    {record.direction === 'bullish' ? 'BUY' : 'SELL'}
                  </td>
                  <td className={`px-1.5 py-1 font-black ${
                    record.result === 'tp'
                      ? 'text-emerald-700'
                      : record.result === 'rf' || record.result === 'risk-free'
                        ? 'text-amber-600' : record.result === 'open' ? 'text-blue-700' : 'text-rose-700'
                  }`}>
                    {record.result.toUpperCase()}
                  </td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-slate-700">{formatPrice(record.entry)}</td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-slate-700">{formatPrice(record.stopLoss)}</td>
                  <td className="whitespace-nowrap px-1.5 py-1 text-slate-700">{formatPrice(record.takeProfit)}</td>
                  <td className="px-1.5 py-1 font-bold text-slate-700">1:{record.rewardRisk}</td>
                  {activeTab === 'MT5' && <>
                    <td className="px-1.5 py-1 font-bold text-indigo-700">#{record.brokerTicket}</td>
                    <td className="px-1.5 py-1 text-slate-700">{record.volume ?? '—'}</td>
                    <td className="px-1.5 py-1 text-slate-700">{record.realizedProfit === undefined ? '—' : record.realizedProfit.toFixed(2)}</td>
                  </>}
                  </tr>
                ))}
              {filteredAllRecords.length === 0 && (
                  <tr>
                    <td colSpan={activeTab === 'MT5' ? 18 : 15} className="px-2 py-3 text-center text-slate-400">
                      {activeTab === 'MT5' ? 'No executed MT5 trades match these filters'
                        : 'No completed setups match these filters'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export const OandaProChart: React.FC<{
  terminalId?: 'primary' | 'secondary';
  onTerminalChange?: (id: 'primary' | 'secondary') => void;
  userRole?: UserRole;
}> = ({ terminalId = 'primary', onTerminalChange, userRole = 'client' }) => {
  const canAdmin = userRole !== 'client';
  const terminalFetch = useCallback((url: string, options?: RequestInit) => {
    if (!canAdmin && (url.startsWith('/api/telegram/') || (url.startsWith('/api/mt5/') && options?.method && options.method !== 'GET'))) {
      return Promise.resolve(Response.json({ ok: false, error: 'Admins only.' }, { status: 403 }));
    }
    const scoped = url.startsWith('/api/mt5/') || url.startsWith('/api/journal/') || url.startsWith('/api/telegram/');
    return fetch(scoped ? `${url}${url.includes('?') ? '&' : '?'}terminal=${terminalId}` : url, options);
  }, [terminalId, canAdmin]);
  const retainedStorageKey = terminalId === 'primary' ? RETAINED_CHART_TRADES_STORAGE_KEY
    : `${RETAINED_CHART_TRADES_STORAGE_KEY}:secondary`;
  const [terminalAccounts, setTerminalAccounts] = useState<Array<{
    id: 'primary' | 'secondary'; label: string; connected: boolean; account?: string;
    server?: string; equity?: number; enabled: boolean; dryRun: boolean;
    riskPercent: number; maximumDailyLossPercent: number;
    intradayRiskPercent?: number; scalpingRiskPercent?: number; scalpOneToOneRiskPercent?: number; bollingerM5RiskPercent?: number;
  }>>([]);

  const hostRef = useRef<HTMLDivElement | null>(null);
  const chartPaneRef = useRef<HTMLDivElement | null>(null);
  const drawingToolbarDragRef = useRef<{
    offsetX: number;
    offsetY: number;
    width: number;
    height: number;
  } | null>(null);
  const chartRef = useRef<any>(null);
  const candleSeriesRef = useRef<any>(null);
  const volumeSeriesRef = useRef<any>(null);
  const markersRef = useRef<any>(null);
  const zoneLayerRef = useRef<HTMLDivElement | null>(null);
  const livePriceLabelRef = useRef<HTMLDivElement | null>(null);
  const livePriceValueRef = useRef<HTMLSpanElement | null>(null);
  const liveCountdownRef = useRef<HTMLSpanElement | null>(null);
  const headerOpenRef = useRef<HTMLElement | null>(null);
  const headerHighRef = useRef<HTMLElement | null>(null);
  const headerLowRef = useRef<HTMLElement | null>(null);
  const headerCloseRef = useRef<HTMLElement | null>(null);
  const headerChangeRef = useRef<HTMLSpanElement | null>(null);
  const updateHeaderCandleRef = useRef<(timestamp?: number) => void>(() => undefined);
  const replaySelectionLineRef = useRef<HTMLDivElement | null>(null);
  const journalSyncSignatureRef = useRef('');
  const telegramAlertSentRef = useRef(new Set<string>());
  const telegramAlertSendingRef = useRef(false);
  const mt5JournalImageSignatureRef = useRef('');
  const capturedTradeSetupsRef = useRef(new Set<string>());
  const zonesRef = useRef<StructureZone[]>([]);
  const visualZonesRef = useRef<DisplayStructureZone[]>([]);
  const swingFibMovesRef = useRef<SwingFibMove[]>([]);
  const h1SwingFibMovesRef = useRef<SwingFibMove[]>([]);
  const dayFibMovesRef = useRef<DayFibMove[]>([]);
  const structureLinesRef = useRef<StructureLine[]>([]);
  const structureMarkersRef = useRef<any[]>([]);
  const issMarkersRef = useRef<any[]>([]);
  const internalMarkersRef = useRef<any[]>([]);
  const showMgZonesRef = useRef(true);
  const showSupplyDemandRef = useRef(true);
  const showStructureRef = useRef(true);
  const showTrendlinesRef = useRef(false);
  const showAllTrendlinesRef = useRef(false);
  const showIssRef = useRef(true);
  const showInternalRef = useRef(true);
  const showFibRef = useRef(true);
  const showAlignedH1FibRef = useRef(false);
  const fibVisibilityRef = useRef<Record<FibVisibilityKey, boolean>>(DEFAULT_FIB_VISIBILITY);
  const fibPreviousVisibilityRef = useRef<Record<FibVisibilityKey, boolean>>(DEFAULT_FIB_VISIBILITY);
  const chochFibVisibilityRef = useRef<ChochFibVisibility>(DEFAULT_CHOCH_FIB_VISIBILITY);
  const showInvalidZonesRef = useRef(false);
  const showTradeLevelsRef = useRef(true);
  const tradeOverlaysRef = useRef<TradeOverlay[]>([]);
  const entryHoversRef = useRef<EntryHover[]>([]);
  const [hoveredEntry, setHoveredEntry] = useState<{ entry: EntryHover; x: number; y: number } | null>(null);
  const redrawZonesRef = useRef<() => void>(() => undefined);
  const overlayRedrawFrameRef = useRef<number | null>(null);
  const overlayScrollTimerRef = useRef<number | null>(null);
  const lastOverlayRedrawAtRef = useRef(0);
  const drawingRedrawFrameRef = useRef<number | null>(null);
  const drawingRedrawTimerRef = useRef<number | null>(null);
  const lastDrawingRedrawAtRef = useRef(0);
  const hasChartDrawingLayerRef = useRef(false);
  const hasFittedRef = useRef(false);
  const pendingMarketSymbolFitRef = useRef(false);
  const replayTimeRef = useRef<number | null>(null);
  const pendingReplayViewportRef = useRef<{ fromOffset: number; toOffset: number } | null>(null);
  const loadRequestIdRef = useRef(0);
  const loadedGranularityRef = useRef<OandaGranularity>('M15');
  const loadedDataSourceRef = useRef<LiveChartDataSource>('OANDA');
  const loadedMarketSymbolRef = useRef<OandaMarketSymbol>('XAUUSD');
  const candlesRef = useRef<OandaCandle[]>([]);
  const analysisWorkerRef = useRef<Worker | null>(null);
  const analysisRequestIdRef = useRef(0);
  const analysisRequestsRef = useRef(new Map<number, {
    resolve: (updates: PreparedStructureAnalysis[]) => void;
    reject: (error: Error) => void;
  }>());
  const preparedAnalysesRef = useRef(new Map<string, PreparedStructureAnalysis>());
  const supportAnalysisCacheRef = useRef<Partial<Record<MarketGranularity, {
    candles: OandaCandle[];
    structure: ReturnType<typeof analyzeMarketStructure>;
  }>>>({});
  const supportContextsRef = useRef<Array<{ timeframe: string; zones: StructureZone[] }>>([]);
  const tableAnalysisCacheRef = useRef<Partial<Record<OandaGranularity, {
    candles: OandaCandle[];
    structure: ReturnType<typeof analyzeMarketStructure>;
  }>>>({});
  const replaySelectingRef = useRef(false);
  const replaySelectionIndexRef = useRef<number | null>(null);
  const syncReplaySelectionLineRef = useRef<() => void>(() => undefined);
  const [granularity, setGranularity] = useState<OandaGranularity>('M15');
  const [marketSymbol, setMarketSymbol] = useState<OandaMarketSymbol>(loadStoredMarketSymbol);
  const [liveChartDataSource, setLiveChartDataSource] = useState<LiveChartDataSource>('OANDA');
  const [candleSnapshot, setCandleSnapshot] = useState<ChartCandleSnapshot<OandaCandle> | null>(null);
  const candles = useMemo(() => matchingChartCandles(candleSnapshot, {
    granularity, symbol: marketSymbol, dataSource: liveChartDataSource,
  }), [candleSnapshot, granularity, marketSymbol, liveChartDataSource]);
  const [vipCandles, setVipCandles] = useState<Partial<Record<MarketGranularity, OandaCandle[]>>>({});
  const vipCandlesRef = useRef(vipCandles);
  vipCandlesRef.current = vipCandles;
  const [source, setSource] = useState('Loading TradingView OANDA candles');
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mtfCandleErrors, setMtfCandleErrors] = useState<Partial<Record<MarketGranularity, string>>>({});
  const [refreshKey, setRefreshKey] = useState(0);
  const [chartTimeZone, setChartTimeZone] = useState<ChartTimeZone>('Asia/Kathmandu');
  const [showStructure, setShowStructure] = useState(true);
  const [showStructureOptions, setShowStructureOptions] = useState(false);
  const [showTrendlines, setShowTrendlines] = useState(false);
  const [showAllTrendlines, setShowAllTrendlines] = useState(false);
  const [trendlineTimeframes, setTrendlineTimeframes] = useState<Set<OandaGranularity>>(() => loadStoredTrendlineTimeframes(granularity));
  const [showTrendlineOptions, setShowTrendlineOptions] = useState(false);
  const [shortenedTrendlineIds, setShortenedTrendlineIds] = useState<Set<string>>(() => new Set());
  const [hiddenHtfTrendlineIds, setHiddenHtfTrendlineIds] = useState<Set<string>>(() => new Set());
  const [showMgZones, setShowMgZones] = useState(true);
  const [showSupplyDemand, setShowSupplyDemand] = useState(true);
  const [showIss, setShowIss] = useState(true);
  const [showInternal, setShowInternal] = useState(true);
  const [showFib, setShowFib] = useState(true);
  const [showAlignedH1Fib, setShowAlignedH1Fib] = useState(false);
  const [showFibOptions, setShowFibOptions] = useState(false);
  const [showInternalFibOptions, setShowInternalFibOptions] = useState(false);
  const [expandedFibOption, setExpandedFibOption] = useState<FibVisibilityKey | null>(null);
  const [fibVisibility, setFibVisibility] = useState<Record<FibVisibilityKey, boolean>>(
    DEFAULT_FIB_VISIBILITY,
  );
  const [fibPreviousVisibility, setFibPreviousVisibility] = useState<Record<FibVisibilityKey, boolean>>(
    DEFAULT_FIB_VISIBILITY,
  );
  const [chochFibVisibility, setChochFibVisibility] = useState<ChochFibVisibility>(
    DEFAULT_CHOCH_FIB_VISIBILITY,
  );
  const [showEngulfing, setShowEngulfing] = useState(true);
  const [tradingTimeEnabled, setTradingTimeEnabled] = useState(false);
  const [telegramMessagesEnabled, setTelegramMessagesEnabled] = useState(true);
  const [showInvalidZones, setShowInvalidZones] = useState(false);
  const [showTradeLevels, setShowTradeLevels] = useState(true);
  const [arrowStrategies, setArrowStrategies] = useState<TradeStrategy[]>([]);
  const [accuracyStrategies, setAccuracyStrategies] = useState<TradeStrategy[]>([...TRADE_STRATEGIES]);
  const [journalStrategies, setJournalStrategies] = useState<TradeStrategy[]>([...TRADE_STRATEGIES]);
  const showScalpOneToOneArrows = arrowStrategies.includes('SCALP_1_1');
  const showEntryArrows = arrowStrategies.length > 0;
  const [showAccuracyTable, setShowAccuracyTable] = useState(false);
  const [showTrendlineStudy, setShowTrendlineStudy] = useState(false);
  const [showVolumeStudy, setShowVolumeStudy] = useState(false);
  const [showBollingerStudy, setShowBollingerStudy] = useState(false);
  const [visitedStudies, setVisitedStudies] = useState({ trendline: false, volume: false });
  const backtestingMenuRef = useRef<HTMLDetailsElement | null>(null);
  const openBacktestingStudy = (study: 'trendline' | 'volume' | 'bollinger') => {
    if (study !== 'bollinger') setVisitedStudies(current => ({ ...current, [study]: true }));
    setShowTrendlineStudy(study === 'trendline');
    setShowVolumeStudy(study === 'volume');
    setShowBollingerStudy(study === 'bollinger');
    if (backtestingMenuRef.current) backtestingMenuRef.current.open = false;
    setShowIndicatorControls(false);
  };
  const [bollingerChartRecords, setBollingerChartRecords] = useState<JournalTradeRecord[]>([]);
  const [showAccuracyOptions, setShowAccuracyOptions] = useState(false);
  const [showAllAccuracyTrades, setShowAllAccuracyTrades] = useState(false);
  const [executedMt5Trades, setExecutedMt5Trades] = useState<AccuracyTradeRecord[]>([]);
  const [showJournal, setShowJournal] = useState(() => (
    new URLSearchParams(window.location.search).get('journal') === '1'
  ));
  const [loadedJournalTrades, setSavedJournalTrades] = useState<AccuracyTradeRecord[]>([]);
  const savedJournalTrades = useMemo(() => loadedJournalTrades.filter(record => (
    record.mt5Managed || record.brokerTicket !== undefined || record.mt5SignalId || record.id.startsWith('MT5:')
    || !isDirectTradeOverlay(record.id, record.setupId)
    || !((record.symbol ?? 'XAUUSD') === marketSymbol)
    || chartSignalMatchesLoadedCandles(record.signalAt,
      record.signalTimeframe === granularity ? candles : vipCandles[record.signalTimeframe])
  )), [loadedJournalTrades, marketSymbol, granularity, candles, vipCandles]);
  const [mt5Status, setMt5Status] = useState<Mt5AutomationStatus | null>(null);
  const [manualTimeframeSaving, setManualTimeframeSaving] = useState<number | null>(null);
  const [manualTimeframeError, setManualTimeframeError] = useState<string | null>(null);
  const dailyRisk = mt5Status?.bridge.dailyRisk;
  const dailyRiskMoney = (value: number) => `${mt5Status?.bridge.currency === 'USD' ? '$' : `${mt5Status?.bridge.currency || 'USD'} `}${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const scalpingEnabled = mt5Status?.config.scalpingEnabled ?? true;
  const intradayEnabled = mt5Status?.config.intradayEnabled ?? true;
  const scalpOneToOneEnabled = mt5Status?.config.scalpOneToOneEnabled === true;
  const bollingerM5Enabled = mt5Status?.config.bollingerM5Enabled === true;
  const tradeStyleEnabled = useCallback((trade: {
    tradeStyle?: 'SCALPING' | 'INTRADAY' | 'SCALP_1_1' | 'BOLLINGER_M5'; zoneTimeframe?: TradeTimeframe;
  }) => trade.tradeStyle === 'BOLLINGER_M5' || trade.tradeStyle === 'SCALP_1_1'
    || isTradeStyleEnabled({ scalpingEnabled, intradayEnabled, scalpOneToOneEnabled, bollingerM5Enabled }, trade),
  [scalpingEnabled, intradayEnabled, scalpOneToOneEnabled, bollingerM5Enabled]);
  const directTradeStyleEnabled = tradeStyleEnabled({
    tradeStyle: marketSymbol === 'XAUUSD' ? 'INTRADAY' : undefined,
    zoneTimeframe: granularity,
  });
  const overlayStyleEnabled = useCallback((overlay: TradeOverlay) => {
    const stored = (mt5Status?.recentSignals ?? []).find((signal) => (
      overlay.id === `MT5:${signal.brokerTicket}`
      || (overlay.setupId !== undefined && overlay.setupId === signal.setupId)
    ));
    return tradeStyleEnabled(stored ?? {
      tradeStyle: overlay.id.startsWith('SCALP_1_1:') || overlay.setupId?.startsWith('SCALP_1_1:')
        || overlay.label?.toUpperCase().includes('SCALP 1:1')
        ? 'SCALP_1_1' : overlay.id.startsWith('GOLD_SCALP:') || overlay.label?.includes('SCALP')
        ? 'SCALPING' : marketSymbol === 'XAUUSD' ? 'INTRADAY' : undefined,
      zoneTimeframe: overlay.chartTimeframe ?? granularity,
    });
  }, [granularity, marketSymbol, mt5Status?.recentSignals, tradeStyleEnabled]);
  const visibleMt5Positions = useMemo(() => (mt5Status?.positions ?? []).filter((position) => {
    const signal = (mt5Status?.recentSignals ?? []).find((candidate) => (
      candidate.brokerTicket === position.ticket
      || (position.setupId !== undefined && candidate.setupId === position.setupId)
    ));
    return tradeStyleEnabled(signal ?? { zoneTimeframe: position.zoneTimeframe });
  }), [mt5Status?.positions, mt5Status?.recentSignals, tradeStyleEnabled]);
  useEffect(() => { setHoveredEntry(null); }, [tradeStyleEnabled]);
  const [mt5SettingsOpen, setMt5SettingsOpen] = useState(false);
  const [mt5BridgeControlError, setMt5BridgeControlError] = useState<string | null>(null);
  const [mt5SettingsSaveError, setMt5SettingsSaveError] = useState<string | null>(null);
  const [showIndicatorControls, setShowIndicatorControls] = useState(false);
  const [showZoneComparison, setShowZoneComparison] = useState(false);
  const [showLtfChoch, setShowLtfChoch] = useState(false);
  const [comparisonTimeframe, setComparisonTimeframe] = useState<OandaGranularity | null>(null);
  const [hiddenComparisonZoneKeys, setHiddenComparisonZoneKeys] = useState<string[]>([]);
  const [zoneLengthModes, setZoneLengthModes] = useState<Record<string, 'left' | 'original' | 'live'>>({});
  const [hiddenCompletedTradeDrawings, setHiddenCompletedTradeDrawings] = useState<Set<string>>(() => new Set());
  const [showDrawingTools, setShowDrawingTools] = useState(false);
  const [activeDrawingTool, setActiveDrawingTool] = useState<ChartDrawingTool | null>(null);
  const [chartDrawings, setChartDrawings] = useState<ChartDrawing[]>(loadStoredChartDrawings);
  const [drawingDraft, setDrawingDraft] = useState<ChartDrawingDraft | null>(null);
  const [selectedDrawingId, setSelectedDrawingId] = useState<string | null>(null);
  const [showDrawingVisibility, setShowDrawingVisibility] = useState(false);
  const [drawingToolbarPosition, setDrawingToolbarPosition] = useState<{ left: number; top: number } | null>(null);
  const [drawingTextEditor, setDrawingTextEditor] = useState<ChartDrawingTextEditor | null>(null);
  const [drawingDrag, setDrawingDrag] = useState<ChartDrawingDrag | null>(null);
  const [drawingRenderVersion, setDrawingRenderVersion] = useState(0);
  const [replayIndex, setReplayIndex] = useState<number | null>(null);
  const [replayPlaying, setReplayPlaying] = useState(false);
  const [replaySelecting, setReplaySelecting] = useState(false);
  const [replaySelectionIndex, setReplaySelectionIndex] = useState<number | null>(null);
  const [replaySpeed, setReplaySpeed] = useState(1);
  const [trackedDirectTradeSetups, setTrackedDirectTradeSetups] = useState<
  Map<string, TrackedDirectTradeSetup>
  >(new Map());
  const [retainedChartTradeOverlays, setRetainedChartTradeOverlays] = useState<
  Map<string, TradeOverlay>
  >(() => loadStoredRetainedChartTrades(retainedStorageKey));
  candlesRef.current = candles;
  replaySelectingRef.current = replaySelecting;
  replaySelectionIndexRef.current = replaySelectionIndex;

  const marketConfig = oandaMarketSymbolConfig(marketSymbol);
  const mtfLtfFibRequired = mt5Status?.config.mtfLtfFibRequired === true;
  const drawingScope = `${liveChartDataSource}:${marketSymbol}`;
  hasChartDrawingLayerRef.current = drawingDraft !== null || chartDrawings.some(drawing => (
    drawing.scope === drawingScope && !drawing.hidden
    && ((drawing.visibility ?? 'all') === 'all'
      || (drawing.visibilityTimeframe ?? granularity) === granularity
      || (drawing.visibility === 'current-and-above'
        && DRAWING_TIMEFRAME_ORDER.indexOf(granularity) >= DRAWING_TIMEFRAME_ORDER.indexOf(drawing.visibilityTimeframe ?? granularity))
      || (drawing.visibility === 'current-and-below'
        && DRAWING_TIMEFRAME_ORDER.indexOf(granularity) <= DRAWING_TIMEFRAME_ORDER.indexOf(drawing.visibilityTimeframe ?? granularity)))
  ));

  useEffect(() => {
    userStorage.setItem(CHART_DRAWINGS_STORAGE_KEY, JSON.stringify(chartDrawings));
  }, [chartDrawings]);

  useEffect(() => {
    userStorage.setItem(MARKET_SYMBOL_STORAGE_KEY, marketSymbol);
  }, [marketSymbol]);

  useEffect(() => {
    try {
      userStorage.setItem(TRENDLINE_TIMEFRAMES_STORAGE_KEY,
        JSON.stringify(DRAWING_TIMEFRAME_ORDER.filter(timeframe => trendlineTimeframes.has(timeframe))));
    } catch { /* Keep the controls usable if browser storage is unavailable. */ }
  }, [trendlineTimeframes]);

  useEffect(() => {
    userStorage.setItem(
      retainedStorageKey,
      JSON.stringify([...retainedChartTradeOverlays.values()]),
    );
  }, [retainedChartTradeOverlays, retainedStorageKey]);

  useEffect(() => {
    setDrawingDraft(null);
    setDrawingDrag(null);
    setSelectedDrawingId(null);
    setShowDrawingVisibility(false);
  }, [drawingScope, granularity]);

  useEffect(() => {
    setDrawingToolbarPosition(null);
    drawingToolbarDragRef.current = null;
    setDrawingTextEditor((current) => (
      current?.drawingId === selectedDrawingId ? current : null
    ));
  }, [selectedDrawingId]);

  useEffect(() => {
    const moveToolbar = (event: MouseEvent) => {
      const drag = drawingToolbarDragRef.current;
      const pane = chartPaneRef.current;
      if (!drag || !pane) return;
      const bounds = pane.getBoundingClientRect();
      setDrawingToolbarPosition({
        left: Math.max(0, Math.min(bounds.width - drag.width, event.clientX - bounds.left - drag.offsetX)),
        top: Math.max(0, Math.min(bounds.height - drag.height, event.clientY - bounds.top - drag.offsetY)),
      });
    };
    const finishToolbarMove = () => {
      drawingToolbarDragRef.current = null;
    };
    window.addEventListener('mousemove', moveToolbar);
    window.addEventListener('mouseup', finishToolbarMove);
    return () => {
      window.removeEventListener('mousemove', moveToolbar);
      window.removeEventListener('mouseup', finishToolbarMove);
    };
  }, []);

  useEffect(() => {
    const cancelDrawing = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      setDrawingDraft(null);
      setDrawingDrag(null);
      setSelectedDrawingId(null);
      setShowDrawingVisibility(false);
      setActiveDrawingTool(null);
    };
    window.addEventListener('keydown', cancelDrawing);
    return () => window.removeEventListener('keydown', cancelDrawing);
  }, []);

  useEffect(() => {
    let cancelled = false;
    void terminalFetch('/api/journal/trades?view=dashboard', { cache: 'no-store' })
      .then(async (response) => {
        const payload = await response.json() as { ok?: boolean; trades?: AccuracyTradeRecord[] };
        if (!cancelled && response.ok && payload.ok && Array.isArray(payload.trades)) {
          setSavedJournalTrades(payload.trades);
        }
      })
      .catch(() => undefined);
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!showAccuracyTable) return;
    let cancelled = false;
    const refreshExecutedTrades = async () => {
      try {
        const response = await terminalFetch('/api/journal/trades?view=dashboard', { cache: 'no-store' });
        const payload = await response.json() as { ok?: boolean; trades?: AccuracyTradeRecord[] };
        if (!cancelled && response.ok && payload.ok && Array.isArray(payload.trades)) {
          setExecutedMt5Trades(payload.trades.filter((trade) => (
            trade.mt5Managed === true && Number.isFinite(trade.brokerTicket)
            && (trade.brokerTicket ?? 0) > 0
          )).sort((first, second) => second.completedAt - first.completedAt));
        }
      } catch { /* Keep the latest broker records while the local server reconnects. */ }
    };
    void refreshExecutedTrades();
    const timer = window.setInterval(() => void refreshExecutedTrades(), 5_000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [showAccuracyTable, terminalFetch]);

  const refreshMt5Status = useCallback(async () => {
    try {
      const [response, accountsResponse] = await Promise.all([
        terminalFetch('/api/mt5/status', { cache: 'no-store' }),
        canAdmin ? terminalFetch('/api/mt5/accounts', { cache: 'no-store' }) : Promise.resolve(Response.json({ accounts: [] })),
      ]);
      if (accountsResponse.ok) {
        const accountsPayload = await accountsResponse.json();
        if (accountsPayload.ok && Array.isArray(accountsPayload.accounts)) setTerminalAccounts(accountsPayload.accounts);
      }
      const payload = await response.json() as Mt5AutomationStatus;
      if (response.ok && payload.ok) {
        setMt5Status((current) => current
          && mt5StatusRenderSignature(current) === mt5StatusRenderSignature(payload)
          ? current
          : payload);
      }
    } catch {
      // The chart remains usable when the optional local bridge is offline.
    }
  }, []);

  useEffect(() => {
    void refreshMt5Status();
    const timer = window.setInterval(() => void refreshMt5Status(), 5_000);
    return () => window.clearInterval(timer);
  }, [refreshMt5Status]);

  const mt5JournalLifecycleSignature = useMemo(() => (
    (mt5Status?.recentSignals ?? [])
      .filter((signal) => ['ACTIVE', 'RISK_FREE', 'TP', 'SL', 'RF'].includes(signal.status))
      .map((signal) => `${signal.id}:${signal.status}:${signal.updatedAt}`)
      .sort()
      .join('|')
  ), [mt5Status?.recentSignals]);

  useEffect(() => {
    const lifecycleSignals = (mt5Status?.recentSignals ?? []).filter((signal) => (
      ['ACTIVE', 'RISK_FREE', 'TP', 'SL', 'RF'].includes(signal.status)
    ));
    const signature = mt5JournalLifecycleSignature;
    if (!signature || signature === mt5JournalImageSignatureRef.current) return;
    mt5JournalImageSignatureRef.current = signature;
    let cancelled = false;
    const prepareMt5JournalImages = async () => {
      try {
        const response = await terminalFetch('/api/journal/trades?view=pending-images', { cache: 'no-store' });
        const payload = await response.json() as { ok?: boolean; trades?: JournalTradeRecord[] };
        if (!response.ok || !payload.ok || !Array.isArray(payload.trades)) return;
        const signalIds = new Set(lifecycleSignals.map((signal) => signal.id));
        const candidates = payload.trades.filter((trade) => (
          trade.mt5Managed && trade.mt5SignalId && signalIds.has(trade.mt5SignalId)
          && (!trade.entryScreenshotDataUrl
            || (trade.lifecycleStatus === 'closed' && !trade.exitScreenshotDataUrl))
        ));
        let savedTrades: JournalTradeRecord[] | undefined;
        for (const trade of candidates) {
          if (cancelled) return;
          const entryScreenshotDataUrl = trade.entryScreenshotDataUrl
            || (trade.entrySnapshotCandles && trade.entrySnapshotCandles.length >= 2
              ? renderHistoricalTradeSnapshot(trade, trade.entrySnapshotCandles)
              : undefined);
          const exitScreenshotDataUrl = trade.lifecycleStatus === 'closed'
            ? trade.exitScreenshotDataUrl
              || (trade.exitSnapshotCandles && trade.exitSnapshotCandles.length >= 2
                ? renderHistoricalTradeSnapshot(trade, trade.exitSnapshotCandles)
                : undefined)
            : undefined;
          if (!entryScreenshotDataUrl
            || (trade.lifecycleStatus === 'closed' && !exitScreenshotDataUrl)) continue;
          const updated = {
            ...trade,
            entryScreenshotDataUrl,
            exitScreenshotDataUrl,
            screenshotDataUrl: trade.screenshotDataUrl
              || exitScreenshotDataUrl || entryScreenshotDataUrl,
          };
          const saveResponse = await terminalFetch('/api/journal/trades?view=dashboard', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ trades: [updated] }),
          });
          const savePayload = await saveResponse.json() as {
            ok?: boolean;
            trades?: JournalTradeRecord[];
          };
          if (saveResponse.ok && savePayload.ok && Array.isArray(savePayload.trades)) {
            savedTrades = savePayload.trades;
          }
        }
        if (!cancelled && savedTrades) setSavedJournalTrades(savedTrades);
      } catch {
        mt5JournalImageSignatureRef.current = '';
      }
    };
    void prepareMt5JournalImages();
    return () => { cancelled = true; };
  }, [mt5JournalLifecycleSignature]);

  const updateManualTradeTimeframe = useCallback(async (
    position: Mt5AutomationStatus['positions'][number], timeframe: string,
  ) => {
    if (!canAdmin || !mt5Status) return;
    setManualTimeframeSaving(position.ticket);
    setManualTimeframeError(null);
    try {
      const response = await terminalFetch(`/api/mt5/positions/${position.ticket}/timeframe`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeframe, account: mt5Status.bridge.account, server: mt5Status.bridge.server,
          brokerSymbol: mt5Status.bridge.brokerSymbol, identifier: position.identifier, openedAtMsc: position.openedAtMsc }),
      });
      const payload = await response.json();
      if (!response.ok || !payload.ok) throw new Error(payload.error || 'Unable to save the trade timeframe.');
      await refreshMt5Status();
    } catch (error) {
      setManualTimeframeError(error instanceof Error ? error.message : 'Unable to save the trade timeframe.');
    } finally { setManualTimeframeSaving(null); }
  }, [canAdmin, mt5Status, refreshMt5Status]);

  const updateMt5Config = useCallback(async (changes: Record<string, unknown>) => {
    if (!canAdmin || !mt5Status) return;
    setMt5SettingsSaveError(null);
    try {
      const response = await terminalFetch('/api/mt5/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changes),
      });
      const payload = await response.json() as { ok?: boolean; error?: string; config?: Mt5AutomationStatus['config'] };
      if (!response.ok || !payload.ok || !payload.config) throw new Error(payload.error || 'Unable to save MT5 settings.');
      setMt5Status((current) => current ? { ...current, config: payload.config! } : current);
    } catch (error) {
      setMt5SettingsSaveError(error instanceof Error ? error.message : 'Unable to save MT5 settings.');
    }
  }, [canAdmin, mt5Status, terminalFetch]);

  useEffect(() => {
    if (mt5Status?.config) {
      setTradingTimeEnabled(mt5Status.config.tradingTimeEnabled === true);
      setTelegramMessagesEnabled(mt5Status.config.telegramMessagesEnabled !== false);
    }
  }, [mt5Status?.config?.tradingTimeEnabled, mt5Status?.config?.telegramMessagesEnabled]);

  const controlMt5Bridge = useCallback(async (action: 'start' | 'stop') => {
    setMt5BridgeControlError(null);
    try {
      const response = await terminalFetch(`/api/mt5/bridge/${action}`, { method: 'POST' });
      const payload = await response.json() as { ok?: boolean; error?: string };
      if (!response.ok || !payload.ok) throw new Error(payload.error || `Unable to ${action} bridge.`);
      window.setTimeout(() => void refreshMt5Status(), 500);
    } catch (error) {
      setMt5BridgeControlError(error instanceof Error ? error.message : 'Bridge control failed.');
    }
  }, [refreshMt5Status]);

  const syncReplaySelectionLine = useCallback(() => {
    const line = replaySelectionLineRef.current;
    const chart = chartRef.current;
    const host = hostRef.current;
    const selectionIndex = replaySelectionIndexRef.current;
    const currentCandles = candlesRef.current;
    if (!line || !chart || !host || !replaySelectingRef.current
      || selectionIndex === null || !currentCandles[selectionIndex]) {
      if (line) line.style.display = 'none';
      return;
    }
    const coordinate = chart.timeScale().timeToCoordinate(
      currentCandles[selectionIndex].time as UTCTimestamp,
    );
    const rightEdge = Math.max(0, host.clientWidth - 72);
    if (coordinate === null || coordinate < 0 || coordinate > rightEdge) {
      line.style.display = 'none';
      return;
    }
    line.style.display = 'block';
    line.style.left = `${coordinate}px`;
  }, []);

  syncReplaySelectionLineRef.current = syncReplaySelectionLine;

  const displayCandles = useMemo(() => replayIndex === null
    ? candles
    : candles.slice(0, Math.min(candles.length, replayIndex + 1)), [candles, replayIndex]);
  const autoTrendlines = useMemo(() => trendlineTimeframes.has(granularity)
    ? detectAutoTrendlines(displayCandles, marketConfig.pipSize, true) : [],
  [displayCandles, granularity, marketConfig.pipSize, trendlineTimeframes]);
  const htfTrendlineCutoff = displayCandles.length > 0
    ? displayCandles[displayCandles.length - 1].time
      + (displayCandles[displayCandles.length - 1].complete ? TIMEFRAME_SECONDS[granularity] : 0)
    : 0;
  const htfTrendlines = useMemo<HigherTimeframeTrendline[]>(() => {
    if (htfTrendlineCutoff === 0) return [];
    const currentTime = displayCandles[displayCandles.length - 1].time;
    const sourceCutoff = replayIndex === null ? Date.now() / 1000 : htfTrendlineCutoff;
    return DRAWING_TIMEFRAME_ORDER
      .filter((timeframe) => timeframe !== granularity && trendlineTimeframes.has(timeframe))
      .flatMap((timeframe) => {
        const sourceCandles = (vipCandles[timeframe] ?? []).filter((candle) => (
          candle.complete !== false && marketCandleCloseTime(candle.time, timeframe) <= sourceCutoff
        ));
        if (sourceCandles.length < 9) return [];
        return detectAutoTrendlines(sourceCandles, marketConfig.pipSize).map((line) => ({
          id: `${marketSymbol}:${timeframe}:${sourceCandles[line.firstIndex].time}:${sourceCandles[line.secondIndex].time}:${line.firstPrice.toFixed(6)}:${line.slope.toFixed(9)}`,
          timeframe,
          sourceCandles,
          line,
          currentPrice: trendlinePriceAtTime(line, sourceCandles, timeframe, currentTime),
        }));
      });
  }, [displayCandles, granularity, htfTrendlineCutoff, marketConfig.pipSize, marketSymbol, replayIndex, trendlineTimeframes, vipCandles]);
  const vipSupportGranularities = VIP_SUPPORT_GRANULARITIES[granularity];
  const mtfLowerGranularities = useMemo(() => MTF_MAPPINGS
    .filter((mapping) => mapping.higher === granularity)
    .map((mapping) => mapping.lower), [granularity]);
  const auxiliaryGranularities = useMemo(() => Array.from(new Set<MarketGranularity>([
    // MTF cannot be evaluated until its mapped lower-timeframe candles exist.
    // Put those feeds first so the table is not left empty behind slower trend
    // and VIP-support requests.
    ...mtfLowerGranularities,
    ...vipSupportGranularities,
    ...TREND_TABLE_GRANULARITIES,
    ...AUTOMATION_GRANULARITIES,
    ...DRAWING_TIMEFRAME_ORDER,
    ...(DIRECT_ENGULFING_FALLBACKS[granularity] ?? []),
  ])).filter((value) => value !== granularity), [
    granularity,
    mtfLowerGranularities,
    vipSupportGranularities,
  ]);
  const analyzeChartStructure = useCallback((
    key: string,
    sourceCandles: OandaCandle[],
    options: Parameters<typeof analyzeMarketStructure>[1],
  ) => {
    const prepared = preparedAnalysesRef.current.get(key);
    const { vipSupport: _vipSupport, ...baseOptions } = options;
    if (prepared && prepared.optionsKey === JSON.stringify(baseOptions)
      && prepared.dependencies.every(({ key: dependencyKey, revision }) => (
        preparedAnalysesRef.current.get(dependencyKey)?.revision === revision
      )) && structureSnapshotsMatch(prepared.candles, sourceCandles)) return prepared.result;
    // Replay edits and browsers without Workers retain the original calculation.
    return analyzeMarketStructure(sourceCandles, options);
  }, []);

  useEffect(() => () => {
    analysisWorkerRef.current?.terminate();
    analysisWorkerRef.current = null;
    for (const request of analysisRequestsRef.current.values()) request.reject(new Error('Chart closed'));
    analysisRequestsRef.current.clear();
    preparedAnalysesRef.current.clear();
  }, []);

  const vipSupportContexts = useMemo(() => {
    if (displayCandles.length === 0) return [];
    const lastSourceCandle = displayCandles[displayCandles.length - 1];
    const cutoff = lastSourceCandle.time
      + (lastSourceCandle.complete ? TIMEFRAME_SECONDS[granularity] : 0);
    const contexts = vipSupportGranularities.map((supportGranularity) => {
      const completedCandles = (vipCandles[supportGranularity] || []).filter((candle) => (
        candle.complete
        && marketCandleCloseTime(candle.time, supportGranularity) <= cutoff
      ));
      const cached = supportAnalysisCacheRef.current[supportGranularity];
      const supportStructure = cached && structureSnapshotsMatch(cached.candles, completedCandles)
        ? cached.structure : analyzeChartStructure(`support:${supportGranularity}`, completedCandles, {
        allowSupplyDemand: ['H1', 'H4', 'D', 'W', 'MO'].includes(supportGranularity),
        sourceBarSeconds: TIMEFRAME_SECONDS[supportGranularity],
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[supportGranularity],
        zoneVisualBars: 30,
      });
      supportAnalysisCacheRef.current[supportGranularity] = { candles: completedCandles, structure: supportStructure };
      return {
        timeframe: GRANULARITY_LABELS[supportGranularity],
        zones: supportStructure.zones,
      };
    });
    const previous = supportContextsRef.current;
    if (previous.length === contexts.length && contexts.every((context, index) => (
      context.timeframe === previous[index].timeframe && context.zones === previous[index].zones
    ))) return previous;
    supportContextsRef.current = contexts;
    return contexts;
  }, [displayCandles, granularity, vipCandles, vipSupportGranularities]);

  const structure = useMemo(
    () => analyzeChartStructure('chart', displayCandles, {
      allowSupplyDemand: ['H1', 'H4', 'D', 'W'].includes(granularity),
      sourceBarSeconds: TIMEFRAME_SECONDS[granularity],
      confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[granularity],
      zoneVisualBars: 30,
      vipSupport: vipSupportContexts,
    }),
    [displayCandles, granularity, vipSupportContexts],
  );

  const h4SwingSource = useMemo(() => {
    if (granularity === 'D') return { candles: [] as OandaCandle[], lines: [] as StructureLine[] };
    if (granularity === 'H4') return { candles: displayCandles, lines: structure.lines };
    const h4Candles = vipCandles.H4 || [];
    if (h4Candles.length === 0) return { candles: h4Candles, lines: [] as StructureLine[] };
    const h4Structure = analyzeChartStructure('h4', h4Candles, {
      allowSupplyDemand: true,
      sourceBarSeconds: TIMEFRAME_SECONDS.H4,
      confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS.H4,
      zoneVisualBars: 30,
    });
    return { candles: h4Candles, lines: h4Structure.lines };
  }, [displayCandles, granularity, structure.lines, vipCandles]);

  const swingFibMoves = useMemo(() => {
    const seedLine = h4SwingSource.lines
      .filter((line) => line.type === 'swing'
        && line.fromTime !== line.toTime
        && line.fromPrice !== line.toPrice)
      .sort((first, second) => first.toTime - second.toTime)[0];
    if (!seedLine) return [];

    return buildAlternatingSwingFibs(h4SwingSource.candles, {
      sourceTime: seedLine.fromTime,
      sourcePrice: seedLine.fromPrice,
      zeroTime: seedLine.toTime,
      zeroPrice: seedLine.toPrice,
    });
  }, [h4SwingSource]);

  const h1SwingSource = useMemo(() => {
    if (!(fibVisibility.h1Swing || fibPreviousVisibility.h1Swing
      || (marketSymbol === 'XAUUSD' && granularity === 'M15'))
      || !['M5', 'M15', 'M30', 'H1'].includes(granularity)) {
      return { candles: [] as OandaCandle[], markers: [] as typeof structure.markers };
    }
    if (granularity === 'H1') return { candles: displayCandles, markers: structure.markers };
    const h1Candles = vipCandles.H1 || [];
    if (h1Candles.length === 0) {
      return { candles: h1Candles, markers: [] as typeof structure.markers };
    }
    const h1Structure = analyzeChartStructure('h1-swing', h1Candles, {
      allowSupplyDemand: true,
      sourceBarSeconds: TIMEFRAME_SECONDS.H1,
      confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS.H1,
      zoneVisualBars: 30,
    });
    return { candles: h1Candles, markers: h1Structure.markers };
  }, [displayCandles, fibPreviousVisibility.h1Swing, fibVisibility.h1Swing,
    granularity, marketSymbol, structure.markers, vipCandles]);

  const h1SwingFibMoves = useMemo(() => buildOneHourSwingFibs(
    h1SwingSource.candles, h1SwingSource.markers,
  ), [h1SwingSource]);

  const [dayFibCalendarDay, setDayFibCalendarDay] = useState(() => nepalDayStartUtc(Date.now() / 1000));
  useEffect(() => {
    const update = () => setDayFibCalendarDay(nepalDayStartUtc(Date.now() / 1000));
    const timer = window.setInterval(update, 1000);
    document.addEventListener('visibilitychange', update);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', update); };
  }, []);
  const dayFibAsOf = useMemo(() => replayIndex === null ? Date.now() / 1000
    : (displayCandles.at(-1)?.time ?? 0) + (displayCandles.at(-1)?.complete ? TIMEFRAME_SECONDS[granularity] : 0),
  [dayFibCalendarDay, displayCandles, granularity, replayIndex]);
  const dayFibMoves = useMemo(() => (
    ['M1', 'M5', 'M15', 'M30'].includes(granularity)
      ? buildDayFibs(displayCandles)
      : []
  ), [displayCandles, granularity]);

  const swingFibConfluence = useMemo(() => applySwingFibConfluence(
    displayCandles,
    structure.zones,
    isDaySwingFibEntryTimeframe(granularity)
      && ['M15', 'M30', 'H1'].includes(granularity)
      ? swingFibMoves
      : undefined,
  ), [displayCandles, granularity, structure.zones, swingFibMoves]);
  const dayFibConfluence = useMemo(() => applyDayFibConfluence(
    displayCandles,
    swingFibConfluence.zones,
    isDaySwingFibEntryTimeframe(granularity)
      && ['M15', 'M30'].includes(granularity)
      ? selectDayFibForTime(dayFibMoves, dayFibAsOf)
      : undefined,
    10, dayFibAsOf,
  ), [dayFibAsOf, dayFibMoves, displayCandles, granularity, swingFibConfluence.zones]);
  const h1PostChochZones = useMemo(() => (
    marketSymbol === 'XAUUSD' && granularity === 'M15'
      ? applyPostChochH1SwingFibConfluence(
        displayCandles, dayFibConfluence.zones, structure.lines, h1SwingFibMoves,
      )
      : dayFibConfluence.zones
  ), [dayFibConfluence.zones, displayCandles, granularity, h1SwingFibMoves,
    marketSymbol, structure.lines]);
  const displayZones = useMemo(() => {
    const fallbackGranularities = DIRECT_ENGULFING_FALLBACKS[granularity] ?? [];
    const latestChartCandle = displayCandles[displayCandles.length - 1];
    if (!latestChartCandle) return h1PostChochZones;
    const cutoff = timeframeWindowCutoff(
      latestChartCandle.time,
      TIMEFRAME_SECONDS[granularity],
    );
    let zones = fallbackGranularities.reduce((currentZones, fallbackGranularity) => {
      const fallbackCandles = (vipCandles[fallbackGranularity] || []).filter((candle) => (
        candle.complete && marketCandleCloseTime(candle.time, fallbackGranularity) <= cutoff
      ));
      return applyTradeableZoneEngulfingFallback(
        fallbackCandles,
        currentZones,
        fallbackGranularity,
        granularity === 'H1',
      );
    }, h1PostChochZones);
    if (granularity === 'M1') {
      const dailyCandles = (vipCandles.D || []).filter((candle) => candle.time <= cutoff);
      zones = applyOneMinuteGenesisQml(zones, displayCandles, dailyCandles);
    }
    return zones;
  }, [displayCandles, granularity, h1PostChochZones, vipCandles]);
  const opposingGoldZones = useMemo(() => {
    if (marketSymbol !== 'XAUUSD') return [] as StructureZone[];
    const latest = displayCandles[displayCandles.length - 1];
    if (!latest) return [] as StructureZone[];
    const cutoff = latest.time + (latest.complete ? TIMEFRAME_SECONDS[granularity] : 0);
    const confirmationCandles = { ...vipCandles, [granularity]: displayCandles };
    const m15Candles = confirmationCandles.M15 ?? [];
    const confirmationOptions = { requireLtfFib: mtfLtfFibRequired,
      m15Structure: granularity === 'M15' ? structure : analyzeChartStructure('opposing:M15', m15Candles, {
        allowSupplyDemand: false, sourceBarSeconds: TIMEFRAME_SECONDS.M15,
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS.M15, zoneVisualBars: 30,
      }) };
    return (['M15', 'H1', 'H4'] as const).flatMap((timeframe) => {
      if (timeframe === granularity) return prepareGoldOpposingZones(displayZones, timeframe, confirmationCandles, confirmationOptions);
      const support = vipSupportContexts.find((context) => context.timeframe === GRANULARITY_LABELS[timeframe]);
      if (support) return prepareGoldOpposingZones(support.zones, timeframe, confirmationCandles, confirmationOptions);
      const sourceCandles = (vipCandles[timeframe] ?? []).filter((candle) => candle.time <= cutoff);
      if (sourceCandles.length === 0) return [];
      return prepareGoldOpposingZones(analyzeChartStructure(`opposing:${timeframe}`, sourceCandles, {
        allowSupplyDemand: timeframe !== 'M15',
        sourceBarSeconds: TIMEFRAME_SECONDS[timeframe],
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[timeframe],
        zoneVisualBars: 30,
      }).zones, timeframe, confirmationCandles, confirmationOptions);
    });
  }, [analyzeChartStructure, displayCandles, displayZones, granularity, marketSymbol, mtfLtfFibRequired, structure, vipCandles, vipSupportContexts]);
  const consolidatedDisplayZones = useMemo(
    () => consolidateZonesForDisplay(displayZones, marketConfig.pipSize),
    [displayZones, marketConfig.pipSize],
  );
  const redundantStandaloneZoneIds = useMemo(
    () => redundantStandaloneLiquidityZoneIds(displayZones, marketConfig.pipSize),
    [displayZones, marketConfig.pipSize],
  );
  const blockedGoldChartEntry = useMemo(() => {
    const trendCache = new Map<string, ReturnType<typeof analyzeMarketStructure>['trend']>();
    const blockedCache = new Map<string, boolean>();
    const trendAt = (timeframe: 'M15' | 'H1', cutoff: number) => {
      const key = `${timeframe}:${cutoff}`;
      const cached = trendCache.get(key);
      if (cached) return cached;
      const source = granularity === timeframe ? displayCandles : vipCandles[timeframe] ?? [];
      const completed = source.filter((candle) => (
        candle.complete !== false && candle.time + TIMEFRAME_SECONDS[timeframe] <= cutoff
      ));
      if (completed.length === 0) return undefined;
      const trend = analyzeMarketStructure(completed, {
        allowSupplyDemand: timeframe === 'H1',
        sourceBarSeconds: TIMEFRAME_SECONDS[timeframe],
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[timeframe],
        zoneVisualBars: 30,
      }).trend;
      trendCache.set(key, trend);
      return trend;
    };
    return (signalTime: number, signalTimeframe: TradeTimeframe,
      direction: 'bullish' | 'bearish', scalpingEntry = false) => {
      if (marketSymbol !== 'XAUUSD' || direction !== 'bullish'
        || (signalTimeframe !== 'M1' && !(scalpingEntry && signalTimeframe === 'M5'))) return false;
      const key = `${signalTime}:${signalTimeframe}:${scalpingEntry}`;
      const cached = blockedCache.get(key);
      if (cached !== undefined) return cached;
      const cutoff = signalTime + TIMEFRAME_SECONDS[signalTimeframe];
      const m15Trend = trendAt('M15', cutoff);
      const h1Trend = trendAt('H1', cutoff);
      const blocked = goldM1BuyCountertrendBlocked(signalTimeframe, 'BUY', m15Trend, h1Trend)
        || (scalpingEntry && goldM5ScalpingBuyCountertrendBlocked(
          signalTimeframe, 'BUY', m15Trend, h1Trend,
        ));
      blockedCache.set(key, blocked);
      return blocked;
    };
  }, [displayCandles, granularity, marketSymbol, vipCandles]);
  const blockedGoldHistoricalTrade = useCallback((record: AccuracyTradeRecord) => {
    if (marketSymbol !== 'XAUUSD' || (record.symbol ?? 'XAUUSD') !== 'XAUUSD'
      || record.direction !== 'bullish') return false;
    const scalpCandle = record.source === 'ENGULFING' && record.tradeStyle === 'SCALPING';
    if (record.signalTimeframe !== 'M1' && !(scalpCandle && record.signalTimeframe === 'M5')) return false;
    const bias = record.biasAtEntry;
    if (bias?.M15 !== undefined && bias.H1 !== undefined) {
      return goldM1BuyCountertrendBlocked(record.signalTimeframe, 'BUY', bias.M15, bias.H1)
        || (scalpCandle && goldM5ScalpingBuyCountertrendBlocked(
          record.signalTimeframe, 'BUY', bias.M15, bias.H1,
        ));
    }
    return record.signalAt !== undefined && blockedGoldChartEntry(
      record.signalAt, record.signalTimeframe, record.direction, scalpCandle,
    );
  }, [blockedGoldChartEntry, marketSymbol]);
  const visibleSavedJournalTrades = useMemo(() => savedJournalTrades.filter((record) => (
    record.mt5Managed || record.brokerTicket !== undefined || record.mt5SignalId
    || record.id.startsWith('MT5:')
    || (!(marketSymbol === 'XAUUSD' && (record.symbol ?? 'XAUUSD') === 'XAUUSD'
      && record.tradeStyle !== 'SCALPING' && record.tradeStyle !== 'SCALP_1_1' && record.tradeStyle !== 'BOLLINGER_M5' && !record.intradayEntry)
      && (record.signalAt === undefined || !blockedGoldChartEntry(record.signalAt, record.signalTimeframe, record.direction)))
  )), [blockedGoldChartEntry, savedJournalTrades, marketSymbol]);
  const visibleRetainedChartTradeOverlays = useMemo(() => [
    ...retainedChartTradeOverlays.values(),
  ].filter((overlay) => (
    overlay.id.startsWith('MT5:') || !blockedGoldChartEntry(
      overlay.trade.signal.time, overlay.trade.signal.timeframe,
      overlay.trade.signal.direction,
    )
  )), [blockedGoldChartEntry, retainedChartTradeOverlays]);
  const extremeAPlusTjl2Selection = useMemo(
    () => selectExtremeAPlusTjl2Zones(displayZones, marketConfig.pipSize),
    [displayZones, marketConfig.pipSize],
  );
  const redundantRetainedOverlayIds = useMemo(() => new Set(
    [...retainedChartTradeOverlays.values()]
      .filter((overlay) => (overlay.symbol ?? 'XAUUSD') === marketSymbol
        && overlay.chartTimeframe === granularity
        && retainedLiquidityTradeDuplicatesConfluence(
          overlay,
          consolidatedDisplayZones,
          displayCandles,
        ))
      .map((overlay) => overlay.id),
  ), [consolidatedDisplayZones, displayCandles, granularity, marketSymbol, retainedChartTradeOverlays]);

  const zoneEntryRecords = useMemo<ZoneTradeRecord[]>(() => [
    ...visibleSavedJournalTrades.filter(confirmedBrokerZoneEntry),
    ...(mt5Status?.recentSignals ?? []).filter(confirmedBrokerZoneEntry)
      .map((signal) => ({ ...signal, signalAt: signal.signalAt })),
  ], [visibleSavedJournalTrades, mt5Status?.recentSignals]);

  // Preserve Gold's original tracking identity exactly. Currency pairs receive
  // their own symbol-prefixed scopes without changing Gold's entry lifecycle.
  const tradeTrackingScope = marketSymbol === 'XAUUSD'
    ? `${liveChartDataSource}:${granularity}:${replayIndex === null ? 'live' : 'replay'}`
    : `${marketSymbol}:${liveChartDataSource}:${granularity}:${replayIndex === null ? 'live' : 'replay'}`;
  const pendingM15DbBlocksSignal = useCallback((zone: StructureZone, signal: EngulfingTradeSignal) => {
    if (granularity !== 'M15' || signal.timeframe !== 'M15') return false;
    const signalCandle = displayCandles.find((candle) => candle.time === signal.time);
    if (!signalCandle) return false;
    return displayZones.some((db) => db.name === 'DB' && db.active
      && db.m15H1ChochClosePending
      && db.isBuy === zone.isBuy
      && signal.time >= (db.chochTime ?? db.startTime)
      && zone.bottom <= db.top && db.bottom <= zone.top
      && signalCandle.low <= db.top && signalCandle.high >= db.bottom);
  }, [displayCandles, displayZones, granularity]);
  const expiredGoldZoneBeforeSignal = useCallback((
    zone: StructureZone,
    signal: EngulfingTradeSignal,
    entry?: { price: number; filledAt: number; stopLoss: number },
  ) => (
    marketSymbol === 'XAUUSD' && isGoldZoneEntryBlocked(
      zone, displayCandles, granularity, marketConfig.pipSize, signal.time, entry,
    )
  ), [displayCandles, granularity, marketConfig.pipSize, marketSymbol]);
  const currentDirectTradeSetups = useMemo(() => {
    const setups = new Map<string, TrackedDirectTradeSetup>();
    const zoneTimeframe = granularity as TradeTimeframe;
    for (const zone of displayZones) {
      if (redundantStandaloneZoneIds.has(zone.id)) continue;
      if (extremeAPlusTjl2Selection.blockedZoneIds.has(zone.id)) continue;
      if (!isZoneEligibleForEngulfingEntry(zone)) continue;
      const signal = resolveZoneEngulfingSignal(zone, zoneTimeframe);
      if (!signal) continue;
      if (pendingM15DbBlocksSignal(zone, signal) || expiredGoldZoneBeforeSignal(zone, signal)) continue;
      if (marketSymbol === 'XAUUSD'
        && !isGoldIntradayCandleRoute(zoneTimeframe, signal.timeframe)) continue;
      const rule = getDirectTradeRule(zoneTimeframe, signal.timeframe);
      if (!rule) continue;
      setups.set(`${tradeTrackingScope}:${tradeZoneExecutionKey({
        symbol: marketSymbol, zoneTimeframe, zoneId: zone.id,
      })}`, {
        scope: tradeTrackingScope,
        zone: { ...zone },
        signal,
        rule,
      });
    }
    return setups;
  }, [displayZones, expiredGoldZoneBeforeSignal, extremeAPlusTjl2Selection.blockedZoneIds, granularity, marketSymbol, pendingM15DbBlocksSignal, redundantStandaloneZoneIds, tradeTrackingScope]);

  useEffect(() => {
    setTrackedDirectTradeSetups((existing) => {
      let changed = false;
      const next = new Map<string, TrackedDirectTradeSetup>(existing);
      for (const [key, setup] of next) {
        if (setup.scope === tradeTrackingScope
          && extremeAPlusTjl2Selection.blockedZoneIds.has(setup.zone.id)) {
          next.delete(key);
          changed = true;
        }
      }
      for (const [key, setup] of currentDirectTradeSetups) {
        // A zone gets one entry only. Once its first valid engulfing has been
        // captured, a later T1/T2/T3/T4 on that same zone cannot replace it.
        if (!next.has(key)) {
          next.set(key, setup);
          changed = true;
        }
      }
      return changed ? next : existing;
    });
  }, [currentDirectTradeSetups, extremeAPlusTjl2Selection.blockedZoneIds, tradeTrackingScope]);

  const directZoneEntryDecisions = useMemo(() => {
    const decisions = new Map<string, DirectZoneEntryDecision>();
    if (!marketConfig.mt5AutomationEnabled) return decisions;
    const latestChartCandle = displayCandles[displayCandles.length - 1];
    if (!latestChartCandle) return decisions;
    const cutoff = timeframeWindowCutoff(
      latestChartCandle.time,
      TIMEFRAME_SECONDS[granularity],
    );
    const setups = new Map<string, TrackedDirectTradeSetup>();
    for (const setup of trackedDirectTradeSetups.values()) {
      if (setup.scope === tradeTrackingScope
        && (marketSymbol !== 'XAUUSD'
          || isGoldIntradayCandleRoute(granularity, setup.signal.timeframe))
        && !redundantStandaloneZoneIds.has(setup.zone.id)
        && !extremeAPlusTjl2Selection.blockedZoneIds.has(setup.zone.id)) {
        const liveZone = displayZones.find(zone => zone.id === setup.zone.id);
        const source = setup.signal.timeframe === granularity ? displayCandles : vipCandles[setup.signal.timeframe] ?? [];
        // An unexecuted cached paper setup must still pass today's exact zone/Fib signal checks.
        if (replayIndex === null && !isUnfilledDirectSetupQualified({
          zone: liveZone, signal: setup.signal, zoneTimeframe: granularity, sourceCandles: source,
          goldZone: marketSymbol === 'XAUUSD' ? { candles: displayCandles, pipSize: marketConfig.pipSize } : undefined,
        })) continue;
        setups.set(setup.zone.id, setup);
      }
    }
    for (const setup of currentDirectTradeSetups.values()) {
      if (!setups.has(setup.zone.id)) setups.set(setup.zone.id, setup);
    }

    for (const setup of setups.values()) {
      const liveZone = displayZones.find((zone) => zone.id === setup.zone.id);
      const currentZone = liveZone ?? setup.zone;
      if (pendingM15DbBlocksSignal(currentZone, setup.signal)
        || expiredGoldZoneBeforeSignal(currentZone, setup.signal)) continue;
      const sourceCandles = setup.signal.timeframe === granularity
        ? displayCandles
        : (vipCandles[setup.signal.timeframe] || []).filter((candle) => (
          marketCandleCloseTime(candle.time, setup.signal.timeframe) <= cutoff
        ));
      const executionCandles = TIMEFRAME_SECONDS[setup.signal.timeframe]
        < TIMEFRAME_SECONDS[granularity]
        ? sourceCandles
        : displayCandles;
      const policy = resolveDirectEntryPolicy({
        zoneTimeframe: granularity,
        signal: setup.signal,
        sourceCandles,
        baseRule: setup.rule,
      });
      const signalClose = setup.signal.time + TIMEFRAME_SECONDS[setup.signal.timeframe];
      const earlierEntry = findEarlierZoneEntry({
        symbol: marketSymbol, zoneTimeframe: granularity,
        zoneId: setup.zone.id, signalAt: setup.signal.time,
      }, zoneEntryRecords);
      if (earlierEntry) {
        // Keep the execution block, but show a concurrent 15M/30M confirmation
        // as a chart reference when both describe the already-used entry event.
        const sameConfirmation = isSameZoneEntryConfirmation({
          symbol: marketSymbol, zoneTimeframe: granularity, zoneId: setup.zone.id,
          signalAt: setup.signal.time, signalTimeframe: setup.signal.timeframe,
        }, earlierEntry);
        const reference = sameConfirmation && policy.allowed && policy.rule
          ? calculateTradeLevels({ sourceCandles, executionCandles, signal: setup.signal,
            rule: policy.rule, riskFreeEnabled: marketSymbol !== 'XAUUSD',
            omitStopBuffer: marketSymbol !== 'XAUUSD' && isDeepDiscountTradeSignal(currentZone, setup.signal) })
          : undefined;
        decisions.set(setup.zone.id, {
          policy: { ...policy, allowed: false, rule: undefined, reason: 'zone-used' },
          usedZoneTrade: reference?.filledAt !== undefined ? reference : undefined,
          oppositePositionOpen: false,
        });
        continue;
      }
      if (!policy.allowed || !policy.rule) {
        decisions.set(setup.zone.id, { policy, oppositePositionOpen: false });
        continue;
      }
      const adjusted = applyOppositePositionRewardRisk(
        policy.rule,
        replayIndex === null && marketSymbol !== 'XAUUSD' ? mt5Status?.positions : undefined,
        setup.signal.direction,
      );
      const trade = calculateTradeLevels({
        sourceCandles,
        executionCandles,
        signal: setup.signal,
        rule: adjusted.rule,
        riskFreeEnabled: marketSymbol !== 'XAUUSD',
        omitStopBuffer: marketSymbol !== 'XAUUSD'
          && isDeepDiscountTradeSignal(currentZone, setup.signal),
      });
      if (trade && trade.filledAt === undefined && !isUnfilledDirectSetupQualified({
        zone: liveZone,
        signal: setup.signal,
        zoneTimeframe: granularity,
        sourceCandles,
        goldZone: marketSymbol === 'XAUUSD'
          ? { candles: displayCandles, pipSize: marketConfig.pipSize } : undefined,
      })) continue;
      const firstOutsideTradingTime = tradingTimeEnabled && (!isNepalTradingTime(signalClose)
        || (trade?.filledAt !== undefined && !isNepalTradingTime(trade.filledAt)));
      const attempts = trade ? [trade] : [];
      if (firstOutsideTradingTime) {
        decisions.set(setup.zone.id, {
          policy: { ...policy, allowed: false, rule: undefined, reason: 'outside-trading-time' },
          previewTrade: trade,
          trades: attempts,
          oppositePositionOpen: false,
        });
        continue;
      }
      const opposingZoneBlock = marketSymbol === 'XAUUSD' && trade
        ? goldOpposingZoneBeforeOneR({
          direction: setup.signal.direction === 'bullish' ? 'BUY' : 'SELL',
          entry: trade.entry,
          stopLoss: trade.stopLoss,
          signalAt: setup.signal.time,
          calculatedAt: signalClose,
        }, opposingGoldZones)
        : undefined;
      if (opposingZoneBlock) {
        decisions.set(setup.zone.id, {
          policy,
          oppositePositionOpen: false,
          opposingZoneBlock,
        });
        continue;
      }
      decisions.set(setup.zone.id, {
        policy,
        trade,
        trades: attempts,
        oppositePositionOpen: adjusted.oppositePositionOpen,
      });
    }
    return decisions;
  }, [
    currentDirectTradeSetups,
    displayCandles,
    displayZones,
    extremeAPlusTjl2Selection.blockedZoneIds,
    granularity,
    expiredGoldZoneBeforeSignal,
    marketConfig.mt5AutomationEnabled,
    marketConfig.pipSize,
    mt5Status?.positions,
    opposingGoldZones,
    pendingM15DbBlocksSignal,
    replayIndex,
    redundantStandaloneZoneIds,
    trackedDirectTradeSetups,
    tradeTrackingScope,
    tradingTimeEnabled,
    vipCandles,
    zoneEntryRecords,
  ]);
  const directZoneTrades = useMemo(() => {
    const trades = new Map<string, TradeLevels>();
    for (const [zoneId, decision] of directZoneEntryDecisions) {
      if (decision.trade) trades.set(zoneId, decision.trade);
    }
    return trades;
  }, [directZoneEntryDecisions]);
  const displayedTapCount = useCallback((zone: DisplayStructureZone): number | undefined => {
    if (marketSymbol !== 'XAUUSD') return confluenceLatestTap(zone)?.count;
    const trade = confluenceMapValue<TradeLevels>(zone, directZoneTrades);
    const entry = trade?.filledAt === undefined ? undefined
      : { price: trade.entry, filledAt: trade.filledAt, stopLoss: trade.stopLoss };
    const latestMember = displayZoneMembers(zone)
      .filter((member) => member.tapTime !== undefined)
      .sort((first, second) => (second.lastTapTime ?? second.tapTime ?? 0)
        - (first.lastTapTime ?? first.tapTime ?? 0))[0];
    return latestMember
      ? getGoldZoneTapState(latestMember, displayCandles, granularity,
        marketConfig.pipSize, Infinity, entry).tapIndices.length
      : undefined;
  }, [directZoneTrades, displayCandles, granularity, marketConfig.pipSize, marketSymbol]);
  const directZoneMt5Signals = useMemo(() => {
    const signals = new Map<string, Mt5StoredSignal>();
    if (replayIndex !== null || liveChartDataSource !== 'MT5') return signals;
    const setupPrefix = `DIRECT:${granularity}:`;
    for (const signal of mt5Status?.recentSignals ?? []) {
      if (signal.source !== 'ENGULFING' || !signal.setupId?.startsWith(setupPrefix)) continue;
      const zoneId = signal.setupId.slice(setupPrefix.length);
      if (!zoneId || signals.has(zoneId)) continue;
      const trade = directZoneTrades.get(zoneId);
      if (!trade || signal.signalAt !== trade.signal.time
        || signal.signalTimeframe !== trade.signal.timeframe) continue;
      signals.set(zoneId, signal);
    }
    return signals;
  }, [directZoneTrades, granularity, liveChartDataSource, mt5Status?.recentSignals, replayIndex]);

  const restorePresentChartView = useCallback(() => {
    const chart = chartRef.current;
    const host = hostRef.current;
    if (!chart || !host || displayCandles.length === 0) return;
    const lastIndex = displayCandles.length - 1;
    const plotWidth = Math.max(
      PRESENT_VIEW_BAR_SPACING * 72,
      host.clientWidth - PRESENT_VIEW_PRICE_SCALE_WIDTH,
    );
    const totalVisibleSlots = Math.max(
      72,
      Math.floor(plotWidth / PRESENT_VIEW_BAR_SPACING),
    );
    const rightOffset = Math.max(
      12,
      Math.round(totalVisibleSlots * PRESENT_VIEW_RIGHT_GAP_RATIO),
    );
    const visibleCandleCount = Math.max(
      48,
      totalVisibleSlots - rightOffset,
    );
    chart.timeScale().setVisibleLogicalRange({
      from: Math.max(0, lastIndex - visibleCandleCount + 1),
      to: lastIndex + rightOffset,
    });
    window.requestAnimationFrame(() => {
      redrawZonesRef.current();
      syncReplaySelectionLineRef.current();
    });
  }, [displayCandles.length]);

  const tableTimeframeData = useMemo(() => {
    const replayCutoff = replayIndex === null || displayCandles.length === 0
      ? undefined
      : displayCandles[displayCandles.length - 1].time
        + (displayCandles[displayCandles.length - 1].complete ? TIMEFRAME_SECONDS[granularity] : 0);
    const data: Partial<Record<OandaGranularity, {
      candles: OandaCandle[];
      structure: ReturnType<typeof analyzeMarketStructure>;
    }>> = {};
    for (const tableGranularity of Array.from(new Set([
      ...TREND_TABLE_GRANULARITIES,
      ...AUTOMATION_GRANULARITIES,
    ]))) {
      const availableCandles = tableGranularity === granularity
        ? displayCandles
        : vipCandles[tableGranularity] || [];
      const timeframeCandles = replayCutoff === undefined
        ? availableCandles
        : availableCandles.filter((candle) => candle.time <= replayCutoff);
      if (timeframeCandles.length === 0) continue;
      const cached = tableAnalysisCacheRef.current[tableGranularity];
      const timeframeStructure = tableGranularity === granularity
          ? structure
          : cached && structureSnapshotsMatch(cached.candles, timeframeCandles)
            ? cached.structure : analyzeChartStructure(`table:${tableGranularity}`, timeframeCandles, {
          allowSupplyDemand: ['H1', 'H4', 'D'].includes(tableGranularity),
          sourceBarSeconds: TIMEFRAME_SECONDS[tableGranularity],
          confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[tableGranularity],
          zoneVisualBars: 30,
          });
      tableAnalysisCacheRef.current[tableGranularity] = {
        candles: timeframeCandles,
        structure: timeframeStructure,
      };
      data[tableGranularity] = {
        candles: timeframeCandles,
        structure: timeframeStructure,
      };
      const context = data[tableGranularity]!;
      const supplyDemandFibZones = new Map(applySwingFibConfluence(
        timeframeCandles,
        context.structure.zones.filter((zone) => zone.category === 'supplyDemand'),
        swingFibMoves,
      ).zones.map((zone) => [zone.id, zone]));
      context.structure = { ...context.structure, zones: context.structure.zones.map((zone) => (
        supplyDemandFibZones.get(zone.id) ?? zone
      )) };
    }
    return data;
  }, [displayCandles, granularity, replayIndex, structure, swingFibMoves, vipCandles]);
  // Mouse/viewport renders must not invalidate the market-data calculation graph.
  // Refresh the display cutoff when candle inputs (including auxiliary feeds) change.
  const tradeDisplayAsOf = useMemo(() => replayIndex === null ? Date.now() / 1000
    : (displayCandles.at(-1)?.time ?? 0) + (displayCandles.at(-1)?.complete ? TIMEFRAME_SECONDS[granularity] : 0),
  [replayIndex, displayCandles, granularity, tableTimeframeData]);
  const hasTradeDisplayExpired = useCallback((trade: TradeDisplayState | undefined) => {
    const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
    return tradeDisplayExpired(trade, timeframe ? tableTimeframeData[timeframe]?.candles ?? [] : [], tradeDisplayAsOf);
  }, [tableTimeframeData, tradeDisplayAsOf]);
  const hasTradeDrawingExpired = useCallback((trade: TradeDisplayState | undefined) => {
    const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
    return tradeDrawingExpired(trade, timeframe ? tableTimeframeData[timeframe]?.candles ?? [] : [], tradeDisplayAsOf);
  }, [tableTimeframeData, tradeDisplayAsOf]);
  const hasZoneTableTradeExpired = useCallback((trade: TradeDisplayState | undefined, zone?: DisplayStructureZone) => {
    const timeframe = trade?.signal?.timeframe ?? trade?.signalTimeframe;
    const tapTime = zone ? confluenceLatestTap(zone)?.time : trade?.signal?.time;
    const tapBarsAgo = tapTime !== undefined
      ? Math.max(zone ? confluenceTapBarsAgo(zone) ?? 0 : 0,
        displayCandles.filter(candle => candle.time > tapTime).length)
      : zone ? confluenceTapBarsAgo(zone) ?? Infinity : Infinity;
    return zoneTableTradeExpired(trade, tapBarsAgo,
      timeframe ? tableTimeframeData[timeframe]?.candles ?? [] : [], tradeDisplayAsOf,
      zone ? displayedTapCount(zone) : undefined, marketSymbol);
  }, [displayCandles, tableTimeframeData, tradeDisplayAsOf, displayedTapCount, marketSymbol]);
  const hasRetainedDirectTradeSource = useCallback((overlay: TradeOverlay) => {
    const sourceZoneId = directTradeOverlayZoneId(overlay);
    const sourceZone = overlay.id.startsWith('DIRECT:')
      ? displayZones.find((zone) => zone.id === sourceZoneId)
      : undefined;
    if (sourceZone && (pendingM15DbBlocksSignal(sourceZone, overlay.trade.signal)
      || expiredGoldZoneBeforeSignal(sourceZone, overlay.trade.signal))) return false;
    const signalTimeframe = overlay.trade.signal.timeframe;
    const sourceTimeframes = AUTOMATION_GRANULARITIES.filter((timeframe) => (
      getDirectTradeRule(timeframe, signalTimeframe) !== undefined
    ));
    return retainedDirectTradeHasSource({
      id: overlay.id,
      setupId: overlay.setupId,
      label: overlay.label,
      signalTime: overlay.trade.signal.time,
      direction: overlay.trade.signal.direction,
    }, tableTimeframeData[signalTimeframe]?.candles, sourceTimeframes.map((timeframe) => (
      timeframe === granularity
        ? displayZones
        : tableTimeframeData[timeframe]?.structure.zones
    )));
  }, [displayZones, expiredGoldZoneBeforeSignal, granularity, pendingM15DbBlocksSignal, tableTimeframeData]);
  const ltfChochContext = useMemo(() => {
    if (!showLtfChoch || !comparisonTimeframe
      || DRAWING_TIMEFRAME_ORDER.indexOf(comparisonTimeframe)
        >= DRAWING_TIMEFRAME_ORDER.indexOf(granularity)) return null;
    const lowerData = tableTimeframeData[comparisonTimeframe];
    const chartTime = displayCandles[displayCandles.length - 1]?.time;
    if (!lowerData || chartTime === undefined) return null;
    const lowerTime = lowerData.candles[lowerData.candles.length - 1]?.time ?? chartTime;
    const currentTime = Math.min(Math.max(chartTime, lowerTime),
      chartTime + TIMEFRAME_SECONDS[granularity] - 1);
    return selectLtfChochContext(displayZones, lowerData.structure.zones,
      lowerData.structure.lines, currentTime, lowerData.candles,
      marketSymbol === 'XAUUSD' && granularity === 'M15' && comparisonTimeframe === 'M1');
  }, [comparisonTimeframe, displayCandles, displayZones, granularity, marketSymbol, showLtfChoch, tableTimeframeData]);
  const comparisonZones = useMemo(() => {
    if (!comparisonTimeframe || comparisonTimeframe === granularity) return [];
    if (ltfChochContext) return ltfChochContext.zones;
    const sourceZones = tableTimeframeData[comparisonTimeframe]?.structure.zones ?? [];
    const currentTime = displayCandles[displayCandles.length - 1]?.time;
    return currentTime === undefined ? [] : selectRecentComparisonZones(
      sourceZones, displayZones, currentTime,
    );
  }, [comparisonTimeframe, displayCandles, displayZones, granularity, ltfChochContext, tableTimeframeData]);
  const visibleComparisonZones = useMemo(() => comparisonZones.filter(({ zone }) => (
    !hiddenComparisonZoneKeys.includes(`${marketSymbol}:${comparisonTimeframe}:${zone.id}`)
  )), [comparisonTimeframe, comparisonZones, hiddenComparisonZoneKeys, marketSymbol]);
  const oneMinuteScalpingZones = useMemo(() => (
    marketSymbol === 'XAUUSD' && granularity === 'M1'
      ? (tableTimeframeData.M15?.structure.zones ?? []).filter((zone) => (
        zone.active && zone.status === 'valid'
        && isGoldScalpingZone('M15', goldScalpingZoneWidthPips(zone))
      ))
      : []
  ), [granularity, marketSymbol, tableTimeframeData]);

  const trendTableRows = useMemo<TrendTableRow[]>(() => (
    TREND_TABLE_GRANULARITIES.map((tableGranularity) => {
      const timeframeData = tableTimeframeData[tableGranularity];
      const latestTimeframeCandle = timeframeData?.candles[timeframeData.candles.length - 1];
      return {
        granularity: tableGranularity,
        label: TREND_TABLE_LABELS[tableGranularity],
        trend: timeframeData?.structure.trend ?? 'neutral',
        closesAt: latestTimeframeCandle
          ? marketCandleCloseTime(latestTimeframeCandle.time, tableGranularity)
          : undefined,
      };
    })
  ), [tableTimeframeData]);

  const extremeAPlusMtfBlockedZoneIds = useMemo(() => {
    const blockedByTimeframe = new Map<string, Set<string>>();
    for (const tableGranularity of Object.keys(tableTimeframeData) as OandaGranularity[]) {
      const timeframeData = tableTimeframeData[tableGranularity];
      if (!timeframeData) continue;
      blockedByTimeframe.set(
        tableGranularity,
        selectExtremeAPlusTjl2Zones(
          timeframeData.structure.zones,
          marketConfig.pipSize,
        ).blockedZoneIds,
      );
    }
    return blockedByTimeframe;
  }, [marketConfig.pipSize, tableTimeframeData]);
  const goldScalpingCandidates = useMemo(() => {
    if (marketSymbol !== 'XAUUSD') return [];
    const rows: Array<{
      zone: StructureZone;
      zoneTimeframe: 'M15' | 'H1';
      trade: TradeLevels;
      countertrendBlocked: boolean;
      opposingZoneBlock?: NonNullable<ReturnType<typeof goldOpposingZoneBeforeOneR>>;
    }> = [];
    for (const zoneTimeframe of ['M15', 'H1'] as const) {
      const zoneData = tableTimeframeData[zoneTimeframe];
      if (!zoneData) continue;
      let zones = applySwingFibConfluence(
        zoneData.candles, zoneData.structure.zones, swingFibMoves,
      ).zones;
      if (zoneTimeframe === 'M15') {
        const dayMoves = buildDayFibs(zoneData.candles);
        zones = applyDayFibConfluence(
          zoneData.candles, zones, selectDayFibForTime(dayMoves, dayFibAsOf), 10, dayFibAsOf,
        ).zones;
      }
      for (const zone of zones) {
        if (extremeAPlusMtfBlockedZoneIds.get(zoneTimeframe)?.has(zone.id)) continue;
        const signalTimeframe = goldScalpingCandleTimeframe(
          zoneTimeframe, goldScalpingZoneWidthPips(zone),
        );
        const signalData = signalTimeframe && tableTimeframeData[signalTimeframe];
        if (!signalTimeframe || !signalData) continue;
        const signal = findGoldScalpingCandleSignal(
          zone, zoneTimeframe, signalData.candles,
        );
        const rule = goldScalpingTradeRule(zoneTimeframe, signalTimeframe);
        if (!signal || !rule) continue;
        if (findEarlierZoneEntry({ symbol: marketSymbol, zoneTimeframe,
          zoneId: zone.id, signalAt: signal.time }, zoneEntryRecords)) continue;
        if (isGoldZoneEntryBlocked(
          zone, zoneData.candles, zoneTimeframe, marketConfig.pipSize, signal.time,
        )) continue;
        const trade = calculateTradeLevels({
          sourceCandles: signalData.candles,
          executionCandles: signalData.candles,
          signal,
          rule,
        });
        if (!trade) continue;
        const opposingZoneBlock = goldOpposingZoneBeforeOneR({
          direction: signal.direction === 'bullish' ? 'BUY' : 'SELL',
          entry: trade.entry,
          stopLoss: trade.stopLoss,
          signalAt: signal.time,
          calculatedAt: trade.calculatedAt,
        }, opposingGoldZones);
        rows.push({ zone, zoneTimeframe, trade, countertrendBlocked: blockedGoldChartEntry(
          signal.time, signal.timeframe, signal.direction, true,
        ), opposingZoneBlock });
      }
    }
    return rows;
  }, [dayFibAsOf, blockedGoldChartEntry, extremeAPlusMtfBlockedZoneIds, marketConfig.pipSize, marketSymbol, opposingGoldZones, swingFibMoves, tableTimeframeData, zoneEntryRecords]);
  const goldScalpingAccuracyTrades = useMemo(() => goldScalpingCandidates.filter(
    (candidate) => !candidate.countertrendBlocked && !candidate.opposingZoneBlock,
  ), [goldScalpingCandidates]);
  const blockedGoldScalpingSetups = useMemo(() => goldScalpingCandidates.filter(
    (candidate) => candidate.countertrendBlocked,
  ), [goldScalpingCandidates]);
  const blockedGoldScalpingOpposingSetups = useMemo(() => goldScalpingCandidates.filter(
    (candidate) => !candidate.countertrendBlocked && candidate.opposingZoneBlock,
  ), [goldScalpingCandidates]);
  const goldScalpingDirectTrades = useMemo(() => goldScalpingAccuracyTrades.filter(({ trade }) => (
    !tradingTimeEnabled || (isNepalTradingTime(trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe])
      && (trade.filledAt === undefined || isNepalTradingTime(trade.filledAt)))
  )), [goldScalpingAccuracyTrades, tradingTimeEnabled]);
  const activeMtfRows = useMemo(() => {
    const rows = new Map((marketSymbol === 'XAUUSD'
      ? buildGoldIntradayMtfRows(tableTimeframeData, mtfLtfFibRequired)
      : buildMtfRows(tableTimeframeData, mtfLtfFibRequired)).map((row) => [row.id, row]));
    if (marketSymbol === 'XAUUSD') {
      for (const row of buildGoldScalpingMtfRows(tableTimeframeData, mtfLtfFibRequired)) rows.set(row.id, row);
    }
    return Array.from(rows.values())
    .filter((row) => !extremeAPlusMtfBlockedZoneIds
      .get(row.higherTimeframe)?.has(row.higherTimeframeZoneId))
    .filter((row) => row.engulfingTime === undefined || !blockedGoldChartEntry(
      row.engulfingTime, row.lowerTimeframe, row.direction,
    ))
    .filter((row) => {
      if (marketSymbol !== 'XAUUSD' || row.engulfingTime === undefined) return true;
      const zoneData = tableTimeframeData[row.higherTimeframe];
      const zone = zoneData?.structure.zones.find((candidate) => (
        candidate.id === row.higherTimeframeZoneId
      ));
      return !zone || !zoneData || !isGoldZoneEntryBlocked(
        zone, zoneData.candles, row.higherTimeframe, marketConfig.pipSize,
        row.engulfingTime ?? Infinity,
      );
    })
    .filter((row) => row.engulfingBarsAgo !== undefined
      ? row.engulfingBarsAgo <= 100
      : (row.tapBarsAgo ?? row.confirmationBarsAgo) <= 50);
  }, [blockedGoldChartEntry, extremeAPlusMtfBlockedZoneIds, marketConfig.pipSize, marketSymbol, mtfLtfFibRequired, tableTimeframeData]);

  const allMtfTradeRows = useMemo<DisplayMtfRow[]>(() => {
    const setupIds = new Map<string, string>();
    return activeMtfRows.map((row) => {
      const setupKey = `${row.higherTimeframeZoneId}:${row.higherTimeframeTapTime}`;
      let setupId = setupIds.get(setupKey);
      if (!setupId) {
        setupId = `MTF-${setupIds.size + 1}`;
        setupIds.set(setupKey, setupId);
      }
      let trade: TradeLevels | undefined;
      let previewTrade: TradeLevels | undefined;
      let tradingTimeBlocked = false;
      let opposingZoneBlock: NonNullable<ReturnType<typeof goldOpposingZoneBeforeOneR>> | undefined;
      const lowerTimeframeData = tableTimeframeData[row.lowerTimeframe];
      if (marketConfig.mt5AutomationEnabled
        && !findEarlierZoneEntry({ symbol: marketSymbol, zoneTimeframe: row.higherTimeframe,
          zoneId: row.higherTimeframeZoneId, signalAt: row.engulfingTime ?? Infinity }, zoneEntryRecords)
        && row.engulfingType && row.engulfingTime !== undefined && lowerTimeframeData) {
        const signal: EngulfingTradeSignal = {
          type: row.engulfingType,
          direction: row.direction,
          time: row.engulfingTime,
          candleCount: row.engulfingCandleCount ?? 2,
          timeframe: row.lowerTimeframe,
        };
        const rule = row.goldScalping
          ? goldScalpingChochTradeRule(row.higherTimeframe, row.lowerTimeframe)
          : marketSymbol === 'XAUUSD'
            ? goldIntradayMtfTradeRule(row.higherTimeframe, row.lowerTimeframe)
            : getMtfTradeRule(row.higherTimeframe, row.lowerTimeframe);
        const signalClose = signal.time + TIMEFRAME_SECONDS[signal.timeframe];
        if (rule) {
          trade = calculateTradeLevels({
            sourceCandles: lowerTimeframeData.candles,
            executionCandles: lowerTimeframeData.candles,
            signal,
            rule,
            riskFreeEnabled: marketSymbol !== 'XAUUSD' || row.goldScalping === true,
            omitStopBuffer: marketSymbol !== 'XAUUSD'
              && row.engulfingDeepDiscount === true,
          });
          if (tradingTimeEnabled && (!isNepalTradingTime(signalClose)
            || (trade?.filledAt !== undefined && !isNepalTradingTime(trade.filledAt)))) {
            previewTrade = trade;
            trade = undefined;
            tradingTimeBlocked = true;
          }
          if (marketSymbol === 'XAUUSD' && trade) {
            opposingZoneBlock = goldOpposingZoneBeforeOneR({
              direction: signal.direction === 'bullish' ? 'BUY' : 'SELL',
              entry: trade.entry,
              stopLoss: trade.stopLoss,
              signalAt: signal.time,
              calculatedAt: signalClose,
            }, opposingGoldZones);
            if (opposingZoneBlock) trade = undefined;
          }
        }
      }
      const displayedTrade = trade ?? previewTrade;
      const tradeIndex = displayedTrade && lowerTimeframeData
        ? lowerTimeframeData.candles.findIndex((candle) => candle.time === displayedTrade.calculatedAt)
        : -1;
      const tradeBarsAgo = tradeIndex >= 0 && lowerTimeframeData
        ? lowerTimeframeData.candles.length - 1 - tradeIndex
        : undefined;
      return { ...row, setupId, trade, previewTrade, tradeBarsAgo, tradingTimeBlocked, opposingZoneBlock };
    });
  },
    [activeMtfRows, marketConfig.mt5AutomationEnabled, marketSymbol, opposingGoldZones, tableTimeframeData, tradingTimeEnabled, zoneEntryRecords],
  );

  const mtfRows = useMemo<DisplayMtfRow[]>(() => (
    // An MTF setup belongs to both charts in its pair. Keeping the table on
    // only the HTF made a valid setup appear to be missing during LTF replay
    // until the user switched back to the higher timeframe.
    allMtfTradeRows.filter((row) => (
      (row.higherTimeframe === granularity || row.lowerTimeframe === granularity)
      && tradeStyleEnabled({ tradeStyle: marketSymbol === 'XAUUSD'
        ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined,
        zoneTimeframe: row.higherTimeframe })
    ))
  ), [allMtfTradeRows, granularity, marketSymbol, tradeStyleEnabled]);

  const repeatedLtfChochLabels = useMemo(() => {
    const rows = marketSymbol === 'XAUUSD'
      ? [...buildGoldScalpingMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired),
        ...buildGoldIntradayMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired)]
      : buildMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired);
    return new Map(rows.filter((row) => row.lowerTimeframe === granularity
      && tradeStyleEnabled({ tradeStyle: marketSymbol === 'XAUUSD'
        ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined,
        zoneTimeframe: row.higherTimeframe })
      && (row.chochSequence ?? 1) > 1)
      .sort((first, second) => first.higherTimeframeTapTime - second.higherTimeframeTapTime)
      .map((row) => [`${row.structureScope}:${row.confirmationTime}`,
        mtfChochSequenceLabel(row.chochSequence!)]));
  }, [granularity, marketSymbol, mtfLtfFibRequired, tableTimeframeData, tradeStyleEnabled]);

  const savedChartMtfEntryQualification = useCallback((entry: {
    id: string;
    signalTime: number;
    direction: EngulfingTradeSignal['direction'];
    engulfingType: EngulfingTradeSignal['type'];
    zoneName: string;
    goldScalping?: boolean;
  }) => getSavedMtfEntryQualification(tableTimeframeData, {
    ...entry,
    zoneName: entry.zoneName as StructureZone['name'],
    goldIntraday: marketSymbol === 'XAUUSD' && !entry.goldScalping,
    requireLtfFib: mtfLtfFibRequired,
  }), [marketSymbol, mtfLtfFibRequired, tableTimeframeData]);

  const accuracyTradeRecords = useMemo<AccuracyTradeRecord[]>(() => {
    const records = new Map<string, AccuracyTradeRecord>();
    const addRecord = (
      id: string,
      zoneName: string,
      zoneTimeframe: TradeTimeframe,
      source: AccuracyTradeRecord['source'],
      trade: TradeLevels | undefined,
      volumeCandles: OandaCandle[] | undefined,
      journalDetails: Partial<JournalTradeRecord> = {},
    ) => {
      if (!trade?.result || blockedGoldChartEntry(
        trade.signal.time, trade.signal.timeframe, trade.signal.direction,
      )) return;
      const screenshotDataUrl = readPendingJournalScreenshot(id);
      const reference: AccuracyTradeRecord = {
        ...records.get(id),
        id,
        symbol: marketSymbol,
        zoneName,
        zoneTimeframe,
        result: trade.result,
        completedAt: trade.resolvedAt ?? trade.calculatedAt,
        source,
        direction: trade.signal.direction,
        signalTimeframe: trade.signal.timeframe,
        engulfingType: trade.signal.type,
        engulfingCandleCount: trade.signal.candleCount,
        entry: trade.entry,
        stopLoss: trade.stopLoss,
        takeProfit: trade.takeProfit,
        rewardRisk: trade.rewardRisk,
        riskPips: trade.riskPips,
        signalAt: trade.signal.time,
        openedAt: trade.filledAt,
        outsideTradingTime: !isNepalTradingTime(trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe])
          || (trade.filledAt !== undefined && !isNepalTradingTime(trade.filledAt)),
        ...(volumeCandles ? journalVolumeMetadata(volumeCandles, trade.signal) : {}),
        ...journalDetails,
        ...(screenshotDataUrl ? { screenshotDataUrl } : {}),
      };
      if (marketSymbol === 'XAUUSD' && reference.tradeStyle === 'INTRADAY') {
        const source = volumeCandles ?? tableTimeframeData[trade.signal.timeframe]?.candles ?? [];
        const execution = TIMEFRAME_SECONDS[zoneTimeframe] < TIMEFRAME_SECONDS[trade.signal.timeframe]
          ? tableTimeframeData[zoneTimeframe]?.candles ?? [] : source;
        for (const row of intradayPullbackChartRecords(reference, source, execution, tradeDisplayAsOf)) records.set(row.id, row);
      } else records.set(id, reference);
    };

    // Reconstruct direct engulfing outcomes from every historical zone that
    // retained a qualified signal, including zones invalidated after entry.
    const historyTimeframes: TradeTimeframe[] = marketSymbol === 'XAUUSD' ? ['M15', 'H1'] : [granularity];
    for (const zoneTimeframe of historyTimeframes) {
      const zoneData = tableTimeframeData[zoneTimeframe];
      if (!zoneData) continue;
      let sourceZones = zoneTimeframe === granularity ? displayZones
        : applySwingFibConfluence(zoneData.candles, zoneData.structure.zones, swingFibMoves).zones;
      if (zoneTimeframe !== granularity) {
        if (zoneTimeframe === 'M15') {
          const moves = buildDayFibs(zoneData.candles);
          sourceZones = applyDayFibConfluence(zoneData.candles, sourceZones, selectDayFibForTime(moves, dayFibAsOf), 10, dayFibAsOf).zones;
        }
        for (const fallback of DIRECT_ENGULFING_FALLBACKS[zoneTimeframe] ?? []) {
          sourceZones = applyTradeableZoneEngulfingFallback(
            tableTimeframeData[fallback]?.candles.filter((candle) => candle.complete !== false) ?? [],
            sourceZones, fallback, zoneTimeframe === 'H1',
          );
        }
      }
      const redundantIds = redundantStandaloneLiquidityZoneIds(sourceZones, marketConfig.pipSize);
      const blockedIds = selectExtremeAPlusTjl2Zones(sourceZones, marketConfig.pipSize).blockedZoneIds;
      for (const zone of sourceZones) {
        if (redundantIds.has(zone.id)) continue;
        if (blockedIds.has(zone.id)) continue;
        if (zone.status === 'rejected'
          || (!isZoneEligibleForEngulfingEntry(zone) && zone.tradeable === false)) continue;
        const signal = resolveZoneEngulfingSignal(zone, zoneTimeframe);
        if (!signal) continue;
        if (zoneTimeframe === granularity && pendingM15DbBlocksSignal(zone, signal)) continue;
        if (zoneTimeframe === 'M15' && signal.timeframe === 'M15' && sourceZones.some((db) => (
          db.name === 'DB' && db.active && db.m15H1ChochClosePending && db.isBuy === zone.isBuy
          && signal.time >= (db.chochTime ?? db.startTime) && zone.bottom <= db.top && db.bottom <= zone.top
          && zoneData.candles.some((candle) => candle.time === signal.time && candle.low <= db.top && candle.high >= db.bottom)
        ))) continue;
        if (marketSymbol === 'XAUUSD' && isGoldZoneEntryBlocked(
          zone, zoneData.candles, zoneTimeframe, marketConfig.pipSize, signal.time,
        )) continue;
        if (marketSymbol === 'XAUUSD'
          && !isGoldIntradayCandleRoute(zoneTimeframe, signal.timeframe)) continue;
        const baseRule = getDirectTradeRule(zoneTimeframe, signal.timeframe);
        if (!baseRule) continue;
        const sourceCandles = signal.timeframe === zoneTimeframe
          ? zoneData.candles
          : tableTimeframeData[signal.timeframe]?.candles || [];
        const rule = resolveRuleForDirectEntry({
          zoneTimeframe,
          signal,
          sourceCandles,
          baseRule,
        });
        if (!rule) continue;
        const executionCandles = TIMEFRAME_SECONDS[signal.timeframe]
          < TIMEFRAME_SECONDS[zoneTimeframe]
          ? sourceCandles
          : zoneData.candles;
        const trade = calculateTradeLevels({
          sourceCandles,
          executionCandles,
          signal,
          rule,
          riskFreeEnabled: marketSymbol !== 'XAUUSD',
          omitStopBuffer: marketSymbol !== 'XAUUSD'
            && isDeepDiscountTradeSignal(zone, signal),
        });
        addRecord(
          `DIRECT:${zone.id}:${signal.time}:${trade?.entry ?? 'NA'}`,
          executionZoneName(zone),
          zoneTimeframe,
          'ENGULFING',
          trade,
          sourceCandles,
          { zoneId: zone.id, ...journalFibMetadata(zone, signal),
            ...(marketSymbol === 'XAUUSD' ? { tradeStyle: 'INTRADAY' as const } : {}) },
        );
      }
    }

    for (const { zone, zoneTimeframe, trade } of goldScalpingAccuracyTrades) {
      addRecord(
        `GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`,
        executionZoneName(zone), zoneTimeframe, 'ENGULFING', trade,
        tableTimeframeData[trade.signal.timeframe]?.candles,
        { zoneId: zone.id, ...journalFibMetadata(zone, trade.signal), tradeStyle: 'SCALPING' },
      );
    }

    // Unlike the compact live MTF table, history evaluates every eligible
    // mapped CHOCH event in the loaded candle window.
    const historicalMtfRows = new Map((marketSymbol === 'XAUUSD'
      ? buildGoldIntradayMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired)
      : buildMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired)).map((row) => [row.id, row]));
    if (marketSymbol === 'XAUUSD') {
      for (const row of buildGoldScalpingMtfHistoryRows(tableTimeframeData, mtfLtfFibRequired)) {
        historicalMtfRows.set(row.id, row);
      }
    }
    for (const row of historicalMtfRows.values()) {
      if (extremeAPlusMtfBlockedZoneIds
        .get(row.higherTimeframe)?.has(row.higherTimeframeZoneId)) continue;
      if (!row.engulfingType || row.engulfingTime === undefined) continue;
      const lowerTimeframeData = tableTimeframeData[row.lowerTimeframe];
      const rule = row.goldScalping
        ? goldScalpingChochTradeRule(row.higherTimeframe, row.lowerTimeframe)
        : marketSymbol === 'XAUUSD'
          ? goldIntradayMtfTradeRule(row.higherTimeframe, row.lowerTimeframe)
          : getMtfTradeRule(row.higherTimeframe, row.lowerTimeframe);
      if (!lowerTimeframeData || !rule) continue;
      const signal: EngulfingTradeSignal = {
        type: row.engulfingType,
        direction: row.direction,
        time: row.engulfingTime,
        candleCount: row.engulfingCandleCount ?? 2,
        timeframe: row.lowerTimeframe,
      };
      const trade = calculateTradeLevels({
        sourceCandles: lowerTimeframeData.candles,
        executionCandles: lowerTimeframeData.candles,
        signal,
        rule,
        riskFreeEnabled: marketSymbol !== 'XAUUSD' || row.goldScalping === true,
        omitStopBuffer: marketSymbol !== 'XAUUSD'
          && row.engulfingDeepDiscount === true,
      });
      addRecord(
        `MTF:${row.id}:${signal.time}:${trade?.entry ?? 'NA'}`,
        row.tappedZone ?? row.higherTimeframeZone,
        row.higherTimeframe,
        'MTF',
        trade,
        lowerTimeframeData.candles,
        {
          zoneId: row.higherTimeframeZoneId,
          setupId: `MTF:${row.id}`,
          mtfContext: row,
          fibSource: row.engulfingFibBand ? 'MTF FIB' : undefined,
          fibBand: row.engulfingFibBand,
          tradeStyle: marketSymbol === 'XAUUSD'
            ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined,
        },
      );
    }

    // Merge session-tracked records as a safety net for trades whose zones
    // have just rolled out of the current reconstructed structure collection.
    const directSetups = new Map<string, TrackedDirectTradeSetup>();
    for (const setup of trackedDirectTradeSetups.values()) {
      if (setup.scope === tradeTrackingScope
        && (marketSymbol !== 'XAUUSD'
          || isGoldIntradayCandleRoute(granularity, setup.signal.timeframe))) {
        directSetups.set(setup.zone.id, setup);
      }
    }
    for (const setup of currentDirectTradeSetups.values()) {
      directSetups.set(setup.zone.id, setup);
    }
    for (const [zoneId, decision] of directZoneEntryDecisions) {
      const setup = directSetups.get(zoneId);
      if (!setup) continue;
      const sourceCandles = setup.signal.timeframe === granularity
        ? displayCandles
        : vipCandles[setup.signal.timeframe] || [];
      for (const trade of decision.trades ?? (decision.trade ? [decision.trade] : decision.previewTrade ? [decision.previewTrade] : [])) {
        const id = `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`;
        addRecord(id, executionZoneName(setup.zone), granularity, 'ENGULFING', trade,
          sourceCandles, marketSymbol === 'XAUUSD' ? { tradeStyle: 'INTRADAY' } : undefined);
      }
    }
    // A retained direct trade can reach TP/SL after its original zone stops
    // producing a fresh entry decision. Keep the journal and arrows in sync
    // with the completed trade already displayed in the Zone Table.
    for (const overlay of visibleRetainedChartTradeOverlays) {
      if (!overlay.id.startsWith('DIRECT:') || overlay.referenceOnly
        || (overlay.symbol ?? 'XAUUSD') !== marketSymbol
        || !overlay.trade.result || overlay.trade.filledAt === undefined) continue;
      const saved = savedJournalTrades.find((record) => record.id === overlay.id);
      addRecord(overlay.id, saved?.zoneName ?? tradeOverlayZoneLabel(overlay.label) ?? 'Unknown',
        saved?.zoneTimeframe ?? overlay.trade.signal.timeframe, 'ENGULFING', overlay.trade,
        tableTimeframeData[overlay.trade.signal.timeframe]?.candles,
        { zoneId: saved?.zoneId ?? directTradeOverlayZoneId(overlay),
          tradeStyle: saved?.tradeStyle ?? (marketSymbol === 'XAUUSD' ? 'INTRADAY' : undefined),
          fibSource: saved?.fibSource, fibBand: saved?.fibBand });
    }
    for (const row of mtfRows) {
      const trade = row.trade ?? row.previewTrade;
      if (!trade) continue;
      const id = `MTF:${row.id}:${row.engulfingTime}:${trade.entry}`;
      addRecord(
        id,
        row.tappedZone ?? row.higherTimeframeZone,
        row.higherTimeframe,
        'MTF',
        trade,
        tableTimeframeData[row.lowerTimeframe]?.candles,
        { zoneId: row.higherTimeframeZoneId, tradeStyle: marketSymbol === 'XAUUSD'
          ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined },
      );
    }
    return deduplicateTradeRecords(Array.from(records.values()));
  }, [
    blockedGoldChartEntry,
    currentDirectTradeSetups,
    dayFibAsOf,
    displayCandles,
    displayZones,
    directZoneEntryDecisions,
    directZoneTrades,
    expiredGoldZoneBeforeSignal,
    extremeAPlusTjl2Selection.blockedZoneIds,
    extremeAPlusMtfBlockedZoneIds,
    granularity,
    goldScalpingAccuracyTrades,
    marketSymbol,
    mtfLtfFibRequired,
    mtfRows,
    pendingM15DbBlocksSignal,
    redundantStandaloneZoneIds,
    tableTimeframeData,
    swingFibMoves,
    trackedDirectTradeSetups,
    tradeTrackingScope,
    tradingTimeEnabled,
    savedJournalTrades,
    visibleRetainedChartTradeOverlays,
    vipCandles,
    tradeDisplayAsOf,
  ]);

  const [scalpOneToOnePreview, setScalpOneToOnePreview] = useState<Mt5SignalInput[]>([]);
  const [scalpOneToOneChartRecords, setScalpOneToOneChartRecords] = useState<JournalTradeRecord[]>([]);
  const [scalpOneToOneChartFills, setScalpOneToOneChartFills] = useState<ScalpOneToOneChartFill[]>([]);
  const [scalpOneToOneHistoryStatus, setScalpOneToOneHistoryStatus] = useState('');
  const scalpOneToOneHistoryRequested = marketSymbol === 'XAUUSD'
    && (showScalpOneToOneArrows || showAccuracyTable || showJournal || scalpOneToOneEnabled);
  const scalpOneToOneScanTime = Math.floor(tradeDisplayAsOf / 900) * 900;
  const scalpScanTimeRef = useRef(scalpOneToOneScanTime);
  scalpScanTimeRef.current = scalpOneToOneScanTime;
  const scalpHistoryQueueRef = useRef<LatestWorkerTask<unknown> | null>(null);
  const scalpReplayActive = replayIndex !== null;
  // Use an unfinished bar's open only, keeping long scans alive as its wick changes.
  const scalpOneToOneHistoryInput = useMemo(() => !scalpOneToOneHistoryRequested ? '' : JSON.stringify({ candles: Object.fromEntries(
    (['M15', 'H1', 'H4'] as const).map(timeframe => [timeframe,
      tableTimeframeData[timeframe]?.candles.map(candle => (
        candle.complete === false || candle.time + TIMEFRAME_SECONDS[timeframe] > scalpOneToOneScanTime
          ? { ...candle, complete: false, high: candle.open, low: candle.open, close: candle.open, volume: 0 }
          : candle
      )),
    ])), now: scalpOneToOneScanTime,
    pendingExpiryMinutes: mt5Status?.config.pendingExpiryMinutes ?? 240 }),
    [scalpOneToOneHistoryRequested, tableTimeframeData, scalpOneToOneScanTime, mt5Status?.config.pendingExpiryMinutes]);
  useEffect(() => {
    setScalpOneToOnePreview([]); setScalpOneToOneChartRecords([]); setScalpOneToOneChartFills([]);
    if (!scalpOneToOneHistoryRequested) {
      setScalpOneToOneHistoryStatus(''); return;
    }
    setScalpOneToOneHistoryStatus('Loading Scalp 1:1 chart results...');
    const task = new Worker(new URL('../services/scalpOneToOne.worker.ts', import.meta.url), { type: 'module' });
    const queue = new LatestWorkerTask<unknown>(message => task.postMessage(message));
    scalpHistoryQueueRef.current = queue;
    task.onmessage = (event: MessageEvent<{ signals?: Mt5SignalInput[]; records?: JournalTradeRecord[];
      fills?: ScalpOneToOneChartFill[]; error?: string; progress?: number;
      taskId: number; now: number; done?: boolean }>) => {
      if (!queue.accepts(event.data.taskId)) return;
      if (event.data.done) { queue.complete(event.data.taskId); return; }
      // A scan may finish after rewind. Never publish its future evidence.
      if (event.data.now > scalpScanTimeRef.current) return;
      if (event.data.signals) setScalpOneToOnePreview(event.data.signals);
      if (event.data.records) setScalpOneToOneChartRecords(event.data.records);
      if (event.data.fills) setScalpOneToOneChartFills(event.data.fills);
      setScalpOneToOneHistoryStatus(event.data.error ?? (event.data.progress !== undefined
        ? `Loading Scalp 1:1 chart results... ${event.data.progress}%`
        : `Scalp 1:1: ${event.data.fills?.length ?? 0} confirmed historical entry fills. Results and MT5 executions are tracked separately.`));
    };
    task.onerror = () => setScalpOneToOneHistoryStatus('Scalp 1:1 history unavailable.');
    return () => {
      queue.dispose(); scalpHistoryQueueRef.current = null;
      task.onmessage = null; task.terminate();
    };
  }, [scalpOneToOneHistoryRequested, liveChartDataSource, scalpReplayActive]);
  useEffect(() => {
    if (scalpOneToOneHistoryInput) scalpHistoryQueueRef.current?.submit(JSON.parse(scalpOneToOneHistoryInput));
  }, [scalpOneToOneHistoryInput, liveChartDataSource, scalpReplayActive]);

  const openChartJournalTrades = useMemo<JournalTradeRecord[]>(() => {
    if (replayIndex !== null) return [];
    const records: JournalTradeRecord[] = [];
    const add = (id: string, zoneId: string | undefined, zoneName: string,
      zoneTimeframe: TradeTimeframe, source: 'ENGULFING' | 'MTF',
      trade: TradeLevels | undefined, tradeStyle?: 'SCALPING' | 'INTRADAY' | 'SCALP_1_1' | 'BOLLINGER_M5', mtfContext?: MtfRow) => {
      if (!trade || trade.filledAt === undefined || isCompletedTrade(trade)) return;
      if (blockedGoldChartEntry(
        trade.signal.time, trade.signal.timeframe, trade.signal.direction,
      )) return;
      if (tradingTimeEnabled && (!isNepalTradingTime(trade.calculatedAt)
        || !isNepalTradingTime(trade.filledAt))) return;
      const reference: JournalTradeRecord = {
        id, zoneId, symbol: marketSymbol, zoneName, zoneTimeframe, source, tradeStyle,
        mtfContext, setupId: mtfContext ? `MTF:${mtfContext.id}` : undefined,
        result: trade.status === 'risk-free' ? 'risk-free' : 'open',
        completedAt: trade.filledAt, openedAt: trade.filledAt,
        signalAt: trade.signal.time, signalTimeframe: trade.signal.timeframe,
        engulfingType: trade.signal.type, engulfingCandleCount: trade.signal.candleCount,
        direction: trade.signal.direction, entry: trade.entry, stopLoss: trade.stopLoss,
        takeProfit: trade.takeProfit, rewardRisk: trade.rewardRisk, riskPips: trade.riskPips,
      };
      if (marketSymbol === 'XAUUSD' && tradeStyle === 'INTRADAY') {
        const source = tableTimeframeData[trade.signal.timeframe]?.candles ?? [];
        const execution = TIMEFRAME_SECONDS[zoneTimeframe] < TIMEFRAME_SECONDS[trade.signal.timeframe]
          ? tableTimeframeData[zoneTimeframe]?.candles ?? [] : source;
        records.push(...intradayPullbackChartRecords(reference, source, execution, tradeDisplayAsOf)
          .filter(row => row.result === 'open'));
      } else records.push(reference);
    };
    for (const [zoneId, trade] of directZoneTrades) {
      const zone = displayZones.find((candidate) => candidate.id === zoneId);
      add(`DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`, zoneId,
        zone ? executionZoneName(zone) : 'Chart entry', granularity, 'ENGULFING', trade,
        marketSymbol === 'XAUUSD' ? 'INTRADAY' : undefined);
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingDirectTrades) {
      add(`GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`,
        zone.id, executionZoneName(zone), zoneTimeframe, 'ENGULFING', trade, 'SCALPING');
    }
    for (const row of allMtfTradeRows) {
      if (!row.trade) continue;
      add(`MTF:${row.id}:${row.trade.signal.time}:${row.trade.entry}`, row.higherTimeframeZoneId,
        row.tappedZone ?? row.higherTimeframeZone, row.higherTimeframe, 'MTF', row.trade,
        marketSymbol === 'XAUUSD' ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined, row);
    }
    return records;
  }, [allMtfTradeRows, blockedGoldChartEntry, directZoneTrades, displayZones, goldScalpingDirectTrades, granularity,
    marketSymbol, replayIndex, tradingTimeEnabled, tableTimeframeData, tradeDisplayAsOf]);

  const reconciledMtfJournalTrades = useMemo(() => visibleSavedJournalTrades.map(record => (
    replayIndex === null && record.source === 'MTF' && !record.intradayEntry && (record.symbol ?? 'XAUUSD') === marketSymbol
      ? reconcileSavedMtfTrade(record, tableTimeframeData[record.signalTimeframe]?.candles ?? [], tradeDisplayAsOf).record
      : record
  )), [visibleSavedJournalTrades, replayIndex, marketSymbol, tableTimeframeData, tradeDisplayAsOf]);
  const intradayPullbackPreview = useMemo(() => {
    if (marketSymbol !== 'XAUUSD' || !intradayEnabled) return [];
    const result: Mt5SignalInput[] = [];
    const add = (trade: TradeLevels | undefined, source: 'ENGULFING' | 'MTF', setupId: string,
      zoneId: string, zoneName: string, zoneTimeframe: TradeTimeframe) => {
      if (!trade) return;
      const base = tradeToMt5Signal({ source, setupId, zoneName, zoneTimeframe, trade,
        now: tradeDisplayAsOf, pendingExpiryMinutes: 15 });
      base.tradeStyle = 'INTRADAY'; base.zoneId = zoneId;
      for (const signal of buildIntradayPullbackSignals(base, tableTimeframeData[trade.signal.timeframe]?.candles ?? [])) {
        if (signal.calculatedAt <= tradeDisplayAsOf && signal.expiresAt > tradeDisplayAsOf) result.push(signal);
      }
    };
    for (const [zoneId, decision] of directZoneEntryDecisions) {
      const zone = displayZones.find(z => z.id === zoneId);
      if (zone) add(decision.trade, 'ENGULFING', `DIRECT:${granularity}:${zoneId}`,
        zoneId, executionZoneName(zone), granularity);
    }
    for (const row of allMtfTradeRows) if (!row.goldScalping) add(row.trade, 'MTF', `MTF:${row.id}`,
      row.higherTimeframeZoneId, row.tappedZone ?? row.higherTimeframeZone, row.higherTimeframe);
    return result;
  }, [marketSymbol, intradayEnabled, tradeDisplayAsOf, tableTimeframeData,
    directZoneEntryDecisions, displayZones, granularity, allMtfTradeRows]);
  const bollingerCandles = useMemo(() => ({ M5: tableTimeframeData.M5?.candles ?? [], H4: tableTimeframeData.H4?.candles ?? [] }), [tableTimeframeData]);
  const canonicalTradeRecords = useMemo(() => buildCanonicalTradeRecords(
    reconciledMtfJournalTrades, [...openChartJournalTrades.filter(record => record.intradayEntry),
      ...accuracyTradeRecords, ...scalpOneToOneChartRecords, ...bollingerChartRecords], {
      marketSymbol, pipSize: marketConfig.pipSize, requireLtfFib: mtfLtfFibRequired,
      timeframeData: tableTimeframeData, qualifyMtf: savedChartMtfEntryQualification,
    },
  ), [accuracyTradeRecords, openChartJournalTrades, scalpOneToOneChartRecords, bollingerChartRecords, marketConfig.pipSize, marketSymbol, mtfLtfFibRequired,
    savedChartMtfEntryQualification, reconciledMtfJournalTrades, tableTimeframeData]);
  const visibleCanonicalTradeRecords = useMemo(() => canonicalTradeRecords.filter((record) => (
    tradeStyleEnabled(record) && !blockedGoldHistoricalTrade(record)
  )), [blockedGoldHistoricalTrade, canonicalTradeRecords, tradeStyleEnabled]);
  const allSavedAccuracyRecords = useMemo(() => visibleCanonicalTradeRecords.filter((record) => (
    record.result === 'tp' || record.result === 'sl' || record.result === 'rf'
  )), [visibleCanonicalTradeRecords]);

  useEffect(() => {
    const facts = (record: AccuracyTradeRecord) => JSON.stringify([
      record.id, record.result, record.completedAt, record.entry, record.stopLoss,
      record.zoneId, record.setupId,
      record.mtfContext,
      record.takeProfit, record.openedAt, record.rewardRisk, record.tradeStyle,
      record.fibSource, record.fibBand, record.volumeLogicStatus,
      record.volume1, record.volume2, record.volume3, record.engulfingCandleCount,
      record.intradayEntry,
    ]);
    const stored = new Map(savedJournalTrades.map((record) => [record.id, facts(record)]));
    const storedRecords = new Map(savedJournalTrades.map((record) => [record.id, record]));
    const recordsToSave = new Map([...openChartJournalTrades, ...canonicalTradeRecords,
      ...reconciledMtfJournalTrades.filter((record) => record !== storedRecords.get(record.id))]
      .map((record) => [record.id, record]));
    const changed = [...recordsToSave.values()].filter((record) => (
      stored.get(record.id) !== facts(record)
      && !((record.result === 'open' || record.result === 'risk-free')
        && savedJournalTrades.some((saved) => saved.id === record.id
          && ['tp', 'sl', 'rf'].includes(saved.result)))
    ));
    if (changed.length === 0) return;
    const signature = changed.map(facts).sort().join('|');
    if (signature === journalSyncSignatureRef.current) return;
    journalSyncSignatureRef.current = signature;
    void (async () => {
      let saved: AccuracyTradeRecord[] | undefined;
      for (let offset = 0; offset < changed.length; offset += 2000) {
        const batch = changed.slice(offset, offset + 2000);
        const response = await terminalFetch('/api/journal/trades?view=dashboard', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ trades: batch }),
        });
        if (!response.ok) throw new Error('Unable to save validated trade records.');
        const payload = await response.json() as { ok?: boolean; trades?: AccuracyTradeRecord[] };
        if (!payload.ok || !Array.isArray(payload.trades)) throw new Error('Invalid journal response.');
        saved = payload.trades;
        for (const record of batch) {
          if (!record.screenshotDataUrl) continue;
          try { userStorage.removeItem(`${JOURNAL_SCREENSHOT_PREFIX}${record.id}`); }
          catch { /* The server copy remains durable. */ }
        }
      }
      if (saved) setSavedJournalTrades(saved);
    })().catch(() => { journalSyncSignatureRef.current = ''; });
  }, [canonicalTradeRecords, openChartJournalTrades, savedJournalTrades, reconciledMtfJournalTrades]);

  const replayResultCutoff = replayIndex === null ? undefined
    : displayCandles.length === 0 ? Number.NEGATIVE_INFINITY
      : marketCandleCloseTime(displayCandles[displayCandles.length - 1].time, granularity);
  const replayVisibleAccuracyRecords = useMemo(() => replayResultCutoff === undefined
    ? allSavedAccuracyRecords
    : allSavedAccuracyRecords.filter((record) => record.completedAt <= replayResultCutoff),
  [allSavedAccuracyRecords, replayResultCutoff]);
  const timeframeAccuracyRecords = useMemo(() => selectTradeChartRecords(
    replayVisibleAccuracyRecords, granularity, displayCandles, marketSymbol === 'XAUUSD',
  ), [
      displayCandles,
      granularity,
      marketSymbol,
      replayVisibleAccuracyRecords,
    ]);

  const tradeOverlays = useMemo<TradeOverlay[]>(() => {
    const overlays = new Map<string, TradeOverlay>();
    const addTrade = (
      id: string,
      trade: TradeLevels,
      label?: string,
      drawingTimeframe: OandaGranularity = trade.signal.timeframe,
      zone?: StructureZone,
      zoneTimeframe?: TradeTimeframe,
    ) => {
      if (marketSymbol === 'XAUUSD' && !id.startsWith('GOLD_SCALP:') && !label?.includes('SCALP MTF')) return;
      if (isCompletedTrade(trade) || blockedGoldChartEntry(
        trade.signal.time, trade.signal.timeframe, trade.signal.direction,
      )) return;
      const signature = [
        trade.calculatedAt,
        trade.entry,
        trade.stopLoss,
        trade.takeProfit,
      ].join(':');
      if (!overlays.has(signature)) overlays.set(signature, {
        id,
        symbol: marketSymbol,
        trade,
        label,
        fibLabels: zone ? tradeZoneFibLabels(zone) : undefined,
        chartTimeframe: drawingTimeframe,
        zoneTimeframe,
      });
    };
    for (const [zoneId, trade] of directZoneTrades) {
      let setup: TrackedDirectTradeSetup | undefined;
      for (const candidate of trackedDirectTradeSetups.values()) {
        if (candidate.scope === tradeTrackingScope && candidate.zone.id === zoneId
          && candidate.signal.time === trade.signal.time) {
          setup = candidate;
          break;
        }
      }
      if (!setup) {
        for (const candidate of currentDirectTradeSetups.values()) {
          if (candidate.zone.id === zoneId && candidate.signal.time === trade.signal.time) {
            setup = candidate;
            break;
          }
        }
      }
      if (!setup) continue;
      addTrade(
        `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`,
        trade,
        `${executionZoneName(setup.zone)} · CHART · 1:${trade.rewardRisk}`,
        trade.signal.timeframe,
        setup.zone,
        setup.rule.zoneTimeframe,
      );
    }
    // Reconstruct filled, unresolved direct trades from historical zones too.
    // This restores their drawings and table rows after a refresh, even when
    // the originating zone is no longer part of the compact active-zone table.
    for (const zone of displayZones) {
      if (extremeAPlusTjl2Selection.blockedZoneIds.has(zone.id)
        || zone.status === 'rejected'
        || (!isZoneEligibleForEngulfingEntry(zone) && zone.tradeable === false)) continue;
      const signal = resolveZoneEngulfingSignal(zone, granularity);
      if (!signal) continue;
      if (pendingM15DbBlocksSignal(zone, signal) || expiredGoldZoneBeforeSignal(zone, signal)) continue;
      if (marketSymbol === 'XAUUSD'
        && !isGoldIntradayCandleRoute(granularity, signal.timeframe)) continue;
      const baseRule = getDirectTradeRule(granularity, signal.timeframe);
      if (!baseRule) continue;
      const sourceCandles = signal.timeframe === granularity
        ? displayCandles
        : vipCandles[signal.timeframe] || [];
      const rule = resolveRuleForDirectEntry({
        zoneTimeframe: granularity,
        signal,
        sourceCandles,
        baseRule,
      });
      if (!rule) continue;
      const executionCandles = TIMEFRAME_SECONDS[signal.timeframe]
        < TIMEFRAME_SECONDS[granularity]
        ? sourceCandles
        : displayCandles;
      const trade = calculateTradeLevels({
        sourceCandles,
        executionCandles,
        signal,
        rule,
        riskFreeEnabled: marketSymbol !== 'XAUUSD',
        omitStopBuffer: marketSymbol !== 'XAUUSD'
          && isDeepDiscountTradeSignal(zone, signal),
      });
      if (!trade || trade.filledAt === undefined || isCompletedTrade(trade)) continue;
      if (tradingTimeEnabled && (!isNepalTradingTime(signal.time + TIMEFRAME_SECONDS[signal.timeframe])
        || !isNepalTradingTime(trade.filledAt))) continue;
      addTrade(
        `DIRECT:${zone.id}:${signal.time}:${trade.entry}`,
        trade,
        `${executionZoneName(zone)} · CHART · 1:${trade.rewardRisk}`,
        trade.signal.timeframe,
        zone,
        granularity as TradeTimeframe,
      );
    }
    for (const row of mtfRows) {
      if (row.trade) {
        addTrade(
          `MTF:${row.id}:${row.engulfingTime}:${row.trade.entry}`,
          row.trade,
          `${row.tappedZone ?? row.higherTimeframeZone} · ${row.goldScalping ? 'SCALP MTF' : 'MTF'} · 1:${row.trade.rewardRisk}`,
          row.lowerTimeframe,
        );
      }
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingDirectTrades) {
      addTrade(
        `GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`,
        trade,
        `${executionZoneName(zone)} · SCALP · 1:${trade.rewardRisk}`,
        trade.signal.timeframe,
      );
    }
    for (const record of openChartJournalTrades) {
      if (!record.intradayEntry) continue;
      const trade = tradeDrawingFromRecord(record);
      overlays.set(record.id, { id: record.id, symbol: marketSymbol, setupId: record.setupId,
        trade, chartTimeframe: record.signalTimeframe, zoneTimeframe: record.zoneTimeframe,
        label: `${record.zoneName} · ${record.intradayEntry.leg}% PULLBACK · ${record.intradayEntry.riskShare * 100}% RISK` });
    }
    return Array.from(overlays.values())
      .sort((first, second) => second.trade.calculatedAt - first.trade.calculatedAt);
  }, [
    blockedGoldChartEntry,
    currentDirectTradeSetups,
    displayCandles,
    displayZones,
    directZoneTrades,
    expiredGoldZoneBeforeSignal,
    extremeAPlusTjl2Selection.blockedZoneIds,
    granularity,
    goldScalpingDirectTrades,
    marketSymbol,
    mtfRows,
    openChartJournalTrades,
    pendingM15DbBlocksSignal,
    trackedDirectTradeSetups,
    tradeTrackingScope,
    tradingTimeEnabled,
    vipCandles,
  ]);

  useEffect(() => {
    setRetainedChartTradeOverlays((existing) => {
      const next = new Map<string, TradeOverlay>(existing);
      for (const [id, overlay] of next) {
        if ((overlay.symbol ?? 'XAUUSD') !== marketSymbol) continue;
        if (marketSymbol === 'XAUUSD' && (id.startsWith('DIRECT:')
          || id.startsWith('MTF:') && !overlay.label?.includes('SCALP MTF'))
          && !id.includes(':INTRA:P')) { next.delete(id); continue; }
        if (redundantRetainedOverlayIds.has(id)) {
          next.delete(id);
          continue;
        }
        const directZoneId = directTradeOverlayZoneId(overlay);
        if (directZoneId && (redundantStandaloneZoneIds.has(directZoneId)
          || extremeAPlusTjl2Selection.blockedZoneIds.has(directZoneId))) {
          next.delete(id);
          continue;
        }
        if (!hasIdentifiedDirectZoneLabel(overlay.id, overlay.setupId, overlay.label)) next.delete(id);
      }
      const liveBrokerSetupKeys = new Set(
        (mt5Status?.positions ?? []).flatMap((position) => (
          position.setupId
            ? [resolveTradeOverlaySetupKey(`MT5:${position.ticket}`, position.setupId)]
            : []
        )),
      );
      for (const overlay of tradeOverlays) {
        if (overlay.trade.filledAt !== undefined && !isCompletedTrade(overlay.trade)) {
          if (!isCompletedTrade(next.get(overlay.id)?.trade)) next.set(overlay.id, {
            ...overlay, zoneTimeframe: next.get(overlay.id)?.zoneTimeframe ?? overlay.zoneTimeframe,
          });
        }
      }
      for (const [id, overlay] of next) {
        if ((overlay.symbol ?? 'XAUUSD') !== marketSymbol) continue;
        if (!hasRetainedDirectTradeSource(overlay)) {
          next.delete(id);
          continue;
        }
        if (liveBrokerSetupKeys.has(tradeOverlaySetupKey(overlay))) {
          next.delete(id);
          continue;
        }
        const directZoneId = directTradeOverlayZoneId(overlay);
        if (overlay.chartTimeframe === 'M5' && directZoneId
          && displayZones.some((zone) => (
            zone.id === directZoneId && zone.confirmationRouteDisabled
          ))) {
          next.delete(id);
          continue;
        }
        if (overlay.chartTimeframe !== granularity) continue;
        const resolved = resolveRetainedTrade(overlay.trade, displayCandles);
        // Keep the final state so a stale active copy cannot resurrect the entry.
        // Drawings expire after five bars; zone rows retain their separate tap-age limit.
        next.set(id, { ...overlay, trade: resolved });
      }
      const firstTradeBySetup = new Map<string, { id: string; signalAt: number }>();
      for (const [id, overlay] of next) {
        const setupKey = `${overlay.symbol ?? 'XAUUSD'}:${tradeOverlaySetupKey(overlay)}`;
        const previous = firstTradeBySetup.get(setupKey);
        if (!previous || overlay.trade.signal.time < previous.signalAt) {
          if (previous) next.delete(previous.id);
          firstTradeBySetup.set(setupKey, { id, signalAt: overlay.trade.signal.time });
        } else {
          next.delete(id);
        }
      }
      const signature = (entries: Map<string, TradeOverlay>) => Array.from(entries)
        .map(([id, overlay]) => `${overlay.symbol ?? 'XAUUSD'}:${id}:${overlay.zoneTimeframe ?? ''}:${overlay.trade.status}:${overlay.trade.resolvedAt ?? ''}:${overlay.fibLabels?.join(',') ?? ''}`)
        .sort()
        .join('|');
      return signature(next) === signature(existing) ? existing : next;
    });
  }, [displayCandles, displayZones, extremeAPlusTjl2Selection.blockedZoneIds, granularity, hasRetainedDirectTradeSource, marketSymbol, mt5Status?.positions, redundantRetainedOverlayIds, redundantStandaloneZoneIds, tradeOverlays]);

  const retainedChartTradesForTimeframe = useMemo(() => {
    if (!candles.length) return [];
    const firstTradeBySetup = new Map<string, TradeOverlay>();
    const candidates = visibleRetainedChartTradeOverlays
      .filter((overlay) => (overlay.symbol ?? 'XAUUSD') === marketSymbol
        && overlayStyleEnabled(overlay)
        && overlay.chartTimeframe === granularity
        && hasRetainedDirectTradeSource(overlay)
        && (!overlay.id.startsWith('MTF:') || savedChartMtfEntryQualification({
          id: overlay.id,
          signalTime: overlay.trade.signal.time,
          direction: overlay.trade.signal.direction,
          engulfingType: overlay.trade.signal.type,
          zoneName: tradeOverlayZoneLabel(overlay.label) ?? '',
          goldScalping: overlay.label?.includes('SCALP MTF') === true,
        }) !== undefined)
        && (!tradingTimeEnabled
          || (isNepalTradingTime(overlay.trade.signal.time + TIMEFRAME_SECONDS[overlay.trade.signal.timeframe])
            && (overlay.trade.filledAt === undefined || isNepalTradingTime(overlay.trade.filledAt)))))
      .sort((first, second) => first.trade.signal.time - second.trade.signal.time);
    for (const overlay of candidates) {
      const setupKey = tradeOverlaySetupKey(overlay);
      if (!firstTradeBySetup.has(setupKey)) firstTradeBySetup.set(setupKey, overlay);
    }
    return [...firstTradeBySetup.values()]
      .sort((first, second) => second.trade.calculatedAt - first.trade.calculatedAt);
  }, [candles.length, granularity, hasRetainedDirectTradeSource, marketSymbol, overlayStyleEnabled, visibleRetainedChartTradeOverlays, savedChartMtfEntryQualification, tradingTimeEnabled]);

  // The Zone Table owns only direct chart-zone trades. MTF trades remain
  // drawable on the chart, but all their row/details UI belongs to MTF Table.
  const retainedDirectChartTradesForTimeframe = useMemo(() => (
    retainedChartTradesForTimeframe.filter((overlay) => (
      isDirectTradeOverlay(overlay.id, overlay.setupId)
      && hasIdentifiedDirectZoneLabel(overlay.id, overlay.setupId, overlay.label)
      && internalSbrTableSourceVisible(tradeOverlayZoneLabel(overlay.label),
        directTradeOverlayZoneId(overlay), displayZones, showInternal)
      && !redundantRetainedOverlayIds.has(overlay.id)
      && !redundantStandaloneZoneIds.has(directTradeOverlayZoneId(overlay) ?? '')
      && !extremeAPlusTjl2Selection.blockedZoneIds.has(directTradeOverlayZoneId(overlay) ?? '')
    ))
  ), [displayZones, extremeAPlusTjl2Selection.blockedZoneIds, redundantRetainedOverlayIds, redundantStandaloneZoneIds, retainedChartTradesForTimeframe, showInternal]);

  const scalpChartDisplays = useMemo(() => buildScalpChartDisplays({
    marketSymbol, timeframe: granularity, asOf: tradeDisplayAsOf, replay: replayIndex !== null,
    connection: mt5Status?.bridge ?? {}, positions: mt5Status?.positions ?? [],
    signals: mt5Status?.recentSignals ?? [], previews: scalpOneToOnePreview,
    candles: tableTimeframeData[granularity]?.candles ?? [],
  }), [marketSymbol, granularity, tradeDisplayAsOf, replayIndex, mt5Status, scalpOneToOnePreview, tableTimeframeData]);

  const liveMt5TradeOverlays = useMemo<TradeOverlay[]>(() => (
    (mt5Status?.positions ?? []).flatMap((position) => {
      const scalp = scalpChartDisplays.find(item => item.kind === 'live' && item.brokerTicket === position.ticket);
      if (scalp) return [scalp];
      // Once MT5 opens a position, its broker lifecycle controls the drawing.
      // Later zone/FIB invalidation must not hide an otherwise open trade.
      if (!(position.stopLoss > 0) || !(position.takeProfit > 0) || !(position.priceOpen > 0)) return [];
      const riskDistance = Math.abs(position.priceOpen - position.stopLoss);
      if (riskDistance <= 0) return [];
      const rewardRisk = Math.max(0.1, Math.round(
        Math.abs(position.takeProfit - position.priceOpen) / riskDistance * 10,
      ) / 10);
      const signalTimeframe = position.signalTimeframe ?? granularity;
      const signalType = (['T1', 'T2', 'T3', 'T4'].includes(position.engulfingType ?? '')
        ? position.engulfingType
        : 'T1') as EngulfingTradeSignal['type'];
      const isBuy = position.direction === 'BUY';
      const storedSignal = (mt5Status?.recentSignals ?? []).find((candidate) => (
        candidate.brokerTicket === position.ticket
        || (position.setupId !== undefined && candidate.setupId === position.setupId
          && ['ACTIVE', 'RISK_FREE', 'PLACED'].includes(candidate.status))
      ));
      if (!tradeStyleEnabled(storedSignal ?? { zoneTimeframe: position.zoneTimeframe })) return [];
      const signalAt = position.signalAt ?? storedSignal?.signalAt;
      // The drawing begins when the entry candle confirms. A broker fill can
      // occur later, so its timestamp belongs only to the execution record.
      const confirmedAt = signalAt !== undefined && Number.isFinite(signalAt)
        ? signalAt + TIMEFRAME_SECONDS[signalTimeframe]
        : storedSignal?.calculatedAt ?? position.openedAt;
      const trade: TradeLevels & { partialClosedAt?: number } = {
        entry: position.priceOpen,
        stopLoss: position.stopLoss,
        takeProfit: position.takeProfit,
        riskFree: isBuy ? position.priceOpen + riskDistance : position.priceOpen - riskDistance,
        riskFreeEnabled: storedSignal?.tradeStyle === 'SCALPING'
          || storedSignal?.status === 'RISK_FREE',
        riskPips: Math.round(riskDistance / 0.1 * 100) / 100,
        rewardRisk,
        status: storedSignal?.status === 'RISK_FREE' || position.signalStatus === 'RISK_FREE' ? 'risk-free' : 'active',
        partialClosedAt: storedSignal?.partialClosedAt,
        pendingAtCreation: false,
        calculatedAt: confirmedAt,
        filledAt: position.openedAt,
        signal: {
          type: signalType,
          direction: isBuy ? 'bullish' : 'bearish',
          time: signalAt ?? position.openedAt,
          candleCount: signalType === 'T1' ? 2 : 3,
          timeframe: signalTimeframe,
        },
      };
      return [{
        id: `MT5:${position.ticket}`,
        symbol: 'XAUUSD' as const,
        setupId: position.setupId,
        trade,
        label: `${storedSignal?.tradeStyle === 'BOLLINGER_M5' ? 'BOLLINGER M5 ? ' : storedSignal?.tradeStyle === 'SCALP_1_1' ? 'SCALP 1:1 · ' : storedSignal?.tradeStyle === 'SCALPING' ? 'SCALP · ' : ''}${position.zoneTimeframe ?? '?'}→${position.signalTimeframe ?? '?'} · 1:${position.rewardRisk ?? rewardRisk}`,
        chartTimeframe: signalTimeframe,
      }];
    })
  ), [granularity, mt5Status?.positions, mt5Status?.recentSignals, tradeStyleEnabled, scalpChartDisplays]);

  const liveMtfTableTrades = useMemo<LiveMt5TableTrade[]>(() => (
    (mt5Status?.positions ?? []).flatMap((position) => {
      if (position.source !== 'MTF' && !position.setupId?.startsWith('MTF:')) return [];
      if (marketSymbol !== 'XAUUSD' || replayIndex !== null
        || (position.zoneTimeframe !== granularity && position.signalTimeframe !== granularity)) return [];
      const overlay = liveMt5TradeOverlays.find((candidate) => candidate.id === `MT5:${position.ticket}`);
      if (!overlay) return [];
      const signal = (mt5Status?.recentSignals ?? []).find((candidate) => (
        candidate.brokerTicket === position.ticket
        || (position.setupId !== undefined && candidate.setupId === position.setupId
          && ['ACTIVE', 'RISK_FREE', 'PLACED'].includes(candidate.status))
      ));
      return [{ position, trade: overlay.trade, signal }];
    })
  ), [liveMt5TradeOverlays, mt5Status?.positions, mt5Status?.recentSignals, marketSymbol, granularity, replayIndex]);

  const recordedMtfTrades = useMemo(() => {
    const chartEnd = displayCandles[displayCandles.length - 1]?.time;
    if (chartEnd === undefined) return [];
    const cutoff = chartEnd + TIMEFRAME_SECONDS[granularity];
    return deduplicateTradeRecords([...savedJournalTrades, ...openChartJournalTrades])
      .filter(record => record.source === 'MTF'
        && (record.symbol ?? 'XAUUSD') === marketSymbol
        && (record.zoneTimeframe === granularity || record.signalTimeframe === granularity)
        && tradeStyleEnabled(record)
        && (record.openedAt ?? record.signalAt ?? Infinity) <= cutoff
        // A completed record cannot reveal a future result while replaying.
        && (replayIndex === null || record.completedAt <= cutoff))
      .slice(0, 20)
      .flatMap(record => {
        const verified = validateRecordedMtfTrade(record,
          tableTimeframeData[record.signalTimeframe]?.candles, savedChartMtfEntryQualification);
        return verified ? [verified] : [];
      });
  }, [savedJournalTrades, openChartJournalTrades, displayCandles, granularity, marketSymbol,
    tradeStyleEnabled, replayIndex, savedChartMtfEntryQualification, tableTimeframeData]);

  const mtfDrawingZones = useMemo(() => {
    const zones = new Map<string, { zone: StructureZone; label: string; timeframe: TradeTimeframe; endTime: number }>();
    const add = (context: MtfRow | undefined, endTime: number) => {
      if (!context || !(context.higherTimeframe === granularity || context.lowerTimeframe === granularity)) return;
      for (const [zone, timeframe, role] of [
        [context.higherZone, context.higherTimeframe, 'SETUP'],
        [context.entryZone, context.lowerTimeframe, 'ENTRY'],
      ] as const) {
        if (!zone) continue;
        zones.set(`${timeframe}:${zone.id}`, {
          zone, timeframe, label: `${formatTradeTimeframe(timeframe)} MTF ${role} · ${zone.name}`,
          endTime: Math.max(zone.startTime + TIMEFRAME_SECONDS[granularity], endTime),
        });
      }
    };
    const now = displayCandles[displayCandles.length - 1]?.time ?? 0;
    for (const row of mtfRows) if (!hasTradeDisplayExpired(row.trade ?? row.previewTrade)) add(row, now);
    for (const record of recordedMtfTrades) if (!hasTradeDisplayExpired(record)) add(record.mtfContext,
      ['open', 'risk-free'].includes(record.result) ? now : record.completedAt);
    for (const { signal } of liveMtfTableTrades) if (!hasTradeDisplayExpired(signal)) add(signal?.journalContext?.mtfContext, now);
    return [...zones.values()];
  }, [hasTradeDisplayExpired, mtfRows, recordedMtfTrades, liveMtfTableTrades, displayCandles, granularity]);

  const completedChartTradeKeys = useMemo(() => {
    const setupKeys = new Set<string>();
    const entryEventKeys = new Set<string>();
    const addCompletedEntry = (setupKey: string, signal: TradeLevels['signal']) => {
      const eventKey = tradeOverlayEntryEventKey(signal);
      setupKeys.add(tradeOverlaySetupEntryKey(setupKey, eventKey));
      entryEventKeys.add(eventKey);
    };
    for (const overlay of retainedChartTradesForTimeframe) {
      if (!isCompletedTrade(overlay.trade)) continue;
      addCompletedEntry(tradeOverlaySetupKey(overlay), overlay.trade.signal);
    }
    for (const [zoneId, trade] of directZoneTrades) {
      if (!isCompletedTrade(trade)) continue;
      addCompletedEntry(resolveTradeOverlaySetupKey(
        `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`,
      ), trade.signal);
    }
    for (const row of mtfRows) {
      if (!row.trade || !isCompletedTrade(row.trade)) continue;
      addCompletedEntry(resolveTradeOverlaySetupKey(
        `MTF:${row.id}:${row.engulfingTime}:${row.trade.entry}`,
      ), row.trade.signal);
    }
    for (const record of visibleSavedJournalTrades) {
      if ((record.symbol ?? 'XAUUSD') !== marketSymbol || !record.signalAt || record.completedAt > tradeDisplayAsOf
        || (!['sl', 'tp', 'rf'].includes(record.result) && !hasTradeDrawingExpired(record))) continue;
      const eventKey = tradeOverlayEntryEventKey({
        timeframe: record.signalTimeframe, direction: record.direction, time: record.signalAt,
      });
      setupKeys.add(tradeOverlaySetupEntryKey(resolveTradeOverlaySetupKey(record.id, record.setupId), eventKey));
      entryEventKeys.add(eventKey);
    }
    return { setupKeys, entryEventKeys };
  }, [directZoneTrades, mtfRows, visibleSavedJournalTrades, marketSymbol, tradeDisplayAsOf, hasTradeDrawingExpired, retainedChartTradesForTimeframe]);

  const pullbackChartSetups = useMemo(() => {
    if (marketSymbol !== 'XAUUSD') return [];
    const history: PullbackTableSignal[] = scalpOneToOneChartFills.flatMap(fill => {
      if (!fill.signal || fill.trade.filledAt === undefined || fill.trade.filledAt + 900 > tradeDisplayAsOf) return [];
      const signal = chartSignalFromHistoryFill(fill);
      return signal ? [signal] : [];
    });
    const records = visibleCanonicalTradeRecords.flatMap(record => {
      const signal = chartSignalFromRecord(record); return signal ? [signal] : [];
    });
    const previews: PullbackTableSignal[] = [...scalpOneToOnePreview, ...intradayPullbackPreview].map(signal => ({
      ...signal, status: 'SIMULATED', preview: true, createdAt: signal.calculatedAt, updatedAt: signal.calculatedAt,
    }));
    return buildPullbackChartSetups({ signals: [...history, ...records, ...previews,
      ...(replayIndex === null ? mt5Status?.recentSignals ?? [] : [])], asOf: tradeDisplayAsOf,
      candles: Object.fromEntries(Object.keys(tableTimeframeData).map(tf => [tf, tableTimeframeData[tf as TradeTimeframe]?.candles ?? []])),
      positions: replayIndex === null ? mt5Status?.positions ?? [] : [], context: mt5Status?.bridge ?? {},
    }).filter(setup => setup.chartTimeframe === granularity
      && (setup.style === 'SCALP_1_1' ? scalpOneToOneEnabled || setup.alwaysVisible : intradayEnabled || setup.alwaysVisible));
  }, [marketSymbol, granularity, scalpOneToOneChartFills, visibleCanonicalTradeRecords, scalpOneToOnePreview,
    intradayPullbackPreview, mt5Status, replayIndex, tradeDisplayAsOf, tableTimeframeData, scalpOneToOneEnabled, intradayEnabled]);

  const chartFillAlertBusy = useRef(false);
  const chartFillAlertSent = useRef(new Set<string>());
  useEffect(() => {
    if (terminalId !== 'primary' || !canAdmin || replayIndex !== null || chartFillAlertBusy.current || !telegramMessagesEnabled
      || mt5Status?.config?.telegramMessagesEnabled === false) return;
    const alerts = pullbackChartSetups.flatMap(setup => pullbackTelegramAlerts(setup, tradeDisplayAsOf))
      .filter(alert => !chartFillAlertSent.current.has(`${alert.id}:${alert.kind}`)).slice(0, 40);
    if (!alerts.length) return;
    chartFillAlertBusy.current = true;
    void fetch('/api/telegram/alerts', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alerts }) }).then(async response => {
      if (!response.ok) return;
      const payload = await response.json();
      for (const id of payload.acknowledged ?? []) chartFillAlertSent.current.add(id);
    }).catch(error => console.error('Chart fill Telegram alert failed:', error))
      .finally(() => { chartFillAlertBusy.current = false; });
  }, [terminalId, canAdmin, pullbackChartSetups, replayIndex, telegramMessagesEnabled, mt5Status?.config?.telegramMessagesEnabled, tradeDisplayAsOf]);

  const visibleTradeOverlays = useMemo(() => {
    const overlays = new Map<string, TradeOverlay>();
    const chartSetupKeys = new Set<string>();
    const entryEventKeys = new Set<string>();
    const addOverlay = (overlay: TradeOverlay) => {
      if (isSlTpTradeDisplayFinished(overlay.trade)
        && (overlay.id.startsWith('SCALP_1_1:') || overlay.setupId?.startsWith('SCALP_1_1:')
          || overlay.label?.toUpperCase().includes('SCALP 1:1'))) return;
      if (hasTradeDrawingExpired(overlay.trade)) return;
      if (!overlay.alwaysVisible && !overlayStyleEnabled(overlay)) return;
      if ((overlay.symbol ?? 'XAUUSD') !== marketSymbol) return;
      if (!overlay.alwaysVisible && !overlay.id.startsWith('MT5:') && blockedGoldChartEntry(
        overlay.trade.signal.time, overlay.trade.signal.timeframe,
        overlay.trade.signal.direction,
      )) return;
      if (!overlay.alwaysVisible && !overlay.referenceOnly && !isCompletedTrade(overlay.trade) && !hasRetainedDirectTradeSource(overlay)) return;
      // The result owns the five-bar window; stale active copies must not reappear afterward.
      const setupKey = tradeOverlaySetupKey(overlay);
      const entryEventKey = tradeOverlayEntryEventKey(overlay.trade.signal);
      const setupEntryKey = tradeOverlaySetupEntryKey(setupKey, entryEventKey);
      const liveBrokerPosition = replayIndex === null
        && liveMt5TradeOverlays.some((live) => live.id === overlay.id);
      if (!liveBrokerPosition && isDirectTradeOverlay(overlay.id, overlay.setupId)
        && !internalSbrTableSourceVisible(tradeOverlayZoneLabel(overlay.label),
          directTradeOverlayZoneId(overlay), displayZones, showInternal)) return;
      if (!liveBrokerPosition && !isCompletedTrade(overlay.trade) && !overlay.referenceOnly && isTradeOverlayTerminated(
        setupKey,
        entryEventKey,
        false,
        completedChartTradeKeys.setupKeys,
        completedChartTradeKeys.entryEventKeys,
      )) return;
      if (!isTradeOverlayVisibleOnTimeframe(overlay.chartTimeframe, granularity)) return;
      if (!liveBrokerPosition && !overlay.referenceOnly && (setupKey.startsWith('DIRECT:') || setupKey.startsWith('MTF:'))
        && chartSetupKeys.has(setupEntryKey)) return;
      // OANDA/chart recalculation can revise a zone ID or its SL/TP after MT5
      // has filled it. The entry candle still identifies the same execution.
      if (!liveBrokerPosition && !overlay.referenceOnly && entryEventKeys.has(entryEventKey)) return;
      const signature = liveBrokerPosition ? `LIVE:${overlay.id}` : overlay.referenceOnly ? `REFERENCE:${overlay.id}` : [
        overlay.trade.entry,
        overlay.trade.stopLoss,
        overlay.trade.takeProfit,
        overlay.trade.signal.direction,
      ].join(':');
      if (!overlays.has(signature)) {
        overlays.set(signature, overlay);
        if (!overlay.referenceOnly && (setupKey.startsWith('DIRECT:') || setupKey.startsWith('MTF:'))) {
          chartSetupKeys.add(setupEntryKey);
        }
        if (!overlay.referenceOnly) entryEventKeys.add(entryEventKey);
      }
    };
    // An open broker position owns its drawing, including after partial RF.
    if (replayIndex === null) liveMt5TradeOverlays.forEach(addOverlay);
    scalpChartDisplays.filter(item => item.referenceOnly && !item.markerOnly).forEach(addOverlay);
    // A final exit starts the drawing's five-completed-candle retention window.
    for (const record of deduplicateTradeRecords<JournalTradeRecord>(visibleSavedJournalTrades)) {
      if (!['sl', 'tp', 'rf', 'risk-free'].includes(record.result)
        || (record.symbol ?? 'XAUUSD') !== marketSymbol || record.signalTimeframe !== granularity
        || record.completedAt > tradeDisplayAsOf || hasTradeDrawingExpired(record)
        || !tradeStyleEnabled(record)) continue;
      addOverlay({ id: record.id, setupId: record.setupId, symbol: marketSymbol,
        trade: tradeDrawingFromRecord(record), chartTimeframe: record.signalTimeframe,
        label: `${record.zoneName} · ${record.tradeStyle === 'SCALPING' ? 'SCALP · ' : ''}${record.source}` });
    }
    for (const [zoneId, trade] of directZoneTrades) {
      if (!isCompletedTrade(trade)) continue;
      addOverlay({ id: `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`, symbol: marketSymbol,
        trade, chartTimeframe: trade.signal.timeframe, label: 'TRADE RESULT' });
    }
    for (const row of mtfRows) {
      if (!row.trade || !isCompletedTrade(row.trade)) continue;
      addOverlay({ id: `MTF:${row.id}:${row.trade.signal.time}:${row.trade.entry}`, symbol: marketSymbol,
        trade: row.trade, chartTimeframe: row.lowerTimeframe, label: `${row.goldScalping ? 'SCALP ' : ''}MTF RESULT` });
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingAccuracyTrades) {
      if (!isCompletedTrade(trade)) continue;
      addOverlay({ id: `GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`, symbol: marketSymbol,
        trade, chartTimeframe: trade.signal.timeframe, label: `${zone.name} · SCALP RESULT` });
    }
    retainedChartTradesForTimeframe.forEach(addOverlay);
    tradeOverlays.forEach(addOverlay);
    for (const [zoneId, decision] of directZoneEntryDecisions) {
      const trade = decision.previewTrade;
      if (!trade) continue;
      addOverlay({
        id: `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`,
        symbol: marketSymbol,
        trade,
        label: `1:${trade.rewardRisk}`,
        chartTimeframe: trade.signal.timeframe,
        referenceOnly: true,
      });
    }
    for (const row of mtfRows) {
      if (!row.previewTrade) continue;
      addOverlay({
        id: `MTF:${row.id}:${row.engulfingTime}:${row.previewTrade.entry}`,
        symbol: marketSymbol,
        trade: row.previewTrade,
        label: `1:${row.previewTrade.rewardRisk}`,
        chartTimeframe: row.lowerTimeframe,
        referenceOnly: true,
      });
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingAccuracyTrades) {
      if (!tradingTimeEnabled || (isNepalTradingTime(trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe])
        && (trade.filledAt === undefined || isNepalTradingTime(trade.filledAt)))) continue;
      addOverlay({
        id: `GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`,
        symbol: marketSymbol,
        trade,
        label: `1:${trade.rewardRisk}`,
        chartTimeframe: trade.signal.timeframe,
        referenceOnly: true,
      });
    }
    const grouped: TradeOverlay[] = pullbackChartSetups.filter(setup => setup.drawing).map(setup => ({
      ...setup, pullbackSetup: setup,
    }));
    return [...Array.from(overlays.values()).filter(overlay => !pullbackChartSetups.some(setup =>
      belongsToPullbackSetup(setup, overlay.trade, undefined, overlay))), ...grouped]
      .sort((first, second) => second.trade.calculatedAt - first.trade.calculatedAt);
  }, [pullbackChartSetups, scalpChartDisplays, blockedGoldChartEntry, displayZones, showInternal, hasTradeDrawingExpired, visibleSavedJournalTrades, directZoneTrades, granularity, tradeDisplayAsOf, tradeStyleEnabled, completedChartTradeKeys, directZoneEntryDecisions, goldScalpingAccuracyTrades, hasRetainedDirectTradeSource, liveMt5TradeOverlays, marketSymbol, mtfRows, overlayStyleEnabled, replayIndex, retainedChartTradesForTimeframe, tradeOverlays, tradingTimeEnabled]);

  useEffect(() => {
    if (replayIndex !== null || !mt5Status?.config
      || mt5Status.config.telegramMessagesEnabled === false
      || !telegramMessagesEnabled || telegramAlertSendingRef.current) return;
    const now = Math.floor(Date.now() / 1000);
    const alerts = new Map<string, Record<string, unknown>>();
    const addEntry = (details: {
      zoneName: string; zoneTimeframe: TradeTimeframe;
      source?: 'MTF' | 'ENGULFING'; higherZoneName?: string; entryZoneName?: string;
      tradeStyle?: 'SCALPING' | 'INTRADAY' | 'SCALP_1_1' | 'BOLLINGER_M5';
      trade: TradeLevels;
    }) => {
      const { trade } = details;
      if (marketSymbol === 'XAUUSD' && details.tradeStyle !== 'SCALPING') return;
      if (!isTradeStyleEnabled({ scalpingEnabled, intradayEnabled, scalpOneToOneEnabled, bollingerM5Enabled }, details)) return;
      if (trade.filledAt === undefined || trade.filledAt > now + 5
        || now - trade.filledAt > 180) return;
      const id = [marketSymbol, trade.signal.direction, trade.signal.timeframe,
        trade.signal.time, trade.entry.toFixed(5)].join(':');
      const alert = {
        id, kind: 'entry', symbol: marketSymbol,
        outsideTradingTime: !isNepalTradingTime(
          trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe],
        ) || !isNepalTradingTime(trade.filledAt),
        direction: trade.signal.direction === 'bullish' ? 'BUY' : 'SELL',
        zoneName: details.zoneName, zoneTimeframe: details.zoneTimeframe,
        source: details.source, higherZoneName: details.higherZoneName, entryZoneName: details.entryZoneName,
        signalTimeframe: trade.signal.timeframe, engulfingType: trade.signal.type,
        entry: trade.entry, stopLoss: trade.stopLoss, takeProfit: trade.takeProfit,
        riskPips: trade.riskPips, rewardRisk: trade.rewardRisk, openedAt: trade.filledAt,
        tradeStyle: details.tradeStyle,
        ...(details.tradeStyle === 'SCALPING' ? { riskFree: trade.riskFree } : {}),
      };
      if (!telegramAlertSentRef.current.has(`${id}:entry`)) alerts.set(`${id}:entry`, alert);
    };
    for (const overlay of tradeOverlays) {
      const { trade } = overlay;
      if (trade.result || trade.filledAt === undefined) continue;
      const mtfRow = overlay.id.startsWith('MTF:')
        ? mtfRows.find((row) => row.trade?.signal.time === trade.signal.time
          && row.trade.entry === trade.entry) : undefined;
      const zoneTimeframe = mtfRow?.higherTimeframe
        ?? (overlay.id.startsWith('GOLD_SCALP:')
          ? overlay.id.split(':')[1] as TradeTimeframe : granularity);
      addEntry({
        zoneName: mtfRow?.tappedZone ?? mtfRow?.higherTimeframeZone
          ?? tradeOverlayZoneLabel(overlay.label) ?? 'Chart entry',
        zoneTimeframe, trade,
        source: mtfRow || overlay.id.startsWith('MTF:') ? 'MTF' : 'ENGULFING',
        higherZoneName: mtfRow?.higherTimeframeZone,
        entryZoneName: mtfRow?.entryZone?.name ?? mtfRow?.tappedZone,
        tradeStyle: marketSymbol === 'XAUUSD'
          ? mtfRow?.goldScalping || overlay.id.startsWith('GOLD_SCALP:')
            ? 'SCALPING' : 'INTRADAY' : undefined,
      });
    }
    for (const [zoneId, decision] of directZoneEntryDecisions) {
      if (!decision.previewTrade) continue;
      const zone = displayZones.find((candidate) => candidate.id === zoneId);
      addEntry({
        zoneName: zone ? executionZoneName(zone) : 'Chart entry',
        zoneTimeframe: granularity,
        tradeStyle: marketSymbol === 'XAUUSD' ? 'INTRADAY' : undefined,
        trade: decision.previewTrade,
      });
    }
    for (const row of mtfRows) {
      if (!row.previewTrade) continue;
      addEntry({
        zoneName: row.tappedZone ?? row.higherTimeframeZone,
        source: 'MTF', higherZoneName: row.higherTimeframeZone,
        entryZoneName: row.entryZone?.name ?? row.tappedZone,
        zoneTimeframe: row.higherTimeframe,
        tradeStyle: marketSymbol === 'XAUUSD'
          ? row.goldScalping ? 'SCALPING' : 'INTRADAY' : undefined,
        trade: row.previewTrade,
      });
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingAccuracyTrades) {
      if (isNepalTradingTime(trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe])
        && (trade.filledAt === undefined || isNepalTradingTime(trade.filledAt))) continue;
      addEntry({ zoneName: executionZoneName(zone), zoneTimeframe, tradeStyle: 'SCALPING', trade });
    }
    for (const record of [...allSavedAccuracyRecords].sort((first, second) => second.completedAt - first.completedAt)) {
      if (record.scalpEntry || record.intradayEntry) continue;
      if (record.tradeStyle === 'BOLLINGER_M5') continue; // Server owns these alerts; chart studies never send messages.
      if (record.tradeStyle === 'SCALP_1_1' && !record.mt5Managed && record.brokerTicket === undefined) continue;
      if (record.symbol && record.symbol !== marketSymbol) continue;
      if (!record.openedAt || !record.signalAt || !['tp', 'sl'].includes(record.result)
        || now - record.completedAt > 86_400) continue;
      const id = [marketSymbol, record.direction, record.signalTimeframe,
        record.signalAt, record.entry.toFixed(5)].join(':');
      const entryKey = `${id}:entry`;
      if (now - record.openedAt <= 180 && !telegramAlertSentRef.current.has(entryKey)
        && !alerts.has(entryKey)) {
        addEntry({
          zoneName: record.zoneName, zoneTimeframe: record.zoneTimeframe,
          source: record.source,
          higherZoneName: record.mtfContext?.higherTimeframeZone
            ?? (record.source === 'MTF' ? record.zoneId?.match(/^(.+)-\d{9,}-.+$/)?.[1] : record.zoneName),
          entryZoneName: record.source === 'MTF' ? record.mtfContext?.entryZone?.name ?? record.zoneName : undefined,
          tradeStyle: record.tradeStyle,
          trade: {
            entry: record.entry, stopLoss: record.stopLoss, takeProfit: record.takeProfit,
            riskFree: record.direction === 'bullish'
              ? record.entry + Math.abs(record.entry - record.stopLoss)
              : record.entry - Math.abs(record.entry - record.stopLoss),
            riskPips: record.riskPips, rewardRisk: record.rewardRisk,
            status: record.result === 'tp' ? 'tp-hit' : 'sl-hit', pendingAtCreation: false,
            calculatedAt: record.signalAt, filledAt: record.openedAt,
            signal: { type: record.engulfingType as EngulfingTradeSignal['type'],
              direction: record.direction, timeframe: record.signalTimeframe,
              time: record.signalAt, candleCount: 2 },
          },
        });
      }
      const resultKey = `${id}:${record.result}`;
      if (telegramAlertSentRef.current.has(resultKey) || !record.completedAt) continue;
      const returnR = record.result === 'sl' ? -1
        : record.tradeStyle === 'INTRADAY' && !record.partialClosedAt
          ? record.rewardRisk : (1 + record.rewardRisk) / 2;
      alerts.set(resultKey, {
        id, kind: record.result, symbol: marketSymbol,
        direction: record.direction === 'bullish' ? 'BUY' : 'SELL',
        zoneName: record.zoneName, zoneTimeframe: record.zoneTimeframe,
        signalTimeframe: record.signalTimeframe, engulfingType: record.engulfingType,
        entry: record.entry, stopLoss: record.stopLoss, takeProfit: record.takeProfit,
        riskPips: record.riskPips, rewardRisk: record.rewardRisk, openedAt: record.openedAt,
        tradeStyle: record.tradeStyle,
        closedAt: record.closedAt ?? record.completedAt,
        exitPrice: record.closePrice ?? (record.result === 'tp' ? record.takeProfit : record.stopLoss),
        returnR,
      });
    }
    if (alerts.size === 0) return;
    telegramAlertSendingRef.current = true;
    const batch = Array.from(alerts.entries()).slice(0, 40);
    void terminalFetch('/api/telegram/alerts', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alerts: batch.map(([, alert]) => alert) }),
    }).then(async (response) => {
      if (!response.ok) return;
      const payload = await response.json() as { acknowledged?: string[] };
      for (const key of payload.acknowledged ?? []) telegramAlertSentRef.current.add(key);
    }).catch(() => undefined).finally(() => {
      telegramAlertSendingRef.current = false;
    });
  }, [allSavedAccuracyRecords, directZoneEntryDecisions, displayZones, goldScalpingAccuracyTrades, granularity, marketSymbol, mt5Status?.config?.telegramMessagesEnabled, mtfRows, replayIndex, telegramMessagesEnabled, tradeOverlays, scalpingEnabled, intradayEnabled, scalpOneToOneEnabled]);

  const chartEntryRecords = useMemo(() => selectTradeChartRecords(
    deduplicateTradeRecords([
      ...openChartJournalTrades.filter(tradeStyleEnabled),
      ...visibleCanonicalTradeRecords,
    ]), granularity, displayCandles, marketSymbol === 'XAUUSD',
    { includeActive: true, asOf: replayResultCutoff },
  ), [openChartJournalTrades, tradeStyleEnabled, visibleCanonicalTradeRecords,
    granularity, displayCandles, marketSymbol, replayResultCutoff]);
  const hoveredTradeZones = useMemo(() => {
    const record = chartEntryRecords.find((candidate) => candidate.id === hoveredEntry?.entry.id);
    if (!record) return undefined;
    return resolveArrowTradeZones(record, mt5Status?.recentSignals ?? [], (id) => (
      savedChartMtfEntryQualification({
        id, signalTime: record.signalAt!, direction: record.direction,
        engulfingType: record.engulfingType as EngulfingTradeSignal['type'],
        zoneName: record.zoneName, goldScalping: record.tradeStyle === 'SCALPING',
      })?.context
    ));
  }, [chartEntryRecords, hoveredEntry?.entry.id, mt5Status?.recentSignals, savedChartMtfEntryQualification]);
  const hoveredTrendlineSupport = useMemo(() => {
    const entry = hoveredEntry?.entry;
    if (!entry) return undefined;
    const record = chartEntryRecords.find(candidate => candidate.id === entry.id);
    const zoneTimeframe = record?.zoneTimeframe ?? entry.trade.signal.timeframe;
    const confirmedAt = entry.trade.signal.time + TIMEFRAME_SECONDS[entry.trade.signal.timeframe];
    const candles = { ...vipCandles, [granularity]: displayCandles };
    const evidence = collectStudySupport(candles, zoneTimeframe,
      entry.trade.signal.direction === 'bullish', confirmedAt, marketConfig.pipSize);
    const { support: matches, distanceContext } = measureStudySupportDistance(evidence, candles, entry.trade, marketConfig.pipSize);
    const unavailable = studyTimeframes(zoneTimeframe).filter(timeframe => (
      studyClosedCandles(candles[timeframe] ?? [], timeframe, confirmedAt).length < 9
    ));
    return { matches, unavailable, distanceContext };
  }, [hoveredEntry?.entry, chartEntryRecords, vipCandles, granularity, displayCandles, marketConfig.pipSize]);
  const zoneTableTrade = (trade: TradeLevels | undefined, zone?: DisplayStructureZone, zoneName?: string, recordId?: string) => {
    const resolved = resolveZoneTableTrade(trade, visibleCanonicalTradeRecords, tradeDisplayAsOf,
      zone ? displayZoneMembers(zone).map(member => member.id)
        : visibleCanonicalTradeRecords.filter(record => record.id === recordId && record.zoneId)
          .map(record => record.zoneId!),
      zone ? displayZoneMembers(zone).map(member => executionZoneName(member)) : zoneName ? [zoneName] : []);
    return resolved && marketSymbol === 'XAUUSD' && isGoldIntradayCandleRoute(granularity, resolved.signal.timeframe)
      ? { ...resolved, intradayReference: true } : resolved;
  };
  // Resolve saved row visibility once so a hidden/expired row cannot suppress a current entry.
  const retainedDirectZoneTableCandidates: DirectZoneTableRow[] = retainedDirectChartTradesForTimeframe.flatMap((overlay) => {
    const sourceZoneId = directTradeOverlayZoneId(overlay);
    const matchesSource = (zone: StructureZone) => sourceZoneId !== undefined
      && tradeOverlayZoneOriginKey(zone.id) === tradeOverlayZoneOriginKey(sourceZoneId)
      && zone.isBuy === (overlay.trade.signal.direction === 'bullish');
    const sourceZone = displayZones.find((zone) => zone.id === sourceZoneId)
      ?? displayZones.find(matchesSource)
      ?? [...trackedDirectTradeSetups.values()].find((setup) => (
        setup.scope === tradeTrackingScope && matchesSource(setup.zone)
      ))?.zone;
    const trade = zoneTableTrade(overlay.trade, sourceZone, tradeOverlayZoneLabel(overlay.label), overlay.id);
    if (!trade || hasZoneTableTradeExpired(trade, sourceZone)) return [];
    const record = [...visibleCanonicalTradeRecords, ...openChartJournalTrades, ...visibleSavedJournalTrades].find(candidate => candidate.id === overlay.id);
    const setup = [...trackedDirectTradeSetups.values()].find(candidate => matchesSource(candidate.zone)
      && candidate.signal.time === trade.signal.time && candidate.signal.timeframe === trade.signal.timeframe);
    const inferred = (['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D'] as const)
      .filter(timeframe => tableTimeframeData[timeframe]?.structure?.zones.some(matchesSource));
    const sourceTimeframe = resolveZoneTableSourceTimeframe({ stored: overlay.zoneTimeframe,
      recorded: record?.zoneTimeframe, setup: setup?.rule.zoneTimeframe, inferred });
    return [{ overlay, sourceZoneId, sourceZone, trade,
      sourceTimeframe,
      confirmedAt: trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe],
      tapCount: sourceZone ? displayedTapCount(sourceZone) : undefined }];
  });
  // Only this table groups later signals. Saved trades, arrows and execution rules are untouched.
  const listedDirectZoneKeys = new Map<string, DirectZoneTableRow>(retainedDirectZoneTableCandidates.filter(row => row.sourceZoneId).map(row => [
    directZoneTableGroupKey(row.sourceZoneId!, row.overlay.symbol ?? marketSymbol, row.trade.signal.direction), row,
  ]));
  for (const record of visibleCanonicalTradeRecords) {
    if ((record.symbol ?? 'XAUUSD') !== marketSymbol || record.source !== 'ENGULFING'
      || !isDirectTradeOverlay(record.id, record.setupId) || record.signalAt === undefined || record.openedAt === undefined
      || record.openedAt > tradeDisplayAsOf || record.completedAt > tradeDisplayAsOf
      || (tradingTimeEnabled && tradeRecordOutsideTradingTime(record))) continue;
    const setupKey = resolveTradeOverlaySetupKey(record.id, record.setupId);
    const sourceZoneId = record.zoneId ?? (setupKey.startsWith('DIRECT:') ? setupKey.slice(7) : undefined);
    if (!sourceZoneId) continue;
    const listed = listedDirectZoneKeys.get(directZoneTableGroupKey(sourceZoneId, marketSymbol, record.direction));
    if (!listed) continue;
    const trade = tradeDrawingFromRecord(record);
    if (record.result === 'open') trade.status = 'active';
    if (hasZoneTableTradeExpired(trade, listed.sourceZone)) continue;
    retainedDirectZoneTableCandidates.push({ ...listed, sourceZoneId, trade, sourceTimeframe: record.zoneTimeframe,
      overlay: { ...listed.overlay, id: record.id, setupId: record.setupId, symbol: marketSymbol,
        trade, label: `${record.zoneName} · ${record.source}` },
      confirmedAt: trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe] });
  }
  const zoneTableConfirmations: ZoneTableConfirmation[] = [];
  for (const timeframe of ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D'] as const) {
    const data = tableTimeframeData[timeframe];
    for (const zone of data?.structure?.zones ?? []) {
      const signal = resolveZoneEngulfingSignal(zone, timeframe as TradeTimeframe);
      if (!signal || !listedDirectZoneKeys.has(directZoneTableGroupKey(zone.id, marketSymbol, signal.direction))) continue;
      const confirmedAt = signal.time + TIMEFRAME_SECONDS[signal.timeframe];
      if ((tradingTimeEnabled && !isNepalTradingTime(confirmedAt))
        || blockedGoldChartEntry(signal.time, signal.timeframe, signal.direction)) continue;
      zoneTableConfirmations.push({ sourceZoneId: zone.id, symbol: marketSymbol, signal, confirmedAt });
    }
  }
  const retainedDirectZoneTableRows = groupDirectZoneTableRows(
    retainedDirectZoneTableCandidates, zoneTableConfirmations, tradeDisplayAsOf,
  );
  const entryHovers = useMemo<EntryHover[]>(() => {
    const entries = new Map<string, EntryHover>();
    const add = (id: string, trade: TradeLevels, source: string, zone: string, fib: string, style: string, tradingTimeBlocked: boolean, chartEntryTime = trade.signal.time, display?: ScalpChartDisplay) => {
      const candle = displayCandles.find((candidate) => (
        chartEntryTime >= candidate.time
        && chartEntryTime < candidate.time + TIMEFRAME_SECONDS[granularity]
      ));
      if (!candle) return;
      if (!entries.has(id)) entries.set(id, {
        id, candleTime: candle.time, high: candle.high, low: candle.low,
        trade, source, zone, fib, style, tradingTimeBlocked, display,
      });
    };
    for (const item of scalpChartDisplays) {
      if (item.markerOnly && chartEntryRecords.some(record => record.tradeStyle === 'SCALP_1_1'
        && (record.mt5Managed || record.brokerTicket !== undefined) && record.signalAt === item.trade.signal.time
        && record.signalTimeframe === item.trade.signal.timeframe && record.direction === item.trade.signal.direction
        && record.scalpEntry?.leg === item.entryLeg)) continue;
      add(item.id, item.trade, item.statusText, 'Scalp setup', 'Not recorded', item.style, false, item.markerTime, item);
    }
    const historyDisplays = marketSymbol === 'XAUUSD' && granularity === 'M15'
      ? scalpHistoryFillDisplays(scalpOneToOneChartFills, tradeDisplayAsOf) : [];
    for (const item of historyDisplays) {
      if (scalpChartDisplays.some(current => current.chartFilled && entries.has(current.id)
        && current.trade.signal.time === item.trade.signal.time && current.trade.signal.direction === item.trade.signal.direction
        && (current.entryLeg === undefined || current.entryLeg === item.entryLeg))) continue;
      if (chartEntryRecords.some(record => record.tradeStyle === 'SCALP_1_1' && (record.mt5Managed || record.brokerTicket !== undefined)
        && record.signalAt === item.trade.signal.time && record.direction === item.trade.signal.direction
        && (record.scalpEntry === undefined || record.scalpEntry.leg === item.entryLeg))) continue;
      add(item.id, item.trade, item.statusText, 'Scalp 1:1 chart fill', 'Not recorded', item.style, false, item.markerTime, item);
    }
    for (const record of chartEntryRecords) {
      if (record.tradeStyle === 'BOLLINGER_M5' && !record.mt5Managed && record.brokerTicket === undefined) continue; // Dedicated study overlay.
      if (record.tradeStyle === 'SCALP_1_1' && historyDisplays.some(item => entries.has(item.id)
        && item.trade.signal.time === record.signalAt && item.trade.signal.direction === record.direction
        && item.entryLeg === record.scalpEntry?.leg)) continue;
      if (record.tradeStyle === 'SCALP_1_1' && scalpChartDisplays.some(item => entries.has(item.id) && item.chartFilled
        && item.trade.signal.time === record.signalAt && item.trade.signal.timeframe === record.signalTimeframe
        && item.trade.signal.direction === record.direction
        && (item.entryLeg === undefined || item.entryLeg === record.scalpEntry?.leg))) continue;
      if (scalpChartDisplays.some(item => item.kind === 'live' && record.brokerTicket === item.brokerTicket)) continue;
      if (blockedGoldHistoricalTrade(record)) continue;
      const active = record.result === 'open' || record.result === 'risk-free';
      const signalAt = record.signalAt!;
      const projected = record.signalTimeframe !== granularity;
      const risk = Math.abs(record.entry - record.stopLoss);
      const bullish = record.direction === 'bullish';
      const trade: TradeLevels = {
        entry: record.entry,
        stopLoss: record.stopLoss,
        takeProfit: record.takeProfit,
        riskFree: bullish ? record.entry + risk : record.entry - risk,
        riskFreeEnabled: record.tradeStyle === 'SCALPING' || marketSymbol !== 'XAUUSD',
        riskPips: record.riskPips,
        rewardRisk: record.rewardRisk,
        status: record.result === 'tp' ? 'tp-hit' : record.result === 'sl' ? 'sl-hit'
          : record.result === 'open' ? 'active' : 'risk-free',
        pendingAtCreation: false,
        calculatedAt: signalAt,
        filledAt: record.openedAt,
        result: active ? undefined : record.result as 'tp' | 'sl' | 'rf',
        resolvedAt: active ? undefined : record.completedAt,
        signal: {
          type: record.engulfingType as EngulfingTradeSignal['type'],
          direction: record.direction,
          time: signalAt,
          candleCount: record.engulfingCandleCount ?? (record.engulfingType === 'T1' ? 2 : 3),
          timeframe: record.signalTimeframe,
        },
      };
      add(record.id, trade,
        record.tradeStyle === 'BOLLINGER_M5' ? 'BOLLINGER M5 BROKER ENTRY' : projected ? `${record.signalTimeframe} ${record.tradeStyle === 'SCALPING' ? 'SCALPING' : 'INTRADAY'} ENTRY`
          : record.source === 'MTF'
          ? `${record.zoneTimeframe} → ${record.signalTimeframe} MTF` : 'CANDLE CONFIRMATION',
        record.zoneName,
        [record.fibSource, record.fibBand].filter(Boolean).join(' · ') || 'Not recorded',
        record.tradeStyle ?? 'INTRADAY',
        tradingTimeEnabled && accuracyRecordOutsideTradingTime(record),
        record.tradeStyle === 'SCALP_1_1' || record.tradeStyle === 'BOLLINGER_M5' ? record.openedAt ?? signalAt
          : projected ? record.openedAt ?? signalAt + TIMEFRAME_SECONDS[record.signalTimeframe]
          : signalAt);
    }
    if (replayIndex === null && marketSymbol !== 'XAUUSD') {
      // Gold Intraday arrows come from the qualified layered records above.
      // Project confirmed lower-timeframe entries onto their containing H1 bar.
      for (const [zoneId, decision] of directZoneEntryDecisions) {
        const trade = decision.trade ?? decision.usedZoneTrade;
        if (!directTradeStyleEnabled || !trade || trade.filledAt === undefined || isCompletedTrade(trade)) continue;
        const zone = displayZones.find(candidate => candidate.id === zoneId);
        const id = `DIRECT:${zoneId}:${trade.signal.time}:${trade.entry}`;
        if ([...entries.values()].some(entry => entry.trade.signal.time === trade.signal.time
          && entry.trade.signal.timeframe === trade.signal.timeframe && entry.trade.entry === trade.entry)) continue;
        add(id, trade, decision.usedZoneTrade ? 'CONFIRMED SETUP · ZONE ALREADY USED' : 'CHART ENTRY',
          zone ? executionZoneName(zone) : 'Unknown', zone ? tradeZoneFibLabels(zone).join(' · ') : 'Not recorded',
          marketSymbol === 'XAUUSD' ? 'INTRADAY' : 'ALL', false,
          trade.signal.timeframe === granularity ? trade.signal.time : trade.filledAt);
      }
      for (const overlay of retainedDirectChartTradesForTimeframe) {
        const trade = overlay.trade;
        if (!overlay.id.startsWith('DIRECT:') || overlay.referenceOnly
          || trade.filledAt === undefined) continue;
        add(overlay.id, trade, 'CHART ENTRY', tradeOverlayZoneLabel(overlay.label) ?? 'Unknown',
          overlay.fibLabels?.join(' · ') ?? 'Not recorded',
          marketSymbol === 'XAUUSD' ? 'INTRADAY' : 'ALL', false,
          trade.signal.timeframe === granularity ? trade.signal.time : trade.filledAt);
      }
    }
    const grouped: EntryHover[] = pullbackChartSetups.flatMap(setup => {
      if (setup.markerTime === undefined) return [];
      const candle = displayCandles.find(c => setup.markerTime! >= c.time && setup.markerTime! < c.time + TIMEFRAME_SECONDS[granularity]);
      if (!candle) return [];
      return [{ id: setup.id, candleTime: candle.time, high: candle.high, low: candle.low,
        trade: setup.trade, style: setup.style, source: 'CHART ENTRY', zone: 'Pullback setup',
        fib: 'Not recorded', tradingTimeBlocked: false, pullbackSetup: setup }];
    });
    return [...Array.from(entries.values()).filter(entry => !pullbackChartSetups.some(setup =>
      belongsToPullbackSetup(setup, entry.trade, entry.style, entry))), ...grouped];
  }, [pullbackChartSetups, scalpOneToOneChartFills, tradeDisplayAsOf, scalpChartDisplays, blockedGoldHistoricalTrade, chartEntryRecords, displayCandles, granularity, marketSymbol, replayIndex,
    directTradeStyleEnabled, directZoneEntryDecisions, displayZones, retainedDirectChartTradesForTimeframe, tradingTimeEnabled]);
  const visibleEntryHovers = useMemo(() => entryHovers.filter(entry => (
    matchesTradeStrategies(entry.style, arrowStrategies)
  )), [entryHovers, arrowStrategies]);
  const trendlineSetupLabel = useMemo(() => {
    const records = new Map<string, JournalTradeRecord>(chartEntryRecords.map(record => [record.id, record] as const));
    const key = (trade: TradeLevels) => `${trade.signal.time}:${tradeOverlayExecutionKey(trade)}`;
    const entries = new Map<string, EntryHover>(entryHovers.map(entry => [key(entry.trade), entry] as const));
    const labels = new Map<string, string | undefined>();
    const trendCache = new Map<string, AutoTrendline[]>();
    const candles = { ...vipCandles, [granularity]: displayCandles };
    const cutoff = replayResultCutoff ?? Date.now() / 1000;
    return (trade: TradeLevels | undefined) => {
      if (marketSymbol !== 'XAUUSD' || !trade || trade.signal.timeframe !== 'M15') return undefined;
      const tradeKey = key(trade);
      if (!labels.has(tradeKey)) {
        const entry = entries.get(tradeKey);
        let label: string | undefined;
        if (entry && !entry.tradingTimeBlocked && entry.trade.filledAt !== undefined
          && entry.trade.signal.time + TIMEFRAME_SECONDS.M15 <= cutoff
          && entry.fib.trim() && !/^(not recorded|no fib|none)$/i.test(entry.fib.trim())) {
          const zoneTimeframe = records.get(entry.id)?.zoneTimeframe ?? entry.trade.signal.timeframe;
          const evidence = collectStudySupport(candles, zoneTimeframe,
            entry.trade.signal.direction === 'bullish', entry.trade.signal.time + TIMEFRAME_SECONDS.M15,
            marketConfig.pipSize, trendCache);
          const measured = measureStudySupportDistance(evidence, candles, entry.trade, marketConfig.pipSize);
          const rank = bestTrendlineSetupRank(entry, measured.support, cutoff);
          const secondRank = bestTrendlineSetupRank(entry, measured.support, cutoff, 'second');
          label = rank ? `⭐ BEST TL #${rank}` : secondRank ? `2nd BEST TL #${secondRank}` : undefined;
        }
        labels.set(tradeKey, label);
      }
      return labels.get(tradeKey);
    };
  }, [chartEntryRecords, entryHovers, vipCandles, granularity, displayCandles,
    replayResultCutoff, marketSymbol, marketConfig.pipSize]);
  const bestTrendlineBadge = (trade: TradeLevels | undefined) => {
    const label = trendlineSetupLabel(trade);
    return label ? <span className="ml-1 rounded bg-amber-100 px-1 py-0.5 text-[8px] font-black text-amber-900">
      {label}
    </span> : null;
  };
  const entryArrowStudyEntries = useMemo<EntryArrowStudyEntry[]>(() => {
    if (!showTrendlineStudy) return [];
    const records = new Map<string, JournalTradeRecord>(chartEntryRecords.map(record => [record.id, record] as const));
    return visibleEntryHovers.map(entry => {
      const record = records.get(entry.id);
      const zones = record ? resolveArrowTradeZones(record, mt5Status?.recentSignals ?? [], id => (
        savedChartMtfEntryQualification({ id, signalTime: record.signalAt!, direction: record.direction,
          engulfingType: record.engulfingType as EngulfingTradeSignal['type'],
          zoneName: record.zoneName, goldScalping: record.tradeStyle === 'SCALPING' })?.context
      )) : undefined;
      return { id: entry.id, trade: entry.trade,
        zoneTimeframe: record?.zoneTimeframe ?? entry.trade.signal.timeframe,
        mainZone: zones?.mainZone ?? (record?.source === 'MTF' ? 'Name unavailable in saved history' : entry.zone),
        entryZone: zones?.entryZone ?? entry.zone, source: entry.source, fib: entry.fib,
        style: entry.style, tradingTimeBlocked: entry.tradingTimeBlocked };
    });
  }, [showTrendlineStudy, chartEntryRecords, visibleEntryHovers, mt5Status?.recentSignals, savedChartMtfEntryQualification]);
  const latestCandle = displayCandles[displayCandles.length - 1] || null;
  const previousCandle = displayCandles.length > 1 ? displayCandles[displayCandles.length - 2] : null;
  const headerCandlesByTime = useMemo(() => new Map(displayCandles.map((candle, index) => (
    [candle.time, { candle, previous: index > 0 ? displayCandles[index - 1] : null }] as const
  ))), [displayCandles]);
  const retainedDirectTradeZoneIds = useMemo(() => new Set(
    retainedChartTradesForTimeframe
      .map(directTradeOverlayZoneId)
      .filter((zoneId): zoneId is string => Boolean(zoneId)),
  ), [retainedChartTradesForTimeframe]);
  const zoneTableRows = useMemo(() => {
    if (!directTradeStyleEnabled) return [];
    const candidates = consolidatedDisplayZones
    .filter((zone) => zone.active && zone.status === 'valid'
      && !hasZoneTableTradeExpired(confluenceMapValue<TradeLevels>(zone, directZoneTrades), zone)
      && !displayZoneMembers(zone).some(member => hasZoneTableTradeExpired(directZoneMt5Signals.get(member.id), zone))
      && !redundantStandaloneZoneIds.has(zone.id)
      && ((displayedTapCount(zone) ?? 0) > 1
        || !displayZoneMembers(zone).some((member) => retainedDirectTradeZoneIds.has(member.id)))
      && ((displayedTapCount(zone) ?? 0) > 1
        || !retainedDirectChartTradesForTimeframe.some((overlay) => {
          const trade = confluenceMapValue<TradeLevels>(zone, directZoneTrades);
          return trade && tradeOverlayExecutionKey(overlay.trade) === tradeOverlayExecutionKey(trade);
        }))
      && (showInternal || zone.category !== 'internal')
      && zone.doubleChochStatus === undefined
      && (confluenceTapBarsAgo(zone) ?? Infinity) <= zoneTableTapBarLimit(displayedTapCount(zone), marketSymbol))
    .sort((a, b) => (
      (confluenceLatestTap(b)?.time ?? b.startTime)
      - (confluenceLatestTap(a)?.time ?? a.startTime)
    ));
    const bestByTrade = new Map<string, { zone: DisplayStructureZone; expired: boolean }>();
    for (const zone of candidates) {
      const trade = confluenceMapValue<TradeLevels>(zone, directZoneTrades);
      if (!trade) continue;
      const key = tradeOverlayExecutionKey(trade);
      const expired = marketSymbol === 'XAUUSD' && displayZoneMembers(zone).every((member) => (
        isGoldZoneOpportunityExpired(member, displayCandles, granularity, marketConfig.pipSize,
          Infinity, trade.filledAt === undefined ? undefined
            : { price: trade.entry, filledAt: trade.filledAt, stopLoss: trade.stopLoss })
      ));
      const previous = bestByTrade.get(key);
      if (!previous || (previous.expired && !expired)) bestByTrade.set(key, { zone, expired });
    }
    return candidates.filter((zone) => {
      const trade = confluenceMapValue<TradeLevels>(zone, directZoneTrades);
      return !trade || bestByTrade.get(tradeOverlayExecutionKey(trade))?.zone === zone;
    }).slice(0, 8);
  }, [hasZoneTableTradeExpired, consolidatedDisplayZones, directTradeStyleEnabled, directZoneTrades, directZoneMt5Signals, displayedTapCount, displayCandles, granularity, marketConfig.pipSize, marketSymbol, redundantStandaloneZoneIds, retainedDirectChartTradesForTimeframe, retainedDirectTradeZoneIds, showInternal]);
  const scalpEntryTableRows = useMemo(() => {
    if (!scalpingEnabled) return [];
    const rows = new Map<string, {
      id: string;
      zone: string;
      trade: TradeLevels;
      tradingTimeBlocked: boolean;
    }>();
    for (const entry of entryHovers) {
      if (entry.style !== 'SCALPING' || entry.trade.signal.timeframe !== granularity) continue;
      rows.set(entry.id, {
        id: entry.id,
        zone: entry.zone,
        trade: entry.trade,
        tradingTimeBlocked: entry.tradingTimeBlocked,
      });
    }
    for (const { zone, zoneTimeframe, trade } of goldScalpingAccuracyTrades) {
      if (trade.signal.timeframe !== granularity
        || !displayCandles.some((candle) => candle.time === trade.signal.time)) continue;
      const id = `GOLD_SCALP:${zoneTimeframe}:${zone.id}:${trade.signal.time}:${trade.entry}`;
      if (!rows.has(id)) rows.set(id, {
        id,
        zone: executionZoneName(zone),
        trade,
        tradingTimeBlocked: tradingTimeEnabled
          && (!isNepalTradingTime(trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe])
            || (trade.filledAt !== undefined && !isNepalTradingTime(trade.filledAt))),
      });
    }
    return Array.from(rows.values())
      .filter(({ trade }) => !hasZoneTableTradeExpired(trade,
        goldScalpingAccuracyTrades.find(candidate => candidate.trade.signal.time === trade.signal.time
          && candidate.trade.entry === trade.entry)?.zone))
      .sort((first, second) => second.trade.signal.time - first.trade.signal.time)
      .slice(0, 8);
  }, [hasZoneTableTradeExpired, displayCandles, entryHovers, goldScalpingAccuracyTrades, granularity, scalpingEnabled, tradingTimeEnabled]);
  const replayDirectCandidates = useMemo<EntryHover[]>(() => {
    if (!directTradeStyleEnabled || replayIndex === null || replayResultCutoff === undefined) return [];
    const entries: EntryHover[] = [];
    for (const zone of displayZones) {
      if (redundantStandaloneZoneIds.has(zone.id)
        || extremeAPlusTjl2Selection.blockedZoneIds.has(zone.id)
        || zone.status === 'rejected'
        || (!isZoneEligibleForEngulfingEntry(zone) && zone.tradeable === false)) continue;
      const signal = resolveZoneEngulfingSignal(zone, granularity);
      if (!signal || signal.timeframe !== granularity) continue;
      if (pendingM15DbBlocksSignal(zone, signal) || expiredGoldZoneBeforeSignal(zone, signal)) continue;
      if (marketSymbol === 'XAUUSD'
        && !isGoldIntradayCandleRoute(granularity, signal.timeframe)) continue;
      const confirmationTime = signal.time + TIMEFRAME_SECONDS[signal.timeframe];
      if (confirmationTime > replayResultCutoff
        || !displayCandles.some((candle) => candle.time >= confirmationTime)) continue;
      const baseRule = getDirectTradeRule(granularity, signal.timeframe);
      if (!baseRule) continue;
      const rule = resolveRuleForDirectEntry({
        zoneTimeframe: granularity,
        signal,
        sourceCandles: displayCandles,
        baseRule,
      });
      if (!rule) continue;
      const trade = calculateTradeLevels({
        sourceCandles: displayCandles,
        executionCandles: displayCandles,
        signal,
        rule,
        riskFreeEnabled: marketSymbol !== 'XAUUSD',
        omitStopBuffer: marketSymbol !== 'XAUUSD'
          && isDeepDiscountTradeSignal(zone, signal),
      });
      const candle = displayCandles.find((item) => item.time === signal.time);
      if (!trade || !candle) continue;
      const fib = journalFibMetadata(zone, signal);
      const candidate: EntryHover = {
        id: `DIRECT:${zone.id}:${signal.time}:${trade.entry}`,
        candleTime: candle.time,
        high: candle.high,
        low: candle.low,
        trade,
        source: 'CANDLE CONFIRMATION',
        zone: executionZoneName(zone),
        fib: [fib.fibSource, fib.fibBand].filter(Boolean).join(' · '),
        style: 'INTRADAY',
        tradingTimeBlocked: tradingTimeEnabled
          && (!isNepalTradingTime(confirmationTime)
            || (trade.filledAt !== undefined && !isNepalTradingTime(trade.filledAt))),
      };
      if (marketSymbol === 'XAUUSD') {
        const reference: JournalTradeRecord = { id: candidate.id, zoneId: zone.id,
          symbol: 'XAUUSD', zoneName: candidate.zone, zoneTimeframe: granularity,
          source: 'ENGULFING', tradeStyle: 'INTRADAY', direction: signal.direction,
          signalAt: signal.time, signalTimeframe: signal.timeframe, engulfingType: signal.type,
          engulfingCandleCount: signal.candleCount, entry: trade.entry, stopLoss: trade.stopLoss,
          takeProfit: trade.takeProfit, rewardRisk: trade.rewardRisk, riskPips: trade.riskPips,
          result: trade.result ?? 'open', openedAt: trade.filledAt,
          completedAt: trade.resolvedAt ?? trade.calculatedAt };
        entries.push(...intradayPullbackChartRecords(reference, displayCandles, displayCandles, replayResultCutoff)
          .map(row => ({ ...candidate, id: row.id, trade: tradeDrawingFromRecord(row) })));
      } else entries.push(candidate);
    }
    return entries;
  }, [directTradeStyleEnabled, displayCandles, displayZones, expiredGoldZoneBeforeSignal, extremeAPlusTjl2Selection.blockedZoneIds, granularity, marketSymbol, pendingM15DbBlocksSignal, redundantStandaloneZoneIds, replayIndex, replayResultCutoff, tradingTimeEnabled]);
  // Keep completed SL/TP entry arrows and hover details in the same visible history.
  entryHoversRef.current = visibleEntryHovers;
  const entryMarkers = useMemo(() => visibleEntryHovers.map(({ candleTime, trade, style, source, display, pullbackSetup }) => {
    const bullish = trade.signal.direction === 'bullish';
    const projectedScalp = (granularity === 'M15' || granularity === 'H1') && style === 'SCALPING'
      && (trade.signal.timeframe === 'M1' || trade.signal.timeframe === 'M5');
    const setupLabel = trendlineSetupLabel(trade);
    const secondSetupLabel = setupLabel?.startsWith('2nd BEST TL') ? setupLabel : undefined;
    return {
      time: candleTime as UTCTimestamp,
      position: bullish ? 'belowBar' as const : 'aboveBar' as const,
      color: display?.referenceOnly && !display.chartFilled ? '#b45309' : bullish ? '#059669' : '#e11d48',
      shape: display?.referenceOnly && !display.chartFilled ? 'circle' as const : bullish ? 'arrowUp' as const : 'arrowDown' as const,
      text: pullbackSetup ? pullbackSetup.markerText : marketSymbol === 'XAUUSD' && (style === 'SCALP_1_1' || style === 'INTRADAY')
        ? trade.result === 'tp' || trade.result === 'sl' ? trade.result.toUpperCase() : ''
        : display?.markerText ?? (style === 'SCALP_1_1' ? trade.result?.toUpperCase()
        : secondSetupLabel ? [trade.result?.toUpperCase(), secondSetupLabel].filter(Boolean).join(' · ')
        : trade.result?.toUpperCase() ?? (granularity === 'H1' && ['M15', 'M30'].includes(trade.signal.timeframe)
          ? `${formatTradeTimeframe(trade.signal.timeframe)} ENTRY${source.includes('ZONE ALREADY USED') ? ' REF' : ''}` : undefined)),
      size: projectedScalp ? 1 : 2,
    };
  }).sort((first, second) => Number(first.time) - Number(second.time) || second.size - first.size),
  [marketSymbol, granularity, visibleEntryHovers, trendlineSetupLabel]);
  const replayDirectHistoryByZone = useMemo(() => {
    const entries = new Map<string, EntryHover>();
    if (replayIndex === null) return entries;
    const directEntries = [...entryHovers, ...replayDirectCandidates].filter((entry) => (
      entry.id.startsWith('DIRECT:') && entry.trade.signal.timeframe === granularity
    )).sort((first, second) => second.trade.signal.time - first.trade.signal.time);
    for (const zone of zoneTableRows) {
      const match = directEntries.find((entry) => displayZoneMembers(zone).some((member) => (
        entry.id.startsWith(`DIRECT:${member.id}:`)
      )));
      if (match) entries.set(zone.id, match);
    }
    return entries;
  }, [entryHovers, granularity, replayDirectCandidates, replayIndex, zoneTableRows]);
  const replayHistoryOverlays = useMemo<TradeOverlay[]>(() => {
    if (replayIndex === null) return [];
    const entries = new Map<string, {
      id: string;
      trade: TradeLevels;
      tradingTimeBlocked: boolean;
    }>();
    for (const entry of replayDirectHistoryByZone.values()) entries.set(entry.id, entry);
    for (const entry of scalpEntryTableRows) entries.set(entry.id, entry);
    return Array.from(entries.values()).filter(({ trade }) => !hasTradeDisplayExpired(trade) && !visibleTradeOverlays.some((overlay) => (
      overlay.trade.signal.time === trade.signal.time && overlay.trade.entry === trade.entry
    )))
      .map(({ id, trade, tradingTimeBlocked }) => ({
        id,
        symbol: marketSymbol,
        trade,
        label: tradingTimeBlocked
          ? 'OUTSIDE TRADING TIME · REFERENCE'
          : `REPLAY · ${isCompletedTrade(trade) ? tradeStatusLabel(trade) : 'ENTRY'}`,
        chartTimeframe: trade.signal.timeframe,
        referenceOnly: true,
      }));
  }, [hasTradeDisplayExpired, marketSymbol, replayDirectHistoryByZone, replayIndex, scalpEntryTableRows, visibleTradeOverlays]);
  const retainedTradeZoneRows = useMemo(() => {
    if (!directTradeStyleEnabled) return [];
    const activeZoneIds = new Set([
      ...zoneTableRows.flatMap((zone) => displayZoneMembers(zone).map((member) => member.id)),
      ...displayZones
        .filter((zone) => zone.active && zone.status === 'valid'
          && zone.doubleChochStatus !== undefined)
        .map((zone) => zone.id),
    ]);
    const rows = new Map<string, StructureZone>();
    const listedTradeKeys = new Set([
      ...retainedDirectChartTradesForTimeframe.map((overlay) => tradeOverlayExecutionKey(overlay.trade)),
      ...zoneTableRows.flatMap((zone) => {
        const trade = confluenceMapValue<TradeLevels>(zone, directZoneTrades);
        return trade ? [tradeOverlayExecutionKey(trade)] : [];
      }),
    ]);
    for (const setup of trackedDirectTradeSetups.values()) {
      if (setup.scope !== tradeTrackingScope || activeZoneIds.has(setup.zone.id)
        || retainedDirectTradeZoneIds.has(setup.zone.id)
        || redundantStandaloneZoneIds.has(setup.zone.id)) continue;
      const trade = directZoneTrades.get(setup.zone.id);
      if (!trade) continue;
      const tradeKey = tradeOverlayExecutionKey(trade);
      if (listedTradeKeys.has(tradeKey)) continue;
      const row = displayZones.find((zone) => zone.id === setup.zone.id) ?? setup.zone;
      if (hasZoneTableTradeExpired(trade, row)) continue;
      if ((!showInternal && row.category === 'internal')
        || (isCompletedTrade(trade) && (confluenceTapBarsAgo(row) ?? Infinity)
          > zoneTableTapBarLimit(displayedTapCount(row), marketSymbol))) continue;
      rows.set(
        setup.zone.id,
        row,
      );
      listedTradeKeys.add(tradeKey);
    }
    const sorted = Array.from(rows.values())
      .sort((a, b) => (b.invalidatedAt ?? b.startTime) - (a.invalidatedAt ?? a.startTime));
    const open = sorted.filter((row) => !isCompletedTrade(directZoneTrades.get(row.id)));
    const completed = sorted.filter((row) => isCompletedTrade(directZoneTrades.get(row.id))).slice(0, 4);
    return [...open, ...completed];
  }, [
    hasZoneTableTradeExpired,
    displayedTapCount,
    marketSymbol,
    directTradeStyleEnabled,
    directZoneTrades,
    displayZones,
    showInternal,
    retainedDirectTradeZoneIds,
    retainedDirectChartTradesForTimeframe,
    redundantStandaloneZoneIds,
    trackedDirectTradeSetups,
    tradeTrackingScope,
    zoneTableRows,
  ]);
  const latestDisplayCandleTime = displayCandles[displayCandles.length - 1]?.time;
  const doubleChochRows = useMemo(() => consolidatedDisplayZones
    .filter((zone) => directTradeStyleEnabled && zone.active && zone.status === 'valid'
      && zone.doubleChochStatus !== undefined
      && (showInternal || zone.category !== 'internal')
      && (zone.tapTime !== undefined
        ? (zone.lastTapBarsAgo ?? zone.tapBarsAgo ?? Infinity)
          <= zoneTableTapBarLimit(displayedTapCount(zone), marketSymbol)
        : zone.doubleChochStatus === 'pending'
          ? ['SBR', 'RBS', 'Internal SBR', 'Internal RBS'].includes(zone.name)
          : (['SBR', 'RBS', 'Internal SBR', 'Internal RBS'].includes(zone.name))
            && zone.doubleChochConfirmationTime !== undefined
            && latestDisplayCandleTime !== undefined
            && latestDisplayCandleTime + TIMEFRAME_SECONDS[granularity]
              === zone.doubleChochConfirmationTime))
    .sort((a, b) => (b.tapTime ?? b.doubleChochTime ?? b.startTime)
      - (a.tapTime ?? a.doubleChochTime ?? a.startTime)
      || b.startTime - a.startTime)
    .slice(0, 8), [consolidatedDisplayZones, directTradeStyleEnabled, granularity, latestDisplayCandleTime, showInternal,
      displayedTapCount, marketSymbol]);
  const pendingConfirmationRows = useMemo(() => consolidatedDisplayZones
    .filter((zone) => directTradeStyleEnabled && (zone.name === 'TJL1' || zone.name === 'ISS L3' || zone.name === 'Internal TJL1')
      && zone.active && zone.status === 'pending'
      && (showInternal || zone.category !== 'internal'))
    .sort((a, b) => b.startTime - a.startTime)
    .slice(0, 4), [consolidatedDisplayZones, directTradeStyleEnabled, showInternal]);
  const chochStatusTableRows = useMemo(() => {
    if (!directTradeStyleEnabled) return [];
    const listedIds = new Set<string>(zoneTableRows.flatMap(zone => displayZoneMembers(zone).map(member => member.id)));
    return selectChochStatusTableZones(consolidatedDisplayZones.filter(zone => (
      showInternal || zone.category !== 'internal'
    )), displayCandles, listedIds);
  }, [consolidatedDisplayZones, directTradeStyleEnabled, displayCandles, showInternal, zoneTableRows]);
  updateHeaderCandleRef.current = (timestamp?: number) => {
    const selected = timestamp === undefined ? undefined : headerCandlesByTime.get(timestamp);
    const candle = selected?.candle ?? latestCandle;
    const prior = selected?.previous ?? previousCandle;
    if (!candle) return;
    if (headerOpenRef.current) headerOpenRef.current.textContent = formatPrice(candle.open);
    if (headerHighRef.current) headerHighRef.current.textContent = formatPrice(candle.high);
    if (headerLowRef.current) headerLowRef.current.textContent = formatPrice(candle.low);
    if (headerCloseRef.current) headerCloseRef.current.textContent = formatPrice(candle.close);
    if (headerChangeRef.current) {
      const selectedChange = prior ? candle.close - prior.close : 0;
      const selectedPercent = prior?.close ? selectedChange / prior.close * 100 : 0;
      headerChangeRef.current.textContent = `${selectedChange >= 0 ? '+' : ''}${formatPrice(selectedChange)} (${selectedPercent >= 0 ? '+' : ''}${selectedPercent.toFixed(2)}%)`;
      headerChangeRef.current.className = `font-black ${selectedChange >= 0 ? 'text-emerald-600' : 'text-rose-600'}`;
    }
  };
  useEffect(() => {
    updateHeaderCandleRef.current();
  }, [displayCandles]);

  // Zone endpoints scan candle history. They depend on market data, never on
  // the viewport, so dragging must only project the already computed result.
  const zoneDrawingEndIndices = useMemo(() => new Map(consolidatedDisplayZones.map((zone) => [
    zone.id,
    marketSymbol === 'XAUUSD'
      ? tappedZoneDrawingEndIndex(zone, displayCandles, granularity, marketConfig.pipSize)
      : undefined,
  ])), [consolidatedDisplayZones, displayCandles, granularity, marketConfig.pipSize, marketSymbol]);
  const overlayCandlesByTime = useMemo(() => new Map<number, OandaCandle>(
    displayCandles.map((candle) => [Number(candle.time), candle]),
  ), [displayCandles]);

  const preEntryTrendlineMarkMap = useMemo(() => {
    const marks = new Map<string, ReturnType<typeof preEntryTrendlineMarks>[number]>();
    if (marketSymbol !== 'XAUUSD') return marks;
    const at = replayResultCutoff ?? Date.now() / 1000;
    const candles = { ...vipCandles, [granularity]: displayCandles };
    const price = candles.M15?.filter(candle => candle.time <= at).at(-1)?.close;
    if (price === undefined) return marks;
    const zones = AUTOMATION_GRANULARITIES.filter(timeframe => (
      isGoldIntradayCandleRoute(timeframe, 'M15')
      || MTF_MAPPINGS.some(mapping => mapping.higher === timeframe && mapping.lower === 'M15')
    )).flatMap(timeframe => (timeframe === granularity ? consolidatedDisplayZones
      : tableTimeframeData[timeframe]?.structure.zones ?? []).map(zone => ({ zone, timeframe })));
    for (const mark of preEntryTrendlineMarks({ zones, candles, at, price, pipSize: marketConfig.pipSize })) {
      const line = mark.support;
      marks.set(`${line.timeframe}:${line.kind}:${line.firstTime}:${line.secondTime}`, mark);
    }
    return marks;
  }, [marketSymbol, replayResultCutoff, vipCandles, granularity, displayCandles,
    consolidatedDisplayZones, tableTimeframeData, marketConfig.pipSize]);

  const nearbyHtfTrendlines = useMemo(() => htfTrendlines.filter((trendline) => (
    showAllTrendlines
    || preEntryTrendlineMarkMap.has(`${trendline.timeframe}:${trendline.line.kind}:${trendline.sourceCandles[trendline.line.firstIndex].time}:${trendline.sourceCandles[trendline.line.secondIndex].time}`)
    || Math.abs(trendline.currentPrice - (displayCandles.at(-1)?.close ?? 0)) <= 400 * marketConfig.pipSize
  )), [displayCandles, htfTrendlines, marketConfig.pipSize, preEntryTrendlineMarkMap, showAllTrendlines]);

  const redrawZones = useCallback(() => {
    const layer = zoneLayerRef.current;
    const host = hostRef.current;
    const chart = chartRef.current;
    const series = candleSeriesRef.current;
    if (!layer || !host || !chart || !series) return;
    if (displayCandles.length === 0) {
      layer.replaceChildren();
      return;
    }

    const fragment = document.createDocumentFragment();
    // Panning changes coordinates, not the candle timestamps. Use binary lookups
    // instead of repeatedly copying/reversing and scanning the entire history.
    const candleIndexAtOrAfter = (time: number) => {
      const prior = findReplayIndexAtOrBefore(displayCandles, time);
      return prior === null ? 0 : displayCandles[prior].time === time ? prior : prior + 1;
    };
    const candleContainingTime = (time: number) => {
      const index = findReplayIndexAtOrBefore(displayCandles, time);
      const candle = index === null ? undefined : displayCandles[index];
      return candle && time < marketCandleCloseTime(candle.time, granularity) ? candle : undefined;
    };
    const livePrice = displayCandles[displayCandles.length - 1].close;
    const touchesLivePrice = (zone: StructureZone) => (
      zone.active && livePrice >= zone.bottom && livePrice <= zone.top
    );
    const zoneKey = (kind: string, id: string) => `${marketSymbol}:${granularity}:${kind}:${id}`;
    const closeButtonPositions: Array<{ left: number; top: number }> = [];
    const zoneEndCoordinate = (key: string, normalRight: number | null) => {
      if (zoneLengthModes[key] === 'live') {
        return chart.timeScale().logicalToCoordinate(displayCandles.length - 1 + 10);
      }
      if (zoneLengthModes[key] !== 'left') return normalRight;
      const scale = chart.timeScale();
      const latestIndex = displayCandles.length - 1;
      const barWidth = Math.abs((scale.logicalToCoordinate(latestIndex) ?? 0)
        - (scale.logicalToCoordinate(Math.max(0, latestIndex - 10)) ?? 0));
      return Math.min(rightEdge, 4 + Math.max(80, barWidth));
    };
    const zoneStartCoordinate = (key: string, normalLeft: number | null) => (
      zoneLengthModes[key] === 'left' ? 4 : normalLeft
    );
    const appendZoneCloseButton = (key: string, name: string, right: number, top: number, bottom: number) => {
      if (top > host.clientHeight || bottom < 0) return;
      const buttonTop = Math.max(0, Math.min(host.clientHeight - 12, top - 6));
      let buttonLeft = Math.max(0, right - 13);
      while (buttonLeft >= 14 && closeButtonPositions.some((position) => (
        Math.abs(position.left - buttonLeft) < 14 && Math.abs(position.top - buttonTop) < 12
      ))) buttonLeft -= 14;
      closeButtonPositions.push({ left: buttonLeft, top: buttonTop });
      const button = document.createElement('button');
      button.type = 'button';
      const currentChartZone = key.startsWith(`${marketSymbol}:${granularity}:chart:`);
      const mtfZone = key.startsWith(`${marketSymbol}:${granularity}:mtf:`);
      const reduced = currentChartZone
        ? zoneLengthModes[key] === 'original' : zoneLengthModes[key] === 'left';
      button.textContent = reduced ? '\u2713' : '\u00d7';
      button.title = reduced ? `Restore ${name} zone to its extended position`
        : currentChartZone ? `Show ${name} zone at its original 30-bar position`
          : mtfZone ? `Show ${name} zone for 10 bars from its source candle`
          : `Move ${name} zone to the left edge`;
      button.setAttribute('aria-label', button.title);
      button.dataset.journalExclude = 'true';
      Object.assign(button.style, {
        position: 'absolute', left: `${buttonLeft}px`, top: `${buttonTop}px`,
        width: '12px', height: '12px', padding: '0', border: '1px solid #cbd5e1',
        borderRadius: '2px', background: 'rgba(255,255,255,0.95)', color: '#64748b',
        fontSize: '10px', lineHeight: '10px', cursor: 'pointer', pointerEvents: 'auto', zIndex: '2',
      });
      button.addEventListener('pointerdown', (event) => event.stopPropagation());
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        setZoneLengthModes((current) => {
          const next = { ...current };
          if (reduced && currentChartZone) next[key] = 'live';
          else if (reduced) delete next[key];
          else next[key] = currentChartZone ? 'original' : 'left';
          return next;
        });
      });
      fragment.appendChild(button);
    };
    const candleByTime = overlayCandlesByTime;
    const mtfBadgesByZone = new Map<string, Set<string>>();
    for (const row of mtfRows) {
      if (!row.higherTimeframeZoneId) continue;
      const badges = mtfBadgesByZone.get(row.higherTimeframeZoneId) ?? new Set<string>();
      badges.add(row.setupId);
      mtfBadgesByZone.set(row.higherTimeframeZoneId, badges);
    }
    const unfinishedEntryZoneIds = new Set<string>();
    const listedZoneIds = new Set(zoneTableRows.flatMap((zone) => (
      displayZoneMembers(zone).map((member) => member.id)
    )));
    for (const [zoneId, trade] of directZoneTrades) {
      if (!isCompletedTrade(trade)) unfinishedEntryZoneIds.add(zoneId);
    }
    for (const row of mtfRows) {
      if (row.higherTimeframeZoneId && row.trade && !isCompletedTrade(row.trade)) {
        unfinishedEntryZoneIds.add(row.higherTimeframeZoneId);
      }
    }
    const isVisualZoneVisible = (zone: DisplayStructureZone) => (
      displayZoneMembers(zone).some((member) => (
        member.category === 'mg'
          ? showMgZonesRef.current
          : member.category === 'iss'
            ? showIssRef.current
            : member.category === 'internal'
              ? showInternalRef.current
              : showSupplyDemandRef.current
      )) && (zone.active || showInvalidZonesRef.current)
    );
    let latestMeasuredZoneId: string | undefined;
    let latestMeasuredTapTime = -Infinity;
    for (const zone of visualZonesRef.current) {
      if (!isVisualZoneVisible(zone) || !measureTradeableFibZone(zone, marketConfig.pipSize)) continue;
      const tapTime = Math.max(...displayZoneMembers(zone)
        .map((member) => member.tapTime ?? -Infinity));
      if (tapTime > latestMeasuredTapTime) {
        latestMeasuredTapTime = tapTime;
        latestMeasuredZoneId = zone.id;
      }
    }
    const rightEdge = Math.max(0, host.clientWidth - 72);
    const visibleTimeRange = chart.timeScale().getVisibleRange();
    // Start each comparison zone at its own origin and extend it 50 chart bars ahead.
    // Interpolating logical coordinates also places lower-timeframe origins between chart bars.
    const latestLogicalIndex = displayCandles.length - 1;
    const comparisonEndX = chart.timeScale().logicalToCoordinate(latestLogicalIndex + 50);
    for (const { zone, overlapsCurrentZone, visibleFromTime } of visibleComparisonZones) {
      if (comparisonEndX === null) continue;
      const sourceStartTime = visibleFromTime ?? zone.startTime;
      let nextIndex = 0;
      let high = displayCandles.length;
      while (nextIndex < high) {
        const middle = Math.floor((nextIndex + high) / 2);
        if (displayCandles[middle].time < sourceStartTime) nextIndex = middle + 1;
        else high = middle;
      }
      let originLogicalIndex = 0;
      if (nextIndex > 0 && nextIndex < displayCandles.length) {
        const previous = displayCandles[nextIndex - 1];
        const next = displayCandles[nextIndex];
        originLogicalIndex = nextIndex - 1 + (sourceStartTime - previous.time)
          / Math.max(1, next.time - previous.time);
      } else if (nextIndex === displayCandles.length) {
        const last = displayCandles[latestLogicalIndex];
        if (sourceStartTime >= last.time + TIMEFRAME_SECONDS[granularity]) continue;
        originLogicalIndex = latestLogicalIndex
          + (sourceStartTime - last.time) / TIMEFRAME_SECONDS[granularity];
      }
      const comparisonStartX = chart.timeScale().logicalToCoordinate(originLogicalIndex);
      if (comparisonStartX === null) continue;
      const comparisonKey = zoneKey(`comparison:${comparisonTimeframe}`, zone.id);
      const left = Math.max(0, zoneStartCoordinate(comparisonKey, comparisonStartX) ?? 0);
      const right = Math.min(rightEdge, zoneEndCoordinate(comparisonKey, comparisonEndX) ?? rightEdge);
      if (right <= left) continue;
      const top = series.priceToCoordinate(zone.top);
      const bottom = series.priceToCoordinate(zone.bottom);
      if (top === null || bottom === null) continue;
      if (Math.min(top, bottom) > host.clientHeight || Math.max(top, bottom) < 0) continue;
      const color = zone.isBuy ? '5, 150, 105' : '225, 29, 72';
      const box = document.createElement('div');
      box.style.position = 'absolute';
      box.style.left = `${left}px`;
      box.style.width = `${right - left}px`;
      box.style.top = `${Math.min(top, bottom)}px`;
      box.style.height = `${Math.max(2, Math.abs(bottom - top))}px`;
      box.style.background = `rgba(${color}, 0.045)`;
      box.style.borderTop = `1px dashed rgba(${color}, 0.32)`;
      box.style.borderBottom = `1px dashed rgba(${color}, 0.32)`;
      box.style.boxSizing = 'border-box';
      box.style.pointerEvents = 'none';
      const label = document.createElement('span');
      const chochZone = ltfChochContext?.confirmations.some(({ line }) => (
        zone.chochTime === line.toTime || zone.doubleChochTime === line.toTime
      ));
      label.textContent = `${GRANULARITY_LABELS[comparisonTimeframe!]} ${zone.isBuy ? 'BUY' : 'SELL'} ${chochZone ? 'CHoCH ZONE · ' : ''}${zone.name}${overlapsCurrentZone ? ' · OVERLAP' : ''}`;
      label.style.position = 'absolute';
      label.style.right = '19px';
      label.style.top = Math.abs(bottom - top) >= 14 ? '1px' : '-12px';
      label.style.fontSize = '9px';
      label.style.fontWeight = '800';
      label.style.color = `rgba(${color}, 0.8)`;
      label.style.whiteSpace = 'nowrap';
      box.appendChild(label);
      const closeButton = document.createElement('button');
      closeButton.type = 'button';
      closeButton.hidden = !touchesLivePrice(zone) && zoneLengthModes[comparisonKey] !== 'left';
      const movedLeft = zoneLengthModes[comparisonKey] === 'left';
      closeButton.textContent = movedLeft ? '\u2713' : '\u00d7';
      closeButton.title = movedLeft
        ? `Restore ${GRANULARITY_LABELS[comparisonTimeframe!]} ${zone.name} zone to its original position`
        : `Move ${GRANULARITY_LABELS[comparisonTimeframe!]} ${zone.name} zone to the left edge`;
      closeButton.setAttribute('aria-label', closeButton.title);
      closeButton.style.position = 'absolute';
      closeButton.style.right = '2px';
      closeButton.style.top = '-6px';
      closeButton.style.width = '14px';
      closeButton.style.height = '14px';
      closeButton.style.border = `1px solid rgba(${color}, 0.4)`;
      closeButton.style.borderRadius = '50%';
      closeButton.style.background = 'white';
      closeButton.style.color = `rgb(${color})`;
      closeButton.style.fontSize = '11px';
      closeButton.style.fontWeight = '800';
      closeButton.style.lineHeight = '12px';
      closeButton.style.padding = '0';
      closeButton.style.cursor = 'pointer';
      closeButton.style.pointerEvents = 'auto';
      closeButton.addEventListener('pointerdown', (event) => event.stopPropagation());
      closeButton.addEventListener('click', (event) => {
        event.stopPropagation();
        setZoneLengthModes((current) => {
          const next = { ...current };
          if (movedLeft) delete next[comparisonKey];
          else next[comparisonKey] = 'left';
          return next;
        });
      });
      box.appendChild(closeButton);
      fragment.appendChild(box);
    }
    const shownLtfConfirmations = new Set<string>();
    for (const { line, chochSequence } of ltfChochContext?.confirmations ?? []) {
      const key = `${line.toTime}:${line.direction}`;
      if (shownLtfConfirmations.has(key)) continue;
      shownLtfConfirmations.add(key);
      const confirmedAt = line.toTime + TIMEFRAME_SECONDS[comparisonTimeframe!];
      const chartCandle = displayCandles[candleIndexAtOrAfter(confirmedAt) - 1];
      if (!chartCandle || confirmedAt > chartCandle.time + TIMEFRAME_SECONDS[granularity]) continue;
      if (visibleTimeRange && (chartCandle.time < Number(visibleTimeRange.from)
        || chartCandle.time > Number(visibleTimeRange.to))) continue;
      const x = chart.timeScale().timeToCoordinate(chartCandle.time as UTCTimestamp);
      const y = series.priceToCoordinate(line.toPrice);
      if (x === null || y === null || x < 0 || x > rightEdge) continue;
      const badge = document.createElement('div');
      badge.style.position = 'absolute';
      badge.style.left = `${x}px`;
      badge.style.top = `${Math.max(0, y + (line.direction === 'bullish' ? 10 : -24))}px`;
      badge.style.transform = 'translateX(-50%)';
      badge.style.padding = '2px 5px';
      badge.style.borderRadius = '4px';
      badge.style.background = line.direction === 'bullish' ? '#dcfce7' : '#ffe4e6';
      badge.style.color = line.direction === 'bullish' ? '#166534' : '#9f1239';
      badge.style.fontSize = '9px';
      badge.style.fontWeight = '800';
      badge.style.whiteSpace = 'nowrap';
      badge.style.pointerEvents = 'none';
      badge.textContent = `${GRANULARITY_LABELS[comparisonTimeframe!]} ${mtfChochSequenceLabel(chochSequence)}${chochSequence === 1 ? ' CONFIRMED' : ''}`;
      fragment.appendChild(badge);
    }
    for (const zone of scalpingEnabled ? oneMinuteScalpingZones : []) {
      const key = zoneKey('scalp', zone.id);
      if (visibleTimeRange && zoneLengthModes[key] !== 'left' && (zone.endTime < Number(visibleTimeRange.from)
        || zone.startTime > Number(visibleTimeRange.to))) continue;
      if (!(zone.category === 'mg' ? showMgZonesRef.current
        : zone.category === 'iss' ? showIssRef.current
          : zone.category === 'internal' ? showInternalRef.current
            : showSupplyDemandRef.current)) continue;
      const rawLeft = chart.timeScale().timeToCoordinate(zone.startTime as UTCTimestamp);
      const rawRight = zoneEndCoordinate(key, chart.timeScale().timeToCoordinate(zone.endTime as UTCTimestamp));
      const top = series.priceToCoordinate(zone.top);
      const bottom = series.priceToCoordinate(zone.bottom);
      if (top === null || bottom === null) continue;
      const left = Math.max(0, zoneStartCoordinate(key, rawLeft) ?? 0);
      const right = Math.min(rightEdge, rawRight ?? rightEdge);
      if (left >= right) continue;
      const box = document.createElement('div');
      box.style.position = 'absolute';
      box.style.left = `${left}px`;
      box.style.width = `${right - left}px`;
      box.style.top = `${Math.min(top, bottom)}px`;
      box.style.height = `${Math.max(2, Math.abs(bottom - top))}px`;
      box.style.background = zone.isBuy ? 'rgba(16, 185, 129, 0.08)' : 'rgba(244, 63, 94, 0.08)';
      box.style.border = `1px dashed ${zone.isBuy ? '#059669' : '#e11d48'}`;
      box.style.boxSizing = 'border-box';
      box.style.overflow = 'hidden';
      const label = document.createElement('span');
      label.textContent = `15M SCALP · ${zone.name}`;
      label.style.fontSize = '9px';
      label.style.fontWeight = '800';
      label.style.color = zone.isBuy ? '#047857' : '#be123c';
      box.appendChild(label);
      fragment.appendChild(box);
      if (touchesLivePrice(zone) || zoneLengthModes[key] === 'left') {
        appendZoneCloseButton(key, `15M SCALP ${zone.name}`, right, Math.min(top, bottom), Math.max(top, bottom));
      }
    }
    for (const { zone, label, timeframe, endTime } of mtfDrawingZones) {
      const sameTimeframe = timeframe === granularity;
      const key = zoneKey(`${sameTimeframe ? 'mtf' : 'mtf-higher'}:${label}`, zone.id);
      const firstIndex = candleIndexAtOrAfter(zone.startTime);
      const first = displayCandles[firstIndex];
      const lastIndex = findReplayIndexAtOrBefore(displayCandles, endTime);
      const last = lastIndex === null ? undefined : displayCandles[lastIndex];
      if (!first || !last || first.time > last.time) continue;
      if (visibleTimeRange && (zoneLengthModes[key] === undefined && last.time < Number(visibleTimeRange.from)
        || first.time > Number(visibleTimeRange.to))) continue;
      const sourceLeft = chart.timeScale().timeToCoordinate(first.time as UTCTimestamp);
      const left = Math.max(0, sameTimeframe ? sourceLeft ?? 0 : zoneStartCoordinate(key, sourceLeft) ?? 0);
      const mtfEnd = zoneLengthModes[key] === 'left'
        ? sameTimeframe ? chart.timeScale().logicalToCoordinate(firstIndex + 10)
          : zoneEndCoordinate(key, chart.timeScale().logicalToCoordinate(displayCandles.length - 1 + 10))
        : chart.timeScale().logicalToCoordinate(displayCandles.length - 1 + 10);
      const right = Math.min(rightEdge, mtfEnd ?? rightEdge);
      const top = series.priceToCoordinate(zone.top);
      const bottom = series.priceToCoordinate(zone.bottom);
      if (top === null || bottom === null || left >= right) continue;
      const box = document.createElement('div');
      Object.assign(box.style, {
        position: 'absolute', left: `${left}px`, width: `${right - left}px`,
        top: `${Math.min(top, bottom)}px`, height: `${Math.max(2, Math.abs(bottom - top))}px`,
        border: `2px solid ${zone.isBuy ? '#059669' : '#e11d48'}`,
        background: zone.isBuy ? 'rgba(16,185,129,0.06)' : 'rgba(244,63,94,0.06)',
        boxSizing: 'border-box', pointerEvents: 'none',
        fontSize: '9px', fontWeight: '800', color: zone.isBuy ? '#047857' : '#be123c',
      });
      box.textContent = label;
      fragment.appendChild(box);
      appendZoneCloseButton(key, label, right, Math.min(top, bottom), Math.max(top, bottom));
    }
    const occupiedZoneLabelRects: Array<{
      left: number;
      right: number;
      top: number;
      bottom: number;
    }> = [];
    for (const zone of visualZonesRef.current) {
      if (!isVisualZoneVisible(zone)) continue;
      const listedInTable = displayZoneMembers(zone).some((member) => listedZoneIds.has(member.id));
      const extendedEndIndex = zoneDrawingEndIndices.get(zone.id);
      if (visibleTimeRange && ((zoneLengthModes[zoneKey('chart', zone.id)] === undefined && extendedEndIndex === undefined && zone.endTime < Number(visibleTimeRange.from))
        || zone.startTime > Number(visibleTimeRange.to))) continue;
      const rawLeft = chart.timeScale().timeToCoordinate(zone.startTime as UTCTimestamp);
      const normalRight = extendedEndIndex === undefined
        ? chart.timeScale().timeToCoordinate(zone.endTime as UTCTimestamp)
        : chart.timeScale().logicalToCoordinate(extendedEndIndex);
      const chartZoneKey = zoneKey('chart', zone.id);
      const rawRight = zoneLengthModes[chartZoneKey] === 'original'
        ? chart.timeScale().timeToCoordinate(zone.endTime as UTCTimestamp)
        : zoneEndCoordinate(chartZoneKey, normalRight);
      const top = series.priceToCoordinate(zone.top);
      const bottom = series.priceToCoordinate(zone.bottom);
      if (top === null || bottom === null) continue;
      if (Math.min(top, bottom) > host.clientHeight || Math.max(top, bottom) < 0) continue;
      const left = Math.max(0, zoneStartCoordinate(zoneKey('chart', zone.id), rawLeft) ?? 0);
      const right = Math.min(rightEdge, rawRight === null ? rightEdge : rawRight);
      if (left >= right || right <= 0) continue;
      const zoneWidth = right - left;

      const box = document.createElement('div');
      const demand = zone.isBuy;
      const isIss = zone.category === 'iss';
      const isInternal = zone.category === 'internal';
      const isMg = zone.category === 'mg';
      const overlappingIssL4 = isMg && zone.name === 'TJL2'
        ? visualZonesRef.current.some((candidate) => (
          candidate.category === 'iss' && candidate.name === 'ISS L4'
          && candidate.active === zone.active && candidate.isBuy === zone.isBuy
          && candidate.startTime === zone.startTime
          && candidate.bottom <= zone.bottom && candidate.top >= zone.top
        )) : false;
      // Like TJL1, show HTF confirmation state only on the zone whose break
      // actually confirmed Double CHoCH (SBR for bearish, RBS for bullish).
      const showsDoubleChochStatus = zone.doubleChochStatus !== undefined
        && (['SBR', 'RBS', 'Internal SBR', 'Internal RBS'].includes(zone.name));
      const pending = zone.status === 'pending'
        || (showsDoubleChochStatus && zone.doubleChochStatus === 'pending');
      const confirmationLabel = TJL1_CONFIRMATION_LABELS[granularity];
      const inactive = !zone.active;
      const rejected = zone.status === 'rejected';
      const fill = inactive
        ? 'rgba(100, 116, 139, 0.10)'
        : pending
        ? demand ? 'rgba(16, 185, 129, 0.13)' : 'rgba(244, 63, 94, 0.12)'
        : isIss
        ? 'rgba(217, 119, 6, 0.14)'
        : isInternal
        ? 'rgba(124, 58, 237, 0.12)'
        : demand ? 'rgba(16, 185, 129, 0.13)' : 'rgba(244, 63, 94, 0.12)';
      const border = inactive
        ? 'rgba(71, 85, 105, 0.72)'
        : pending ? demand ? 'rgba(5, 150, 105, 0.72)' : 'rgba(225, 29, 72, 0.72)' : isIss ? 'rgba(180, 83, 9, 0.72)' : isInternal ? 'rgba(109, 40, 217, 0.72)' : demand ? 'rgba(5, 150, 105, 0.65)' : 'rgba(225, 29, 72, 0.65)';
      const zoneTopCoordinate = Math.min(top, bottom);
      const zoneHeight = Math.max(2, Math.abs(bottom - top));
      box.style.position = 'absolute';
      // The narrower TJL2 is a separate entry zone inside ISS L4. Keep its
      // boundary and name above the ISS fill so the chart matches the table.
      if (overlappingIssL4) box.style.zIndex = '2';
      box.style.left = `${left}px`;
      box.style.width = `${right - left}px`;
      box.style.top = `${zoneTopCoordinate}px`;
      box.style.height = `${zoneHeight}px`;
      box.style.background = fill;
      box.style.borderTop = `1px solid ${border}`;
      box.style.borderBottom = `1px solid ${border}`;
      box.style.overflow = listedInTable && zoneHeight < 16 ? 'visible' : 'hidden';

      const retainMeasurementForEntry = displayZoneMembers(zone)
        .some((member) => unfinishedEntryZoneIds.has(member.id));
      const measurement = listedInTable
        ? measureListedZone(zone, marketConfig.pipSize)
        : zone.id === latestMeasuredZoneId || retainMeasurementForEntry
          ? measureTradeableFibZone(zone, marketConfig.pipSize)
          : undefined;
      if (measurement) {
        const midlineCoordinate = series.priceToCoordinate(measurement.midline);
        if (midlineCoordinate !== null) {
          const midline = document.createElement('div');
          midline.style.position = 'absolute';
          midline.style.left = '0';
          midline.style.right = '0';
          midline.style.top = `${Math.max(0, Math.min(zoneHeight, midlineCoordinate - zoneTopCoordinate))}px`;
          midline.style.borderTop = `1px dashed ${border}`;
          midline.style.pointerEvents = 'none';
          box.appendChild(midline);
        }
      }

      const label = document.createElement('span');
      const name = overlappingIssL4
        ? `TJL2 ${demand ? 'BUY' : 'SELL'} · ISS L4 OVERLAP`
        : isMg || isIss || isInternal
        ? displayConfluenceZoneName(zone, true)
        : demand ? 'DEMAND' : 'SUPPLY';
      const labelDetails: string[] = [];
      if (zone.majorLiquidity) labelDetails.push('MAJOR LIQUIDITY');
      const extremeAPlusMembers = displayZoneMembers(zone);
      const extremeAPlus = extremeAPlusMembers.some((member) => (
        extremeAPlusTjl2Selection.extremeZoneIds.has(member.id)
      ));
      const extremeAPlusBlocked = extremeAPlusMembers.some((member) => (
        extremeAPlusTjl2Selection.blockedZoneIds.has(member.id)
      ));
      if (extremeAPlusBlocked) labelDetails.push('EXTREME A+ HIGHER', 'NO TRADE');
      else if (extremeAPlus) labelDetails.push('EXTREME A+');
      if (measurement) {
        labelDetails.push(`${formatZonePips(measurement.pips)} PIPS`);
      }
      if (inactive) {
        if (rejected) labelDetails.push('REJECTED');
        else if (zone.status === 'superseded') labelDetails.push('SUPERSEDED');
      } else if (showsDoubleChochStatus) {
        if (zone.doubleChochStatus === 'pending') {
          labelDetails.push(
            'DOUBLE CHoCH',
            `PENDING ${confirmationLabel} ${zone.doubleChochConfirmationDirection === 'up' ? 'ABOVE' : 'BELOW'}`,
          );
        } else {
          labelDetails.push('VALID DOUBLE CHoCH');
          if (zone.tradeable === false) labelDetails.push('NO TRADE');
        }
      } else if (zone.name === 'TJL1' || zone.name === 'ISS L3' || zone.name === 'Internal TJL1') {
        labelDetails.push(pending
          ? `PENDING ${confirmationLabel} ${zone.isBuy ? 'ABOVE' : 'BELOW'}`
          : 'VALID');
      } else if (zone.chochClass) {
        if (zone.chochClass !== 'pending') {
          labelDetails.push(zone.chochClass.toUpperCase());
        }
      } else if (pending) {
        labelDetails.push('PENDING');
      }
      if (!inactive && showFibRef.current && zone.fibStatus === 'a-plus'
        && zone.fibBand && zone.fibBand !== 'DB/DT') {
        labelDetails.push(displayFibLabel(zone));
      }
      if (!inactive && showFibRef.current && zone.swingFibStatus === 'a-plus' && zone.swingFibBand) {
        labelDetails.push(`SWING A+ FIB ${zone.swingFibBand}`);
      }
      if (!inactive && zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand) {
        labelDetails.push(`1H SWING FIB ALIGNED ${zone.h1SwingFibBand}`);
      }
      if (!inactive && showFibRef.current && zone.dayFibStatus === 'a-plus' && zone.dayFibBand) {
        labelDetails.push(`DAY FIB A+ ${zone.dayFibBand}`);
      }
      const confluenceLabels = confluenceBadgeLabels(zone);
      if (confluenceLabels.length > 0) {
        labelDetails.push(confluenceLabels.join(' / '));
      }
      const mtfBadges = Array.from(mtfBadgesByZone.get(zone.id) ?? []);
      if (mtfBadges.length > 0) {
        labelDetails.push(mtfBadges.join(' / '));
      }
      const visibleZoneTop = Math.max(0, zoneTopCoordinate);
      const visibleZoneBottom = Math.min(host.clientHeight, zoneTopCoordinate + zoneHeight);
      const visibleZoneHeight = visibleZoneBottom - visibleZoneTop;
      if (zoneWidth < 20 || visibleZoneHeight < 16) {
        if (listedInTable && zoneWidth >= 20 && visibleZoneHeight > 0) {
          const shortLabel = document.createElement('span');
          shortLabel.textContent = name;
          shortLabel.style.position = 'absolute';
          shortLabel.style.right = '2px';
          shortLabel.style.top = '-13px';
          shortLabel.style.padding = '0 2px';
          shortLabel.style.background = 'rgba(255, 255, 255, 0.92)';
          shortLabel.style.color = demand ? '#047857' : '#be123c';
          shortLabel.style.fontSize = '9px';
          shortLabel.style.fontWeight = '800';
          shortLabel.style.whiteSpace = 'nowrap';
          box.appendChild(shortLabel);
        }
        fragment.appendChild(box);
        if (touchesLivePrice(zone) || zoneLengthModes[chartZoneKey] !== undefined) {
          appendZoneCloseButton(zoneKey('chart', zone.id), name, right, zoneTopCoordinate, zoneTopCoordinate + zoneHeight);
        }
        continue;
      }
      const detailLines = zoneWidth >= 160
        ? Math.min(3, Math.max(0, Math.floor((visibleZoneHeight - 16) / 11)))
        : 0;
      const labelHeight = 12 + (labelDetails.length > 0 ? detailLines * 11 : 0);
      const labelLeft = left + 4;
      const labelRight = right - 4;
      const preferredLabelTop = Math.max(
        visibleZoneTop + 2,
        Math.min(
          visibleZoneTop + visibleZoneHeight / 2 - 6,
          visibleZoneBottom - labelHeight - 2,
        ),
      );
      let labelTop = preferredLabelTop;
      for (let step = 0; step <= 8; step += 1) {
        const offsets = step === 0 ? [0] : [step * 12, step * -12];
        const availableOffset = offsets.find((offset) => {
          const candidateTop = preferredLabelTop + offset;
          const candidateBottom = candidateTop + labelHeight;
          if (candidateTop < visibleZoneTop + 2
            || candidateBottom > visibleZoneBottom - 2) return false;
          return !occupiedZoneLabelRects.some((occupied) => (
            labelLeft < occupied.right + 4
            && labelRight > occupied.left - 4
            && candidateTop < occupied.bottom + 2
            && candidateBottom > occupied.top - 2
          ));
        });
        if (availableOffset !== undefined) {
          labelTop = preferredLabelTop + availableOffset;
          break;
        }
      }
      occupiedZoneLabelRects.push({
        left: labelLeft,
        right: labelRight,
        top: labelTop,
        bottom: labelTop + labelHeight,
      });
      label.style.position = 'absolute';
      label.style.left = '4px';
      label.style.right = '4px';
      label.style.top = `${labelTop - zoneTopCoordinate}px`;
      label.style.lineHeight = '12px';
      label.style.maxHeight = `${labelHeight}px`;
      label.style.overflow = 'hidden';
      label.style.color = inactive ? '#475569' : pending ? demand ? '#047857' : '#be123c' : isIss ? '#b45309' : isInternal ? '#6d28d9' : demand ? '#047857' : '#be123c';
      label.style.textAlign = 'center';

      const nameText = document.createElement('span');
      nameText.textContent = name;
      nameText.style.fontSize = '9px';
      nameText.style.fontWeight = '800';
      nameText.style.display = 'block';
      nameText.style.overflow = 'hidden';
      nameText.style.textOverflow = 'ellipsis';
      nameText.style.whiteSpace = 'nowrap';
      label.appendChild(nameText);

      if (labelDetails.length > 0 && detailLines > 0) {
        const detailText = document.createElement('span');
        detailText.textContent = labelDetails.join(' · ');
        detailText.style.fontSize = '8px';
        detailText.style.fontWeight = '400';
        detailText.style.opacity = '0.82';
        detailText.style.display = 'block';
        detailText.style.lineHeight = '11px';
        detailText.style.maxHeight = `${detailLines * 11}px`;
        detailText.style.overflow = 'hidden';
        detailText.style.overflowWrap = 'anywhere';
        label.appendChild(detailText);
      }
      box.appendChild(label);
      fragment.appendChild(box);
      if (touchesLivePrice(zone) || zoneLengthModes[chartZoneKey] !== undefined) {
        appendZoneCloseButton(zoneKey('chart', zone.id), name, right, zoneTopCoordinate, zoneTopCoordinate + zoneHeight);
      }
    }

    const alignedH1SwingMoveIds = new Set((showAlignedH1FibRef.current
      ? h1SwingFibMovesRef.current : [])
      .filter((move) => zonesRef.current.some((zone) => (
        zone.h1SwingFibStatus === 'aligned'
        && zone.h1SwingSourcePrice === move.sourcePrice
        && zone.h1SwingZeroPrice === move.zeroPrice
      )))
      .map((move) => `h1-swing-fib-${move.startedAt}-${move.direction}`));
    const hasVisibleFibMarking = alignedH1SwingMoveIds.size > 0
      || Object.values(fibVisibilityRef.current).some(Boolean)
      || Object.values(fibPreviousVisibilityRef.current).some(Boolean)
      || chochFibVisibilityRef.current.some(Boolean);
    if (showStructureRef.current || showIssRef.current || showInternalRef.current || showTrendlinesRef.current
      || (showFibRef.current && hasVisibleFibMarking)) {
      const namespace = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(namespace, 'svg');
      svg.setAttribute('width', String(host.clientWidth));
      svg.setAttribute('height', String(host.clientHeight));
      svg.style.position = 'absolute';
      svg.style.inset = '0';
      svg.style.overflow = 'hidden';

      if (showTrendlinesRef.current) {
        const scale = chart.timeScale();
        const endIndex = displayCandles.length - 1 + 8;
        const appendSetupLabel = (mark: ReturnType<typeof preEntryTrendlineMarks>[number], x: number, y: number, color: string) => {
          const label = document.createElementNS(namespace, 'text');
          const directionalLabel = `${mark.support.color === 'green' ? '↑' : '↓'} ${mark.label}`;
          const halfWidth = directionalLabel.length * 2.8;
          label.setAttribute('x', String(Math.max(halfWidth + 4, Math.min(rightEdge - halfWidth - 4, x))));
          label.setAttribute('y', String(Math.max(12, Math.min(host.clientHeight - 8, y + 12))));
          label.setAttribute('text-anchor', 'middle');
          label.setAttribute('fill', color);
          label.setAttribute('stroke', 'white');
          label.setAttribute('stroke-width', '3');
          label.setAttribute('paint-order', 'stroke');
          label.setAttribute('font-size', '9');
          label.setAttribute('font-weight', '800');
          label.textContent = directionalLabel;
          const title = document.createElementNS(namespace, 'title');
          title.textContent = `FIB aligned · Far from current 15m price ${formatPrice(mark.referencePrice)}. Entry still requires 15m confirmation and fill.`;
          label.appendChild(title);
          svg.appendChild(label);
        };
        for (const trendline of autoTrendlines) {
          const trendlineId = `${marketSymbol}:${granularity}:${displayCandles[trendline.firstIndex].time}:${displayCandles[trendline.secondIndex].time}:${trendline.firstPrice.toFixed(6)}:${trendline.slope.toFixed(9)}`;
          const shortened = shortenedTrendlineIds.has(trendlineId);
          const currentLinePrice = trendline.firstPrice
            + trendline.slope * (displayCandles.length - 1 - trendline.firstIndex);
          const setupMark = preEntryTrendlineMarkMap.get(`${granularity}:${trendline.kind}:${displayCandles[trendline.firstIndex].time}:${displayCandles[trendline.secondIndex].time}`);
          if (!showAllTrendlinesRef.current && !setupMark
            && Math.abs(currentLinePrice - livePrice) > 400 * marketConfig.pipSize) continue;
          const drawnEndIndex = shortened ? trendline.secondIndex : endIndex;
          const endPrice = trendline.firstPrice + trendline.slope * (drawnEndIndex - trendline.firstIndex);
          const x1 = scale.logicalToCoordinate(trendline.firstIndex);
          const x2 = scale.logicalToCoordinate(drawnEndIndex);
          const y1 = series.priceToCoordinate(trendline.firstPrice);
          const y2 = series.priceToCoordinate(endPrice);
          if (x1 === null || x2 === null || y1 === null || y2 === null
            || (!shortened && x2 <= 0) || x1 >= rightEdge) continue;
          const supportsBuy = trendlineSupportsBuy(trendline);
          const color = supportsBuy ? '#089981' : '#dc2626';
          const baseLabel = `${supportsBuy ? '↑' : '↓'} ${trendline.kind === 'breakout' ? 'Breakout' : 'Continuation'} Trendline`;
          const labelText = setupMark ? `${baseLabel} · ${setupMark.label}` : baseLabel;
          const labelWidth = labelText.length * 5.2 + 12;
          const visibleStartX = Math.max(0, x1);
          const visibleEndX = Math.min(rightEdge, x2);
          const labelX = (visibleStartX + visibleEndX) / 2;
          const labelY = y1 + (y2 - y1) * (labelX - x1) / (x2 - x1);
          const lineLength = Math.hypot(x2 - x1, y2 - y1);
          const showInlineLabel = !shortened && visibleEndX - visibleStartX > labelWidth + 20
            && labelY > 10 && labelY < host.clientHeight - 10;
          const appendLineSegment = (start: number, end: number) => {
            if (end <= start) return;
            const line = document.createElementNS(namespace, 'line');
            line.setAttribute('x1', String(x1 + (x2 - x1) * start));
            line.setAttribute('y1', String(y1 + (y2 - y1) * start));
            line.setAttribute('x2', String(x1 + (x2 - x1) * end));
            line.setAttribute('y2', String(y1 + (y2 - y1) * end));
            line.setAttribute('stroke', color);
            line.setAttribute('stroke-width', setupMark ? '3' : '1.7');
            line.setAttribute('stroke-opacity', shortened ? '0.55' : '0.7');
            if (trendline.kind === 'breakout') line.setAttribute('stroke-dasharray', '6 3');
            svg.appendChild(line);
          };
          if (showInlineLabel) {
            const center = (labelX - x1) / (x2 - x1);
            const halfGap = labelWidth / (2 * lineLength);
            appendLineSegment(0, center - halfGap);
            appendLineSegment(center + halfGap, 1);
          } else appendLineSegment(0, 1);

          const tapIndexes = shortened
            ? [trendline.firstIndex, trendline.secondIndex]
            : [trendline.firstIndex, trendline.secondIndex, trendline.thirdTouchIndex];
          tapIndexes.forEach((tapIndex, tapNumber) => {
            if (tapIndex === undefined) return;
            const tapX = scale.logicalToCoordinate(tapIndex);
            const tapPrice = trendline.firstPrice + trendline.slope * (tapIndex - trendline.firstIndex);
            const tapY = series.priceToCoordinate(tapPrice);
            if (tapX === null || tapY === null || tapX < 0 || tapX > rightEdge
              || tapY < 8 || tapY > host.clientHeight - 8) return;
            const tapLabel = document.createElementNS(namespace, 'text');
            tapLabel.setAttribute('x', String(tapX));
            tapLabel.setAttribute('y', String(tapY + (trendline.direction === 'up' ? 9 : -4)));
            tapLabel.setAttribute('text-anchor', 'middle');
            tapLabel.setAttribute('fill', color);
            tapLabel.setAttribute('fill-opacity', '0.8');
            tapLabel.setAttribute('font-size', '7');
            tapLabel.setAttribute('font-weight', '700');
            tapLabel.textContent = String(tapNumber + 1);
            svg.appendChild(tapLabel);
          });

          if (showInlineLabel) {
            const label = document.createElementNS(namespace, 'text');
            label.setAttribute('x', String(labelX));
            label.setAttribute('y', String(labelY));
            label.setAttribute('text-anchor', 'middle');
            label.setAttribute('dominant-baseline', 'middle');
            label.setAttribute('transform', `rotate(${Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI} ${labelX} ${labelY})`);
            label.setAttribute('fill', color);
            label.setAttribute('fill-opacity', '0.8');
            label.setAttribute('font-size', '9');
            label.setAttribute('font-weight', '700');
            label.textContent = labelText;
            if (setupMark) {
              const title = document.createElementNS(namespace, 'title');
              title.textContent = `FIB aligned · Far from current 15m price ${formatPrice(setupMark.referencePrice)}. Entry still requires 15m confirmation and fill.`;
              label.appendChild(title);
            }
            svg.appendChild(label);
          }

          if (setupMark && !showInlineLabel) appendSetupLabel(setupMark, labelX, labelY, color);
          const toggle = document.createElement('button');
          toggle.type = 'button';
          toggle.textContent = shortened ? '✓' : '×';
          toggle.title = shortened ? `Restore ${labelText}` : `Shorten ${labelText} to second touch`;
          toggle.setAttribute('aria-label', toggle.title);
          const controlX = shortened ? x2 + 3 : labelX + (showInlineLabel ? labelWidth / 2 + 4 : 0);
          const controlY = shortened ? y2 - 5 : y1 + (y2 - y1) * (controlX - x1) / (x2 - x1) - 5;
          Object.assign(toggle.style, {
            position: 'absolute',
            left: `${Math.max(4, Math.min(rightEdge - 10, controlX))}px`,
            top: `${Math.max(4, Math.min(host.clientHeight - 11, controlY))}px`,
            width: '9px', height: '9px', padding: '0', border: '1px solid #cbd5e1',
            borderRadius: '2px', background: 'rgba(255,255,255,0.8)', color,
            fontSize: '7px', lineHeight: '7px', cursor: 'pointer', pointerEvents: 'auto', zIndex: '2',
          });
          toggle.addEventListener('pointerdown', (event) => event.stopPropagation());
          toggle.addEventListener('click', (event) => {
            event.stopPropagation();
            setShortenedTrendlineIds((current) => {
              const next = new Set(current);
              if (shortened) next.delete(trendlineId);
              else next.add(trendlineId);
              return next;
            });
          });
          fragment.appendChild(toggle);
        }

        for (const htfTrendline of nearbyHtfTrendlines) {
          if (hiddenHtfTrendlineIds.has(htfTrendline.id)) continue;
          const { line, sourceCandles, timeframe } = htfTrendline;
          const firstTime = sourceCandles[line.firstIndex].time;
          let startIndex = 0;
          let high = displayCandles.length;
          while (startIndex < high) {
            const middle = (startIndex + high) >> 1;
            if (displayCandles[middle].time <= firstTime) startIndex = middle + 1;
            else high = middle;
          }
          startIndex = Math.max(0, startIndex - 1);
          const startTime = Math.max(firstTime, displayCandles[startIndex].time);
          const startLogical = startIndex + (startTime - displayCandles[startIndex].time)
            / Math.max(1, (displayCandles[startIndex + 1]?.time
              ?? marketCandleCloseTime(displayCandles[startIndex].time, granularity)) - displayCandles[startIndex].time);
          const startPrice = trendlinePriceAtTime(line, sourceCandles, timeframe, startTime);
          const endPrice = trendlinePriceAtTime(line, sourceCandles, timeframe,
            displayCandles[displayCandles.length - 1].time + 8 * TIMEFRAME_SECONDS[granularity]);
          const x1 = scale.logicalToCoordinate(startLogical);
          const x2 = scale.logicalToCoordinate(endIndex);
          const y1 = series.priceToCoordinate(startPrice);
          const y2 = series.priceToCoordinate(endPrice);
          if (x1 === null || x2 === null || y1 === null || y2 === null || x2 <= 0 || x1 >= rightEdge
            || (y1 < 0 && y2 < 0) || (y1 > host.clientHeight && y2 > host.clientHeight)) continue;
          const setupMark = preEntryTrendlineMarkMap.get(`${timeframe}:${line.kind}:${sourceCandles[line.firstIndex].time}:${sourceCandles[line.secondIndex].time}`);
          const supportsBuy = trendlineSupportsBuy(line);
          const color = supportsBuy ? '#089981' : '#dc2626';
          const baseLabel = `${supportsBuy ? '↑' : '↓'} ${GRANULARITY_LABELS[timeframe].toUpperCase()} ${line.kind === 'breakout'
            ? 'Breakout' : 'Continuation'} Trendline`;
          const labelText = setupMark ? `${baseLabel} · ${setupMark.label}` : baseLabel;
          const labelWidth = labelText.length * 4.5 + 12;
          let visibleStartX = Math.max(0, x1);
          let visibleEndX = Math.min(rightEdge, x2);
          if (y1 !== y2) {
            const topX = x1 + (0 - y1) * (x2 - x1) / (y2 - y1);
            const bottomX = x1 + (host.clientHeight - y1) * (x2 - x1) / (y2 - y1);
            visibleStartX = Math.max(visibleStartX, Math.min(topX, bottomX));
            visibleEndX = Math.min(visibleEndX, Math.max(topX, bottomX));
          }
          if (visibleEndX <= visibleStartX) continue;
          const labelX = (visibleStartX + visibleEndX) / 2;
          const labelY = y1 + (y2 - y1) * (labelX - x1) / (x2 - x1);
          const showInlineLabel = visibleEndX - visibleStartX > labelWidth + 20
            && labelY > 8 && labelY < host.clientHeight - 8;
          const appendFadedSegment = (start: number, end: number) => {
            if (end <= start) return;
            const segment = document.createElementNS(namespace, 'line');
            segment.setAttribute('x1', String(x1 + (x2 - x1) * start));
            segment.setAttribute('y1', String(y1 + (y2 - y1) * start));
            segment.setAttribute('x2', String(x1 + (x2 - x1) * end));
            segment.setAttribute('y2', String(y1 + (y2 - y1) * end));
            segment.setAttribute('stroke', color);
            segment.setAttribute('stroke-width', setupMark ? '2.7' : '1.2');
            segment.setAttribute('stroke-opacity', '0.45');
            segment.setAttribute('stroke-dasharray', '5 4');
            svg.appendChild(segment);
          };
          if (showInlineLabel) {
            const center = (labelX - x1) / (x2 - x1);
            const halfGap = labelWidth / (2 * Math.hypot(x2 - x1, y2 - y1));
            appendFadedSegment(0, center - halfGap);
            appendFadedSegment(center + halfGap, 1);
            const label = document.createElementNS(namespace, 'text');
            label.setAttribute('x', String(labelX));
            label.setAttribute('y', String(labelY));
            label.setAttribute('text-anchor', 'middle');
            label.setAttribute('dominant-baseline', 'middle');
            label.setAttribute('transform', `rotate(${Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI} ${labelX} ${labelY})`);
            label.setAttribute('fill', color);
            label.setAttribute('fill-opacity', '0.8');
            label.setAttribute('font-size', '8');
            label.textContent = labelText;
            if (setupMark) {
              const title = document.createElementNS(namespace, 'title');
              title.textContent = `FIB aligned · Far from current 15m price ${formatPrice(setupMark.referencePrice)}. Entry still requires 15m confirmation and fill.`;
              label.appendChild(title);
            }
            svg.appendChild(label);
          } else appendFadedSegment(0, 1);

          if (setupMark && !showInlineLabel) appendSetupLabel(setupMark, labelX, labelY, color);
          const close = document.createElement('button');
          close.type = 'button';
          close.textContent = '×';
          close.title = `Remove ${labelText}`;
          close.setAttribute('aria-label', `Remove ${labelText}`);
          Object.assign(close.style, {
            position: 'absolute',
            left: `${Math.max(4, Math.min(rightEdge - 11, labelX + (showInlineLabel ? labelWidth / 2 + 4 : 0)))}px`,
            top: `${Math.max(4, Math.min(host.clientHeight - 12, labelY - 5))}px`,
            width: '10px', height: '10px', padding: '0', border: '1px solid #cbd5e1',
            borderRadius: '2px', background: 'rgba(255,255,255,0.8)', color: '#64748b',
            fontSize: '8px', lineHeight: '8px', cursor: 'pointer', pointerEvents: 'auto', zIndex: '2',
          });
          close.addEventListener('pointerdown', (event) => event.stopPropagation());
          close.addEventListener('click', (event) => {
            event.stopPropagation();
            setHiddenHtfTrendlineIds((current) => new Set(current).add(htfTrendline.id));
          });
          fragment.appendChild(close);
        }
      }

      if (showFibRef.current && hasVisibleFibMarking) {
        const fibMovesByType = new Map<FibVisibilityKey, StructureZone[]>();
        for (const zone of zonesRef.current) {
          const type = fibVisibilityKey(zone);
          const isIssWaveFib = type === 'iss' && zone.name === 'ISS L3'
            && zone.issPoint0Time !== undefined;
          const isInternalChochFib = type === 'intChoch'
            && zone.category === 'internal'
            && zone.chochTime !== undefined;
          const retainHistoricalChochFib = type === 'choch'
            && chochFibVisibilityRef.current.some(Boolean);
          if (type === 'iss' && !isIssWaveFib) continue;
          if (type === 'intChoch' && !isInternalChochFib) continue;
          if (!zone.active && !showInvalidZonesRef.current
            && !isIssWaveFib && !retainHistoricalChochFib) continue;
          if (!zone.fibRelevant || !isFibMarkingVisible(
            zone,
            showFibRef.current,
            fibVisibilityRef.current,
            fibPreviousVisibilityRef.current,
            chochFibVisibilityRef.current,
          )) continue;
          if (zone.fibSourceTime === undefined || zone.fibSourcePrice === undefined
            || zone.fibZeroTime === undefined || zone.fibZeroPrice === undefined) continue;

          const typeMoves = fibMovesByType.get(type) ?? [];
          typeMoves.push(zone);
          fibMovesByType.set(type, typeMoves);
        }

        if (granularity !== 'D'
          && (fibVisibilityRef.current.swing || fibPreviousVisibilityRef.current.swing)) {
          const swingZones = swingFibMovesRef.current.map<StructureZone>((move) => ({
            id: `swing-fib-${move.startedAt}-${move.direction}`,
            name: move.direction === 'up' ? 'DEMAND' : 'SUPPLY',
            category: 'supplyDemand',
            isBuy: move.direction === 'up',
            startTime: move.startedAt,
            endTime: move.zeroTime,
            top: Math.max(move.sourcePrice, move.zeroPrice),
            bottom: Math.min(move.sourcePrice, move.zeroPrice),
            active: true,
            status: 'valid',
            fibRelevant: true,
            fibSourceTime: move.sourceTime,
            fibSourcePrice: move.sourcePrice,
            fibZeroTime: move.zeroTime,
            fibZeroPrice: move.zeroPrice,
          }));
          fibMovesByType.set('swing', swingZones);
        }

        if (['M5', 'M15', 'M30', 'H1'].includes(granularity)
          && (fibVisibilityRef.current.h1Swing || fibPreviousVisibilityRef.current.h1Swing
            || alignedH1SwingMoveIds.size > 0)) {
          const h1SwingZones = h1SwingFibMovesRef.current.map<StructureZone>((move) => ({
            id: `h1-swing-fib-${move.startedAt}-${move.direction}`,
            name: move.direction === 'up' ? 'DEMAND' : 'SUPPLY',
            category: 'supplyDemand',
            isBuy: move.direction === 'up',
            startTime: move.startedAt,
            endTime: move.zeroTime,
            top: Math.max(move.sourcePrice, move.zeroPrice),
            bottom: Math.min(move.sourcePrice, move.zeroPrice),
            active: true,
            status: 'valid',
            fibRelevant: true,
            fibSourceTime: move.sourceTime,
            fibSourcePrice: move.sourcePrice,
            fibZeroTime: move.zeroTime,
            fibZeroPrice: move.zeroPrice,
          }));
          fibMovesByType.set('h1Swing', h1SwingZones);
        }

        if (fibVisibilityRef.current.day) {
          const dayZones = dayFibMovesRef.current.filter(move => selectDayFibForTime([move], dayFibAsOf) !== undefined).map<StructureZone>((move) => ({
            id: `day-fib-${move.sessionDate}`,
            name: move.direction === 'up' ? 'DEMAND' : 'SUPPLY',
            category: 'supplyDemand',
            isBuy: move.direction === 'up',
            startTime: move.sourceTime,
            endTime: move.zeroTime,
            top: Math.max(move.sourcePrice, move.zeroPrice),
            bottom: Math.min(move.sourcePrice, move.zeroPrice),
            active: true,
            status: 'valid',
            fibRelevant: true,
            fibSourceTime: move.sourceTime,
            fibSourcePrice: move.sourcePrice,
            fibZeroTime: move.zeroTime,
            fibZeroPrice: move.zeroPrice,
          }));
          fibMovesByType.set('day', dayZones);
        }

        const latestFibMoves = [...fibMovesByType.entries()].flatMap(([type, typeMoves]) => {
          const distinctMoves = new Set<string>();
          const orderedMoves = typeMoves
            .sort((first, second) => {
              const firstEventTime = first.issCompletionTime
                ?? first.doubleChochTime ?? first.chochTime ?? first.startTime;
              const secondEventTime = second.issCompletionTime
                ?? second.doubleChochTime ?? second.chochTime ?? second.startTime;
              return secondEventTime - firstEventTime || second.startTime - first.startTime;
            })
            .filter((zone) => {
              const moveKey = [
                zone.fibSourceTime,
                zone.fibSourcePrice,
                zone.fibZeroTime,
                zone.fibZeroPrice,
              ].join(':');
              if (distinctMoves.has(moveKey)) return false;
              distinctMoves.add(moveKey);
              return true;
            });
          if (type === 'choch') {
            return orderedMoves.slice(0, 4).filter((_, index) => (
              chochFibVisibilityRef.current[index]
            ));
          }
          const previousMoves = type !== 'tjl1' && type !== 'tjl2'
            && type !== 'intTjl1' && type !== 'intTjl2'
            && type !== 'doubleChoch' && type !== 'intDoubleChoch' && type !== 'iss'
            && fibPreviousVisibilityRef.current[type]
            ? orderedMoves.slice(1, 2)
            : [];
          const selectedMoves = [
            ...(fibVisibilityRef.current[type] && orderedMoves[0] ? [orderedMoves[0]] : []),
            ...previousMoves,
          ];
          if (type === 'h1Swing') {
            selectedMoves.push(...orderedMoves.filter((zone) => alignedH1SwingMoveIds.has(zone.id)));
          }
          return Array.from(new Map(selectedMoves.map((zone) => [zone.id, zone])).values());
        });

        const fibAnchorCoordinate = (anchorTime: number) => {
          const exactCoordinate = chart.timeScale().timeToCoordinate(anchorTime as UTCTimestamp);
          if (exactCoordinate !== null) return exactCoordinate;

          // Higher-timeframe candles can begin inside a lower-timeframe market
          // gap (for example, an H4 candle at 21:00 while the next M15 candle
          // starts at 22:00). Map that anchor forward to the first available
          // chart candle, but do not pull anchors in from outside loaded data.
          let low = 0;
          let high = displayCandles.length;
          while (low < high) {
            const middle = Math.floor((low + high) / 2);
            if (displayCandles[middle].time < anchorTime) low = middle + 1;
            else high = middle;
          }
          const fallbackCandle = displayCandles[low];
          if (!fallbackCandle || low === 0 && fallbackCandle.time > anchorTime) return null;
          return chart.timeScale().timeToCoordinate(fallbackCandle.time as UTCTimestamp);
        };

        const liveCandle = displayCandles[displayCandles.length - 1];
        const previousCandle = displayCandles[displayCandles.length - 2];
        const liveX = liveCandle
          ? chart.timeScale().timeToCoordinate(liveCandle.time as UTCTimestamp) : null;
        const previousX = previousCandle
          ? chart.timeScale().timeToCoordinate(previousCandle.time as UTCTimestamp) : null;
        const candleSpacing = liveX !== null && previousX !== null
          ? Math.abs(liveX - previousX)
          : chart.timeScale().options().barSpacing;
        const fiveCandlesPastLive = liveX === null
          ? rightEdge : liveX + 5 * candleSpacing;

        for (const zone of latestFibMoves) {
          const isH1Swing = zone.id.startsWith('h1-swing-fib-');
          const isSwingDrawing = isH1Swing || zone.id.startsWith('swing-fib-');
          const fibColor = isH1Swing ? '#7c3aed' : '#e11d48';
          const sourceX = fibAnchorCoordinate(zone.fibSourceTime!);
          const zeroX = fibAnchorCoordinate(zone.fibZeroTime!);
          const sourceY = series.priceToCoordinate(zone.fibSourcePrice);
          const zeroY = series.priceToCoordinate(zone.fibZeroPrice);
          if (sourceX === null || zeroX === null || sourceY === null || zeroY === null) continue;

          const lineLeft = Math.min(sourceX, zeroX);
          const lineRight = Math.max(sourceX, zeroX);
          if ((!isSwingDrawing && lineRight < 0) || lineLeft > rightEdge) continue;
          const levelLineLeft = isSwingDrawing ? Math.max(0, lineLeft) : lineLeft;
          const levelLineRight = isSwingDrawing
            ? Math.min(rightEdge, fiveCandlesPastLive) : lineRight;
          if (levelLineRight <= levelLineLeft) continue;

          for (const level of INDICATOR_FIB_LEVELS) {
            const price = indicatorFibPrice(zone.fibZeroPrice, zone.fibSourcePrice, level.ratio);
            const y = series.priceToCoordinate(price);
            if (y === null || y < -20 || y > host.clientHeight + 20) continue;

            const levelLine = document.createElementNS(namespace, 'line');
            levelLine.setAttribute('x1', String(levelLineLeft));
            levelLine.setAttribute('y1', String(y));
            levelLine.setAttribute('x2', String(levelLineRight));
            levelLine.setAttribute('y2', String(y));
            levelLine.setAttribute('stroke', fibColor);
            levelLine.setAttribute('stroke-width', level.ratio === 0 || level.ratio === 1 ? '1.2' : '1');
            levelLine.setAttribute('stroke-opacity', '0.82');
            svg.appendChild(levelLine);

            const levelText = document.createElementNS(namespace, 'text');
            levelText.setAttribute('x', String(Math.max(18, levelLineLeft - 7)));
            levelText.setAttribute('y', String(y + 3));
            levelText.setAttribute('text-anchor', 'end');
            levelText.setAttribute('fill', fibColor);
            levelText.setAttribute('fill-opacity', '0.9');
            levelText.setAttribute('font-size', '9');
            levelText.setAttribute('font-weight', '700');
            levelText.textContent = level.label;
            svg.appendChild(levelText);
          }

          const anchorLine = document.createElementNS(namespace, 'line');
          anchorLine.setAttribute('x1', String(sourceX));
          anchorLine.setAttribute('y1', String(sourceY));
          anchorLine.setAttribute('x2', String(zeroX));
          anchorLine.setAttribute('y2', String(zeroY));
          anchorLine.setAttribute('stroke', isH1Swing ? '#8b5cf6' : '#f43f5e');
          anchorLine.setAttribute('stroke-width', '1.2');
          anchorLine.setAttribute('stroke-opacity', '0.82');
          anchorLine.setAttribute('stroke-dasharray', '7 6');
          svg.appendChild(anchorLine);

          for (const anchor of [{ x: sourceX, y: sourceY }, { x: zeroX, y: zeroY }]) {
            const circle = document.createElementNS(namespace, 'circle');
            circle.setAttribute('cx', String(anchor.x));
            circle.setAttribute('cy', String(anchor.y));
            circle.setAttribute('r', '4');
            circle.setAttribute('fill', '#ffffff');
            circle.setAttribute('stroke', isH1Swing ? '#7c3aed' : '#2563eb');
            circle.setAttribute('stroke-width', '1.4');
            svg.appendChild(circle);
          }
        }
      }

      const occupiedStructureLabels: Array<{
        left: number;
        right: number;
        top: number;
        bottom: number;
      }> = [];
      for (const structureLine of structureLinesRef.current) {
        const isInternalLine = structureLine.type.startsWith('internal-');
        if (structureLine.type === 'iss' && !showIssRef.current) continue;
        if (isInternalLine && !showInternalRef.current) continue;
        if (structureLine.type !== 'iss' && !isInternalLine && !showStructureRef.current) continue;
        if (visibleTimeRange && (Math.max(structureLine.fromTime, structureLine.toTime)
          < Number(visibleTimeRange.from) || Math.min(structureLine.fromTime, structureLine.toTime)
          > Number(visibleTimeRange.to))) continue;
        const x1 = chart.timeScale().timeToCoordinate(structureLine.fromTime as UTCTimestamp);
        const x2 = chart.timeScale().timeToCoordinate(structureLine.toTime as UTCTimestamp);
        const y1 = series.priceToCoordinate(structureLine.fromPrice);
        const y2 = series.priceToCoordinate(structureLine.toPrice);
        if (x1 === null || x2 === null || y1 === null || y2 === null) continue;
        if ((x1 < 0 && x2 < 0) || (x1 > rightEdge && x2 > rightEdge)
          || (y1 < 0 && y2 < 0) || (y1 > host.clientHeight && y2 > host.clientHeight)) continue;

        const bullish = structureLine.direction === 'bullish';
        const isIssLine = structureLine.type === 'iss';
        const color = isIssLine ? '#d97706' : isInternalLine ? '#7c3aed' : bullish ? '#0f766e' : '#be123c';
        const line = document.createElementNS(namespace, 'line');
        line.setAttribute('x1', String(x1));
        line.setAttribute('y1', String(y1));
        line.setAttribute('x2', String(x2));
        line.setAttribute('y2', String(y2));
        line.setAttribute('stroke', color);
        const isSwing = structureLine.type === 'swing' || structureLine.type === 'internal-swing';
        line.setAttribute('stroke-width', isIssLine ? '0.8' : isSwing ? '1' : '0.8');
        line.setAttribute('stroke-opacity', isIssLine ? '0.74' : isInternalLine ? '0.68' : isSwing ? '0.52' : '0.42');
        if (!isSwing && !isIssLine) line.setAttribute('stroke-dasharray', '4 3');
        svg.appendChild(line);

        const structureLabel = structureLine.type === 'choch' || structureLine.type === 'internal-choch'
          ? repeatedLtfChochLabels.get(`${isInternalLine ? 'internal' : 'external'}:${structureLine.toTime}`)
            ?? structureLine.label
          : structureLine.label;
        if (structureLabel) {
          const labelX = (x1 + x2) / 2;
          const preferredLabelY = y1 - 5;
          const labelWidth = Math.max(28, structureLabel.length * 5);
          const labelHeight = 10;
          let labelY = preferredLabelY;
          for (let attempt = 0; attempt < 20; attempt += 1) {
            const row = Math.ceil(attempt / 2);
            const offset = attempt === 0 ? 0 : row * 11 * (attempt % 2 === 1 ? -1 : 1);
            const candidateY = Math.max(labelHeight, Math.min(host.clientHeight - 2, preferredLabelY + offset));
            const candidateBounds = {
              left: labelX - labelWidth / 2,
              right: labelX + labelWidth / 2,
              top: candidateY - labelHeight,
              bottom: candidateY + 2,
            };
            const overlapsLabel = occupiedStructureLabels.some((bounds) => (
              candidateBounds.left < bounds.right + 3
              && candidateBounds.right > bounds.left - 3
              && candidateBounds.top < bounds.bottom + 2
              && candidateBounds.bottom > bounds.top - 2
            ));
            if (overlapsLabel) continue;
            labelY = candidateY;
            occupiedStructureLabels.push(candidateBounds);
            break;
          }
          const text = document.createElementNS(namespace, 'text');
          text.setAttribute('x', String(labelX));
          text.setAttribute('y', String(labelY));
          text.setAttribute('text-anchor', 'middle');
          text.setAttribute('fill', color);
          text.setAttribute('fill-opacity', '0.55');
          text.setAttribute('font-size', '8');
          text.setAttribute('font-weight', '600');
          text.textContent = structureLabel;
          svg.appendChild(text);
        }
      }

      // ISS point labels are drawn at the real wick coordinate. Series markers
      // are deliberately not used here because they place a large circle away
      // from the candle and make it look like the point belongs elsewhere.
      if (showIssRef.current) {
        for (const marker of issMarkersRef.current) {
          if (visibleTimeRange && (Number(marker.time) < Number(visibleTimeRange.from)
            || Number(marker.time) > Number(visibleTimeRange.to))) continue;
          const candle = candleByTime.get(Number(marker.time));
          if (!candle) continue;
          const x = chart.timeScale().timeToCoordinate(marker.time as UTCTimestamp);
          const isHigh = marker.position === 'aboveBar';
          const markerPrice = typeof marker.pivotPrice === 'number'
            ? marker.pivotPrice
            : isHigh ? candle.high : candle.low;
          const y = series.priceToCoordinate(markerPrice);
          if (x === null || y === null) continue;
          if (x < 0 || x > rightEdge || y < -50 || y > host.clientHeight + 50) continue;
          const overlapsStructureMarker = showStructureRef.current
            && structureMarkersRef.current.some((structureMarker) => (
              Number(structureMarker.time) === Number(marker.time)
              && structureMarker.position === marker.position
            ));
          const overlapsVisibleZone = zonesRef.current.some((zone) => {
            const visible = zone.category === 'mg'
              ? showMgZonesRef.current
              : zone.category === 'iss'
                ? showIssRef.current
                : zone.category === 'internal'
                  ? showInternalRef.current
                  : showSupplyDemandRef.current;
            return visible
              && (zone.active || showInvalidZonesRef.current)
              && Number(marker.time) >= zone.startTime
              && Number(marker.time) <= zone.endTime
              && markerPrice >= zone.bottom
              && markerPrice <= zone.top;
          });
          const offsetForCollision = overlapsStructureMarker || overlapsVisibleZone;
          // Keep every ISS number outside its pivot wick. If a structure marker
          // or zone label occupies that side, move it farther vertically rather
          // than sideways so it remains centered on the correct candle.
          const markerOffset = offsetForCollision ? 38 : 24;
          const text = document.createElementNS(namespace, 'text');
          text.setAttribute('x', String(x));
          text.setAttribute('y', String(y + (isHigh ? -markerOffset : markerOffset)));
          text.setAttribute('text-anchor', 'middle');
          text.setAttribute('dominant-baseline', 'middle');
          text.setAttribute('fill', marker.color || '#d97706');
          text.setAttribute('fill-opacity', '0.95');
          text.setAttribute('font-size', '11');
          text.setAttribute('font-weight', '700');
          text.textContent = marker.text;
          svg.appendChild(text);
        }
      }
      fragment.appendChild(svg);
    }
    if (showTradeLevelsRef.current || tradeOverlaysRef.current.some(item => item.alwaysVisible && !item.referenceOnly)) {
      for (const overlay of tradeOverlaysRef.current) {
        if (!showTradeLevelsRef.current && !(overlay.alwaysVisible && !overlay.referenceOnly)) continue;
        const { trade } = overlay;
        if (hasTradeDrawingExpired(trade)) continue;
        if (isSlTpTradeDisplayFinished(trade)) {
          const exitCandle = trade.resolvedAt === undefined ? undefined : candleContainingTime(trade.resolvedAt);
          const exitX = exitCandle ? chart.timeScale().timeToCoordinate(exitCandle.time as UTCTimestamp) : null;
          const exitY = series.priceToCoordinate(trade.result === 'tp' || trade.status === 'tp-hit'
            ? trade.takeProfit : trade.stopLoss);
          if (exitX !== null && exitY !== null) {
            const label = document.createElement('div');
            Object.assign(label.style, { position: 'absolute', left: `${Math.max(0, exitX)}px`,
              top: `${Math.max(0, exitY - 16)}px`, color: trade.result === 'tp' ? '#047857' : '#be123c',
              background: 'rgba(255, 255, 255, 0.95)', padding: '1px 3px',
              fontSize: '9px', fontWeight: '900', whiteSpace: 'nowrap' });
            label.textContent = completedTradeLabel(trade, tableTimeframeData[trade.signal.timeframe]?.candles ?? displayCandles,
              replayIndex === null ? Date.now() / 1000 : marketCandleCloseTime(displayCandles.at(-1)!.time, granularity)) ?? '';
            fragment.appendChild(label);
          }
          continue;
        }
        // A final exit keeps its drawing for five completed entry-timeframe candles.
        const completedReplayReference = isCompletedTrade(trade);
        const drawingKey = `${marketSymbol}:${tradeOverlayEntryEventKey(trade.signal)}:${tradeOverlayExecutionKey(trade)}`;
        if (completedReplayReference && hiddenCompletedTradeDrawings.has(drawingKey)) continue;
        const anchor = candleContainingTime(trade.calculatedAt)
          ?? displayCandles[candleIndexAtOrAfter(trade.calculatedAt)];
        if (!anchor) continue;
        const rawLeft = chart.timeScale().timeToCoordinate(anchor.time as UTCTimestamp);
        const entryY = series.priceToCoordinate(trade.entry);
        const stopY = series.priceToCoordinate(trade.stopLoss);
        const targetY = series.priceToCoordinate(trade.takeProfit);
        if (rawLeft === null || entryY === null || stopY === null || targetY === null) continue;
        const left = Math.max(0, rawLeft);
        const resolutionTime = completedReplayReference ? trade.resolvedAt : undefined;
        const latestTradeCandle = resolutionTime === undefined
          ? displayCandles[displayCandles.length - 1]
          : candleContainingTime(resolutionTime) ?? displayCandles[displayCandles.length - 1];
        const latestCandleX = latestTradeCandle
          ? chart.timeScale().timeToCoordinate(latestTradeCandle.time as UTCTimestamp)
          : null;
        // Keep an unresolved Long/Short drawing ten bars ahead of the current candle.
        const drawingRightX = resolutionTime === undefined
          ? chart.timeScale().logicalToCoordinate(displayCandles.length - 1 + 10)
          : latestCandleX === null ? null : latestCandleX + 6;
        const drawingRight = drawingRightX === null
          ? rightEdge
          : Math.min(rightEdge, Math.max(left + 8, drawingRightX));
        const width = drawingRight - left;
        if (width < 8 || left >= rightEdge) continue;
        const makeRange = (firstY: number, secondY: number, reward: boolean) => {
          const range = document.createElement('div');
          range.style.position = 'absolute';
          range.style.left = `${left}px`;
          range.style.top = `${Math.min(firstY, secondY)}px`;
          range.style.width = `${width}px`;
          range.style.height = `${Math.max(1, Math.abs(secondY - firstY))}px`;
          range.style.background = overlay.referenceOnly ? 'rgba(148, 163, 184, 0.08)'
            : reward ? 'rgba(16, 185, 129, 0.18)' : 'rgba(244, 63, 94, 0.16)';
          range.style.border = `1px ${overlay.referenceOnly ? 'dashed' : 'solid'} ${reward ? 'rgba(5, 150, 105, 0.34)' : 'rgba(225, 29, 72, 0.32)'}`;
          range.style.opacity = '1';
          return range;
        };
        fragment.appendChild(makeRange(entryY, targetY, true));
        fragment.appendChild(makeRange(entryY, stopY, false));

        const makeLevelLine = (
          y: number,
          color: string,
          label: string,
          dashed = false,
          entryLabel = false,
        ) => {
          const line = document.createElement('div');
          line.style.position = 'absolute';
          line.style.left = `${left}px`;
          line.style.top = `${y}px`;
          line.style.width = `${width}px`;
          line.style.borderTop = `1px ${dashed || overlay.referenceOnly ? 'dashed' : 'solid'} ${color}`;

          const levelLabel = document.createElement('span');
          levelLabel.style.position = 'absolute';
          levelLabel.style.right = '2px';
          levelLabel.style.top = '-11px';
          levelLabel.style.padding = '0 2px';
          levelLabel.style.background = 'rgba(255, 255, 255, 0.9)';
          levelLabel.style.color = color;
          levelLabel.style.fontSize = entryLabel ? '6px' : '8px';
          levelLabel.style.fontWeight = entryLabel ? '400' : '900';
          levelLabel.style.lineHeight = '10px';
          levelLabel.style.whiteSpace = 'nowrap';
          levelLabel.textContent = label;
          line.appendChild(levelLabel);
          fragment.appendChild(line);
        };

        if (overlay.pullbackSetup) {
          makeLevelLine(entryY, '#1e40af', `${overlay.pullbackSetup.secondOnly ? '2nd' : '1st'} Entry ${formatPrice(trade.entry)}`, false, true);
          const second = overlay.pullbackSetup.legs.find(leg => leg.leg === 25);
          const secondY = second ? series.priceToCoordinate(second.entry) : null;
          if (secondY !== null && !overlay.pullbackSetup.secondOnly) makeLevelLine(secondY, '#1e40af', `2nd Entry ${formatPrice(second!.entry)}`, true, true);
        } else makeLevelLine(entryY, '#1e40af', `${overlay.chartFilled ? 'CHART ENTRY' : overlay.referenceOnly ? 'SETUP ENTRY' : overlay.id.startsWith('GOLD_SCALP:') || overlay.label?.includes('SCALP') ? 'SCALP ENTRY' : 'ENTRY'} ${formatPrice(trade.entry)}`);
        makeLevelLine(stopY, '#be123c', `${overlay.pullbackSetup || overlay.referenceOnly ? 'SL' : 'SL EXIT'} ${formatPrice(trade.stopLoss)}`);
        makeLevelLine(targetY, '#047857', `${overlay.pullbackSetup || overlay.referenceOnly ? 'TP' : 'TP EXIT'} ${formatPrice(trade.takeProfit)}`);
        const riskFreeY = trade.riskFreeEnabled === false
          ? null : series.priceToCoordinate(trade.riskFree);
        if (riskFreeY !== null) {
          makeLevelLine(riskFreeY, '#a16207', `1R / BE ${formatPrice(trade.riskFree)}`, true);
        }

        if (completedReplayReference && !overlay.referenceOnly) {
          const closeButton = document.createElement('button');
          closeButton.type = 'button';
          closeButton.textContent = '×';
          closeButton.title = 'Hide completed trade drawing';
          closeButton.setAttribute('aria-label', closeButton.title);
          closeButton.dataset.journalExclude = 'true';
          Object.assign(closeButton.style, {
            position: 'absolute',
            left: `${Math.max(left, drawingRight - 12)}px`,
            top: `${Math.max(0, Math.min(host.clientHeight - 12, Math.min(entryY, stopY, targetY) - 24))}px`,
            width: '12px', height: '12px', padding: '0',
            border: '1px solid #cbd5e1', borderRadius: '2px',
            background: 'rgba(255, 255, 255, 0.95)', color: '#64748b',
            fontSize: '10px', lineHeight: '10px', cursor: 'pointer', pointerEvents: 'auto',
          });
          closeButton.addEventListener('pointerdown', (event) => event.stopPropagation());
          closeButton.addEventListener('click', (event) => {
            event.stopPropagation();
            setHiddenCompletedTradeDrawings((current) => new Set([...current, drawingKey]));
          });
          fragment.appendChild(closeButton);
        }

        if (!overlay.pullbackSetup && !(overlay.referenceOnly && overlay.label === 'OUTSIDE TRADING TIME · REFERENCE')) {
          const badge = document.createElement('div');
          badge.style.position = 'absolute';
          badge.style.left = `${left + width / 2}px`;
          badge.style.top = `${Math.max(entryY, stopY) - 13 - (overlay.displayOffset ?? 0) * 12}px`;
          badge.style.transform = 'translateX(-50%)';
          badge.style.color = overlay.referenceOnly ? '#be123c' : '#0f172a';
          badge.style.fontSize = '8px';
          badge.style.fontWeight = '800';
          badge.style.lineHeight = '10px';
          badge.style.whiteSpace = 'nowrap';
          badge.textContent = overlay.label ?? `CHART · 1:${trade.rewardRisk}`;
          fragment.appendChild(badge);
        }
      }
    }

    // Swap the complete overlay in one operation so the browser does not
    // perform layout work for every individual zone, line, and label.
    layer.replaceChildren(fragment);
  }, [dayFibAsOf, autoTrendlines, hasTradeDrawingExpired, zoneLengthModes, hiddenCompletedTradeDrawings, hiddenHtfTrendlineIds, nearbyHtfTrendlines, shortenedTrendlineIds, comparisonTimeframe, directZoneTrades, displayCandles, extremeAPlusTjl2Selection, granularity, latestCandle?.time, ltfChochContext, marketConfig.pipSize, marketSymbol, mtfRows, mtfDrawingZones, oneMinuteScalpingZones, overlayCandlesByTime, preEntryTrendlineMarkMap, repeatedLtfChochLabels, replayIndex, scalpingEnabled, tableTimeframeData, visibleComparisonZones, zoneDrawingEndIndices, zoneTableRows]);

  redrawZonesRef.current = redrawZones;

  const scheduleOverlayRedraw = useCallback(() => {
    if (overlayScrollTimerRef.current !== null) {
      window.clearTimeout(overlayScrollTimerRef.current);
      overlayScrollTimerRef.current = null;
    }
    if (overlayRedrawFrameRef.current !== null) return;
    overlayRedrawFrameRef.current = window.requestAnimationFrame(() => {
      overlayRedrawFrameRef.current = null;
      redrawZonesRef.current();
      lastOverlayRedrawAtRef.current = performance.now();
    });
  }, []);

  const scheduleScrollOverlayRedraw = useCallback(() => {
    if (overlayRedrawFrameRef.current !== null || overlayScrollTimerRef.current !== null) return;
    const elapsed = performance.now() - lastOverlayRedrawAtRef.current;
    const delay = Math.max(0, SCROLL_OVERLAY_REDRAW_INTERVAL_MS - elapsed);
    if (delay === 0) scheduleOverlayRedraw();
    else overlayScrollTimerRef.current = window.setTimeout(scheduleOverlayRedraw, delay);
  }, [scheduleOverlayRedraw]);

  const scheduleDrawingRedraw = useCallback(() => {
    if (!hasChartDrawingLayerRef.current
      || drawingRedrawFrameRef.current !== null
      || drawingRedrawTimerRef.current !== null) return;
    const elapsed = performance.now() - lastDrawingRedrawAtRef.current;
    const scheduleFrame = () => {
      drawingRedrawTimerRef.current = null;
      drawingRedrawFrameRef.current = window.requestAnimationFrame(() => {
        drawingRedrawFrameRef.current = null;
        lastDrawingRedrawAtRef.current = performance.now();
        setDrawingRenderVersion((version) => version + 1);
      });
    };
    const delay = Math.max(0, DRAWING_REDRAW_INTERVAL_MS - elapsed);
    if (delay > 0) drawingRedrawTimerRef.current = window.setTimeout(scheduleFrame, delay);
    else scheduleFrame();
  }, []);

  useEffect(() => {
    zonesRef.current = displayZones;
    visualZonesRef.current = consolidatedDisplayZones;
    swingFibMovesRef.current = swingFibMoves;
    h1SwingFibMovesRef.current = h1SwingFibMoves;
    dayFibMovesRef.current = dayFibMoves;
    structureLinesRef.current = structure.lines;
    structureMarkersRef.current = structure.markers;
    issMarkersRef.current = structure.issMarkers;
    internalMarkersRef.current = structure.internalMarkers;
    showMgZonesRef.current = showMgZones;
    showSupplyDemandRef.current = showSupplyDemand;
    showStructureRef.current = showStructure;
    showTrendlinesRef.current = showTrendlines;
    showAllTrendlinesRef.current = showAllTrendlines;
    showIssRef.current = showIss;
    showInternalRef.current = showInternal;
    showFibRef.current = showFib;
    showAlignedH1FibRef.current = showAlignedH1Fib;
    fibVisibilityRef.current = fibVisibility;
    fibPreviousVisibilityRef.current = fibPreviousVisibility;
    chochFibVisibilityRef.current = chochFibVisibility;
    showInvalidZonesRef.current = showInvalidZones;
    showTradeLevelsRef.current = showTradeLevels;
    tradeOverlaysRef.current = [...visibleTradeOverlays, ...replayHistoryOverlays.filter(overlay =>
      !pullbackChartSetups.some(setup => belongsToPullbackSetup(setup, overlay.trade, undefined, overlay)))];
    scheduleOverlayRedraw();
  }, [pullbackChartSetups, chochFibVisibility, consolidatedDisplayZones, dayFibMoves, displayZones, fibPreviousVisibility, fibVisibility, h1SwingFibMoves, redrawZones, replayHistoryOverlays, scheduleOverlayRedraw, showAlignedH1Fib, showAllTrendlines, showFib, showInternal, showInvalidZones, showIss, showMgZones, showStructure, showSupplyDemand, showTradeLevels, showTrendlines, structure.internalMarkers, structure.issMarkers, structure.lines, structure.markers, swingFibMoves, visibleTradeOverlays]);

  useEffect(() => {
    const overlay = tradeOverlays[0];
    const pane = chartPaneRef.current;
    if (!overlay || !pane || capturedTradeSetupsRef.current.has(overlay.id)) return undefined;
    const storageKey = `${JOURNAL_SCREENSHOT_PREFIX}${overlay.id}`;
    try {
      if (userStorage.getItem(storageKey)) {
        capturedTradeSetupsRef.current.add(overlay.id);
        return undefined;
      }
    } catch {
      // Capture can still be attempted even when local storage is restricted.
    }
    capturedTradeSetupsRef.current.add(overlay.id);
    const timer = window.setTimeout(() => {
      const capture = async () => {
        const previousShowFib = showFibRef.current;
        const previousShowTradeLevels = showTradeLevelsRef.current;
        const previousFibVisibility = fibVisibilityRef.current;
        const previousFibPreviousVisibility = fibPreviousVisibilityRef.current;
        const previousChochFibVisibility = chochFibVisibilityRef.current;
        try {
          showFibRef.current = true;
          showTradeLevelsRef.current = true;
          fibVisibilityRef.current = Object.fromEntries(
            ALL_FIB_VISIBILITY_OPTIONS.map((option) => [option.key, true]),
          ) as Record<FibVisibilityKey, boolean>;
          fibPreviousVisibilityRef.current = DEFAULT_FIB_VISIBILITY;
          chochFibVisibilityRef.current = [true, true, true, true];
          redrawZonesRef.current();
          await new Promise<void>((resolve) => window.requestAnimationFrame(() => resolve()));
          const { toJpeg } = await import('html-to-image');
          const screenshot = await toJpeg(pane, {
            backgroundColor: '#ffffff',
            cacheBust: false,
            pixelRatio: 1,
            quality: 0.8,
            filter: (node) => !(
              node instanceof HTMLElement && node.dataset.journalExclude === 'true'
            ),
          });
          const resized = await resizeJournalScreenshot(screenshot);
          userStorage.setItem(storageKey, resized);
        } catch {
          capturedTradeSetupsRef.current.delete(overlay.id);
        } finally {
          showFibRef.current = previousShowFib;
          showTradeLevelsRef.current = previousShowTradeLevels;
          fibVisibilityRef.current = previousFibVisibility;
          fibPreviousVisibilityRef.current = previousFibPreviousVisibility;
          chochFibVisibilityRef.current = previousChochFibVisibility;
          redrawZonesRef.current();
        }
      };
      void capture();
    }, 450);
    return () => window.clearTimeout(timer);
  }, [tradeOverlays]);

  useEffect(() => {
    if (granularity === 'D' && expandedFibOption === 'swing') {
      setExpandedFibOption(null);
    }
  }, [expandedFibOption, granularity]);

  useEffect(() => {
    if (!replayPlaying || replayIndex === null) return;
    const timer = window.setInterval(() => {
      setReplayIndex((index) => {
        if (index === null || index >= candles.length - 1) {
          setReplayPlaying(false);
          return index;
        }
        return index + 1;
      });
    }, Math.round(550 / replaySpeed));
    return () => window.clearInterval(timer);
  }, [candles.length, replayIndex, replayPlaying, replaySpeed]);

  useEffect(() => {
    if (replayIndex === null) return;
    const replayCandle = candles[Math.min(replayIndex, candles.length - 1)];
    if (replayCandle) replayTimeRef.current = replayCandle.time;
  }, [candles, replayIndex]);

  const prepareChartAnalysis = useCallback(async (
    nextCandles: OandaCandle[],
    auxiliary: Partial<Record<MarketGranularity, OandaCandle[]>>,
    nextReplayIndex: number | null,
  ) => {
    if (typeof Worker === 'undefined') return;
    const visibleCandles = nextReplayIndex === null ? nextCandles : nextCandles.slice(0, nextReplayIndex + 1);
    const last = visibleCandles[visibleCandles.length - 1];
    if (!last) return;
    const cutoff = last.time + (last.complete ? TIMEFRAME_SECONDS[granularity] : 0);
    const tasks: StructureAnalysisTask[] = vipSupportGranularities.map((timeframe) => ({
      key: `support:${timeframe}`,
      candles: (auxiliary[timeframe] ?? []).filter((candle) => (
        candle.complete && marketCandleCloseTime(candle.time, timeframe) <= cutoff
      )),
      options: {
        allowSupplyDemand: ['H1', 'H4', 'D', 'W', 'MO'].includes(timeframe),
        sourceBarSeconds: TIMEFRAME_SECONDS[timeframe],
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[timeframe],
        zoneVisualBars: 30,
      },
    }));
    tasks.push({
      key: 'chart', candles: visibleCandles,
      options: {
        allowSupplyDemand: ['H1', 'H4', 'D', 'W'].includes(granularity),
        sourceBarSeconds: TIMEFRAME_SECONDS[granularity],
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[granularity], zoneVisualBars: 30,
      },
      support: vipSupportGranularities.map((timeframe) => ({ key: `support:${timeframe}`, timeframe: GRANULARITY_LABELS[timeframe] })),
    });
    if (granularity !== 'D' && granularity !== 'H4') tasks.push({
      key: 'h4', candles: auxiliary.H4 ?? [],
      options: { allowSupplyDemand: true, sourceBarSeconds: TIMEFRAME_SECONDS.H4,
        confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS.H4, zoneVisualBars: 30 },
    });
    for (const timeframe of new Set([...TREND_TABLE_GRANULARITIES, ...AUTOMATION_GRANULARITIES])) {
      if (timeframe === granularity) continue;
      const available = auxiliary[timeframe] ?? [];
      tasks.push({ key: `table:${timeframe}`,
        candles: nextReplayIndex === null ? available : available.filter((candle) => candle.time <= cutoff),
        options: { allowSupplyDemand: ['H1', 'H4', 'D'].includes(timeframe),
          sourceBarSeconds: TIMEFRAME_SECONDS[timeframe],
          confirmationBarSeconds: TJL1_CONFIRMATION_SECONDS[timeframe], zoneVisualBars: 30 },
      });
    }
    try {
      let worker = analysisWorkerRef.current;
      if (!worker) {
        worker = new Worker(new URL('../services/structureAnalysis.worker.ts', import.meta.url), { type: 'module' });
        worker.onmessage = (event: MessageEvent<{ id: number; updates?: PreparedStructureAnalysis[]; error?: string }>) => {
          const request = analysisRequestsRef.current.get(event.data.id);
          analysisRequestsRef.current.delete(event.data.id);
          if (event.data.error) request?.reject(new Error(event.data.error));
          else {
            const updates = event.data.updates ?? [];
            for (const prepared of updates) preparedAnalysesRef.current.set(prepared.key, prepared);
            request?.resolve(updates);
          }
        };
        worker.onerror = () => {
          for (const request of analysisRequestsRef.current.values()) request.reject(new Error('Background analysis failed'));
          analysisRequestsRef.current.clear();
          worker?.terminate();
          analysisWorkerRef.current = null;
        };
        analysisWorkerRef.current = worker;
      }
      const id = ++analysisRequestIdRef.current;
      await new Promise<PreparedStructureAnalysis[]>((resolve, reject) => {
        analysisRequestsRef.current.set(id, { resolve, reject });
        worker!.postMessage({ id, tasks });
      });
    } catch {
      // Keep the existing synchronous result as a fallback if Worker startup fails.
    }
  }, [granularity, vipSupportGranularities]);

  const loadCandles = useCallback(async (signal?: AbortSignal) => {
    const requestId = ++loadRequestIdRef.current;
    setMtfCandleErrors({});
      const replayTime = replayTimeRef.current;
      const shouldShowLoading = candlesRef.current.length === 0
        || loadedGranularityRef.current !== granularity
        || loadedDataSourceRef.current !== liveChartDataSource
        || loadedMarketSymbolRef.current !== marketSymbol;
      if (shouldShowLoading) setIsLoading(true);
      try {
        const requestCandles = async (requestedGranularity: MarketGranularity) => {
        const query = new URLSearchParams({
          symbol: marketSymbol,
          granularity: requestedGranularity,
          count: ['M1', 'M5', 'M15', 'M30'].includes(requestedGranularity) ? '5000' : '1500',
        });
        if (replayTime !== null) query.set('endTime', String(replayTime));
        const useMt5BrokerFeed = replayTime === null && liveChartDataSource === 'MT5'
          && marketConfig.mt5AutomationEnabled
          && MT5_CHART_GRANULARITIES.includes(requestedGranularity as OandaGranularity);
        let lastError = `Market feed returned no ${GRANULARITY_LABELS[requestedGranularity]} candles.`;
        for (let attempt = 0; attempt < 2; attempt += 1) {
          const requestUrl = useMt5BrokerFeed
            ? `/api/mt5/market-data?timeframe=${requestedGranularity}`
            : `/api/tradingview/market-data?${query}`;
          const response = await terminalFetch(requestUrl, {
            signal,
            cache: 'no-store',
          });
           const payload = await response.json() as MarketDataResponse;
           if (!response.ok || !payload.ok || !Array.isArray(payload.candles)) {
             throw new Error(payload.error || `Market data request failed with HTTP ${response.status}`);
           }
          if (!useMt5BrokerFeed && payload.symbol !== marketSymbol) {
            throw new Error(`Market feed returned ${payload.symbol ?? 'unknown'} data while loading ${marketSymbol}.`);
          }
           if (payload.candles.length > 0) return payload;
          lastError = `Market feed returned no ${GRANULARITY_LABELS[requestedGranularity]} candles.`;
        }
        throw new Error(lastError);
      };
      // Prioritize the selected chart. Opening seven unofficial TradingView
      // sockets at once made the main timeframe wait behind slower auxiliary
      // requests even though those are only needed for VIP/trend context.
      const payload = await requestCandles(granularity);
      if (requestId !== loadRequestIdRef.current || signal?.aborted) return;
      if (payload.candles.length === 0) throw new Error(`The market feed returned no ${marketSymbol} candles.`);
      const nextReplayIndex = replayTime === null
        ? null
        : findReplayIndexAtOrBefore(payload.candles, replayTime);
      if (replayTime !== null && nextReplayIndex === null) {
        throw new Error(`The selected replay date is not available on ${GRANULARITY_LABELS[granularity]}.`);
      }
      await prepareChartAnalysis(payload.candles, vipCandlesRef.current, nextReplayIndex);
      if (requestId !== loadRequestIdRef.current || signal?.aborted) return;
      loadedGranularityRef.current = granularity;
      loadedDataSourceRef.current = liveChartDataSource;
      loadedMarketSymbolRef.current = marketSymbol;
      setCandleSnapshot(current => current
        && current.granularity === granularity && current.symbol === marketSymbol
        && current.dataSource === liveChartDataSource && candleSnapshotsMatch(current.candles, payload.candles)
        ? current : { granularity, symbol: marketSymbol, dataSource: liveChartDataSource, candles: payload.candles });
      if (nextReplayIndex !== null) setReplayIndex(nextReplayIndex);
      setSource(payload.source || `MetaTrader 5 · broker ${marketSymbol}`);
      setLastUpdated(payload.fetchedAt || new Date().toISOString());
      setError(null);
      setIsLoading(false);

      // Keep the last valid auxiliary candles visible while their replacements
      // load. Clearing them here made confirmed engulfing signals and their
      // trade rows disappear briefly on every 15-second refresh.
      // Load mapped LTF feeds and the direct chart's engulfing fallback first,
      // then publish them before unrelated trend/support timeframes.
      const priorityGranularities = auxiliaryGranularities.filter((value) => (
        mtfLowerGranularities.includes(value as MtfGranularity)
        || (DIRECT_ENGULFING_FALLBACKS[granularity] ?? []).includes(value as OandaGranularity)
      ));
      const remainingGranularities = auxiliaryGranularities.filter((value) => (
        !priorityGranularities.includes(value)
      ));
      const loadAuxiliaryBatch = async (batch: MarketGranularity[]) => {
        if (batch.length === 0) return true;
        const batchPayloads = await Promise.allSettled(batch.map(requestCandles));
        if (requestId !== loadRequestIdRef.current || signal?.aborted) return false;
        setMtfCandleErrors(current => {
          const next = { ...current };
          batch.forEach((timeframe, index) => {
            const result = batchPayloads[index];
            if (result.status === 'fulfilled') delete next[timeframe];
            else next[timeframe] = result.reason instanceof Error ? result.reason.message : 'Unable to load candles.';
          });
          return next;
        });
        const loadedEntries = batch.flatMap((supportGranularity, index) => {
          const result = batchPayloads[index];
          return result.status === 'fulfilled'
            ? [[supportGranularity, result.value.candles] as const]
            : [];
        });
        if (loadedEntries.length === 0) return true;
          const current = vipCandlesRef.current;
          let changed = false;
          const next = { ...current };
          for (const [supportGranularity, nextCandles] of loadedEntries) {
            if (candleSnapshotsMatch(current[supportGranularity] ?? [], nextCandles)) continue;
            next[supportGranularity] = nextCandles;
            changed = true;
          }
          if (changed) {
            await prepareChartAnalysis(payload.candles, next, nextReplayIndex);
            if (requestId !== loadRequestIdRef.current || signal?.aborted) return false;
            vipCandlesRef.current = next;
            setVipCandles(next);
          }
        return true;
      };
      if (!await loadAuxiliaryBatch(priorityGranularities)) return;
      await loadAuxiliaryBatch(remainingGranularities);
    } catch (loadError) {
      if ((loadError as Error).name !== 'AbortError') {
        setError(loadError instanceof Error ? loadError.message : 'Unable to load market candles.');
        if (requestId === loadRequestIdRef.current && replayTime !== null) {
          pendingReplayViewportRef.current = null;
          setGranularity(loadedGranularityRef.current);
        }
      }
    } finally {
      if (shouldShowLoading && !signal?.aborted && requestId === loadRequestIdRef.current) {
        setIsLoading(false);
      }
    }
  }, [auxiliaryGranularities, granularity, liveChartDataSource, marketConfig.mt5AutomationEnabled, marketSymbol, mtfLowerGranularities, prepareChartAnalysis]);

  useEffect(() => {
    const controller = new AbortController();
    hasFittedRef.current = false;
    let timer: number | undefined;
    // Schedule after completion so slow feeds/analysis cannot build a backlog
    // of fetches, cloned candle snapshots, and worker messages.
    const refresh = async () => {
      try {
        if (!controller.signal.aborted) await loadCandles(controller.signal);
      } finally {
        if (!controller.signal.aborted) timer = window.setTimeout(() => {
          if (replayTimeRef.current === null) void refresh();
        }, 15_000);
      }
    };
    void refresh();
    return () => {
      controller.abort();
      loadRequestIdRef.current += 1;
      window.clearTimeout(timer);
    };
  }, [loadCandles, refreshKey]);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const chart = createChart(host, {
      width: host.clientWidth,
      height: host.clientHeight,
      layout: {
        background: { type: ColorType.Solid, color: '#ffffff' },
        textColor: '#475569',
        fontFamily: 'Inter, ui-sans-serif, system-ui, sans-serif',
        fontSize: 12,
      },
      grid: {
        vertLines: { color: '#f1f5f9' },
        horzLines: { color: '#eef2f7' },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: '#94a3b8',
          width: 1,
          style: LineStyle.Dashed,
          labelVisible: true,
          labelBackgroundColor: '#111111',
        },
        horzLine: { color: '#64748b', width: 1, style: LineStyle.Dashed, labelBackgroundColor: '#334155' },
      },
      rightPriceScale: {
        borderColor: '#e2e8f0',
        scaleMargins: { top: 0.08, bottom: 0.2 },
      },
      timeScale: {
        borderColor: '#e2e8f0',
        timeVisible: true,
        secondsVisible: false,
        tickMarkFormatter: (time, tickMarkType) => formatChartTick(time, tickMarkType, 'Asia/Kathmandu'),
        rightOffset: 8,
        barSpacing: PRESENT_VIEW_BAR_SPACING,
        minBarSpacing: 1.5,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
      localization: {
        timeFormatter: (time) => formatChartTime(time, 'Asia/Kathmandu'),
      },
    });
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#089981',
      downColor: '#f23645',
      borderUpColor: '#089981',
      borderDownColor: '#f23645',
      wickUpColor: '#089981',
      wickDownColor: '#f23645',
      priceFormat: { type: 'price', precision: 3, minMove: 0.001 },
      lastValueVisible: true,
      priceLineVisible: true,
      priceLineColor: '#64748b',
      priceLineStyle: LineStyle.Dotted,
    });
    const seriesMarkers = createSeriesMarkers(candleSeries, []);
    const volumeSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
      lastValueVisible: false,
      priceLineVisible: false,
    });
    chart.priceScale('volume').applyOptions({ scaleMargins: { top: 0.84, bottom: 0 } });

    chart.subscribeCrosshairMove((parameter: any) => {
      const point = parameter.seriesData?.get(candleSeries);
      if (!point || typeof point.open !== 'number') {
        updateHeaderCandleRef.current();
        setHoveredEntry(null);
        return;
      }
      const timestamp = typeof parameter.time === 'number' ? parameter.time : 0;
      updateHeaderCandleRef.current(timestamp);
      const cursor = parameter.point;
      const entry = cursor && entryHoversRef.current.find((candidate) => {
        if (candidate.candleTime !== timestamp) return false;
        const wickY = candleSeries.priceToCoordinate(candidate.trade.signal.direction === 'bullish'
          ? candidate.low : candidate.high);
        if (wickY === null) return false;
        return candidate.trade.signal.direction === 'bullish'
          ? cursor.y >= wickY - 5 && cursor.y <= wickY + 62
          : cursor.y <= wickY + 5 && cursor.y >= wickY - 62;
      });
      if (!entry) {
        setHoveredEntry(null);
        return;
      }
      setHoveredEntry((current) => current?.entry.id === entry.id
        && Math.abs(current.x - cursor.x) < 3 && Math.abs(current.y - cursor.y) < 3
        ? current : { entry, x: cursor.x, y: cursor.y });
    });

    const observer = new ResizeObserver(([entry]) => {
      chart.applyOptions({ width: entry.contentRect.width, height: entry.contentRect.height });
      scheduleOverlayRedraw();
      scheduleDrawingRedraw();
      window.requestAnimationFrame(() => syncReplaySelectionLineRef.current());
    });
    const handleVisibleRangeChange = () => {
      scheduleScrollOverlayRedraw();
      scheduleDrawingRedraw();
      syncReplaySelectionLineRef.current();
    };
    chart.timeScale().subscribeVisibleLogicalRangeChange(handleVisibleRangeChange);
    observer.observe(host);
    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;
    volumeSeriesRef.current = volumeSeries;
    markersRef.current = seriesMarkers;
    return () => {
      observer.disconnect();
      chart.timeScale().unsubscribeVisibleLogicalRangeChange(handleVisibleRangeChange);
      if (overlayRedrawFrameRef.current !== null) {
        window.cancelAnimationFrame(overlayRedrawFrameRef.current);
        overlayRedrawFrameRef.current = null;
      }
      if (overlayScrollTimerRef.current !== null) {
        window.clearTimeout(overlayScrollTimerRef.current);
        overlayScrollTimerRef.current = null;
      }
      if (drawingRedrawFrameRef.current !== null) {
        window.cancelAnimationFrame(drawingRedrawFrameRef.current);
        drawingRedrawFrameRef.current = null;
      }
      if (drawingRedrawTimerRef.current !== null) {
        window.clearTimeout(drawingRedrawTimerRef.current);
        drawingRedrawTimerRef.current = null;
      }
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
      volumeSeriesRef.current = null;
      markersRef.current = null;
    };
  }, [scheduleDrawingRedraw, scheduleOverlayRedraw, scheduleScrollOverlayRedraw]);

  useEffect(() => {
    candleSeriesRef.current?.applyOptions({
      priceFormat: {
        type: 'price',
        precision: marketConfig.pricePrecision,
        minMove: marketConfig.minMove,
      },
    });
  }, [marketConfig.minMove, marketConfig.pricePrecision]);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    chart.applyOptions({
      localization: {
        timeFormatter: (time: Time) => formatChartTime(time, chartTimeZone),
      },
      timeScale: {
        tickMarkFormatter: (time: Time, tickMarkType: TickMarkType) => (
          formatChartTick(time, tickMarkType, chartTimeZone)
        ),
      },
    });
  }, [chartTimeZone]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(syncReplaySelectionLine);
    return () => window.cancelAnimationFrame(frame);
  }, [candles, replaySelecting, replaySelectionIndex, syncReplaySelectionLine]);

  useEffect(() => {
    const chart = chartRef.current;
    const candleSeries = candleSeriesRef.current;
    const volumeSeries = volumeSeriesRef.current;
    if (!chart || !candleSeries || !volumeSeries) return;
    candleSeries.setData(displayCandles.map((candle) => ({
      time: candle.time as UTCTimestamp,
      open: candle.open,
      high: candle.high,
      low: candle.low,
      close: candle.close,
    })));
    volumeSeries.setData(displayCandles.map((candle) => ({
      time: candle.time as UTCTimestamp,
      value: candle.volume,
      color: candle.close >= candle.open ? 'rgba(8, 153, 129, 0.3)' : 'rgba(242, 54, 69, 0.3)',
    })));
    if (displayCandles.length === 0) {
      scheduleOverlayRedraw();
      scheduleDrawingRedraw();
      return;
    }
    if (pendingMarketSymbolFitRef.current) {
      // A price scale can remain fixed to the previous instrument (for example,
      // USDJPY near 158 while XAUUSD is near 4,165). Re-enable autoscaling only
      // for the first populated render after a symbol switch.
      chart.priceScale('right').applyOptions({ autoScale: true });
    }
    const pendingViewport = pendingReplayViewportRef.current;
    if (replayIndex !== null && pendingViewport && loadedGranularityRef.current === granularity) {
      const replayLogicalIndex = displayCandles.length - 1;
      chart.timeScale().setVisibleLogicalRange({
        from: replayLogicalIndex + pendingViewport.fromOffset,
        to: replayLogicalIndex + pendingViewport.toOffset,
      });
      pendingReplayViewportRef.current = null;
      hasFittedRef.current = true;
    } else if (!hasFittedRef.current) {
      restorePresentChartView();
      hasFittedRef.current = true;
    }
    pendingMarketSymbolFitRef.current = false;
    scheduleOverlayRedraw();
    scheduleDrawingRedraw();
  }, [displayCandles, granularity, replayIndex, restorePresentChartView, scheduleDrawingRedraw, scheduleOverlayRedraw]);

  // Marker/filter changes do not replace the entire candle and volume history.
  useEffect(() => {
    markersRef.current?.setMarkers([
      ...(showStructure ? structure.markers : []),
      ...(showInternal ? structure.internalMarkers : []),
      ...entryMarkers,
    ].sort((a: any, b: any) => Number(a.time) - Number(b.time)));
  }, [entryMarkers, showEntryArrows, showInternal, showStructure, structure.internalMarkers, structure.markers]);

  useEffect(() => {
    const label = livePriceLabelRef.current;
    const priceValue = livePriceValueRef.current;
    const countdown = liveCountdownRef.current;
    if (!label || !priceValue || !countdown) return;

    const updateLiveCountdown = () => {
      const series = candleSeriesRef.current;
      const host = hostRef.current;
      const liveCandle = candles[candles.length - 1];
      if (replayIndex !== null || !series || !host || !liveCandle) {
        label.style.display = 'none';
        return;
      }

      const coordinate = series.priceToCoordinate(liveCandle.close);
      if (coordinate === null) {
        label.style.display = 'none';
        return;
      }

      const closesAt = liveCandle.time + TIMEFRAME_SECONDS[granularity];
      const remaining = closesAt - Date.now() / 1000;
      const rising = liveCandle.close >= liveCandle.open;
      label.style.display = 'flex';
      label.style.top = `${Math.max(22, Math.min(host.clientHeight - 22, coordinate))}px`;
      label.style.backgroundColor = rising ? '#089981' : '#f23645';
      priceValue.textContent = formatPrice(liveCandle.close);
      countdown.textContent = formatCandleCountdown(remaining);
    };

    updateLiveCountdown();
    const timer = window.setInterval(updateLiveCountdown, 1000);
    return () => window.clearInterval(timer);
  }, [candles, granularity, replayIndex]);

  const toggleFullscreen = async () => {
    const element = hostRef.current?.parentElement?.parentElement;
    if (!element) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await element.requestFullscreen();
  };

  const openReplaySelector = () => {
    if (candles.length < 2) return;
    setReplayPlaying(false);
    setReplaySelectionIndex(replayIndex ?? Math.max(1, candles.length - 10));
    setReplaySelecting(true);
  };

  const beginReplay = () => {
    if (candles.length < 2) return;
    const nextReplayIndex = replaySelectionIndex ?? Math.max(1, candles.length - 10);
    setReplayPlaying(false);
    replayTimeRef.current = candles[nextReplayIndex]?.time ?? null;
    setReplayIndex(nextReplayIndex);
    setReplaySelecting(false);
    hasFittedRef.current = false;
    // The selected HTF candle can be much older than the rolling 1,500-bar
    // LTF window already in memory. Reload at the replay timestamp immediately
    // so mapped 1m/5m CHOCH data is available without a timeframe switch.
    setRefreshKey((value) => value + 1);
  };

  const exitReplay = () => {
    setReplayPlaying(false);
    replayTimeRef.current = null;
    pendingReplayViewportRef.current = null;
    setReplayIndex(null);
    setReplaySelecting(false);
    setReplaySelectionIndex(null);
    hasFittedRef.current = false;
    setRefreshKey((value) => value + 1);
  };

  const changeTimeframe = (nextGranularity: OandaGranularity) => {
    if (nextGranularity === granularity) return;
    loadRequestIdRef.current += 1;
    setIsLoading(true);
    setHoveredEntry(null);
    if (replayIndex !== null) {
      const replayCandle = candles[Math.min(replayIndex, candles.length - 1)];
      if (replayCandle) replayTimeRef.current = replayCandle.time;
      const visibleRange = chartRef.current?.timeScale().getVisibleLogicalRange();
      const replayLogicalIndex = displayCandles.length - 1;
      if (visibleRange && replayLogicalIndex >= 0) {
        pendingReplayViewportRef.current = {
          fromOffset: visibleRange.from - replayLogicalIndex,
          toOffset: visibleRange.to - replayLogicalIndex,
        };
      }
      setReplayPlaying(false);
    } else {
      setReplaySelecting(false);
      setReplaySelectionIndex(null);
    }
    setGranularity(nextGranularity);
    if (comparisonTimeframe === nextGranularity) {
      setComparisonTimeframe(null);
      setShowLtfChoch(false);
    } else if (showLtfChoch && (!comparisonTimeframe
      || DRAWING_TIMEFRAME_ORDER.indexOf(comparisonTimeframe)
        >= DRAWING_TIMEFRAME_ORDER.indexOf(nextGranularity))) {
      setShowLtfChoch(false);
    }
  };

  const changeLiveChartDataSource = (nextSource: LiveChartDataSource) => {
    if (replayIndex !== null || nextSource === liveChartDataSource
      || (nextSource === 'MT5' && !marketConfig.mt5AutomationEnabled)) return;
    loadRequestIdRef.current += 1;
    setLiveChartDataSource(nextSource);
    setCandleSnapshot(null);
    setVipCandles({});
    setTrackedDirectTradeSetups(new Map<string, TrackedDirectTradeSetup>());
    setSource(nextSource === 'MT5'
      ? 'Waiting for MT5 broker candles'
      : 'Loading TradingView OANDA candles');
    setLastUpdated(null);
    setError(null);
    setIsLoading(true);
    hasFittedRef.current = false;
  };

  const changeMarketSymbol = (nextSymbol: OandaMarketSymbol) => {
    if (nextSymbol === marketSymbol) return;
    // Invalidate every request started for the previous symbol immediately.
    // Waiting for the next render left a short window where an older forex
    // response could repopulate the chart after Gold had been selected.
    loadRequestIdRef.current += 1;
    pendingMarketSymbolFitRef.current = true;
    replayTimeRef.current = null;
    pendingReplayViewportRef.current = null;
    setReplayIndex(null);
    setReplayPlaying(false);
    setReplaySelecting(false);
    setReplaySelectionIndex(null);
    setMarketSymbol(nextSymbol);
    setLiveChartDataSource('OANDA');
    setCandleSnapshot(null);
    setVipCandles({});
    // Entries are already isolated by tradeTrackingScope. Keep Gold's tracked
    // first-entry history intact so visiting a currency pair cannot cause Gold
    // to recalculate a later Internal DB (or any other zone) entry on return.
    setSource(`Loading TradingView OANDA:${nextSymbol} candles`);
    setLastUpdated(null);
    setError(null);
    setIsLoading(true);
    hasFittedRef.current = false;
  };

  const selectReplayBar = (event: React.PointerEvent<HTMLDivElement>) => {
    const chart = chartRef.current;
    const host = hostRef.current;
    if (!chart || !host || candles.length < 2) return;
    const coordinate = event.clientX - host.getBoundingClientRect().left;
    const logicalIndex = chart.timeScale().coordinateToLogical(coordinate);
    if (logicalIndex === null || !Number.isFinite(logicalIndex)) return;
    setReplaySelectionIndex(Math.max(
      1,
      Math.min(candles.length - 1, Math.round(logicalIndex)),
    ));
  };

  const chartDrawingPointFromClient = (clientX: number, clientY: number): ChartDrawingPoint | null => {
    const chart = chartRef.current;
    const series = candleSeriesRef.current;
    const host = hostRef.current;
    if (!chart || !series || !host || displayCandles.length === 0) return null;
    const bounds = host.getBoundingClientRect();
    const logical = chart.timeScale().coordinateToLogical(clientX - bounds.left);
    const price = series.coordinateToPrice(clientY - bounds.top);
    if (logical === null || price === null || !Number.isFinite(logical) || !Number.isFinite(price)) return null;
    const nearestIndex = Math.round(logical);
    let time: number;
    if (nearestIndex >= 0 && nearestIndex < displayCandles.length) {
      time = displayCandles[nearestIndex].time;
    } else if (nearestIndex < 0) {
      time = displayCandles[0].time + nearestIndex * TIMEFRAME_SECONDS[granularity];
    } else {
      const lastIndex = displayCandles.length - 1;
      time = displayCandles[lastIndex].time
        + (nearestIndex - lastIndex) * TIMEFRAME_SECONDS[granularity];
    }
    return { time, price };
  };

  const saveChartDrawing = (
    tool: ChartDrawingTool,
    points: ChartDrawingPoint[],
    text?: string,
  ) => {
    if (points.length === 0) return null;
    const drawingId = `drawing-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    setChartDrawings((current) => [...current, {
      id: drawingId,
      scope: drawingScope,
      tool,
      points,
      text,
      color: '#2563eb',
      visibilityTimeframe: granularity,
      visibility: 'all',
      hidden: false,
    }]);
    setDrawingDraft(null);
    setActiveDrawingTool(null);
    return drawingId;
  };

  const handleDrawingChartClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!activeDrawingTool) return;
    const point = chartDrawingPointFromClient(event.clientX, event.clientY);
    if (!point) return;

    if (activeDrawingTool === 'path') {
      if (!drawingDraft || drawingDraft.tool !== 'path') {
        setDrawingDraft({ tool: 'path', points: [point], hover: point });
        return;
      }
      const nextPoints = [...drawingDraft.points, point].filter((candidate, index, points) => (
        index === 0 || candidate.time !== points[index - 1].time
        || Math.abs(candidate.price - points[index - 1].price) > 0.0001
      ));
      if (event.detail >= 2 && nextPoints.length >= 2) saveChartDrawing('path', nextPoints);
      else setDrawingDraft({ tool: 'path', points: nextPoints, hover: point });
      return;
    }

    if (!drawingDraft || drawingDraft.tool !== activeDrawingTool) {
      setDrawingDraft({ tool: activeDrawingTool, points: [point], hover: point });
      return;
    }
    const secondPoint = activeDrawingTool === 'trend' && event.shiftKey
      ? { ...point, price: drawingDraft.points[0].price }
      : point;
    const drawingId = saveChartDrawing(activeDrawingTool, [drawingDraft.points[0], secondPoint]);
    if (activeDrawingTool === 'note' && drawingId) {
      setSelectedDrawingId(drawingId);
      setDrawingTextEditor({ drawingId, value: '' });
    }
  };

  const finishDrawingPath = () => {
    if (drawingDraft?.tool === 'path' && drawingDraft.points.length >= 2) {
      saveChartDrawing('path', drawingDraft.points);
    } else {
      setDrawingDraft(null);
      setActiveDrawingTool(null);
    }
  };

  const undoLastChartDrawing = () => {
    setChartDrawings((current) => {
      const lastIndex = current.map((drawing) => drawing.scope).lastIndexOf(drawingScope);
      return lastIndex < 0 ? current : current.filter((_, index) => index !== lastIndex);
    });
  };

  const clearCurrentChartDrawings = () => {
    if (!chartDrawings.some((drawing) => drawing.scope === drawingScope)) return;
    if (!window.confirm(`Remove all drawings from the ${liveChartDataSource} charts?`)) return;
    setChartDrawings((current) => current.filter((drawing) => drawing.scope !== drawingScope));
    setDrawingDraft(null);
    setActiveDrawingTool(null);
    setSelectedDrawingId(null);
    setShowDrawingVisibility(false);
  };

  const updateChartDrawing = (drawingId: string, updates: Partial<ChartDrawing>) => {
    setChartDrawings((current) => current.map((drawing) => (
      drawing.id === drawingId ? { ...drawing, ...updates } : drawing
    )));
  };

  const removeChartDrawing = (drawingId: string) => {
    setChartDrawings((current) => current.filter((drawing) => drawing.id !== drawingId));
    setSelectedDrawingId(null);
    setShowDrawingVisibility(false);
    setDrawingDrag(null);
  };

  const chartDrawingIsVisible = (drawing: ChartDrawing) => {
    if (drawing.hidden) return false;
    const mode = drawing.visibility ?? 'all';
    if (mode === 'all') return true;
    const origin = drawing.visibilityTimeframe ?? granularity;
    const originIndex = DRAWING_TIMEFRAME_ORDER.indexOf(origin);
    const currentIndex = DRAWING_TIMEFRAME_ORDER.indexOf(granularity);
    if (mode === 'current-only') return currentIndex === originIndex;
    if (mode === 'current-and-above') return currentIndex >= originIndex;
    return currentIndex <= originIndex;
  };

  const chartDrawingPointToCoordinate = (point: ChartDrawingPoint): { x: number; y: number } | null => {
    const chart = chartRef.current;
    const series = candleSeriesRef.current;
    if (!chart || !series || displayCandles.length === 0) return null;
    let logical: number;
    let low = 0;
    let high = displayCandles.length;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      if (displayCandles[middle].time < point.time) low = middle + 1;
      else high = middle;
    }
    if (low < displayCandles.length && displayCandles[low].time === point.time) {
      logical = low;
    } else if (low === 0) {
      logical = (point.time - displayCandles[0].time) / TIMEFRAME_SECONDS[granularity];
    } else if (low < displayCandles.length) {
      const previous = displayCandles[low - 1];
      const next = displayCandles[low];
      const interval = Math.max(1, next.time - previous.time);
      logical = low - 1 + (point.time - previous.time) / interval;
    } else {
      const lastIndex = displayCandles.length - 1;
      logical = lastIndex
        + (point.time - displayCandles[lastIndex].time) / TIMEFRAME_SECONDS[granularity];
    }
    const x = chart.timeScale().logicalToCoordinate(logical);
    const y = series.priceToCoordinate(point.price);
    return x === null || y === null ? null : { x, y };
  };

  // Reading this state ensures SVG drawings are recalculated after chart pan,
  // zoom, resize, or candle replacement even though their data has not changed.
  void drawingRenderVersion;
  const currentSourceChartDrawings = chartDrawings.filter((drawing) => drawing.scope === drawingScope);
  const visibleChartDrawings = currentSourceChartDrawings.filter(chartDrawingIsVisible);
  const hiddenChartDrawings = currentSourceChartDrawings.filter((drawing) => drawing.hidden);
  const selectedChartDrawing = currentSourceChartDrawings.find((drawing) => (
    drawing.id === selectedDrawingId
  ));
  const previewChartDrawing = drawingDraft && drawingDraft.points.length > 0
    ? {
      id: 'drawing-preview',
      scope: drawingScope,
      tool: drawingDraft.tool,
      points: drawingDraft.hover
        ? [...drawingDraft.points, drawingDraft.hover]
        : drawingDraft.points,
    } satisfies ChartDrawing
    : null;
  const textEditorDrawing = drawingTextEditor
    ? currentSourceChartDrawings.find((drawing) => drawing.id === drawingTextEditor.drawingId)
    : undefined;
  const textEditorCoordinates = textEditorDrawing?.points.length
    ? textEditorDrawing.points.map(chartDrawingPointToCoordinate)
    : [];
  const drawingTextEditorPosition = textEditorCoordinates.length >= 1
    && textEditorCoordinates[0]
    ? (() => {
      const firstCoordinate = textEditorCoordinates[0];
      const lastCoordinate = textEditorCoordinates[textEditorCoordinates.length - 1] ?? firstCoordinate;
      let angle = textEditorDrawing?.tool === 'trend'
        ? Math.atan2(lastCoordinate.y - firstCoordinate.y, lastCoordinate.x - firstCoordinate.x) * 180 / Math.PI
        : 0;
      if (angle > 90 || angle < -90) angle += 180;
      return {
        left: (firstCoordinate.x + lastCoordinate.x) / 2,
        top: (firstCoordinate.y + lastCoordinate.y) / 2,
        angle,
      };
    })()
    : null;

  const startChartDrawingDrag = (
    event: React.MouseEvent<SVGElement>,
    drawing: ChartDrawing,
    pointIndex?: number,
    rectangleCorner?: ChartDrawingDrag['rectangleCorner'],
  ) => {
    if (previewChartDrawing) return;
    event.preventDefault();
    event.stopPropagation();
    const start = chartDrawingPointFromClient(event.clientX, event.clientY);
    if (!start) return;
    setSelectedDrawingId(drawing.id);
    setShowDrawingVisibility(false);
    setDrawingDrag({
      drawingId: drawing.id,
      pointIndex,
      rectangleCorner,
      start,
      originalPoints: drawing.points.map((point) => ({ ...point })),
    });
  };

  const moveSelectedChartDrawing = (clientX: number, clientY: number, shiftKey = false) => {
    if (!drawingDrag) return;
    const currentPoint = chartDrawingPointFromClient(clientX, clientY);
    if (!currentPoint) return;
    let points: ChartDrawingPoint[];
    if (drawingDrag.rectangleCorner !== undefined) {
      const { timePointIndex, pricePointIndex } = drawingDrag.rectangleCorner;
      points = drawingDrag.originalPoints.map((point, index) => ({
        time: index === timePointIndex ? currentPoint.time : point.time,
        price: index === pricePointIndex ? currentPoint.price : point.price,
      }));
    } else if (drawingDrag.pointIndex !== undefined) {
      const draggedDrawing = chartDrawings.find((drawing) => drawing.id === drawingDrag.drawingId);
      const oppositePoint = drawingDrag.originalPoints[drawingDrag.pointIndex === 0 ? 1 : 0];
      const draggedPoint = shiftKey && draggedDrawing?.tool === 'trend' && oppositePoint
        ? { ...currentPoint, price: oppositePoint.price }
        : currentPoint;
      points = drawingDrag.originalPoints.map((point, index) => (
        index === drawingDrag.pointIndex ? draggedPoint : point
      ));
    } else {
      const timeDelta = currentPoint.time - drawingDrag.start.time;
      const priceDelta = currentPoint.price - drawingDrag.start.price;
      points = drawingDrag.originalPoints.map((point) => ({
        time: point.time + timeDelta,
        price: point.price + priceDelta,
      }));
    }
    updateChartDrawing(drawingDrag.drawingId, { points });
  };

  useEffect(() => {
    if (!drawingDrag) return undefined;
    const moveDrawing = (event: MouseEvent) => (
      moveSelectedChartDrawing(event.clientX, event.clientY, event.shiftKey)
    );
    const finishMoving = () => setDrawingDrag(null);
    window.addEventListener('mousemove', moveDrawing);
    window.addEventListener('mouseup', finishMoving);
    return () => {
      window.removeEventListener('mousemove', moveDrawing);
      window.removeEventListener('mouseup', finishMoving);
    };
  }, [drawingDrag, chartDrawings]);

  const editChartDrawingText = (drawing: ChartDrawing) => {
    if (drawing.tool !== 'rectangle' && drawing.tool !== 'trend' && drawing.tool !== 'note') return;
    setSelectedDrawingId(drawing.id);
    setDrawingTextEditor({ drawingId: drawing.id, value: drawing.text ?? '' });
  };

  const saveChartDrawingText = () => {
    if (!drawingTextEditor) return;
    updateChartDrawing(drawingTextEditor.drawingId, {
      text: drawingTextEditor.value.trim().slice(0, 80),
    });
    setDrawingTextEditor(null);
  };

  useEffect(() => {
    const deleteSelectedDrawing = (event: KeyboardEvent) => {
      if (!selectedDrawingId || (event.key !== 'Delete' && event.key !== 'Backspace')) return;
      const target = event.target as HTMLElement | null;
      if (target?.matches('input, textarea, select, [contenteditable="true"]')) return;
      event.preventDefault();
      removeChartDrawing(selectedDrawingId);
    };
    window.addEventListener('keydown', deleteSelectedDrawing);
    return () => window.removeEventListener('keydown', deleteSelectedDrawing);
  }, [selectedDrawingId]);

  const renderChartDrawing = (drawing: ChartDrawing, preview = false) => {
    const points = drawing.points
      .map(chartDrawingPointToCoordinate)
      .filter((point): point is { x: number; y: number } => point !== null);
    if (points.length === 0) return null;
    const selected = !preview && drawing.id === selectedDrawingId;
    const drawingColor = drawing.color ?? '#2563eb';
    const stroke = preview ? '#7c3aed' : drawingColor;
    const opacity = preview ? 0.65 : 0.9;
    const wrapDrawing = (content: React.ReactNode) => (
      <g
        key={drawing.id}
        opacity={opacity}
        pointerEvents={preview ? 'none' : 'visiblePainted'}
        onMouseDown={preview ? undefined : (event) => startChartDrawingDrag(event, drawing)}
        onDoubleClick={preview ? undefined : (event) => {
          event.preventDefault();
          event.stopPropagation();
          editChartDrawingText(drawing);
        }}
        style={preview ? undefined : { cursor: 'move' }}
      >
        {content}
        {selected && (drawing.tool === 'rectangle' && drawing.points.length >= 2
          ? ([
            { timePointIndex: 0, pricePointIndex: 0 },
            { timePointIndex: 0, pricePointIndex: 1 },
            { timePointIndex: 1, pricePointIndex: 0 },
            { timePointIndex: 1, pricePointIndex: 1 },
          ] as const).map((corner) => {
            const point = {
              time: drawing.points[corner.timePointIndex].time,
              price: drawing.points[corner.pricePointIndex].price,
            };
            const coordinate = chartDrawingPointToCoordinate(point);
            if (!coordinate) return null;
            return (
              <circle
                key={`${drawing.id}-corner-${corner.timePointIndex}-${corner.pricePointIndex}`}
                cx={coordinate.x}
                cy={coordinate.y}
                r="4"
                fill="white"
                stroke="#7c3aed"
                strokeWidth="1.5"
                pointerEvents="all"
                onMouseDown={(event) => startChartDrawingDrag(event, drawing, undefined, corner)}
                style={{ cursor: 'nwse-resize' }}
              />
            );
          })
          : drawing.points.map((point, index) => {
          const coordinate = chartDrawingPointToCoordinate(point);
          if (!coordinate) return null;
          return (
            <circle
              key={`${drawing.id}-handle-${index}`}
              cx={coordinate.x}
              cy={coordinate.y}
              r="4"
              fill="white"
              stroke="#7c3aed"
              strokeWidth="1.5"
              pointerEvents="all"
              onMouseDown={(event) => startChartDrawingDrag(event, drawing, index)}
              style={{ cursor: 'grab' }}
            />
          );
        }))}
      </g>
    );

    if (drawing.tool === 'note') {
      const anchor = points[0];
      const labelPoint = points.length > 1 ? points[points.length - 1] : { x: anchor.x + 40, y: anchor.y - 30 };
      const label = drawing.text || 'Add text';
      const width = Math.min(220, Math.max(64, label.length * 5.4 + 18));
      return wrapDrawing(
        <>
          <line x1={anchor.x} y1={anchor.y} x2={labelPoint.x} y2={labelPoint.y} stroke={stroke} strokeWidth="1" />
          <circle cx={anchor.x} cy={anchor.y} r="3" fill="white" stroke={stroke} strokeWidth="1.2" />
          <rect x={labelPoint.x - width / 2} y={labelPoint.y - 10} width={width} height="20" rx="3" fill="white" stroke={stroke} />
          {drawingTextEditor?.drawingId !== drawing.id && (
            <text x={labelPoint.x} y={labelPoint.y + 3} textAnchor="middle" fill={stroke} fontSize="9" fontWeight="700">
              {label.length > 38 ? `${label.slice(0, 38)}…` : label}
            </text>
          )}
        </>
      );
    }

    if (drawing.tool === 'path') {
      return wrapDrawing(
        <>
          <polyline
            points={points.map((point) => `${point.x},${point.y}`).join(' ')}
            fill="none"
            stroke="transparent"
            strokeWidth="10"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          <polyline
            points={points.map((point) => `${point.x},${point.y}`).join(' ')}
            fill="none"
            stroke={stroke}
            strokeWidth="1.5"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
        </>
      );
    }

    if (points.length < 2) {
      return wrapDrawing(<circle cx={points[0].x} cy={points[0].y} r="3" fill={stroke} />);
    }
    const [first, second] = points;

    if (drawing.tool === 'rectangle') {
      const left = Math.min(first.x, second.x);
      const top = Math.min(first.y, second.y);
      const width = Math.abs(second.x - first.x);
      return wrapDrawing(
        <>
          <rect
            x={left}
            y={top}
            width={width}
            height={Math.abs(second.y - first.y)}
            fill={`${drawingColor}1a`}
            stroke={stroke}
            strokeWidth="1"
          />
          {drawing.text && drawingTextEditor?.drawingId !== drawing.id && (
            <text
              x={left + width / 2}
              y={top + 14}
              textAnchor="middle"
              fill={drawingColor}
              fontSize="9"
              fontWeight="700"
              pointerEvents="none"
            >
              {drawing.text}
            </text>
          )}
        </>
      );
    }

    if (drawing.tool === 'fib') {
      const sourcePrice = drawing.points[0].price;
      const zeroPrice = drawing.points[drawing.points.length - 1].price;
      const left = Math.min(first.x, second.x);
      const right = Math.max(first.x, second.x);
      return wrapDrawing(
        <>
          <rect
            x={left}
            y={Math.min(first.y, second.y)}
            width={Math.max(8, right - left)}
            height={Math.max(8, Math.abs(second.y - first.y))}
            fill="transparent"
          />
          <line
            x1={first.x}
            y1={first.y}
            x2={second.x}
            y2={second.y}
            stroke={selected ? stroke : '#f43f5e'}
            strokeWidth="1.2"
            strokeOpacity="0.82"
            strokeDasharray="7 6"
          />
          {INDICATOR_FIB_LEVELS.map((level) => {
            const price = indicatorFibPrice(zeroPrice, sourcePrice, level.ratio);
            const coordinate = candleSeriesRef.current?.priceToCoordinate(price);
            if (coordinate === null || coordinate === undefined) return null;
            return (
              <g key={level.ratio}>
                <line
                  x1={left}
                  y1={coordinate}
                  x2={right}
                  y2={coordinate}
                  stroke={selected ? stroke : '#e11d48'}
                  strokeWidth={level.ratio === 0 || level.ratio === 1 ? '1.2' : '1'}
                  strokeOpacity="0.82"
                />
                <text
                  x={Math.max(18, left - 7)}
                  y={coordinate + 3}
                  textAnchor="end"
                  fill={selected ? stroke : '#e11d48'}
                  fillOpacity="0.9"
                  fontSize="9"
                  fontWeight="700"
                >
                  {level.label}
                </text>
              </g>
            );
          })}
        </>
      );
    }

    if (drawing.tool === 'measure') {
      const priceChange = drawing.points[1].price - drawing.points[0].price;
      const percentChange = drawing.points[0].price === 0 ? 0 : priceChange / drawing.points[0].price * 100;
      const elapsedSeconds = Math.abs(drawing.points[1].time - drawing.points[0].time);
      const elapsedDays = Math.floor(elapsedSeconds / 86_400);
      const elapsedHours = Math.floor(elapsedSeconds % 86_400 / 3_600);
      const elapsedMinutes = Math.floor(elapsedSeconds % 3_600 / 60);
      const elapsedParts = [
        elapsedDays ? `${elapsedDays}d` : '',
        elapsedHours ? `${elapsedHours}h` : '',
        elapsedMinutes || (!elapsedDays && !elapsedHours) ? `${elapsedMinutes}m` : '',
      ].filter(Boolean).join(' ');
      const firstTime = Math.min(drawing.points[0].time, drawing.points[1].time);
      const lastTime = Math.max(drawing.points[0].time, drawing.points[1].time);
      const measuredCandles = displayCandles.filter((candle) => (
        candle.time > firstTime && candle.time <= lastTime
      ));
      const bars = measuredCandles.length;
      const totalVolume = measuredCandles.reduce((sum, candle) => sum + candle.volume, 0);
      const volumeLabel = totalVolume >= 1_000_000
        ? `${(totalVolume / 1_000_000).toFixed(2)} M`
        : totalVolume >= 1_000
          ? `${(totalVolume / 1_000).toFixed(2)} K`
          : totalVolume.toLocaleString(undefined, { maximumFractionDigits: 0 });
      const left = Math.min(first.x, second.x);
      const top = Math.min(first.y, second.y);
      const width = Math.abs(second.x - first.x);
      const height = Math.abs(second.y - first.y);
      const centerX = left + width / 2;
      const measureColor = priceChange >= 0 ? '#22ab94' : '#f7525f';
      const chartHeight = chartPaneRef.current?.clientHeight ?? 0;
      const cardWidth = 180;
      const cardHeight = 58;
      const cardTop = top + height + cardHeight + 12 < chartHeight
        ? top + height + 12
        : Math.max(4, top - cardHeight - 12);
      const signedPrice = `${priceChange >= 0 ? '+' : ''}${formatPrice(priceChange)}`;
      const signedPercent = `${percentChange >= 0 ? '+' : ''}${percentChange.toFixed(2)}%`;
      const pips = priceChange / marketConfig.pipSize;
      const signedPips = `${pips >= 0 ? '+' : ''}${pips.toFixed(1)}`;
      return wrapDrawing(
        <>
          <defs>
            <marker
              id={`measure-arrow-${drawing.id}`}
              markerWidth="7"
              markerHeight="7"
              refX="6"
              refY="3.5"
              orient="auto"
              markerUnits="strokeWidth"
            >
              <path d="M0,0 L7,3.5 L0,7 Z" fill={measureColor} />
            </marker>
          </defs>
          <rect
            x={left}
            y={top}
            width={width}
            height={height}
            fill={measureColor}
            fillOpacity="0.16"
            stroke={measureColor}
            strokeOpacity="0.65"
            strokeWidth="1"
          />
          {width > 2 && (
            <line
              x1={first.x}
              y1={top + height / 2}
              x2={second.x}
              y2={top + height / 2}
              stroke={measureColor}
              strokeWidth="1"
              strokeOpacity="0.8"
              markerEnd={`url(#measure-arrow-${drawing.id})`}
            />
          )}
          {height > 2 && (
            <line
              x1={centerX}
              y1={first.y}
              x2={centerX}
              y2={second.y}
              stroke={measureColor}
              strokeWidth="1"
              strokeOpacity="0.8"
              markerEnd={`url(#measure-arrow-${drawing.id})`}
            />
          )}
          <rect
            x={centerX - cardWidth / 2}
            y={cardTop}
            width={cardWidth}
            height={cardHeight}
            rx="4"
            fill={measureColor}
          />
          <text x={centerX} y={cardTop + 16} textAnchor="middle" fill="white" fontSize="9" fontWeight="700">
            {signedPrice} ({signedPercent}) {signedPips} pips
          </text>
          <text x={centerX} y={cardTop + 33} textAnchor="middle" fill="white" fontSize="9" fontWeight="700">
            {bars > 0 ? `${bars} bars, ` : ''}{elapsedParts}
          </text>
          <text x={centerX} y={cardTop + 50} textAnchor="middle" fill="white" fontSize="9" fontWeight="700">
            Vol {volumeLabel}
          </text>
        </>
      );
    }

    return wrapDrawing(
      <>
        <line
          x1={first.x}
          y1={first.y}
          x2={second.x}
          y2={second.y}
          stroke="transparent"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <line
          x1={first.x}
          y1={first.y}
          x2={second.x}
          y2={second.y}
          stroke={stroke}
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        {drawing.text && drawingTextEditor?.drawingId !== drawing.id && (() => {
          const centerX = (first.x + second.x) / 2;
          const centerY = (first.y + second.y) / 2;
          let angle = Math.atan2(second.y - first.y, second.x - first.x) * 180 / Math.PI;
          if (angle > 90 || angle < -90) angle += 180;
          return (
            <text
              x={centerX}
              y={centerY - 3}
              textAnchor="middle"
              fill={drawingColor}
              stroke="white"
              strokeWidth="2.5"
              paintOrder="stroke"
              transform={`rotate(${angle} ${centerX} ${centerY})`}
              fontSize="9"
              fontWeight="700"
              pointerEvents="none"
            >
              {drawing.text}
            </text>
          );
        })()}
      </>
    );
  };

  const hasAnyFibMarking = (showAlignedH1Fib && displayZones.some((zone) => (
    zone.h1SwingFibStatus === 'aligned'
  ))) || Object.values(fibVisibility).some(Boolean)
    || Object.values(fibPreviousVisibility).some(Boolean)
    || chochFibVisibility.some(Boolean);

  const renderFibOptionButton = (option: { key: FibVisibilityKey; label: string }) => {
    const isSingleMarking = isSingleFibMarkingKey(option.key);
    const isChochMarking = option.key === 'choch';
    const isUnavailable = (option.key === 'swing' && granularity === 'D')
      || (option.key === 'h1Swing' && !['M5', 'M15', 'M30', 'H1'].includes(granularity))
      || (option.key === 'day' && !['M1', 'M5', 'M15', 'M30'].includes(granularity));
    const latestOn = fibVisibility[option.key];
    const previousOn = fibPreviousVisibility[option.key];
    const autoAligned = option.key === 'h1Swing' && showFib && showAlignedH1Fib
      && displayZones.some((zone) => zone.h1SwingFibStatus === 'aligned');
    const chochVisibleCount = chochFibVisibility.filter(Boolean).length;
    const status = isUnavailable
      ? option.key === 'day' ? '≤30m' : option.key === 'h1Swing' ? '≤1H' : '≤4H'
      : isChochMarking
        ? `${chochVisibleCount}/4`
      : isSingleMarking
      ? latestOn ? 'ON' : 'OFF'
      : latestOn && previousOn
        ? 'BOTH'
        : latestOn ? 'LATEST' : previousOn ? 'PREV' : autoAligned ? 'ON' : 'OFF';
    const active = !isUnavailable && (isChochMarking
      ? chochVisibleCount > 0
      : latestOn || (!isSingleMarking && previousOn) || autoAligned);
    return (
      <button
        key={option.key}
        type="button"
        disabled={isUnavailable}
        onClick={() => {
          if (isChochMarking) {
            setExpandedFibOption((current) => current === option.key ? null : option.key);
            return;
          }
          if (isSingleMarking) {
            setFibVisibility((current) => ({
              ...current,
              [option.key]: !current[option.key],
            }));
            setFibPreviousVisibility((current) => ({
              ...current,
              [option.key]: false,
            }));
            setExpandedFibOption((current) => current === option.key ? null : current);
            return;
          }
          setExpandedFibOption((current) => current === option.key ? null : option.key);
        }}
        className={`flex h-7 items-center justify-between rounded-md border px-1.5 text-[8px] font-black leading-none transition ${
          isUnavailable
            ? 'cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400'
            : expandedFibOption === option.key
            ? 'border-fuchsia-300 bg-fuchsia-100 text-fuchsia-800'
            : active
              ? 'border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700'
              : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'
        }`}
        title={isUnavailable
          ? option.key === 'day'
            ? 'Day FIB is available on the 1m, 5m, 15m, and 30m charts'
            : option.key === 'h1Swing'
            ? 'Show the 1H Swing FIB drawing on the 5m, 15m, 30m, or 1H chart'
            : 'Show the 4H Swing FIB drawing on charts from 1m through 4H'
          : isChochMarking
            ? 'Choose each of the latest four CHoCH FIB drawings separately'
          : isSingleMarking
          ? `Show or hide the single current ${option.label.replace(' MARKING', '')} FIB marking`
          : `Choose latest or previous ${option.label}`}
        aria-expanded={isSingleMarking ? undefined : expandedFibOption === option.key}
      >
        <span className="whitespace-nowrap">{option.label.replace(' MARKING', '')}</span>
        <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
          active ? 'bg-fuchsia-200 text-fuchsia-800' : 'bg-slate-200 text-slate-500'
        }`}>
          {status}
        </span>
      </button>
    );
  };

  const zoneEntryEvidenceById = useMemo(() => {
    const evidence = new Map<string, { zone: StructureZone; evidence: ZoneEntryEvidence }>();
    for (const zone of [...zoneTableRows, ...doubleChochRows]) {
      const candidates = displayZoneMembers(zone).map(member => ({
        zone: member, evidence: inspectZoneEntryEvidence(member, displayCandles, granularity as TradeTimeframe),
      }));
      candidates.sort((a, b) => Number(!isZoneEligibleForEngulfingEntry(a.zone)) - Number(!isZoneEligibleForEngulfingEntry(b.zone))
        || Number(!a.evidence.signal) - Number(!b.evidence.signal)
        || Number(!a.evidence.observedSignal) - Number(!b.evidence.observedSignal)
        || a.evidence.waiting.length - b.evidence.waiting.length);
      evidence.set(zone.id, candidates[0]);
    }
    return evidence;
  }, [zoneTableRows, doubleChochRows, displayCandles, granularity]);
  const zoneEntryMissed = (zone: DisplayStructureZone) => replayIndex === null && mt5Status
    && displayZoneMembers(zone).some(member => findMissedZoneEntry({ symbol: marketSymbol,
      zoneTimeframe: granularity, zoneId: member.id }, mt5Status.missedEntries ?? mt5Status.recentSignals, mt5Status.bridge));
  const zoneReadiness = (zone: DisplayStructureZone, trade?: TradeLevels,
    decision?: DirectZoneEntryDecision, extra: Partial<Parameters<typeof explainZoneEntry>[0]> = {}) => {
    const inspected = zoneEntryEvidenceById.get(zone.id) ?? {
      zone, evidence: inspectZoneEntryEvidence(zone, displayCandles, granularity as TradeTimeframe),
    };
    const signal = trade?.signal ?? inspected.evidence.signal;
    const signalClose = signal ? signal.time + TIMEFRAME_SECONDS[signal.timeframe] : tradeDisplayAsOf;
    const brokerSignal = replayIndex === null ? mt5Status?.recentSignals.find(candidate => (
      candidate.signalAt <= tradeDisplayAsOf && candidate.account === mt5Status.bridge.account
      && candidate.server === mt5Status.bridge.server && candidate.brokerSymbol === mt5Status.bridge.brokerSymbol
      && displayZoneMembers(zone).some(member => tradeZoneExecutionKey(candidate)
        === tradeZoneExecutionKey({ symbol: marketSymbol, zoneTimeframe: granularity, zoneId: member.id }))
    )) : undefined;
    return explainZoneEntry({
      zone: inspected.zone, timeframe: granularity, evidence: inspected.evidence, trade, decision,
      confirmationLabel: TJL1_CONFIRMATION_LABELS[granularity].toUpperCase(),
      outsideHours: tradingTimeEnabled && !isNepalTradingTime(signalClose),
      countertrendBlocked: signal && blockedGoldChartEntry(signal.time, signal.timeframe, signal.direction),
      replay: replayIndex !== null, automationSupported: marketConfig.mt5AutomationEnabled,
      automation: mt5Status ?? undefined, now: tradeDisplayAsOf, symbol: marketSymbol,
      barsAgo: latestZoneTapBarsAgo(zone, displayCandles), brokerSignal, ...extra,
    });
  };

  const scalpOneToOneBrokerSignals = (mt5Status?.recentSignals ?? []).filter(signal => signal.tradeStyle === 'SCALP_1_1'
      && mt5Status?.bridge.account === signal.account && mt5Status?.bridge.server === signal.server
      && mt5Status?.bridge.brokerSymbol === signal.brokerSymbol);
  const scalpTableRecords = replayIndex === null ? scalpOneToOneBrokerSignals
    : scalpReplayTableSignals(scalpOneToOneChartRecords, tradeDisplayAsOf);
  const scalpOneToOneTableSignals: Array<Mt5StoredSignal & { preview?: boolean; simulatedFill?: boolean }> = [
    ...scalpTableRecords,
    ...scalpOneToOnePreview.filter(signal => !scalpTableRecords.some(stored =>
      stored.tradeStyle === 'SCALP_1_1' && stored.signalAt === signal.signalAt
        && stored.scalpEntry?.leg === signal.scalpEntry?.leg)).map(signal => ({
      ...signal, status: 'QUEUED' as const, createdAt: signal.calculatedAt,
      updatedAt: signal.calculatedAt, preview: true,
    })),
  ];
  const intradayBrokerSignals = (mt5Status?.recentSignals ?? []).filter(signal => signal.intradayEntry
    && mt5Status?.bridge.account === signal.account && mt5Status?.bridge.server === signal.server
    && mt5Status?.bridge.brokerSymbol === signal.brokerSymbol);
  const intradayTableSignals: Array<Mt5StoredSignal & { preview?: boolean }> = [
    ...intradayBrokerSignals,
    ...intradayPullbackPreview.filter(signal => !intradayBrokerSignals.some(stored =>
      stored.intradayEntry?.setupKey === signal.intradayEntry?.setupKey
      && stored.intradayEntry?.leg === signal.intradayEntry?.leg)).map(signal => ({
        ...signal, status: 'QUEUED' as const, createdAt: signal.calculatedAt,
        updatedAt: signal.calculatedAt, preview: true,
      })),
  ];
  const pullbackFillEvidence: PullbackFillEvidence = {
    asOf: tradeDisplayAsOf, replay: replayIndex !== null, records: canonicalTradeRecords,
    signals: (mt5Status?.recentSignals ?? []).filter(signal => signal.account === mt5Status?.bridge.account
      && signal.server === mt5Status?.bridge.server && signal.brokerSymbol === mt5Status?.bridge.brokerSymbol),
    positions: mt5Status?.positions ?? [],
  };
  const pullbackTableCandles = Object.fromEntries(AUTOMATION_GRANULARITIES
    .map(timeframe => [timeframe, tableTimeframeData[timeframe]?.candles])) as Partial<Record<TradeTimeframe, readonly OandaCandle[]>>;
  const tablePullbackSetups = marketSymbol === 'XAUUSD' ? buildPullbackChartSetups({
    signals: [...visibleCanonicalTradeRecords.flatMap(record => {
      const signal = chartSignalFromRecord(record); return signal ? [signal] : [];
    }), ...intradayTableSignals],
    asOf: tradeDisplayAsOf, candles: pullbackTableCandles,
    positions: replayIndex === null ? mt5Status?.positions ?? [] : [], context: mt5Status?.bridge ?? {},
  }).filter(setup => setup.style === 'INTRADAY') : [];
  const retainedRowForZone = (zone: DisplayStructureZone) => retainedDirectZoneTableRows.find(row =>
    row.sourceZoneId !== undefined && (row.sourceTimeframe ?? granularity) === granularity
    && row.trade.signal.direction === (zone.isBuy ? 'bullish' : 'bearish')
    && displayZoneMembers(zone).some(member => tradeOverlayZoneOriginKey(member.id) === tradeOverlayZoneOriginKey(row.sourceZoneId!)));
  const zonePullback = (zone: DisplayStructureZone, trade?: TradeLevels) => findZoneTablePullbackSetup(tablePullbackSetups, {
    zoneIds: displayZoneMembers(zone).map(member => member.id), symbol: marketSymbol,
    zoneTimeframe: granularity, direction: zone.isBuy ? 'bullish' : 'bearish', trade,
  });
  const representedPullbackSetups = tablePullbackSetups.filter(setup => setup.style === 'INTRADAY' && (
    retainedDirectZoneTableRows.some(row => row.sourceZoneId && findZoneTablePullbackSetup([setup], {
      zoneIds: [row.sourceZoneId], symbol: marketSymbol, zoneTimeframe: row.sourceTimeframe ?? granularity,
      direction: row.trade.signal.direction, trade: row.trade,
    })) || [...zoneTableRows, ...doubleChochRows].some(zone => zonePullback(zone)?.id === setup.id)
  ));
  const zoneTableContent = (
    <>
    {replayIndex === null && marketSymbol === 'XAUUSD' && intradayEnabled && <PullbackSetupRows
      signals={intradayTableSignals.filter(signal => signal.signalTimeframe === granularity || signal.zoneTimeframe === granularity)}
      representedSetups={representedPullbackSetups}
      style="INTRADAY" asOf={tradeDisplayAsOf} entryCandles={pullbackTableCandles}
      positions={mt5Status?.positions ?? []} connection={mt5Status?.bridge} timeZone={chartTimeZone} limit={12} />}
    {marketSymbol === 'XAUUSD' && scalpOneToOneEnabled && granularity === 'M15' && <PullbackSetupRows
      signals={scalpOneToOneTableSignals} style="SCALP_1_1" asOf={tradeDisplayAsOf} entryCandles={pullbackTableCandles}
      replay={replayIndex !== null}
      positions={replayIndex === null ? mt5Status?.positions ?? [] : []}
      connection={mt5Status?.bridge} timeZone={chartTimeZone} />}
    {scalpEntryTableRows.map(({ id, zone, trade: sourceTrade, tradingTimeBlocked }) => {
      const trade = zoneTableTrade(sourceTrade, undefined, zone, id)!;
      const sourceSetup = goldScalpingAccuracyTrades.find(candidate => candidate.trade.signal.time === trade.signal.time
        && candidate.trade.entry === trade.entry);
      const sourceZone = sourceSetup?.zone;
      if (hasZoneTableTradeExpired(trade, sourceZone)) return null;
      const bullish = trade.signal.direction === 'bullish';
      return (
        <tr key={`scalp-entry-${id}`} className="border-t border-indigo-200 bg-indigo-50/80">
          <td className="px-2 py-1 font-black text-slate-800">
            <div>SCALP · {zone}<ZoneSourceTimeframeLabel timeframe={sourceSetup?.zoneTimeframe
              ?? chartEntryRecords.find(record => record.id === id)?.zoneTimeframe} /></div>
            <div className="text-[8px] font-semibold text-slate-500">
              {formatAccuracyTradeTime(
                trade.signal.time + TIMEFRAME_SECONDS[trade.signal.timeframe],
                chartTimeZone,
              )}
            </div>
          </td>
          <td className={`px-2 py-1 font-bold ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
            {bullish ? 'BUY' : 'SELL'}
          </td>
          <td className="whitespace-nowrap px-2 py-1 font-bold text-blue-700">
            <ZoneTableEntryPrice trade={trade} zone={sourceZone} pipSize={marketConfig.pipSize} />
          </td>
          <td className="px-2 py-1 text-center font-black">{trade.signal.type}</td>
          <td className={`whitespace-nowrap px-2 py-1 text-right font-black ${
            tradingTimeBlocked ? 'text-rose-700' : 'text-indigo-700'
          }`}>
            {zoneTableCompletedStatus(trade) ?? (tradingTimeBlocked
              ? 'OUTSIDE TRADING TIME · NO TRADE'
              : <TradeStatusText trade={trade} />)}
          </td>
        </tr>
      );
    })}
    {blockedGoldScalpingSetups.filter(({ trade }) => (
      trade.signal.timeframe === granularity
      && displayCandles.some((candle) => candle.time === trade.signal.time)
      && latestCandle !== null
      && latestCandle.time - trade.signal.time <= 50 * TIMEFRAME_SECONDS.M1
    )).sort((first, second) => second.trade.signal.time - first.trade.signal.time)
      .slice(0, 3).map(({ zone, zoneTimeframe, trade }) => (
        <tr key={`blocked-scalp-${zoneTimeframe}-${zone.id}-${trade.signal.time}`}
          className="border-t border-amber-200 bg-amber-50/80">
          <td className="px-2 py-1 font-black text-slate-700">SCALP · {executionZoneName(zone)}<ZoneSourceTimeframeLabel timeframe={zoneTimeframe} /></td>
          <td className="px-2 py-1 font-bold text-slate-600">BUY SETUP</td>
          <td className="px-2 py-1 text-slate-400">—</td>
          <td className="px-2 py-1 text-center font-black text-slate-600">{trade.signal.type}</td>
          <td className="whitespace-nowrap px-2 py-1 text-right font-black text-amber-800">
            BLOCKED · 15M + 1H BEARISH · NO ENTRY
          </td>
        </tr>
      ))}
    {blockedGoldScalpingOpposingSetups.filter(({ trade, zoneTimeframe }) => (
      (trade.signal.timeframe === granularity || zoneTimeframe === granularity)
      && latestCandle !== null
      && latestCandle.time - trade.signal.time <= 50 * TIMEFRAME_SECONDS.M1
    )).sort((first, second) => second.trade.signal.time - first.trade.signal.time)
      .slice(0, 3).map(({ zone, zoneTimeframe, trade, opposingZoneBlock }) => (
        <tr key={`opposing-scalp-${zoneTimeframe}-${zone.id}-${trade.signal.time}`}
          className="border-t border-amber-200 bg-amber-50/80">
          <td className="px-2 py-1 font-black text-slate-700">SCALP · {executionZoneName(zone)}<ZoneSourceTimeframeLabel timeframe={zoneTimeframe} /></td>
          <td className="px-2 py-1 font-bold text-slate-600">
            {trade.signal.direction === 'bullish' ? 'BUY' : 'SELL'} SETUP
          </td>
          <td className="px-2 py-1 text-slate-400">—</td>
          <td className="px-2 py-1 text-center font-black text-slate-600">{trade.signal.type}</td>
          <td className="whitespace-nowrap px-2 py-1 text-right font-black text-amber-800">
            {goldOpposingZoneBlockLabel(opposingZoneBlock!)}
          </td>
        </tr>
      ))}
    {retainedDirectZoneTableRows.map(({ overlay, sourceZoneId, sourceZone, sourceTimeframe, trade, tapCount, additionalConfirmations }) => {
      const pullback = findZoneTablePullbackSetup(tablePullbackSetups, {
        zoneIds: sourceZoneId ? [sourceZoneId] : [], symbol: marketSymbol,
        zoneTimeframe: sourceTimeframe ?? granularity, direction: trade.signal.direction, trade,
      });
      const bullish = trade.signal.direction === 'bullish';
      const zoneLabel = tradeOverlayZoneLabel(overlay.label);
      const currentFibLabels = sourceZone ? tradeZoneFibLabels(sourceZone) : [];
      const fibLabels = currentFibLabels.length > 0 ? currentFibLabels : overlay.fibLabels ?? [];
      return (
        <React.Fragment key={`open-chart-trade-${overlay.id}`}>
          <tr className={`border-t ${bullish ? 'border-emerald-200 bg-emerald-50' : 'border-rose-200 bg-rose-50'}`}>
            <td className="px-2 py-1 font-black text-slate-800">
              <span>{zoneLabel ?? 'OPEN CHART TRADE'}</span>
              <ZoneSourceTimeframeLabel timeframe={sourceTimeframe} />
              {tapCount !== undefined && (
                <span className="ml-1 rounded bg-sky-100 px-1 py-0.5 text-[8px] font-black text-sky-800">
                  TAP {tapCount}
                </span>
              )}
              {sourceZone?.doubleChochStatus && <>
                <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">DOUBLE CHoCH</span>
                <span className="ml-1 rounded bg-emerald-100 px-1 py-0.5 text-[8px] font-black text-emerald-800">HTF {sourceZone.doubleChochStatus === 'valid' ? 'VALID' : 'WAIT'}</span>
                {sourceZone.doubleChochOriginClass && <span className="ml-1 rounded bg-slate-100 px-1 py-0.5 text-[8px] font-black text-slate-600">FROM {sourceZone.doubleChochOriginClass.toUpperCase()}</span>}
              </>}
              {(sourceZone ? isDeepDiscountZoneDisplay(sourceZone, trade.signal)
                : isDefaultDeepDiscountZoneName(zoneLabel)) && (
                <span className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
                  DEEP DISCOUNT
                </span>
              )}
              {fibLabels.map((label) => (
                <span key={label} className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
                  {label}
                </span>
              ))}
            </td>
            <td className={`px-2 py-1 font-bold ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
              {bullish ? 'BUY' : 'SELL'}
            </td>
            <td className="whitespace-nowrap px-2 py-1">
              {sourceZone ? <>
                <div>{formatPrice(sourceZone.bottom)} – {formatPrice(sourceZone.top)}</div>
                <div className="text-[8px] font-black text-slate-600">{formatZonePips((sourceZone.top - sourceZone.bottom) / marketConfig.pipSize)} PIPS</div>
              </>
                : <ZoneTableEntryPrice trade={trade} zone={sourceZone} pipSize={marketConfig.pipSize} />}
            </td>
            <td className={`whitespace-nowrap px-2 py-1 text-center font-black ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
              {trade.signal.type} {bullish ? 'BULL' : 'BEAR'}
              <ZoneTableEngulfingConfirmations confirmations={additionalConfirmations} />
            </td>
            <td className={`whitespace-nowrap px-2 py-1 text-right font-black ${trade.status === 'sl-hit' ? 'text-rose-700' : 'text-emerald-700'}`}>
              <ZoneTableTapAge barsAgo={sourceZone ? latestZoneTapBarsAgo(sourceZone,
                sourceTimeframe ? tableTimeframeData[sourceTimeframe]?.candles ?? displayCandles : displayCandles) : undefined}>
              {pullback ? <ZonePullbackTradeStatus setup={pullback} /> : zoneTableCompletedStatus(trade) ?? <TradeStatusText trade={trade} />}
              </ZoneTableTapAge>
              {bestTrendlineBadge(trade)}
            </td>
          </tr>
          {pullback ? <ZonePullbackDetailsRow setup={pullback} /> : <TradeDetailsRow trade={trade} colSpan={5} zoneTimeframe={granularity} fillEvidence={pullbackFillEvidence}
            entryCandles={tableTimeframeData[trade.signal.timeframe]?.candles} />}
        </React.Fragment>
      );
    })}
    {chochStatusTableRows.map(zone => (
      <ChochStatusTableRow key={`choch-status-${zone.id}`} zone={zone} timeframe={granularity} />
    ))}
    {pendingConfirmationRows.map((zone) => (
      <tr key={zone.id} className={`border-t text-slate-700 ${zone.isBuy ? 'border-emerald-100 bg-emerald-50/70' : 'border-rose-100 bg-rose-50/70'}`}>
        <td className={`px-2 py-1 font-black ${zone.isBuy ? 'text-emerald-800' : 'text-rose-800'}`}>{displayZoneName(zone.name, zone.oneMinuteGenesisQml)}<ZoneSourceTimeframeLabel timeframe={granularity} /></td>
        <td className={`px-2 py-1 font-bold ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
          {zone.isBuy ? 'BUY' : 'SELL'}
        </td>
        <td className="px-2 py-1 whitespace-nowrap">{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</td>
        <td className="px-2 py-1 text-center text-slate-400">—</td>
        <td className={`px-2 py-1 text-right font-black whitespace-nowrap ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
          <ZoneEntryReadinessText readiness={zoneReadiness(zone)} compactLabel={`WAIT ${TJL1_CONFIRMATION_LABELS[granularity].toUpperCase()} ${zone.isBuy ? 'ABOVE' : 'BELOW'}`} />
        </td>
      </tr>
    ))}
    {doubleChochRows.map((zone) => {
      if (retainedRowForZone(zone)) return null;
      const pullback = zonePullback(zone);
      const pending = zone.doubleChochStatus === 'pending';
      const confirmationLabel = TJL1_CONFIRMATION_LABELS[granularity].toUpperCase();
      const confirmationSide = zone.doubleChochConfirmationDirection === 'up' ? 'ABOVE' : 'BELOW';
      const trade = zoneTableTrade(confluenceMapValue<TradeLevels>(zone, directZoneTrades), zone);
      const entryDecision = confluenceMapValue<DirectZoneEntryDecision>(zone, directZoneEntryDecisions);
      const outsideTimePreview = !trade ? entryDecision?.previewTrade : undefined;
      const displayedTrade = zoneTableTrade(trade ?? outsideTimePreview, zone);
      const mt5Signal = confluenceMapValue<Mt5StoredSignal>(zone, directZoneMt5Signals);
      if (hasZoneTableTradeExpired(displayedTrade, zone) || hasZoneTableTradeExpired(mt5Signal, zone)) return null;
      const completedStatus = zoneEntryMissed(zone) ? 'ENTRY MISSED' : zoneTableCompletedStatus(displayedTrade, mt5Signal);
      const readiness = zoneReadiness(zone, trade, entryDecision, {
        recordedTrade: displayedTrade,
        opportunityExpired: marketSymbol === 'XAUUSD' && isGoldZoneOpportunityExpired(
          zone, displayCandles, granularity, marketConfig.pipSize, Infinity,
          displayedTrade?.filledAt === undefined ? undefined
            : { price: displayedTrade.entry, filledAt: displayedTrade.filledAt, stopLoss: displayedTrade.stopLoss }),
        zoneUsed: marketSymbol === 'XAUUSD' && (displayedTapCount(zone) ?? 0) > 1,
      });
      const measurement = confluenceFirstValue(zone, (member) => (
        measureTradeableFibZone(member, marketConfig.pipSize)
      )) ?? (completedStatus ? measureListedZone(zone, marketConfig.pipSize) : undefined);
      return (
        <React.Fragment key={`double-${zone.id}`}>
        <tr className={`border-t text-slate-700 ${
          pending ? 'border-amber-100 bg-amber-50/70' : 'border-emerald-100 bg-emerald-50/50'
        }`}>
          <td className="px-2 py-1 font-black text-slate-800">
            <span>{displayZoneName(zone.name, zone.oneMinuteGenesisQml)}</span>
            <ZoneSourceTimeframeLabel timeframe={mt5Signal?.zoneTimeframe ?? granularity} />
            {displayedTapCount(zone) !== undefined && (
              <span className="ml-1 rounded bg-sky-100 px-1 py-0.5 text-[8px] font-black text-sky-800">
                TAP {displayedTapCount(zone)}
              </span>
            )}
            <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">
              DOUBLE CHoCH
            </span>
            {displayZoneMembers(zone).some(member => isDeepDiscountZoneDisplay(member, displayedTrade?.signal)) && (
              <span className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
                DEEP DISCOUNT
              </span>
            )}
            <span className={`ml-1 rounded px-1 py-0.5 text-[8px] font-black ${
              pending ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
            }`}>
              HTF {pending ? 'WAIT' : 'VALID'}
            </span>
            {zone.doubleChochOriginClass && (
              <span className="ml-1 rounded bg-slate-100 px-1 py-0.5 text-[8px] font-black text-slate-600">
                FROM {zone.doubleChochOriginClass.toUpperCase()}
              </span>
            )}
            {showFib && zone.swingFibStatus === 'a-plus' && zone.swingFibBand && (
              <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">
                SWING A+ FIB {zone.swingFibBand}
              </span>
            )}
            {zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand && (
              <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">
                1H SWING FIB ALIGNED {zone.h1SwingFibBand}
              </span>
            )}
            {showFib && zone.dayFibStatus === 'a-plus' && zone.dayFibBand && (
              <span className="ml-1 rounded bg-sky-100 px-1 py-0.5 text-[8px] font-black text-sky-800">
                DAY FIB A+ {zone.dayFibBand}
              </span>
            )}
          </td>
          <td className={`px-2 py-1 font-bold ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
            {zone.isBuy ? 'BUY' : 'SELL'}
          </td>
          <td className="px-2 py-1 whitespace-nowrap">
            <div>{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</div>
            {measurement && (
              <div className="text-[8px] font-black text-slate-600">
                {formatZonePips(measurement.pips)} PIPS
              </div>
            )}
          </td>
          <td className={`px-2 py-1 text-center font-black whitespace-nowrap ${
            zone.isBuy ? 'text-emerald-700' : 'text-rose-700'
          }`}>
            {showEngulfing
              ? displayedTrade
                ? `${displayedTrade.signal.type} ${displayedTrade.signal.direction === 'bullish' ? 'BULL' : 'BEAR'}`
                : displayEngulfingLabel(zone, granularity) ?? '—'
              : '—'}
          </td>
          <td className={`px-2 py-1 text-right font-black whitespace-nowrap ${
            trade?.status === 'sl-hit'
              ? 'text-rose-700'
              : outsideTimePreview ? 'text-rose-700'
                : pending ? 'text-amber-700' : 'text-emerald-700'
          }`}>
            <ZoneTableTapAge barsAgo={latestZoneTapBarsAgo(zone, displayCandles)}>
            {pullback ? <ZonePullbackTradeStatus setup={pullback} /> : <ZoneEntryReadinessText readiness={readiness} compactLabel={completedStatus ?? (isCompletedTrade(outsideTimePreview)
              ? <TradeStatusText trade={outsideTimePreview!} />
              : mt5Signal ? mt5SignalStatusLabel(mt5Signal)
              : replayIndex !== null && trade?.filledAt !== undefined ? <TradeStatusText trade={trade} />
              : pending ? `WAIT ${confirmationLabel} ${confirmationSide}`
              : compactZoneTableStatus(readiness, undefined, confluenceIsTradeable(zone)))} />}
            </ZoneTableTapAge>
          </td>
        </tr>
        {pullback ? <ZonePullbackDetailsRow setup={pullback} /> : displayedTrade
          && (completedStatus || marketSymbol !== 'XAUUSD' || (displayedTapCount(zone) ?? 0) <= 1)
          && <TradeDetailsRow trade={displayedTrade} colSpan={5}
            fillEvidence={pullbackFillEvidence}
            zoneTimeframe={granularity} entryCandles={tableTimeframeData[displayedTrade.signal.timeframe]?.candles}
            mt5Signal={mt5Signal} referenceOnly={outsideTimePreview !== undefined}
            hideReferenceStatus={outsideTimePreview !== undefined} />}
        </React.Fragment>
      );
    })}
    {zoneTableRows.map((zone) => {
      const pullback = zonePullback(zone);
      const scalpTrade = marketSymbol === 'XAUUSD' && scalpingEnabled
        ? goldScalpingDirectTrades.find((candidate) => (
          candidate.zoneTimeframe === granularity
          && displayZoneMembers(zone).some((member) => member.id === candidate.zone.id)
        ))?.trade
        : undefined;
      const scalpPreview = marketSymbol === 'XAUUSD' && scalpingEnabled && tradingTimeEnabled && !scalpTrade
        ? goldScalpingAccuracyTrades.find((candidate) => (
          candidate.zoneTimeframe === granularity
          && displayZoneMembers(zone).some((member) => member.id === candidate.zone.id)
          && (!isNepalTradingTime(candidate.trade.signal.time + TIMEFRAME_SECONDS[candidate.trade.signal.timeframe])
            || (candidate.trade.filledAt !== undefined && !isNepalTradingTime(candidate.trade.filledAt)))
        ))?.trade
        : undefined;
      const trade = zoneTableTrade(scalpTrade ?? confluenceMapValue<TradeLevels>(zone, directZoneTrades), zone);
      const entryDecision = confluenceMapValue<DirectZoneEntryDecision>(zone, directZoneEntryDecisions);
      const outsideTimePreview = !trade
        ? entryDecision?.previewTrade ?? scalpPreview : undefined;
      const historicalEntry = replayDirectHistoryByZone.get(zone.id);
      const historicalTrade = !trade && !outsideTimePreview ? zoneTableTrade(historicalEntry?.trade, zone) : undefined;
      const usedZoneTrade = zoneTableTrade(entryDecision?.usedZoneTrade, zone);
      const engulfingTrade = zoneTableTrade(trade ?? outsideTimePreview ?? historicalTrade ?? usedZoneTrade, zone);
      if (hasZoneTableTradeExpired(engulfingTrade, zone)) return null;
      // Once listed, this zone's later engulfings belong beside its original entry type.
      if (retainedDirectZoneTableRows.some(retained => retained.sourceZoneId
        && displayZoneMembers(zone).some(member => directZoneTableGroupKey(
          member.id, marketSymbol, zone.isBuy ? 'bullish' : 'bearish',
        ) === directZoneTableGroupKey(retained.sourceZoneId!, marketSymbol, retained.trade.signal.direction)))) return null;
      const scalpEngulfingTrade = scalpTrade ?? (!trade ? scalpPreview : undefined);
      const deepDiscount = displayZoneMembers(zone).some(member => (
        isDeepDiscountZoneDisplay(member, engulfingTrade?.signal)
      ));
      const mt5Signal = confluenceMapValue<Mt5StoredSignal>(zone, directZoneMt5Signals);
      const completedStatus = zoneEntryMissed(zone) ? 'ENTRY MISSED' : zoneTableCompletedStatus(engulfingTrade, mt5Signal);
      const measurement = confluenceFirstValue(zone, (member) => (
        measureTradeableFibZone(member, marketConfig.pipSize)
      )) ?? measureListedZone(zone, marketConfig.pipSize);
      const tapBarsAgo = latestZoneTapBarsAgo(zone, displayCandles);
      const latestTap = confluenceLatestTap(zone);
      const tapCount = displayedTapCount(zone);
      const repeatedTap = marketSymbol === 'XAUUSD' && (tapCount ?? 0) > 1;
      const opportunityExpired = marketSymbol === 'XAUUSD'
        && displayZoneMembers(zone).every((member) => isGoldZoneOpportunityExpired(
          member, displayCandles, granularity, marketConfig.pipSize,
          Infinity, trade?.filledAt === undefined ? undefined
            : { price: trade.entry, filledAt: trade.filledAt, stopLoss: trade.stopLoss },
        ));
      const confluenceLabels = confluenceBadgeLabels(zone);
      const extremeAPlus = displayZoneMembers(zone).some((member) => (
        extremeAPlusTjl2Selection.extremeZoneIds.has(member.id)
      ));
      const extremeAPlusBlocked = displayZoneMembers(zone).some((member) => (
        extremeAPlusTjl2Selection.blockedZoneIds.has(member.id)
      ));
      const pendingChoch = zone.chochClass === 'pending';
      const mtfStatus = zoneTableMtfStatus(displayZoneMembers(zone), granularity,
        mtfRows.filter(row => !hasTradeDisplayExpired(row.trade ?? row.previewTrade)));
      const chochConfirmationLabel = TJL1_CONFIRMATION_LABELS[granularity].toUpperCase();
      const chochConfirmationSide = zone.isBuy ? 'ABOVE' : 'BELOW';
      const observedPattern = zoneEntryEvidenceById.get(zone.id)?.evidence.observedSignal;
      const readiness = zoneReadiness(zone, trade, entryDecision, {
        recordedTrade: engulfingTrade,
        opportunityExpired, zoneUsed: repeatedTap, extremeBlocked: extremeAPlusBlocked,
        outsideHours: Boolean(outsideTimePreview) || (tradingTimeEnabled
          && !isNepalTradingTime((trade?.signal.time ?? tradeDisplayAsOf)
            + (trade ? TIMEFRAME_SECONDS[trade.signal.timeframe] : 0))),
        scalping: Boolean(scalpTrade),
      });
      return (
      <React.Fragment key={zone.id}>
      <tr className="border-t border-slate-100 text-slate-700">
        <td className="px-2 py-1 font-black text-slate-800">
          <span>{displayConfluenceZoneName(zone)}</span>
          <ZoneSourceTimeframeLabel timeframe={mt5Signal?.zoneTimeframe ?? granularity} />
          {latestTap && (
            <span className="ml-1 rounded bg-sky-100 px-1 py-0.5 text-[8px] font-black text-sky-800">
              TAP {tapCount ?? latestTap.count}
            </span>
          )}
          {extremeAPlus && (
            <span className="ml-1 rounded bg-emerald-100 px-1 py-0.5 text-[8px] font-black text-emerald-800">
              EXTREME A+
            </span>
          )}
          {extremeAPlusBlocked && (
            <span className="ml-1 rounded bg-rose-100 px-1 py-0.5 text-[8px] font-black text-rose-800">
              EXTREME A+ HIGHER
            </span>
          )}
          {deepDiscount && (
            <span className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
              DEEP DISCOUNT
            </span>
          )}
          {confluenceLabels.map((label) => (
            <span key={`${zone.id}-confluence-${label}`} className="ml-1 rounded bg-slate-100 px-1 py-0.5 text-[8px] font-black text-slate-700">
              {label}
            </span>
          ))}
          {zone.majorLiquidity && (
            <span className="ml-1 rounded bg-cyan-100 px-1 py-0.5 text-[8px] font-black text-cyan-800">
              MAJOR LIQUIDITY
            </span>
          )}
          {zone.chochClass && (
            <span className={`ml-1 rounded px-1 py-0.5 text-[8px] font-black ${
              zone.chochClass === 'vip'
                ? 'bg-amber-100 text-amber-800'
                : zone.chochClass === 'valid'
                  ? 'bg-emerald-100 text-emerald-800'
                  : zone.chochClass === 'air'
                    ? 'bg-rose-100 text-rose-700'
                    : 'bg-violet-100 text-violet-700'
            }`}>
              {zone.category === 'internal' ? 'INT ' : ''}
              {pendingChoch
                ? `CHoCH · PENDING — WAIT ${chochConfirmationLabel} CLOSE ${chochConfirmationSide}`
                : `CHoCH · ${zone.chochClass.toUpperCase()}`}
            </span>
          )}
          {zone.chochClass === 'vip' && zone.vipSupportTimeframe && zone.vipSupportZone && (
            <span className="ml-1 rounded bg-amber-50 px-1 py-0.5 text-[8px] font-black text-amber-700">
              {zone.vipSupportTimeframe} {displayZoneName(zone.vipSupportZone)}
            </span>
          )}
          {showFib && zone.fibStatus === 'a-plus'
            && zone.fibBand && zone.fibBand !== 'DB/DT' && (
            <span className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
              {displayFibLabel(zone)}
            </span>
          )}
          {showFib && zone.swingFibStatus === 'a-plus' && zone.swingFibBand && (
            <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">
              SWING A+ FIB {zone.swingFibBand}
            </span>
          )}
          {zone.h1SwingFibStatus === 'aligned' && zone.h1SwingFibBand && (
            <span className="ml-1 rounded bg-violet-100 px-1 py-0.5 text-[8px] font-black text-violet-800">
              1H SWING FIB ALIGNED {zone.h1SwingFibBand}
            </span>
          )}
          {showFib && zone.dayFibStatus === 'a-plus' && zone.dayFibBand && (
            <span className="ml-1 rounded bg-sky-100 px-1 py-0.5 text-[8px] font-black text-sky-800">
              DAY FIB A+ {zone.dayFibBand}
            </span>
          )}
        </td>
        <td className={`px-2 py-1 font-bold ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
          {zone.isBuy ? 'BUY' : 'SELL'}
        </td>
        <td className="px-2 py-1 whitespace-nowrap">
          <div>{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</div>
          {measurement && (
            <div className="text-[8px] font-black text-slate-600">
              {formatZonePips(measurement.pips)} PIPS
            </div>
          )}
        </td>
          <td className={`px-2 py-1 text-center font-black whitespace-nowrap ${
            zone.isBuy ? 'text-emerald-700' : 'text-rose-700'
          }`}>
            {showEngulfing ? engulfingTrade ? <>
              <div>{scalpEngulfingTrade ? 'SCALP ' : ''}{engulfingTrade.signal.timeframe !== granularity ? `${formatTradeTimeframe(engulfingTrade.signal.timeframe)} ` : ''}{engulfingTrade.signal.type} {engulfingTrade.signal.direction === 'bullish' ? 'BULL' : 'BEAR'}</div>
              {(scalpEngulfingTrade || engulfingTrade.signal.timeframe !== granularity) && <div className="text-[8px] text-slate-500">
                {formatTradeTimeframe(engulfingTrade.signal.timeframe)} CONFIRMED {formatAccuracyTradeTime(
                  engulfingTrade.signal.time + TIMEFRAME_SECONDS[engulfingTrade.signal.timeframe],
                  chartTimeZone,
                )}
              </div>}
            </> : confluenceEngulfingLabel(zone, granularity) ?? (observedPattern ? (
              <span className="text-amber-700" title="Observed candle pattern only; the remaining entry conditions have not passed.">
                {observedPattern.type} {observedPattern.direction === 'bullish' ? 'BULL' : 'BEAR'} · OBSERVED
              </span>
            ) : '—') : '—'}
        </td>
        <td className={`px-2 py-1 text-right font-bold whitespace-nowrap ${
          trade?.status === 'sl-hit' ? 'text-rose-700' : ''
        }`}>
          <ZoneTableTapAge barsAgo={tapBarsAgo}>
          {pullback ? <ZonePullbackTradeStatus setup={pullback} /> : <ZoneEntryReadinessText readiness={readiness} compactLabel={
            completedStatus ? completedStatus
              : outsideTimePreview && isCompletedTrade(outsideTimePreview) ? <TradeStatusText trade={outsideTimePreview} />
              : historicalTrade ? <TradeStatusText trade={historicalTrade} />
              : mt5Signal ? mt5SignalStatusLabel(mt5Signal)
              : isCompletedTrade(trade) ? <TradeStatusText trade={trade!} />
              : replayIndex !== null && trade?.filledAt !== undefined ? <TradeStatusText trade={trade} />
              : mtfStatus?.confirmed && !outsideTimePreview && !extremeAPlusBlocked && !repeatedTap ? mtfStatus.label
              : compactZoneTableStatus(readiness, undefined, confluenceIsTradeable(zone))
          } />}
          </ZoneTableTapAge>
          {!outsideTimePreview && !historicalEntry?.tradingTimeBlocked
            && (!repeatedTap || completedStatus) && !extremeAPlusBlocked
            && bestTrendlineBadge(engulfingTrade)}
        </td>
      </tr>
      {pullback && <ZonePullbackDetailsRow setup={pullback} />}
      {!pullback && engulfingTrade && !historicalTrade
        && (!repeatedTap || completedStatus || usedZoneTrade)
        && <TradeDetailsRow
          trade={engulfingTrade}
          fillEvidence={pullbackFillEvidence}
          zoneTimeframe={granularity}
          entryCandles={tableTimeframeData[engulfingTrade.signal.timeframe]?.candles}
          colSpan={5}
          oppositePositionOpen={entryDecision?.oppositePositionOpen}
          mt5Signal={mt5Signal}
          referenceOnly={outsideTimePreview !== undefined || usedZoneTrade !== undefined}
          hideReferenceStatus={usedZoneTrade !== undefined && !trade && !outsideTimePreview && !historicalTrade}
        />}
      {!pullback && historicalTrade && (!repeatedTap || completedStatus) && (
        <TradeDetailsRow trade={historicalTrade} colSpan={5}
          fillEvidence={pullbackFillEvidence}
          zoneTimeframe={granularity} entryCandles={tableTimeframeData[historicalTrade.signal.timeframe]?.candles}
          referenceOnly={historicalEntry?.tradingTimeBlocked}
          hideReferenceStatus={historicalEntry?.tradingTimeBlocked} />
      )}
      </React.Fragment>
      );
    })}
    {retainedTradeZoneRows.map((zone) => {
      const trade = zoneTableTrade(directZoneTrades.get(zone.id), zone)!;
      const mt5Signal = directZoneMt5Signals.get(zone.id);
      if (hasZoneTableTradeExpired(trade, zone) || hasZoneTableTradeExpired(mt5Signal, zone)) return null;
      const completedStatus = zoneEntryMissed(zone) ? 'ENTRY MISSED' : zoneTableCompletedStatus(trade, mt5Signal);
      return (
        <React.Fragment key={`retained-trade-${zone.id}`}>
          <tr className="border-t border-slate-200 bg-slate-50 text-slate-600">
            <td className="px-2 py-1 font-black">
              {displayZoneName(zone.name, zone.oneMinuteGenesisQml)}
              <ZoneSourceTimeframeLabel timeframe={mt5Signal?.zoneTimeframe ?? granularity} />
              {isDeepDiscountZoneDisplay(zone, trade.signal) && (
                <span className="ml-1 rounded bg-fuchsia-100 px-1 py-0.5 text-[8px] font-black text-fuchsia-800">
                  DEEP DISCOUNT
                </span>
              )}
            </td>
            <td className={`px-2 py-1 font-bold ${zone.isBuy ? 'text-emerald-700' : 'text-rose-700'}`}>
              {zone.isBuy ? 'BUY' : 'SELL'}
            </td>
            <td className="whitespace-nowrap px-2 py-1">
              {completedStatus
                ? <ZoneTableEntryPrice trade={trade} mt5Signal={mt5Signal} zone={zone} pipSize={marketConfig.pipSize} />
                : <>{formatPrice(zone.bottom)} – {formatPrice(zone.top)}</>}
            </td>
            <td className="whitespace-nowrap px-2 py-1 text-center font-black">
              {displayEngulfingLabel(zone, granularity) ?? '—'}
            </td>
            <td className={`whitespace-nowrap px-2 py-1 text-right font-black ${mt5Signal
              ? mt5SignalStatusClassName(mt5Signal)
              : trade.status === 'sl-hit' ? 'text-rose-700' : 'text-emerald-700'
            }`}>
              <ZoneTableTapAge barsAgo={latestZoneTapBarsAgo(zone, displayCandles)}>
              <ZoneEntryReadinessText readiness={zoneReadiness(zone, trade)} compactLabel={
                completedStatus ?? <>{mt5Signal
                  ? mt5SignalStatusLabel(mt5Signal) : <TradeStatusText trade={trade} />}</>
              } />
              </ZoneTableTapAge>
              {bestTrendlineBadge(trade)}
            </td>
          </tr>
          <TradeDetailsRow trade={trade} colSpan={5} mt5Signal={mt5Signal} zoneTimeframe={granularity} fillEvidence={pullbackFillEvidence}
            entryCandles={tableTimeframeData[trade.signal.timeframe]?.candles} />
        </React.Fragment>
      );
    })}
    </>
  );
  const hasZoneTableContent = React.Children.toArray(zoneTableContent.props.children).length > 0;
  const [showZoneTable, toggleZoneTable] = useAutoExpandedTable(hasZoneTableContent);
  const toolbarRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const toolbar = toolbarRef.current;
    if (!toolbar) return;
    const fitMenus = () => {
      const available = Math.max(0, window.innerHeight - toolbar.getBoundingClientRect().bottom - 16);
      toolbar.style.setProperty('--dashboard-menu-space', `${available}px`);
    };
    const observer = new ResizeObserver(fitMenus);
    observer.observe(toolbar);
    window.addEventListener('resize', fitMenus);
    document.addEventListener('scroll', fitMenus, true);
    fitMenus();
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', fitMenus);
      document.removeEventListener('scroll', fitMenus, true);
    };
  }, []);

  return (
    <section className="dashboard-layout flex h-full min-w-0 w-full flex-col overflow-auto bg-slate-100 p-2 sm:p-4">
      <div className="flex min-h-full min-w-0 w-full flex-1 shrink-0 flex-col rounded-xl border border-slate-200 bg-white shadow-sm">
        <div ref={toolbarRef} className="dashboard-toolbar relative flex shrink-0 flex-wrap items-center gap-1.5 rounded-t-xl border-b border-slate-200 bg-white px-2.5 py-1">
          <div className="flex items-center gap-1 pr-1.5 border-r border-slate-200">
            <div className="grid h-5 w-5 place-items-center rounded-full bg-amber-100 text-[6px] font-black text-amber-700">
              {marketSymbol === 'XAUUSD' ? 'Au' : 'FX'}
            </div>
            <div>
              <select
                value={marketSymbol}
                onChange={(event) => changeMarketSymbol(event.target.value as OandaMarketSymbol)}
                className="max-w-40 cursor-pointer border-0 bg-transparent p-0 text-[9px] font-black leading-none text-slate-900 outline-none"
                aria-label="OANDA market symbol"
              >
                {OANDA_MARKET_SYMBOLS.map((symbol) => (
                  <option key={symbol} value={symbol}>{oandaMarketSymbolConfig(symbol).displayName}</option>
                ))}
              </select>
              <div className="mt-0.5 text-[6px] font-bold leading-none tracking-wider text-slate-500">
                {marketConfig.shortName} · {replayIndex !== null ? 'OANDA REPLAY' : liveChartDataSource}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {TIMEFRAMES.map((timeframe) => (
              <button
                key={timeframe.value}
                onClick={() => changeTimeframe(timeframe.value)}
                className={`rounded-full border px-2 py-0.5 text-[9px] font-black transition ${
                  granularity === timeframe.value
                    ? 'border-slate-900 bg-slate-900 text-white shadow-sm'
                    : 'border-transparent text-slate-600 hover:border-slate-200 hover:bg-slate-100 hover:text-slate-950'
                }`}
              >
                {timeframe.label}
              </button>
            ))}
          </div>

          <div
            className="flex items-center gap-0.5"
            title={replayIndex !== null
              ? 'Replay uses OANDA historical candles. Exit replay to choose the live chart source.'
              : 'This changes the chart feed only. Automatic execution always uses MT5 broker candles.'}
          >
            <span className="px-1 text-[9px] font-black tracking-wide text-slate-400">DATA</span>
            {(['MT5', 'OANDA'] as const).map((dataSource) => (
              <button
                key={dataSource}
                type="button"
                onClick={() => changeLiveChartDataSource(dataSource)}
                disabled={replayIndex !== null || (dataSource === 'MT5' && !marketConfig.mt5AutomationEnabled)}
                className={`rounded-full border px-2 py-0.5 text-[9px] font-black transition disabled:cursor-not-allowed disabled:opacity-45 ${
                  replayIndex === null && liveChartDataSource === dataSource
                    ? dataSource === 'MT5'
                      ? 'border-emerald-600 bg-emerald-600 text-white shadow-sm'
                      : 'border-amber-500 bg-amber-500 text-white shadow-sm'
                    : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-white hover:text-slate-900'
                }`}
              >
                {dataSource}
              </button>
            ))}
          </div>

          {canAdmin && <><select
            aria-label="MT5 account"
            value={terminalId}
            onChange={(event) => onTerminalChange?.(event.target.value as 'primary' | 'secondary')}
            className="rounded-full border border-slate-300 bg-white px-2 py-0.5 text-[9px] font-black"
          >
            <option value="primary">ACCOUNT 1</option>
            <option value="secondary">ACCOUNT 2</option>
          </select>
          <div className="relative">
            <button
              type="button"
              onClick={() => setMt5SettingsOpen((visible) => !visible)}
              className={`whitespace-nowrap rounded-full border px-2 py-0.5 text-[9px] font-black transition ${
                mt5Status?.config.enabled
                  ? mt5Status.config.dryRun || mt5Status.marketData?.fresh !== true
                    ? 'border-amber-300 bg-amber-50 text-amber-800'
                    : 'border-emerald-300 bg-emerald-50 text-emerald-800'
                  : 'border-slate-300 bg-slate-50 text-slate-600'
              }`}
              title="Open MT5 automatic execution settings"
            >
              <span className={`mr-1 inline-block h-1.5 w-1.5 rounded-full ${
                mt5Status?.bridge.connected && mt5Status.marketData?.fresh
                  ? 'bg-emerald-500' : 'bg-slate-400'
              }`} />
              MT5 {mt5Status?.config.enabled
                ? mt5Status.config.dryRun
                  ? 'DRY RUN'
                  : mt5Status.marketData?.fresh ? 'AUTO ON' : 'AUTO WAIT'
                : 'OFF'}
            </button>
            {mt5SettingsOpen && mt5Status && (
              <div className="dashboard-toolbar-menu absolute right-0 top-full z-[70] mt-1 w-64 max-w-[calc(100vw_-_16px)] overflow-auto overscroll-contain rounded-lg border border-slate-200 bg-white p-3 text-[10px] shadow-xl">
                <div className="sticky top-0 z-10 mb-2 flex items-center justify-between border-b border-slate-100 bg-white pb-2">
                  <div>
                    <div className="font-black text-slate-800">MT5 AUTO EXECUTION ? ACCOUNT {terminalId === 'primary' ? '1' : '2'}</div>
                    <div className={mt5Status.bridge.connected ? 'text-emerald-700' : 'text-rose-700'}>
                      Bridge {mt5Status.bridge.connected ? 'connected' : 'disconnected'}
                      {mt5Status.bridge.managedByServer ? ' · local server' : ''}
                    </div>
                  </div>
                  <button type="button" onClick={() => setMt5SettingsOpen(false)} className="text-slate-400">✕</button>
                </div>
                <div className="mb-2 space-y-1">
                  <div className="text-[9px] text-slate-500">Shared strategy ? separate account risk limits</div>
                  {terminalAccounts.map((account) => (
                    <button key={account.id} type="button" onClick={() => onTerminalChange?.(account.id)}
                      className={`w-full rounded border p-2 text-left ${account.id === terminalId ? 'border-indigo-300 bg-indigo-50' : 'border-slate-200'}`}>
                      <div className="flex justify-between font-bold">
                        <span>{account.label} ? {account.account ?? 'Not connected'}</span>
                        <span className={account.connected ? 'text-emerald-700' : 'text-rose-700'}>{account.connected ? 'Connected' : 'Offline'}</span>
                      </div>
                      <div>{account.server} ? {account.enabled ? account.dryRun ? 'Dry Run' : 'Auto ON' : 'Auto OFF'}</div>
                      <div>Intraday {mt5StrategyRiskPercent(account, 'INTRADAY')}% · Scalping {mt5StrategyRiskPercent(account, 'SCALPING')}% · Scalp 1:1 {mt5StrategyRiskPercent(account, 'SCALP_1_1')}% · Bollinger M5 {mt5StrategyRiskPercent(account, 'BOLLINGER_M5')}%</div>
                      <div>Daily limit {account.maximumDailyLossPercent}%</div>
                    </button>
                  ))}
                </div>
                <div className="mb-2 flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => void controlMt5Bridge('start')}
                    disabled={mt5Status.bridge.connected || mt5Status.bridge.processRunning}
                    className="flex-1 rounded border border-emerald-200 bg-emerald-50 px-2 py-1 font-black text-emerald-700 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    START BRIDGE
                  </button>
                  <button
                    type="button"
                    onClick={() => void controlMt5Bridge('stop')}
                    disabled={!mt5Status.bridge.processRunning}
                    className="flex-1 rounded border border-rose-200 bg-rose-50 px-2 py-1 font-black text-rose-700 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    STOP BRIDGE
                  </button>
                </div>
                {mt5SettingsSaveError && <div role="alert" className="mb-2 rounded border border-rose-200 bg-rose-50 p-1.5 text-rose-700">
                  Settings were not saved: {mt5SettingsSaveError}
                </div>}
                {mt5BridgeControlError && (
                  <div className="mb-2 rounded border border-rose-200 bg-rose-50 p-1.5 text-rose-700">
                    {mt5BridgeControlError}
                  </div>
                )}
                <label className="mb-2 flex items-center justify-between font-bold text-slate-700">
                  <span>
                    Auto Trading:{' '}
                    <b className={mt5Status.config.enabled ? 'text-emerald-700' : 'text-rose-700'}>
                      {mt5Status.config.enabled ? 'ON' : 'OFF'}
                    </b>
                  </span>
                  <input
                    type="checkbox"
                    checked={mt5Status.config.enabled}
                    onChange={(event) => void updateMt5Config({ enabled: event.target.checked })}
                  />
                </label>
                <label className="mb-2 flex items-center justify-between font-bold text-slate-700">
                  <span>
                    Send Trades to MT5:{' '}
                    <b className={!mt5Status.config.dryRun ? 'text-emerald-700' : 'text-rose-700'}>
                      {!mt5Status.config.dryRun ? 'YES' : 'NO'}
                    </b>
                  </span>
                  <input
                    type="checkbox"
                    checked={!mt5Status.config.dryRun}
                    onChange={(event) => void updateMt5Config({ dryRun: !event.target.checked })}
                  />
                </label>
                <fieldset className="mb-2 rounded border border-slate-200 bg-slate-50 p-2">
                  <legend className="px-1 font-bold text-slate-700">Allowed Trade Styles</legend>
                  <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1">
                    <label className="flex items-center gap-1 font-bold text-slate-700">
                      <input
                        type="checkbox"
                        checked={mt5Status.config.scalpingEnabled}
                        onChange={(event) => void updateMt5Config({ scalpingEnabled: event.target.checked })}
                      />
                      Scalping
                    </label>
                    <label className="flex items-center gap-1 font-bold text-slate-700">
                      <input
                        type="checkbox"
                        checked={mt5Status.config.intradayEnabled}
                        onChange={(event) => void updateMt5Config({ intradayEnabled: event.target.checked })}
                      />
                      Intraday
                    </label>
                    <label className="flex items-center gap-1 font-bold text-cyan-800">
                      <input type="checkbox" aria-label="Enable Scalp 1:1"
                        checked={mt5Status.config.scalpOneToOneEnabled === true}
                        onChange={event => void updateMt5Config({ scalpOneToOneEnabled: event.target.checked })} />
                      Scalp 1:1
                    </label>
                    <label className="flex items-center gap-1 font-bold text-blue-800">
                      <input type="checkbox" aria-label="Enable Bollinger M5"
                        checked={mt5Status.config.bollingerM5Enabled === true}
                        onChange={event => void updateMt5Config({ bollingerM5Enabled: event.target.checked })} />
                      Bollinger M5
                    </label>
                  </div>
                  <span className="mt-1 block text-[8px] font-semibold text-slate-500">
                    Gold scalping uses M15/H1 zones with M1/M5 confirmation. Each style can be enabled independently.
                    {' '}OFF hides that style across the dashboard and stops its alerts and new orders.
                    {' '}Bollinger chart studies remain available with automatic trading OFF.
                  </span>
                </fieldset>
                <fieldset className="mb-2 rounded border border-slate-200 bg-slate-50 p-2">
                  <legend className="px-1 font-bold text-slate-700">Allowed Trade Timeframes</legend>
                  <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    {MT5_ENTRY_TIMEFRAME_OPTIONS.map((timeframe) => {
                      const currentTimeframes = mt5Status.config.enabledTimeframes
                        ?? MT5_DEFAULT_ENABLED_TIMEFRAMES;
                      const checked = currentTimeframes.includes(timeframe);
                      return (
                        <label key={timeframe} className="flex items-center gap-1 font-bold text-slate-700">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(event) => {
                              const enabledTimeframes = event.target.checked
                                ? [...currentTimeframes, timeframe]
                                : currentTimeframes.filter((item) => item !== timeframe);
                              void updateMt5Config({ enabledTimeframes });
                            }}
                          />
                          {timeframe}
                        </label>
                      );
                    })}
                  </div>
                  <span className="mt-1 block text-[8px] font-semibold text-slate-500">
                    OFF blocks that timeframe everywhere. M1 OFF blocks M1 setup, M1 engulfing,
                    and every MTF trade related to M1.
                  </span>
                </fieldset>
                <label className="mb-2 block font-bold text-slate-700">
                  Scalping risk per trade
                  <select aria-label="Scalping risk per trade"
                    value={mt5StrategyRiskPercent(mt5Status.config, 'SCALPING')}
                    onChange={event => void updateMt5Config({ scalpingRiskPercent: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1">
                    {MT5_RISK_PERCENT_OPTIONS.map(risk => <option key={risk} value={risk}>{risk}%</option>)}
                  </select>
                </label>
                <label className="mb-2 block font-bold text-slate-700">
                  Intraday risk per trade
                  <select
                    aria-label="Intraday risk per trade"
                    value={mt5StrategyRiskPercent(mt5Status.config, 'INTRADAY')}
                    onChange={(event) => void updateMt5Config({ intradayRiskPercent: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1"
                  >
                    {MT5_RISK_PERCENT_OPTIONS.map((riskPercent) => (
                      <option key={riskPercent} value={riskPercent}>{riskPercent}%</option>
                    ))}
                  </select>
                </label>
                <label className="mb-2 block font-bold text-blue-800">
                  Bollinger M5 risk per trade (one entry)
                  <select aria-label="Bollinger M5 risk per trade" value={mt5StrategyRiskPercent(mt5Status.config, 'BOLLINGER_M5')}
                    onChange={event => void updateMt5Config({ bollingerM5RiskPercent: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-blue-200 bg-white px-2 py-1">
                    {MT5_RISK_PERCENT_OPTIONS.map(risk => <option key={risk} value={risk}>{risk}%</option>)}
                  </select>
                </label>
                <label className="mb-2 block font-bold text-cyan-800">
                  Scalp 1:1 risk per trade
                  <select aria-label="Scalp 1:1 risk per trade"
                    value={mt5Status.config.scalpOneToOneRiskPercent ?? 0.25}
                    onChange={event => void updateMt5Config({ scalpOneToOneRiskPercent: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-cyan-200 bg-white px-2 py-1">
                    {SCALP_ONE_TO_ONE_RISK_OPTIONS.map(risk => <option key={risk} value={risk}>{risk}%</option>)}
                  </select>
                </label>
                <label className="mb-2 block font-bold text-slate-700">
                  Daily loss limit (%)
                  <select
                    aria-label="Daily loss limit percent"
                    value={mt5Status.config.maximumDailyLossPercent}
                    onChange={(event) => void updateMt5Config({ maximumDailyLossPercent: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1"
                  >
                    {[1, 2, 3, 4, 5].map((lossPercent) => (
                      <option key={lossPercent} value={lossPercent}>{lossPercent}%</option>
                    ))}
                  </select>
                  <span className="mt-1 block text-[8px] font-semibold text-slate-500">Maximum 5%. Closed and floating bot losses count together.</span>
                </label>
                <div className="mb-2 rounded border border-indigo-100 bg-indigo-50 p-2 text-slate-700">
                  <div className="mb-1 font-black text-indigo-800">Today's bot loss limit</div>
                  {mt5Status.bridge.connected && dailyRisk?.available ? <>
                    <div>Daily limit: <b>{dailyRiskMoney(dailyRisk.limitMoney)}</b></div>
                    <div>Loss so far: <b>{dailyRiskMoney(dailyRisk.usedMoney)}</b></div>
                    <div>Allowance left: <b>{dailyRiskMoney(dailyRisk.remainingMoney)}</b></div>
                    <div role="status" className={`mt-2 font-black ${dailyRisk.limitReached || dailyRisk.riskUnbounded || dailyRisk.availableRiskMoney <= 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                      {dailyRisk.limitReached ? 'Daily limit reached. No new bot trades today.'
                        : dailyRisk.riskUnbounded ? 'New bot trades paused. An open trade or order needs a stop loss.'
                          : dailyRisk.availableRiskMoney <= 0 ? 'New bot trades paused. Open trades have reserved the allowance.'
                            : 'Daily limit has not been reached.'}
                    </div>
                    <div className="mt-1 text-[8px] text-slate-500">Resets at midnight Nepal time.</div>
                    <details className="mt-2 text-[8px] text-slate-500">
                      <summary className="cursor-pointer font-bold">More details</summary>
                      <div className="mt-1">Starting balance: <b>{dailyRiskMoney(dailyRisk.startingBalance)}</b></div>
                      <div>Daily limit setting: <b>{dailyRisk.limitPercent.toFixed(2)}%</b></div>
                      <div>Loss from closed bot trades: <b>{dailyRiskMoney(dailyRisk.realizedLossMoney)}</b></div>
                      <div>Current loss on open bot trades: <b>{dailyRiskMoney(dailyRisk.floatingLossMoney)}</b></div>
                      <div>Set aside for open trades and orders: <b>{dailyRiskMoney(dailyRisk.reservedRiskMoney)}</b></div>
                      <div>Available for new trades: <b>{dailyRiskMoney(dailyRisk.availableRiskMoney)}</b></div>
                    </details>
                  </> : <div className="text-amber-700">
                    {dailyRisk?.available === false ? dailyRisk.error : 'Waiting for fresh MT5 daily risk data.'}
                  </div>}
                </div>
                <Mt5CapitalPanel terminalId={terminalId === 'secondary' ? 'secondary' : 'primary'} compact
                  floating={mt5Status.bridge.connected && mt5Status.bridge.overallProfit?.available ? mt5Status.bridge.overallProfit.floatingMoney : 0} />
                <label className="mb-2 block font-bold text-slate-700">
                  Maximum open trades (max 10)
                  <select
                    aria-label="Maximum open trades"
                    value={mt5Status.config.maximumOpenTrades}
                    onChange={(event) => void updateMt5Config({ maximumOpenTrades: Number(event.target.value) })}
                    className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1"
                  >
                    {Array.from({ length: 10 }, (_, index) => index + 1).map((tradeCount) => (
                      <option key={tradeCount} value={tradeCount}>{tradeCount}</option>
                    ))}
                  </select>
                </label>
                <div className="rounded bg-slate-50 p-2 leading-relaxed text-slate-600">
                  Account: <b>{mt5Status.bridge.account || 'Waiting for MT5 login'}</b><br />
                  Server: <b>{mt5Status.bridge.server || '—'}</b><br />
                  Symbol: <b>{mt5Status.config.brokerSymbol}</b><br />
                  {(mt5Status.bridge.symbolCandidates?.length ?? 0) > 1 && <label className="mb-1 block">
                    Broker Gold symbol
                    <select
                      aria-label="Broker Gold symbol"
                      value={mt5Status.bridge.symbolResolved ? mt5Status.bridge.brokerSymbol : ''}
                      onChange={(event) => {
                        if (event.target.value) void updateMt5Config({ brokerSymbol: event.target.value,
                          brokerSymbolAccount: mt5Status.bridge.account, brokerSymbolServer: mt5Status.bridge.server });
                      }}
                      className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1"
                    >
                      <option value="" disabled>Choose Gold symbol</option>
                      {mt5Status.bridge.symbolCandidates?.map((symbol) => <option key={symbol} value={symbol}>{symbol}</option>)}
                    </select>
                  </label>}
                  {mt5Status.bridge.message && <div className="mb-1 text-amber-700">{mt5Status.bridge.message}</div>}
                  Execution candles: <b className={mt5Status.marketData?.fresh ? 'text-emerald-700' : 'text-amber-700'}>
                    MT5 BROKER · {mt5Status.marketData?.fresh ? 'FRESH' : 'WAITING'}
                  </b><br />
                  MT5 Capital: <b>{mt5Status.bridge.balance === undefined
                    ? '—'
                    : `${mt5Status.bridge.currency || '$'} ${mt5Status.bridge.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</b><br />
                  Equity: <b>{mt5Status.bridge.equity === undefined
                    ? '—'
                    : `${mt5Status.bridge.currency || '$'} ${mt5Status.bridge.equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</b><br />
                  {(['INTRADAY', 'SCALPING', 'SCALP_1_1', 'BOLLINGER_M5'] as const).map(style => <div key={style}>
                    {style === 'BOLLINGER_M5' ? 'Bollinger M5' : style === 'SCALP_1_1' ? 'Scalp 1:1' : style === 'INTRADAY' ? 'Intraday' : 'Scalping'} cash risk: <b>{mt5Status.bridge.equity === undefined
                      ? '—' : `${mt5Status.bridge.currency || '$'} ${(mt5Status.bridge.equity * mt5StrategyRiskPercent(mt5Status.config, style) / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}</b>
                  </div>)}
                  Waiting to send: <b>{mt5Status.counts.QUEUED ?? 0}</b> · Open MT5 trades: <b>{mt5Status.positions.length}</b><br />
                  {mt5Status.positions.filter(position => position.magic === 0).map(position => (
                    <ManualTradeTimeframeControl key={`${mt5Status.bridge.account}:${position.ticket}:${position.openedAtMsc}`}
                      position={position} disabled={!mt5Status.bridge.connected || manualTimeframeSaving !== null}
                      onChange={timeframe => void updateManualTradeTimeframe(position, timeframe)} />
                  ))}
                  {manualTimeframeError && <div className="mt-1 text-rose-700" role="alert">{manualTimeframeError}</div>}
                  Process: <b>{mt5Status.bridge.processRunning
                    ? `RUNNING · PID ${mt5Status.bridge.processId ?? '—'}`
                    : mt5Status.bridge.connected ? 'MANUALLY STARTED' : 'STOPPED'}</b><br />
                  Live orders also require <b>MT5_ALLOW_LIVE_EXECUTION=YES</b> in .env.mt5.
                </div>
                {(mt5Status.bridge.logs?.length ?? 0) > 0 && (
                  <div className="mt-2 max-h-24 overflow-auto rounded bg-slate-950 p-2 font-mono text-[8px] leading-relaxed text-slate-200">
                    {mt5Status.bridge.logs!.slice(-8).map((line, index) => (
                      <div key={`${index}:${line}`} className="whitespace-pre-wrap break-words">{line}</div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          </>}
          <div className="relative flex items-center border-l border-slate-200 pl-1">
            <button
              type="button"
              onClick={() => {
                setShowIndicatorControls((visible) => !visible);
                setShowDrawingTools(false);
              }}
              className={`whitespace-nowrap rounded-full border px-2 py-0.5 text-[9px] font-black transition ${
                showIndicatorControls
                  ? 'border-indigo-300 bg-indigo-100 text-indigo-800'
                  : 'border-slate-300 bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
              title={showIndicatorControls ? 'Minimize indicator controls' : 'Show indicator controls'}
              aria-expanded={showIndicatorControls}
            >
              INDICATORS {showIndicatorControls ? '▴' : '▾'}
            </button>
            {showIndicatorControls && (
            <div className="indicator-controls-panel absolute right-0 top-full z-[60] mt-1 w-[min(720px,calc(100vw-2rem))] rounded-lg border border-indigo-100 bg-white p-2 shadow-xl ring-1 ring-slate-900/5">
              <div className="relative mb-1.5 flex min-h-8 items-center justify-center border-b border-slate-100 pb-1.5 pr-8">
                <div className="text-center">
                  <div className="text-[10px] font-black tracking-wide text-slate-700">INDICATOR CONTROLS</div>
                  <div className="text-[8px] font-bold tracking-wide text-slate-400">SELECT EACH INDICATOR ON OR OFF</div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowIndicatorControls(false)}
                  className="absolute right-0 top-0 rounded-full border border-slate-200 px-1.5 py-0.5 text-[8px] font-black text-slate-500 hover:bg-slate-100"
                  aria-label="Close indicator controls"
                >
                  ✕
                </button>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-1">
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowStructureOptions((visible) => !visible)}
                className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                  showStructureOptions
                    ? 'border-indigo-300 bg-indigo-100 text-indigo-800'
                    : 'border-indigo-200 bg-indigo-50 text-indigo-700'
                }`}
                title="Open structure indicator options"
                aria-label="Open structure indicator options"
                aria-expanded={showStructureOptions}
              >
                STRUCTURE {showStructureOptions ? '▴' : '▾'}
              </button>
              {showStructureOptions && (
                <div className="absolute left-0 top-full z-50 mt-1 w-64 rounded-lg border border-indigo-100 bg-white p-2 shadow-xl ring-1 ring-slate-900/5">
                  <div className="mb-1.5 border-b border-slate-100 pb-1 text-[9px] font-black text-slate-700">STRUCTURE INDICATORS</div>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => setShowStructure((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showStructure ? 'border-indigo-200 bg-indigo-50 text-indigo-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide HH, HL, LH and LL structure markings"
                    >
                      Structure {showStructure ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowMgZones((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showMgZones ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide TJL1, TJL2, QML, SBR, RBS, DT and DB zones"
                    >
                      ZONE {showMgZones ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowSupplyDemand((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showSupplyDemand ? 'border-cyan-200 bg-cyan-50 text-cyan-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide supply and demand zones; available only on H1, H4 and D"
                    >
                      S/D 1H+ {showSupplyDemand ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowIss((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showIss ? 'border-amber-200 bg-amber-50 text-amber-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide ISS 0–5 wave markings"
                    >
                      ISS 5-WAVE {showIss ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowInternal((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showInternal ? 'border-violet-200 bg-violet-50 text-violet-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide post-ISS internal structure, zones, BOS and CHoCH"
                    >
                      INT STRUCTURE {showInternal ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowEngulfing((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showEngulfing ? 'border-blue-200 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide confirmed Type 1–4 engulfing signals and their mapped fallback timeframe"
                    >
                      ENGULFING {showEngulfing ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowTradeLevels((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showTradeLevels ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide trade drawings. Open MT5 Scalp positions remain visible."
                    >
                      LONG/SHORT POSITION {showTradeLevels ? 'ON' : 'OFF'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowInvalidZones((value) => !value)}
                      className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                        showInvalidZones ? 'border-slate-400 bg-slate-200 text-slate-700' : 'border-slate-200 bg-white text-slate-500'
                      }`}
                      title="Show or hide rejected, invalidated, and superseded zones"
                    >
                      INVALID ZONES {showInvalidZones ? 'ON' : 'OFF'}
                    </button>
                  </div>
                </div>
              )}
            </div>
            <div className="relative flex">
              <button
                type="button"
                onClick={() => setShowTrendlines((value) => !value)}
                className={`whitespace-nowrap rounded-l-full border border-r-0 px-1.5 py-0.5 text-[8px] font-black transition ${
                  showTrendlines ? 'border-violet-200 bg-violet-50 text-violet-700' : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Show or hide continuation and breakout trend lines"
              >
                TREND LINES {showTrendlines ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                onClick={() => setShowTrendlineOptions((visible) => !visible)}
                className={`rounded-r-full border px-1 py-0.5 text-[8px] font-black transition ${
                  showTrendlineOptions
                    ? 'border-violet-300 bg-violet-100 text-violet-800'
                    : showTrendlines
                      ? 'border-violet-200 bg-violet-50 text-violet-700'
                      : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Open trend line options"
                aria-label="Open trend line options"
                aria-expanded={showTrendlineOptions}
              >
                {showTrendlineOptions ? '▴' : '▾'}
              </button>
              {showTrendlineOptions && (
                <div className="absolute left-0 top-full z-40 mt-1 rounded-lg border border-violet-100 bg-white p-2 shadow-xl ring-1 ring-slate-900/5">
                  <button
                    type="button"
                    onClick={() => setShowAllTrendlines((value) => !value)}
                    className={`whitespace-nowrap rounded-full border px-2 py-1 text-[8px] font-black transition ${
                      showAllTrendlines ? 'border-violet-200 bg-violet-50 text-violet-700' : 'border-slate-200 bg-white text-slate-500'
                    }`}
                    title="Show all active trend lines, including those more than 400 pips from live price"
                  >
                    SHOW ALL TREND LINES {showAllTrendlines ? 'ON' : 'OFF'}
                  </button>
                  <fieldset className="mt-2 border-t border-violet-100 pt-2">
                    <legend className="px-1 text-[9px] font-bold text-violet-700">TRENDLINE TIMEFRAMES</legend>
                    <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                      {DRAWING_TIMEFRAME_ORDER.map((timeframe) => (
                        <label key={timeframe} className="flex cursor-pointer items-center gap-2 whitespace-nowrap rounded px-1 py-1 text-[10px] text-slate-700 hover:bg-violet-50">
                          <input type="checkbox" checked={trendlineTimeframes.has(timeframe)}
                            onChange={() => setTrendlineTimeframes((current) => {
                              const next = new Set(current);
                              if (next.has(timeframe)) next.delete(timeframe);
                              else next.add(timeframe);
                              return next;
                            })}
                            className="h-3 w-3 accent-violet-600" />
                          {GRANULARITY_LABELS[timeframe]}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                </div>
              )}
            </div>
            <div className="relative flex">
              <button
                onClick={() => setShowFib((value) => !value)}
                className={`whitespace-nowrap rounded-l-full border border-r-0 px-1.5 py-0.5 text-[8px] font-black transition ${
                  showFib ? 'border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700' : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Master switch for all Fibonacci confluence markings"
              >
                FIB {showFib ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                onClick={() => setShowFibOptions((visible) => !visible)}
                className={`rounded-r-full border px-1 py-0.5 text-[8px] font-black transition ${
                  showFibOptions
                    ? 'border-fuchsia-300 bg-fuchsia-100 text-fuchsia-800'
                    : showFib
                      ? 'border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700'
                      : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Open individual FIB marking options"
                aria-label="Open individual FIB marking options"
                aria-expanded={showFibOptions}
              >
                {showFibOptions ? '▴' : '▾'}
              </button>
              {showFibOptions && (
                <div className="absolute left-0 top-full z-40 mt-1 w-56 rounded-lg border border-fuchsia-100 bg-white p-2 shadow-xl ring-1 ring-slate-900/5">
                  <div className="mb-1.5 flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <div>
                      <div className="text-[10px] font-black tracking-wide text-slate-700">FIB MARKINGS</div>
                      <div className="text-[8px] font-bold text-slate-400">SELECT FIBS SEPARATELY</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setFibVisibility({ ...DEFAULT_FIB_VISIBILITY });
                        setFibPreviousVisibility({ ...DEFAULT_FIB_VISIBILITY });
                        setChochFibVisibility([false, false, false, false]);
                        setShowAlignedH1Fib(false);
                      }}
                      disabled={!hasAnyFibMarking}
                      className={`rounded-full border px-2 py-1 text-[8px] font-black leading-none transition ${
                        hasAnyFibMarking
                          ? 'border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700 hover:bg-fuchsia-100'
                          : 'border-slate-200 bg-slate-50 text-slate-400'
                      }`}
                      title="Turn off every FIB marking"
                    >
                      CLEAR
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => void updateMt5Config({ mtfLtfFibRequired: !mtfLtfFibRequired })}
                    disabled={!canAdmin || !mt5Status}
                    className={`mb-1.5 w-full whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                      mtfLtfFibRequired
                        ? 'border-fuchsia-200 bg-fuchsia-50 text-fuchsia-700'
                        : 'border-slate-200 bg-white text-slate-500'
                    }`}
                    title="Require the lower-timeframe Fib for MTF CHoCH entries; the zone midpoint and engulfing are always required"
                  >
                    MTF LTF FIB REQUIRED {mtfLtfFibRequired ? 'ON' : 'OFF'}
                  </button>
                  <div className="grid grid-cols-2 gap-1">
                    {FIB_VISIBILITY_OPTIONS.map(renderFibOptionButton)}
                    <button
                      type="button"
                      onClick={() => {
                        setShowInternalFibOptions((visible) => !visible);
                        if (showInternalFibOptions
                          && expandedFibOption
                          && INTERNAL_FIB_VISIBILITY_OPTIONS.some(({ key }) => key === expandedFibOption)) {
                          setExpandedFibOption(null);
                        }
                      }}
                      className={`flex h-7 items-center justify-between rounded-md border px-1.5 text-[8px] font-black leading-none transition ${
                        showInternalFibOptions
                          ? 'border-violet-300 bg-violet-100 text-violet-800'
                          : INTERNAL_FIB_VISIBILITY_OPTIONS.some(({ key }) => (
                            fibVisibility[key] || fibPreviousVisibility[key]
                          ))
                            ? 'border-violet-200 bg-violet-50 text-violet-700'
                            : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'
                      }`}
                      aria-expanded={showInternalFibOptions}
                    >
                      <span>INTERNAL</span>
                      <span className="ml-1 rounded-full bg-violet-200 px-1 py-0.5 text-[8px] text-violet-800">
                        {showInternalFibOptions ? '−' : '+'}
                      </span>
                    </button>
                  </div>
                  {showInternalFibOptions && (
                    <div className="mt-1.5 rounded-md border border-violet-100 bg-violet-50/60 p-1.5">
                      <div className="mb-1 text-[8px] font-black text-violet-800">INTERNAL FIB</div>
                      <div className="grid grid-cols-2 gap-1">
                        {INTERNAL_FIB_VISIBILITY_OPTIONS.map(renderFibOptionButton)}
                      </div>
                    </div>
                  )}
                  {expandedFibOption && !isSingleFibMarkingKey(expandedFibOption) && (
                    <div className="mt-1.5 rounded-md border border-fuchsia-100 bg-fuchsia-50/60 p-1.5">
                      <div className="mb-1 text-[8px] font-black text-fuchsia-800">
                        {ALL_FIB_VISIBILITY_OPTIONS.find(({ key }) => key === expandedFibOption)
                          ?.label.replace(' MARKING', '')} SETUP
                      </div>
                      <div className="grid grid-cols-2 gap-1">
                        {expandedFibOption === 'choch' ? (
                          ['LATEST', 'PREVIOUS 1', 'PREVIOUS 2', 'PREVIOUS 3'].map((label, index) => {
                            const enabled = chochFibVisibility[index];
                            return (
                              <button
                                key={label}
                                type="button"
                                onClick={() => setChochFibVisibility((current) => current.map((value, slot) => (
                                  slot === index ? !value : value
                                )) as ChochFibVisibility)}
                                className={`flex items-center justify-between whitespace-nowrap rounded border px-1.5 py-1 text-[8px] font-black leading-none ${
                                  enabled
                                    ? 'border-fuchsia-300 bg-fuchsia-200 text-fuchsia-800'
                                    : 'border-slate-200 bg-white text-slate-500'
                                }`}
                              >
                                <span>{label}</span>
                                <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
                                  enabled
                                    ? 'bg-fuchsia-300 text-fuchsia-900'
                                    : 'bg-slate-200 text-slate-500'
                                }`}>
                                  {enabled ? 'ON' : 'OFF'}
                                </span>
                              </button>
                            );
                          })
                        ) : <>
                          <button
                            type="button"
                            onClick={() => setFibVisibility((current) => ({
                              ...current,
                              [expandedFibOption]: !current[expandedFibOption],
                            }))}
                            className={`flex items-center justify-between whitespace-nowrap rounded border px-1.5 py-1 text-[8px] font-black leading-none ${
                              fibVisibility[expandedFibOption]
                                ? 'border-fuchsia-300 bg-fuchsia-200 text-fuchsia-800'
                                : 'border-slate-200 bg-white text-slate-500'
                            }`}
                          >
                            <span>LATEST</span>
                            <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
                              fibVisibility[expandedFibOption]
                                ? 'bg-fuchsia-300 text-fuchsia-900'
                                : 'bg-slate-200 text-slate-500'
                            }`}>
                              {fibVisibility[expandedFibOption] ? 'ON' : 'OFF'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setFibPreviousVisibility((current) => ({
                              ...current,
                              [expandedFibOption]: !current[expandedFibOption],
                            }))}
                            className={`flex items-center justify-between whitespace-nowrap rounded border px-1.5 py-1 text-[8px] font-black leading-none ${
                              fibPreviousVisibility[expandedFibOption]
                                ? 'border-fuchsia-300 bg-fuchsia-200 text-fuchsia-800'
                                : 'border-slate-200 bg-white text-slate-500'
                            }`}
                          >
                            <span>PREVIOUS</span>
                            <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
                              fibPreviousVisibility[expandedFibOption]
                                ? 'bg-fuchsia-300 text-fuchsia-900'
                                : 'bg-slate-200 text-slate-500'
                            }`}>
                              {fibPreviousVisibility[expandedFibOption] ? 'ON' : 'OFF'}
                            </span>
                          </button>
                          {expandedFibOption === 'h1Swing' && (
                            <button
                              type="button"
                              onClick={() => setShowAlignedH1Fib((current) => !current)}
                              className={`col-span-2 flex items-center justify-between rounded border px-1.5 py-1 text-[8px] font-black leading-none ${
                                showAlignedH1Fib
                                  ? 'border-fuchsia-300 bg-fuchsia-200 text-fuchsia-800'
                                  : 'border-slate-200 bg-white text-slate-500'
                              }`}
                              title="Show or hide the 1H swing Fib automatically when a 15m TJL zone is aligned"
                            >
                              <span>ALIGNED 1H FIB</span>
                              <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
                                showAlignedH1Fib
                                  ? 'bg-fuchsia-300 text-fuchsia-900'
                                  : 'bg-slate-200 text-slate-500'
                              }`}>
                                {showAlignedH1Fib ? 'ON' : 'OFF'}
                              </span>
                            </button>
                          )}
                        </>}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={() => {
                setShowJournal(true);
                setShowAccuracyTable(false);
                setShowAccuracyOptions(false);
              }}
              className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                showJournal
                  ? 'border-violet-300 bg-violet-100 text-violet-800'
                  : 'border-violet-200 bg-violet-50 text-violet-700'
              }`}
              title="Open the saved trading journal and export Excel or Word reports"
            >
              JOURNAL
            </button>
            <button
              onClick={() => {
                const enabled = !tradingTimeEnabled;
                setTradingTimeEnabled(enabled);
                void updateMt5Config({ tradingTimeEnabled: enabled });
              }}
              className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                tradingTimeEnabled
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                  : 'border-slate-200 bg-white text-slate-500'
              }`}
              title="Restrict dashboard and MT5 entries to the three Nepal trading sessions"
              disabled={!canAdmin}
            >
              TRADING TIME {tradingTimeEnabled ? 'ON' : 'OFF'}
            </button>
            <button
              onClick={() => {
                const enabled = !telegramMessagesEnabled;
                setTelegramMessagesEnabled(enabled);
                void updateMt5Config({ telegramMessagesEnabled: enabled });
              }}
              disabled={!canAdmin || !mt5Status}
              className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                telegramMessagesEnabled
                  ? 'border-sky-200 bg-sky-50 text-sky-700'
                  : 'border-slate-200 bg-white text-slate-500'
              }`}
              title="Send or pause Telegram trade messages"
            >
              TELEGRAM {telegramMessagesEnabled ? 'ON' : 'OFF'}
            </button>
            {(Object.keys(zoneLengthModes).length > 0 || hiddenComparisonZoneKeys.length > 0) && (
              <button
                type="button"
                onClick={() => {
                  setZoneLengthModes({});
                  setHiddenComparisonZoneKeys([]);
                }}
                className="whitespace-nowrap rounded-full border border-slate-200 bg-white px-1.5 py-0.5 text-[8px] font-black text-slate-600"
                title="Restore zones to their original positions"
              >
                RESTORE ZONE POSITIONS
              </button>
            )}
            <details className="relative">
              <summary
                className={`cursor-pointer list-none whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                  showEntryArrows
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                    : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Choose which entry arrows to display"
                aria-label="Entry arrow options"
              >
                ENTRY HISTORY {arrowStrategies.length === 3 ? 'ALL' : showEntryArrows ? `${arrowStrategies.length} SELECTED` : 'OFF'} ▾
              </summary>
              <div className="absolute left-0 top-full z-50 mt-1 w-44 rounded-md border border-emerald-200 bg-white p-2 text-[10px] shadow-lg">
                <TradeStrategyCheckboxes label="Entry arrow strategies" selected={arrowStrategies} onChange={setArrowStrategies} />
              </div>
            </details>
            <details ref={backtestingMenuRef} className="relative" onKeyDown={event => {
              if (event.key === 'Escape') { event.preventDefault(); event.currentTarget.open = false;
                event.currentTarget.querySelector('summary')?.focus(); }
            }}>
              <summary aria-label="Backtesting studies" className={`cursor-pointer list-none whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black ${
                showTrendlineStudy || showVolumeStudy || showBollingerStudy ? 'border-indigo-300 bg-indigo-100 text-indigo-800' : 'border-indigo-200 bg-indigo-50 text-indigo-700'
              }`}>BACKTESTING ▾</summary>
              <div role="group" aria-label="Backtesting study choices" className="absolute left-1/2 top-full z-[70] mt-1 w-64 max-w-[calc(100vw-2rem)] -translate-x-1/2 rounded-lg border border-indigo-200 bg-white p-1.5 text-xs shadow-xl">
                <button type="button" aria-label="Open Trendline Study" aria-pressed={showTrendlineStudy}
                  onClick={() => openBacktestingStudy('trendline')} className="flex w-full items-center justify-between rounded px-3 py-2 text-left font-semibold text-violet-800 hover:bg-violet-50">
                  Trendline Study {showTrendlineStudy && <span className="text-[9px]">OPEN</span>}
                </button>
                <button type="button" aria-label="Open Volume Engulfing Study" aria-pressed={showVolumeStudy}
                  onClick={() => openBacktestingStudy('volume')} className="flex w-full items-center justify-between rounded px-3 py-2 text-left font-semibold text-teal-800 hover:bg-teal-50">
                  Volume Engulfing Study {showVolumeStudy && <span className="text-[9px]">OPEN</span>}
                </button>
                <button type="button" aria-label="Open Bollinger M5 Study" aria-pressed={showBollingerStudy} disabled={marketSymbol !== 'XAUUSD'}
                  title={marketSymbol === 'XAUUSD' ? 'Open the Bollinger 5-minute study' : 'Select Gold / XAUUSD to use Bollinger M5'}
                  onClick={() => openBacktestingStudy('bollinger')} className="flex w-full items-center justify-between rounded px-3 py-2 text-left font-semibold text-blue-800 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-40">
                  Bollinger M5 Study {showBollingerStudy && <span className="text-[9px]">OPEN</span>}
                </button>
              </div>
            </details>
            <div className="relative flex">
              <button
                type="button"
                onClick={() => {
                  setShowAccuracyTable((value) => !value);
                }}
                className={`whitespace-nowrap rounded-l-full border border-r-0 px-1.5 py-0.5 text-[8px] font-black transition ${
                  showAccuracyTable
                    ? 'border-indigo-200 bg-indigo-50 text-indigo-700'
                    : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Show or hide completed engulfing SL, RF, TP, total, and accuracy results"
              >
                ACCURACY TABLE {showAccuracyTable ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                onClick={() => setShowAccuracyOptions((value) => !value)}
                className={`rounded-r-full border px-1 py-0.5 text-[8px] font-black transition ${
                  showAccuracyOptions
                    ? 'border-indigo-300 bg-indigo-100 text-indigo-800'
                    : showAccuracyTable
                      ? 'border-indigo-200 bg-indigo-50 text-indigo-700'
                      : 'border-slate-200 bg-white text-slate-500'
                }`}
                title="Accuracy table options"
                aria-label="Accuracy table options"
                aria-expanded={showAccuracyOptions}
              >
                ▾
              </button>
              {showAccuracyOptions && (
                <div className="absolute right-0 top-full z-50 mt-1 w-40 rounded-md border border-indigo-200 bg-white p-1.5 shadow-lg">
                  <div className="mb-1 px-1 text-[8px] font-black uppercase tracking-wide text-indigo-700">
                    Accuracy options
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAllAccuracyTrades((value) => !value);
                      setShowAccuracyTable(true);
                    }}
                    className={`flex w-full items-center justify-between whitespace-nowrap rounded border px-1.5 py-1 text-[8px] font-black leading-none ${
                      showAllAccuracyTrades
                        ? 'border-indigo-300 bg-indigo-100 text-indigo-800'
                        : 'border-slate-200 bg-white text-slate-500'
                    }`}
                    title="Show or hide every completed trade in the loaded chart history"
                  >
                    <span>SHOW ALL TRADES</span>
                    <span className={`ml-1 rounded-full px-1 py-0.5 text-[8px] ${
                      showAllAccuracyTrades
                        ? 'bg-indigo-200 text-indigo-900'
                        : 'bg-slate-200 text-slate-500'
                    }`}>
                      {showAllAccuracyTrades ? 'ON' : 'OFF'}
                    </span>
                  </button>
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowZoneComparison((value) => !value)}
              className={`whitespace-nowrap rounded-full border px-1.5 py-0.5 text-[8px] font-black transition ${
                comparisonTimeframe
                  ? 'border-sky-300 bg-sky-100 text-sky-800'
                  : 'border-slate-200 bg-white text-slate-500'
              }`}
              aria-expanded={showZoneComparison}
              title="Compare recent valid buy and sell zones from another timeframe"
            >
              HTF/LTF ZONES {comparisonTimeframe ? GRANULARITY_LABELS[comparisonTimeframe] : 'OFF'} ▾
            </button>
              </div>
              {showZoneComparison && (
                <div className="mt-2 max-h-[55vh] overflow-y-auto rounded-lg border border-sky-100 bg-sky-50/40 p-2">
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <div>
                      <div className="text-[10px] font-black text-slate-700">COMPARE HTF / LTF ZONES</div>
                      <div className="text-[8px] text-slate-500">Up to five valid buy and five valid sell zones from one timeframe</div>
                      <div className="text-[8px] text-slate-500">Use × on the chart to hide a zone; SHOW here restores it.</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setComparisonTimeframe(null);
                        setShowLtfChoch(false);
                      }}
                      className="rounded border border-slate-200 bg-white px-2 py-1 text-[8px] font-black text-slate-600 hover:bg-slate-100"
                    >
                      REMOVE ALL
                    </button>
                  </div>
                  <button
                    type="button"
                    aria-pressed={showLtfChoch}
                    disabled={granularity === 'M1'}
                    onClick={() => {
                      if (!showLtfChoch && (!comparisonTimeframe
                        || DRAWING_TIMEFRAME_ORDER.indexOf(comparisonTimeframe)
                          >= DRAWING_TIMEFRAME_ORDER.indexOf(granularity))) {
                        const preferred = MTF_MAPPINGS.find((mapping) => mapping.higher === granularity)?.lower;
                        setComparisonTimeframe(preferred ?? DRAWING_TIMEFRAME_ORDER[
                          DRAWING_TIMEFRAME_ORDER.indexOf(granularity) - 1
                        ]);
                      }
                      setShowLtfChoch((value) => !value);
                    }}
                    className={`mb-1 rounded border px-2 py-1 text-[9px] font-black ${showLtfChoch
                      ? 'border-violet-300 bg-violet-100 text-violet-800'
                      : 'border-slate-200 bg-white text-slate-600'} disabled:opacity-50`}
                    title="After a chart zone tap, show the current valid lower-timeframe TJL levels and confirmed CHoCH"
                  >
                    LTF CHocH {showLtfChoch ? 'ON' : 'OFF'}
                  </button>
                  {showLtfChoch && (
                    <div className="mb-2 text-[8px] text-slate-600">
                      After a chart zone tap, only valid or pending TJL levels from the latest lower structure appear. If TJL1 is invalid, TJL2 remains until invalidated or CHoCH is confirmed. After CHoCH, its QML, SBR/RBS, and DB/DT zones remain while valid or pending.
                    </div>
                  )}
                  <div className="mb-2 flex flex-wrap gap-1">
                    {DRAWING_TIMEFRAME_ORDER.filter((value) => value !== granularity).map((value) => {
                      const higher = DRAWING_TIMEFRAME_ORDER.indexOf(value)
                        > DRAWING_TIMEFRAME_ORDER.indexOf(granularity);
                      return (
                        <button
                          key={value}
                          type="button"
                          onClick={() => {
                            setComparisonTimeframe(value);
                            if (higher) setShowLtfChoch(false);
                          }}
                          aria-pressed={comparisonTimeframe === value}
                          className={`rounded border px-2 py-1 text-[8px] font-black ${
                            comparisonTimeframe === value
                              ? 'border-sky-400 bg-sky-100 text-sky-900'
                              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {GRANULARITY_LABELS[value]} {higher ? 'HTF' : 'LTF'}
                        </button>
                      );
                    })}
                  </div>
                  {!comparisonTimeframe ? (
                    <div className="text-[9px] text-slate-500">Choose a timeframe to show its recent zones.</div>
                  ) : !tableTimeframeData[comparisonTimeframe] ? (
                    <div className="text-[9px] text-slate-500">Loading {GRANULARITY_LABELS[comparisonTimeframe]} zones...</div>
                  ) : comparisonZones.length === 0 ? (
                    <div className="text-[9px] text-slate-500">{ltfChochContext
                      ? ltfChochContext.confirmations.length > 0
                        ? 'CHoCH confirmed; no valid or pending CHoCH zones to show.'
                        : 'Waiting for a chart zone tap or valid TJL levels from the latest lower structure.'
                      : 'No active, valid zones on this timeframe.'}</div>
                  ) : (
                    <div className="space-y-1">
                      {comparisonZones.map(({ zone, overlapsCurrentZone }) => {
                        const key = `${marketSymbol}:${comparisonTimeframe}:${zone.id}`;
                        const visible = !hiddenComparisonZoneKeys.includes(key);
                        return (
                          <button
                            key={key}
                            type="button"
                            aria-pressed={visible}
                            onClick={() => setHiddenComparisonZoneKeys((current) => (
                              current.includes(key) ? current.filter((item) => item !== key)
                                : [...current, key]
                            ))}
                            className={`flex w-full items-center justify-between gap-2 rounded border px-2 py-1 text-left text-[9px] ${
                              visible ? 'border-sky-200 bg-white text-slate-700'
                                : 'border-slate-200 bg-slate-50 text-slate-400'
                            }`}
                            title={visible ? 'Hide this comparison zone' : 'Show this comparison zone'}
                          >
                            <span className="min-w-0 truncate font-bold">
                              {zone.isBuy ? 'BUY' : 'SELL'} {zone.name} · {formatPrice(zone.bottom)}–{formatPrice(zone.top)}
                              {overlapsCurrentZone ? ' · OVERLAPS CHART ZONE' : ''}
                            </span>
                            <span className="shrink-0 font-black text-sky-700">{visible ? 'HIDE ×' : 'SHOW'}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
            )}
          </div>

          <div className="flex items-center gap-0.5 border-l border-slate-200 pl-1.5">
            {replayIndex === null ? (
              <button
                onClick={openReplaySelector}
                disabled={candles.length < 2}
                className="rounded-full border border-violet-200 bg-violet-50 px-1.5 py-px text-[7px] font-black leading-3 text-violet-700 transition hover:bg-violet-100 disabled:cursor-not-allowed disabled:opacity-50"
                title="Choose a chart bar, then start candle-by-candle replay from that point"
              >
                REPLAY
              </button>
            ) : (
              <>
                <button
                  onClick={() => setReplayIndex((index) => Math.max(1, (index ?? 1) - 1))}
                  className="rounded-full border border-violet-200 bg-white px-1.5 py-px text-[7px] font-black leading-3 text-violet-700 hover:bg-violet-50"
                  title="Previous candle"
                >
                  ‹
                </button>
                <button
                  onClick={openReplaySelector}
                  className={`rounded-full border px-1.5 py-px text-[7px] font-black leading-3 transition ${
                    replaySelecting
                      ? 'border-blue-300 bg-blue-100 text-blue-800'
                      : 'border-blue-200 bg-white text-blue-700 hover:bg-blue-50'
                  }`}
                  title="Show the blue Replay line and choose another candle"
                >
                  │ LINE
                </button>
                <button
                  onClick={() => setReplayPlaying((playing) => !playing)}
                  className="rounded-full border border-violet-200 bg-violet-50 px-1.5 py-px text-[7px] font-black leading-3 text-violet-700 hover:bg-violet-100"
                  title={replayPlaying ? 'Pause replay' : 'Play replay'}
                >
                  {replayPlaying ? '❚❚ PAUSE' : '▶ PLAY'}
                </button>
                <button
                  onClick={() => setReplayIndex((index) => Math.min(candles.length - 1, (index ?? 1) + 1))}
                  className="rounded-full border border-violet-200 bg-white px-1.5 py-px text-[7px] font-black leading-3 text-violet-700 hover:bg-violet-50"
                  title="Next candle"
                >
                  ›
                </button>
                <select
                  value={replaySpeed}
                  onChange={(event) => setReplaySpeed(Number(event.target.value))}
                  className="rounded-full border border-violet-200 bg-white px-1.5 py-px text-[7px] font-black leading-3 text-violet-700"
                  title="Replay speed"
                >
                  <option value={0.5}>0.5x</option>
                  <option value={1}>1x</option>
                  <option value={2}>2x</option>
                  <option value={5}>5x</option>
                  <option value={10}>10x</option>
                </select>
                <button
                  onClick={exitReplay}
                  className="rounded-full border border-slate-200 bg-white px-1.5 py-px text-[7px] font-black leading-3 text-slate-500 hover:bg-slate-100"
                  title="Exit replay and return to the live chart"
                >
                  LIVE
                </button>
                <span className="px-0.5 text-[7px] font-bold text-violet-700">
                  {displayCandles.length}/{candles.length}
                </span>
              </>
            )}
          </div>

          <div className="relative flex items-center">
            <button
              type="button"
              onClick={() => {
                setShowDrawingTools((visible) => !visible);
                setShowIndicatorControls(false);
              }}
              className={`whitespace-nowrap rounded-full border px-2 py-0.5 text-[9px] font-black transition ${
                activeDrawingTool
                  ? 'border-violet-400 bg-violet-600 text-white'
                  : showDrawingTools
                    ? 'border-violet-300 bg-violet-100 text-violet-800'
                    : 'border-slate-300 bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
              title="Open chart drawing tools"
              aria-expanded={showDrawingTools}
            >
              TOOLS {activeDrawingTool ? '●' : showDrawingTools ? '▴' : '▾'}
            </button>
            {showDrawingTools && (
              <div className="dashboard-toolbar-menu absolute right-0 top-full z-[65] mt-1 w-80 max-w-[calc(100vw_-_16px)] overflow-auto rounded-lg border border-violet-100 bg-white p-2 shadow-xl ring-1 ring-slate-900/5">
                <div className="relative mb-2 flex min-h-8 items-center justify-center border-b border-slate-100 pb-1.5 pr-8">
                  <div className="text-center">
                    <div className="text-[10px] font-black tracking-wide text-slate-700">CHART DRAWING TOOLS</div>
                    <div className="text-[8px] font-bold tracking-wide text-slate-400">SELECT A TOOL, THEN CLICK ON THE CHART</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowDrawingTools(false)}
                    className="absolute right-0 top-0 rounded-full border border-slate-200 px-1.5 py-0.5 text-[8px] font-black text-slate-500 hover:bg-slate-100"
                    aria-label="Close drawing tools"
                  >
                    ✕
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-1">
                  {CHART_DRAWING_TOOLS.map((option) => (
                    <button
                      key={option.tool}
                      type="button"
                      onClick={() => {
                        setActiveDrawingTool(option.tool);
                        setDrawingDraft(null);
                        setDrawingDrag(null);
                        setSelectedDrawingId(null);
                        setShowDrawingVisibility(false);
                        setReplaySelecting(false);
                        setShowDrawingTools(false);
                      }}
                      className={`rounded-md border px-2 py-1.5 text-left transition ${
                        activeDrawingTool === option.tool
                          ? 'border-violet-400 bg-violet-100 text-violet-900'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-violet-200 hover:bg-violet-50'
                      }`}
                      title={option.hint}
                    >
                      <span className="block text-[9px] font-black">{option.label}</span>
                      <span className="mt-0.5 block text-[7px] font-semibold leading-tight text-slate-400">
                        {option.hint}
                      </span>
                    </button>
                  ))}
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1 border-t border-slate-100 pt-2">
                  <button
                    type="button"
                    onClick={undoLastChartDrawing}
                    disabled={!currentSourceChartDrawings.length}
                    className="rounded-full border border-slate-200 px-2 py-0.5 text-[8px] font-black text-slate-600 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    UNDO LAST
                  </button>
                  <button
                    type="button"
                    onClick={clearCurrentChartDrawings}
                    disabled={!currentSourceChartDrawings.length}
                    className="rounded-full border border-rose-200 px-2 py-0.5 text-[8px] font-black text-rose-700 hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    CLEAR ALL
                  </button>
                  {hiddenChartDrawings.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setChartDrawings((current) => current.map((drawing) => (
                        drawing.scope === drawingScope ? { ...drawing, hidden: false } : drawing
                      )))}
                      className="rounded-full border border-violet-200 px-2 py-0.5 text-[8px] font-black text-violet-700 hover:bg-violet-50"
                    >
                      SHOW HIDDEN ({hiddenChartDrawings.length})
                    </button>
                  )}
                  {(activeDrawingTool || drawingDraft) && (
                    <button
                      type="button"
                      onClick={() => {
                        setDrawingDraft(null);
                        setActiveDrawingTool(null);
                        setShowDrawingTools(false);
                      }}
                      className="ml-auto rounded-full border border-amber-200 px-2 py-0.5 text-[8px] font-black text-amber-700 hover:bg-amber-50"
                    >
                      CANCEL
                    </button>
                  )}
                  <span className="ml-auto text-[8px] font-bold text-slate-400">
                    {currentSourceChartDrawings.length} SAVED
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="flex min-w-0 max-w-full flex-wrap items-center gap-1">
            <label className="flex items-center gap-1 rounded-md border border-slate-200 bg-white px-1.5 py-0.5 text-[8px] font-black text-slate-600">
              TIME
              <select
                value={chartTimeZone}
                onChange={(event) => setChartTimeZone(event.target.value as ChartTimeZone)}
                className="bg-white text-[8px] font-black text-slate-700 outline-none"
                title="Choose the timezone shown on the chart axis and crosshair"
              >
                <option value="Asia/Kathmandu">NEPAL</option>
                <option value="Asia/Kolkata">INDIA</option>
                <option value="UTC">UTC</option>
              </select>
            </label>
            <div className={`flex items-center gap-1 rounded-full border px-1.5 py-0.5 text-[8px] font-black ${
              error
                ? 'border-rose-200 bg-rose-50 text-rose-700'
                : 'border-emerald-200 bg-emerald-50 text-emerald-700'
            }`}>
              {error ? <WifiOff className="h-2.5 w-2.5" /> : <Wifi className="h-2.5 w-2.5" />}
              {error ? 'FEED DISCONNECTED' : source.startsWith('MetaTrader 5')
                ? 'MT5 BROKER CONNECTED' : 'TRADINGVIEW CONNECTED'}
            </div>
            <button
              onClick={() => {
                restorePresentChartView();
                setRefreshKey((value) => value + 1);
              }}
              className="rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-100"
              title="Refresh candles and restore the default chart view"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => void toggleFullscreen()}
              className="rounded-md border border-slate-200 p-1 text-slate-600 hover:bg-slate-100"
              title="Fullscreen chart"
            >
              <Maximize2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {replayIndex === null && visibleMt5Positions.length > 0 && (
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 border-b border-cyan-200 bg-cyan-50 px-3 py-1 text-[8px] font-semibold leading-none text-cyan-900">
            <span className="text-[8px] font-black">MT5 LIVE</span>
            {visibleMt5Positions.map((position) => (
              <span key={position.ticket} className="flex items-center gap-1 rounded border border-cyan-200 bg-white px-1.5 py-1">
                #{position.ticket}
                <b className="rounded bg-slate-100 px-1 py-0.5 text-[7px] font-black text-slate-600">
                  {position.signalTimeframe ?? '?'} ENTRY
                </b>
                · <b className={position.direction === 'BUY' ? 'text-emerald-700' : 'text-rose-700'}>{position.direction}</b>
                {' · '}{position.volume.toLocaleString(undefined, { maximumFractionDigits: 2 })} LOT
                {' · '}RUNNING P/L: <b className={position.profit >= 0 ? 'text-emerald-700' : 'text-rose-700'}>
                  {mt5Status!.bridge.currency || 'USD'} {position.profit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </b>
                {(position.signalStatus === 'RISK_FREE' || position.signalStatus === 'RF') && (
                  <b className="rounded bg-emerald-100 px-1 py-0.5 text-[7px] font-black text-emerald-700">RF DONE</b>
                )}
              </span>
            ))}
          </div>
        )}

        {replayIndex === null && marketSymbol === 'XAUUSD' && mt5Status?.recentSignals
          ?.filter((signal) => signal.status === 'REJECTED'
            && /^(STRONG|WEAK) OPPOSITE (BUY|SELL) SETUP - TRADE SKIPPED:/.test(signal.message ?? '')
            && signal.updatedAt * 1000 >= Date.now() - 15 * 60 * 1000)
          .slice(0, 1).map((signal) => (
            <div key={signal.id} role="status" className={`border-b px-3 py-1.5 text-[10px] font-bold ${
              signal.message?.startsWith('STRONG')
                ? 'border-rose-200 bg-rose-50 text-rose-800'
                : 'border-amber-200 bg-amber-50 text-amber-900'
            }`}>
              {signal.message}
            </div>
          ))}

        <div className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 border-b border-slate-100 px-4 py-2 text-xs">
          <span className="flex items-center gap-1.5 font-black text-slate-800">
            <Crosshair className="h-3.5 w-3.5 text-slate-400" />
            O <b ref={headerOpenRef} />
          </span>
          <span className="text-slate-500">H <b ref={headerHighRef} className="text-slate-800" /></span>
          <span className="text-slate-500">L <b ref={headerLowRef} className="text-slate-800" /></span>
          <span className="text-slate-500">C <b ref={headerCloseRef} className="text-slate-800" /></span>
          <span ref={headerChangeRef} className="font-black" />
          <span className={`rounded px-2 py-0.5 text-[10px] font-black ${
            structure.trend === 'bullish'
              ? 'bg-emerald-50 text-emerald-700'
              : structure.trend === 'bearish'
                ? 'bg-rose-50 text-rose-700'
                : 'bg-slate-100 text-slate-600'
          }`}>
            STRUCTURE: {structure.trend.toUpperCase()}
          </span>
          <span className="ml-auto flex min-w-0 items-center gap-1 break-words text-[10px] font-bold text-slate-500">
            <Wifi className="h-3.5 w-3.5 text-emerald-600" />
            {source} · no fallback · {candles.length.toLocaleString()} bars
          </span>
        </div>

        <div
          ref={chartPaneRef}
          className="dashboard-chart relative min-h-[280px] flex-1 bg-white"
          onMouseLeave={() => setHoveredEntry(null)}
          onMouseDown={() => {
            if (!activeDrawingTool && !drawingDrag) {
              setSelectedDrawingId(null);
              setShowDrawingVisibility(false);
            }
          }}
        >
          <div ref={hostRef} className="absolute inset-0" />
          {marketSymbol === 'XAUUSD' && <BollingerStudy open={showBollingerStudy}
            enabled={showBollingerStudy || arrowStrategies.includes('BOLLINGER_M5') || showAccuracyTable || showJournal || bollingerM5Enabled}
            showArrows={arrowStrategies.includes('BOLLINGER_M5')} timeframe={granularity} symbol={marketSymbol}
            candles={bollingerCandles} cutoff={tradeDisplayAsOf}
            historySeed={liveChartDataSource === 'OANDA' ? bollingerCandles : {}}
            chartRef={chartRef} seriesRef={candleSeriesRef} onClose={() => setShowBollingerStudy(false)}
            onShowM5={() => changeTimeframe('M5')}
            onRecords={setBollingerChartRecords} />}
          {visitedStudies.volume && <div hidden={!showVolumeStudy}><VolumeEngulfingStudy active={showVolumeStudy}
            symbol={marketSymbol} timeframe={granularity}
            chartCandles={displayCandles} candles={vipCandles}
            chartRef={chartRef} seriesRef={candleSeriesRef}
            onClose={() => setShowVolumeStudy(false)}
          /></div>}
          {visitedStudies.trendline && <div hidden={!showTrendlineStudy}><TrendlineStudy active={showTrendlineStudy}
            symbol={marketSymbol} pipSize={marketConfig.pipSize} timeframe={granularity}
            entryArrows={entryArrowStudyEntries}
            chartCandles={displayCandles} candles={vipCandles} tradingTimeEnabled={tradingTimeEnabled}
            chartRef={chartRef} seriesRef={candleSeriesRef} hostRef={hostRef}
            onClose={() => setShowTrendlineStudy(false)}
          /></div>}
          {hoveredEntry && visibleEntryHovers.some(entry => entry.id === hoveredEntry.entry.id) && (() => {
            const { entry, x, y } = hoveredEntry;
            const { trade } = entry;
            const record = chartEntryRecords.find((candidate) => candidate.id === entry.id);
            const bullish = trade.signal.direction === 'bullish';
            const scalpOneToOne = entry.style === 'SCALP_1_1';
            const mtf = record?.source === 'MTF';
            const timeframeName = (timeframe: TradeTimeframe) => timeframe === 'D'
              ? '1-day' : `${timeframe.slice(1)}-${timeframe.startsWith('H') ? 'hour' : 'minute'}`;
            const zoneName = (name: string) => name.replace(/^Int\.?\s+/i, 'Internal ');
            const mainZone = hoveredTradeZones?.mainZone
              ?? (mtf ? 'Name unavailable in saved history' : entry.zone);
            const entryZone = hoveredTradeZones?.entryZone ?? entry.zone;
            const status = entry.pullbackSetup ? (entry.pullbackSetup.markerText || 'CHART: Filled') : entry.display?.statusText ?? (trade.status === 'tp-hit' ? '✅ TAKE PROFIT HIT'
              : trade.status === 'sl-hit' ? '🔴 STOP LOSS HIT'
              : trade.status === 'risk-free' ? '🛡️ RISK-FREE HIT'
              : trade.status === 'pending' ? '⏳ WAITING FOR ENTRY' : '⏳ TRADE OPEN');
            const timeZoneLabel = chartTimeZone === 'Asia/Kathmandu' ? 'Nepal' : chartTimeZone;
            return (
            <div
              className="pointer-events-auto absolute z-40 max-h-[calc(100%_-_16px)] w-80 max-w-[calc(100%_-_16px)] overflow-y-auto rounded-xl border border-slate-200 bg-white/95 p-3 text-[11px] leading-relaxed text-slate-700 shadow-xl"
              style={{
                left: Math.max(8, Math.min(x + 16, (chartPaneRef.current?.clientWidth ?? 340) - 328)),
                top: Math.max(8, Math.min(y + 16, (chartPaneRef.current?.clientHeight ?? 440) - 420)),
              }}
            >
              <div className={`text-xs font-black ${bullish ? 'text-emerald-700' : 'text-rose-700'}`}>
                {bullish ? '🟢' : '🔴'} {marketSymbol} {bullish ? 'BUY' : 'SELL'} · {scalpOneToOne ? 'SCALP 1:1' : entry.style}
              </div>
              {scalpOneToOne && !entry.pullbackSetup && <div className="mt-1 font-bold text-emerald-700">
                {entry.display ? entry.display.statusText + (entry.display.brokerTicket ? ` - Ticket ${entry.display.brokerTicket}` : '') : record?.mt5Managed || record?.brokerTicket !== undefined ? `MT5 execution · Ticket ${record?.brokerTicket ?? 'pending'}` : 'CHART ONLY · Simulated result'}
              </div>}
              <div className="mt-1 font-bold text-slate-800">{status}</div>
              {entry.pullbackSetup && <div className="mt-2 border-t border-slate-100 pt-2" aria-label="Both pullback entry details">
                {entry.pullbackSetup.legs.map(leg => <div key={leg.leg} className="mb-2">
                  <div><b>{leg.leg === 10 ? '1st Entry' : '2nd Entry'} ({leg.leg}%): {formatPrice(leg.entry)}</b></div>
                  <div>SL: {leg.riskPips.toFixed(2)} pips · Risk share: {entry.pullbackSetup!.secondOnly ? leg.leg === 25 ? '100%' : '0%' : leg.leg === 10 ? '60%' : '40%'}</div>
                  <div>CHART: {entry.pullbackSetup!.secondOnly && leg.leg === 10 ? 'Skipped — split lot below minimum' : leg.filled ? '✓ Filled' : leg.uncertain ? 'Fill uncertain — insufficient candle evidence' : 'Not filled'}</div>
                  <div>MT5: {leg.executed ? 'Executed' : 'Not executed'}</div>
                  {leg.outcome && <div>Outcome: {leg.outcome === 'both' ? 'SL / TP order uncertain' : leg.outcome.toUpperCase()}</div>}
                  {leg.filledAt !== undefined && <div>Filled: {formatAccuracyTradeTime(leg.filledAt, chartTimeZone)}</div>}
                </div>)}
                <div>Fixed SL: <b>{formatPrice(trade.stopLoss)}</b> · Fixed TP: <b>{formatPrice(trade.takeProfit)}</b></div>
              </div>}
              {entry.tradingTimeBlocked && <div className="mt-1 text-amber-700">⚠️ Outside trading hours</div>}
              <div className="mt-3 border-t border-slate-100 pt-2">
                <div className="mb-1 font-bold text-slate-900">📍 Trade setup</div>
                {entry.style === 'BOLLINGER_M5' ? <div>Bias: <b>H4 confirmed structure</b></div>
                  : <div>Main zone: <b>{record ? `${timeframeName(record.zoneTimeframe)} ` : ''}{zoneName(mainZone)}</b></div>}
                {mtf && <div>Entry zone: <b>{timeframeName(trade.signal.timeframe)} {zoneName(entryZone)}</b></div>}
                {entry.style === 'BOLLINGER_M5' ? <div>Confirmation: <b>M5 Bollinger re-entry, EMA200, SuperTrend, ADX ≥15, confirmed H4 bias. One entry; fixed SL / 1.5R TP.</b></div> : <div>Confirmation: <b>{timeframeName(trade.signal.timeframe)} {bullish ? 'bullish' : 'bearish'} engulfing {trade.signal.type}</b></div>}
                {entry.style === 'BOLLINGER_M5' ? <div>Entry method: <b>One market entry; original SL and TP fixed</b></div>
                  : scalpOneToOne ? <div>Entry method: <b>10% / 25% body pullbacks · 60% / 40% setup risk · original SL/TP fixed · M15 volume decrease ≥ 250 units · H4 bias + EMA20/50 · H1 continuation/Far</b></div>
                  : entry.pullbackSetup ? <div>Entry method: <b>10% / 25% body pullbacks · 60% / 40% setup risk · original SL/TP fixed</b></div>
                  : !mtf && <div>Entry method: <b>Candle confirmation at the main zone</b></div>}
                {entry.fib !== 'Not recorded' && <div>Fibonacci: <b>{entry.fib}</b></div>}
              </div>
              <div className="mt-3 border-t border-slate-100 pt-2">
                <div className="mb-1 font-bold text-slate-900">💰 Trade levels</div>
                <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 tabular-nums">
                  <span>Entry</span><b>{formatPrice(trade.entry)}</b>
                  <span>Stop loss</span><b>{formatPrice(trade.stopLoss)}</b>
                  {trade.riskFreeEnabled !== false && <><span>Risk-free at 1R</span><b>{formatPrice(trade.riskFree)}</b></>}
                  <span>Take profit</span><b>{formatPrice(trade.takeProfit)}</b>
                  <span>Risk/reward</span><b>1:{trade.rewardRisk}</b>
                </div>
              </div>
              <div className="mt-3 border-t border-slate-100 pt-2">
                <div className="mb-1 font-bold text-slate-900">Supporting trend lines at confirmation</div>
                <div aria-label="Entry supporting trend lines">
                  {hoveredTrendlineSupport?.matches.length ? hoveredTrendlineSupport.matches.map((line, index) => (
                    <div key={`${line.timeframe}:${line.kind}:${index}`}>
                      <b>{line.timeframe.startsWith('H') ? `${line.timeframe.slice(1)}H`
                        : line.timeframe === 'D' ? '1D' : line.timeframe === 'W' ? '1W'
                        : formatTradeTimeframe(line.timeframe)}</b>
                      {' · '}{line.kind === 'continuation' ? 'Continuation' : 'Breakout'}
                      {' · '}{line.color === 'green' ? 'Green' : 'Red'}
                      <div className="pl-2 text-[10px]">{line.distance
                        ? `${line.distance.pips.toFixed(2)} pips from entry · ${line.distance.band}` : 'Distance unknown'}
                      </div>
                    </div>
                  )) : <div>No supporting trend line found in available history.</div>}
                </div>
                <div className="mt-1 text-[10px] text-slate-500">
                  {hoveredTrendlineSupport?.distanceContext.atrPips !== undefined
                    ? `${formatTradeTimeframe(hoveredTrendlineSupport.distanceContext.timeframe)} entry ATR(14): ${hoveredTrendlineSupport.distanceContext.atrPips.toFixed(2)} pips. Near: up to ${hoveredTrendlineSupport.distanceContext.nearPips!.toFixed(2)}; Medium: up to ${hoveredTrendlineSupport.distanceContext.mediumPips!.toFixed(2)}; Far: above that.`
                    : 'Distance group unknown: entry-timeframe ATR history or entry fill is unavailable.'}
                  {' '}Measured at entry using lines confirmed before entry. Study labels only.
                </div>
                {!!hoveredTrendlineSupport?.unavailable.length && <div className="mt-1 text-[10px] text-slate-500">
                  History unavailable or insufficient: {hoveredTrendlineSupport.unavailable.join(', ')}.
                </div>}
              </div>
              <div className="mt-3 border-t border-slate-100 pt-2">
                <div className="font-bold text-slate-900">🕒 {trade.filledAt !== undefined ? 'Entry time' : 'Confirmation time'}</div>
                <div>{formatChartTime((trade.filledAt ?? trade.signal.time
                  + TIMEFRAME_SECONDS[trade.signal.timeframe]) as UTCTimestamp, chartTimeZone)} {timeZoneLabel}</div>
              </div>
            </div>
            );
          })()}
          <div
            ref={zoneLayerRef}
            className="pointer-events-none absolute inset-0 z-10 overflow-hidden"
            style={{ contain: 'layout paint style' }}
          />
          <svg
            className="pointer-events-none absolute inset-0 z-[18] h-full w-full overflow-hidden"
            style={{ contain: 'layout paint style' }}
            aria-label="Saved chart drawings"
          >
            {visibleChartDrawings.map((drawing) => renderChartDrawing(drawing))}
            {previewChartDrawing && renderChartDrawing(previewChartDrawing, true)}
          </svg>
          {drawingTextEditor && drawingTextEditorPosition && (
            <input
              autoFocus
              type="text"
              value={drawingTextEditor.value}
              maxLength={80}
              placeholder="Add text"
              onChange={(event) => setDrawingTextEditor((current) => (
                current ? { ...current, value: event.target.value } : current
              ))}
              onBlur={saveChartDrawingText}
              onKeyDown={(event) => {
                event.stopPropagation();
                if (event.key === 'Enter') {
                  event.preventDefault();
                  saveChartDrawingText();
                } else if (event.key === 'Escape') {
                  event.preventDefault();
                  setDrawingTextEditor(null);
                }
              }}
              onMouseDown={(event) => event.stopPropagation()}
              className={`absolute z-50 w-36 origin-center px-1 py-0.5 text-center text-[9px] font-semibold text-slate-700 outline-none placeholder:italic placeholder:text-slate-400 focus:border-blue-500 ${
                textEditorDrawing?.tool === 'note'
                  ? 'rounded border border-blue-400 bg-white shadow-md'
                  : 'border-0 border-b border-slate-400 bg-white/80 shadow-none'
              }`}
              style={{
                left: drawingTextEditorPosition.left,
                top: drawingTextEditorPosition.top,
                transform: `translate(-50%, -50%) rotate(${drawingTextEditorPosition.angle}deg)`,
              }}
              aria-label="Drawing text"
            />
          )}
          <div
            ref={livePriceLabelRef}
            className="pointer-events-none absolute right-0 z-20 hidden w-[72px] -translate-y-1/2 flex-col items-center justify-center py-0.5 text-white shadow-sm"
            aria-label="Live candle price and time remaining"
          >
            <span ref={livePriceValueRef} className="text-[10px] font-black leading-[12px]" />
            <span ref={liveCountdownRef} className="text-[9px] font-bold leading-[11px]" />
          </div>
          {selectedChartDrawing && chartDrawingIsVisible(selectedChartDrawing) && !activeDrawingTool && (
            <div
              className={`absolute z-40 flex items-center gap-0.5 rounded-md border border-violet-200 bg-white p-0.5 shadow-lg ${
                drawingToolbarPosition ? '' : 'left-1/2 top-2 -translate-x-1/2'
              }`}
              style={drawingToolbarPosition ?? undefined}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <span className="rounded bg-violet-100 px-1 py-0.5 text-[6px] font-black leading-none text-violet-800">
                {CHART_DRAWING_TOOLS.find(({ tool }) => tool === selectedChartDrawing.tool)?.label}
              </span>
              <button
                type="button"
                className="cursor-move select-none rounded px-1 py-0.5 text-[6px] font-black leading-none text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                title="Drag this control bar"
                onMouseDown={(event) => {
                  event.preventDefault();
                  event.stopPropagation();
                  const pane = chartPaneRef.current;
                  if (!pane) return;
                  const toolbarBounds = event.currentTarget.parentElement?.getBoundingClientRect();
                  const paneBounds = pane.getBoundingClientRect();
                  if (!toolbarBounds) return;
                  const left = toolbarBounds.left - paneBounds.left;
                  const top = toolbarBounds.top - paneBounds.top;
                  setDrawingToolbarPosition({ left, top });
                  drawingToolbarDragRef.current = {
                    offsetX: event.clientX - toolbarBounds.left,
                    offsetY: event.clientY - toolbarBounds.top,
                    width: toolbarBounds.width,
                    height: toolbarBounds.height,
                  };
                }}
              >
                ⠿ MOVE
              </button>
              {(selectedChartDrawing.tool === 'rectangle'
                || selectedChartDrawing.tool === 'trend'
                || selectedChartDrawing.tool === 'note') && (
                <>
                  <button
                    type="button"
                    onClick={() => editChartDrawingText(selectedChartDrawing)}
                    className="rounded border border-slate-200 px-1 py-0.5 text-[6px] font-black leading-none text-slate-600 hover:bg-slate-50"
                    title="You can also double-click the drawing"
                  >
                    TEXT
                  </button>
                  <div className="flex items-center gap-px rounded border border-slate-200 px-0.5 py-0.5" title="Drawing colour">
                    {CHART_DRAWING_COLORS.map((color) => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => updateChartDrawing(selectedChartDrawing.id, { color })}
                        className={`h-2.5 w-2.5 rounded-full border ${
                          (selectedChartDrawing.color ?? '#2563eb') === color
                            ? 'border-slate-900 ring-1 ring-slate-400'
                            : 'border-white'
                        }`}
                        style={{ backgroundColor: color }}
                        aria-label={`Use ${color} drawing colour`}
                      />
                    ))}
                  </div>
                </>
              )}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowDrawingVisibility((visible) => !visible)}
                  className={`rounded border px-1 py-0.5 text-[6px] font-black leading-none ${
                    showDrawingVisibility
                      ? 'border-violet-300 bg-violet-100 text-violet-800'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  VISIBILITY ▾
                </button>
                {showDrawingVisibility && (
                  <div className="absolute left-0 top-full z-50 mt-1 w-48 rounded-md border border-slate-200 bg-white p-1.5 shadow-xl">
                    <div className="mb-1 border-b border-slate-100 px-1 pb-1 text-[8px] font-black text-slate-500">
                      CURRENT: {TIMEFRAMES.find(({ value }) => value === granularity)?.label.toUpperCase()}
                    </div>
                    {([
                      ['current-and-above', 'CURRENT INTERVAL AND ABOVE'],
                      ['current-and-below', 'CURRENT INTERVAL AND BELOW'],
                      ['current-only', 'CURRENT INTERVAL ONLY'],
                      ['all', 'ALL INTERVALS'],
                    ] as Array<[ChartDrawingVisibility, string]>).map(([visibility, label]) => (
                      <button
                        key={visibility}
                        type="button"
                        onClick={() => {
                          updateChartDrawing(selectedChartDrawing.id, {
                            visibility,
                            visibilityTimeframe: granularity,
                          });
                          setShowDrawingVisibility(false);
                        }}
                        className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left text-[8px] font-black ${
                          (selectedChartDrawing.visibility ?? 'all') === visibility
                            ? 'bg-violet-100 text-violet-800'
                            : 'text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {label}
                        {(selectedChartDrawing.visibility ?? 'all') === visibility && <span>✓</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  updateChartDrawing(selectedChartDrawing.id, { hidden: true });
                  setSelectedDrawingId(null);
                  setShowDrawingVisibility(false);
                }}
                className="rounded border border-slate-200 px-1 py-0.5 text-[6px] font-black leading-none text-slate-600 hover:bg-slate-50"
              >
                HIDE
              </button>
              <button
                type="button"
                onClick={() => removeChartDrawing(selectedChartDrawing.id)}
                className="rounded border border-rose-200 px-1 py-0.5 text-[6px] font-black leading-none text-rose-700 hover:bg-rose-50"
              >
                DELETE
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedDrawingId(null);
                  setShowDrawingVisibility(false);
                }}
                className="rounded-full border border-slate-200 px-1 py-0 text-[6px] font-black leading-none text-slate-500 hover:bg-slate-100"
                aria-label="Close drawing editor"
              >
                ✕
              </button>
            </div>
          )}
          {activeDrawingTool && !replaySelecting && (
            <div
              className="absolute inset-0 z-30 cursor-crosshair"
              onClick={handleDrawingChartClick}
              onMouseMove={(event) => {
                if (!drawingDraft) return;
                const hover = chartDrawingPointFromClient(event.clientX, event.clientY);
                if (hover) {
                  const constrainedHover = activeDrawingTool === 'trend' && event.shiftKey
                    ? { ...hover, price: drawingDraft.points[0].price }
                    : hover;
                  setDrawingDraft((current) => current ? { ...current, hover: constrainedHover } : current);
                }
              }}
              onContextMenu={(event) => {
                event.preventDefault();
                if (activeDrawingTool === 'path') finishDrawingPath();
                else {
                  setDrawingDraft(null);
                  setActiveDrawingTool(null);
                }
              }}
              title="Click on the chart to place drawing points"
            >
              <div className="pointer-events-none absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-violet-200 bg-white/95 px-3 py-1.5 text-[9px] font-black text-violet-800 shadow-lg">
                {CHART_DRAWING_TOOLS.find(({ tool }) => tool === activeDrawingTool)?.label}
                <span className="font-semibold text-slate-500">
                  {activeDrawingTool === 'note'
                    ? 'Click a price for the note'
                    : activeDrawingTool === 'path'
                      ? 'Click points · double-click or right-click to finish'
                      : activeDrawingTool === 'note'
                        ? drawingDraft
                          ? 'Click where the text box should be placed'
                          : 'Click the anchor point'
                      : activeDrawingTool === 'fib'
                        ? drawingDraft
                          ? 'Click level 0 move extreme'
                          : 'Click level 1 structure source'
                        : activeDrawingTool === 'trend'
                          ? drawingDraft
                            ? 'Click second point · hold Shift for a straight horizontal line'
                            : 'Click the first point'
                          : drawingDraft ? 'Click the second point' : 'Click the first point'}
                </span>
                <span className="text-slate-400">ESC cancels</span>
              </div>
            </div>
          )}
          {replaySelecting && replaySelectionIndex !== null && (
            <div
              className="absolute inset-0 z-30 cursor-ew-resize"
              onPointerDown={(event) => {
                event.currentTarget.setPointerCapture(event.pointerId);
                selectReplayBar(event);
              }}
              onPointerMove={(event) => {
                if (event.currentTarget.hasPointerCapture(event.pointerId)) selectReplayBar(event);
              }}
              onPointerUp={(event) => event.currentTarget.releasePointerCapture(event.pointerId)}
              title="Drag the blue replay line to the candle where replay should start"
            >
              <div
                ref={replaySelectionLineRef}
                className="absolute inset-y-0 w-0.5 bg-blue-600 shadow-[0_0_0_1px_rgba(255,255,255,.9)]"
              >
                <span className="absolute bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded bg-blue-600 px-2 py-1 text-[10px] font-black text-white">
                  REPLAY START
                </span>
              </div>
            </div>
          )}
          {replaySelecting && (
            <div className="absolute bottom-3 left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 shadow-lg">
              <span className="text-[10px] font-black text-slate-600">DRAG BLUE LINE TO SELECT BAR</span>
              <span className="text-[10px] font-bold text-slate-400">{(replaySelectionIndex ?? 0) + 1}/{candles.length}</span>
              <label className="flex items-center gap-1 text-[10px] font-bold text-slate-600">
                Speed
                <select
                  value={replaySpeed}
                  onChange={(event) => setReplaySpeed(Number(event.target.value))}
                  className="rounded border border-slate-200 bg-white px-1 py-0.5 text-[10px] font-black text-violet-700"
                >
                  <option value={0.5}>0.5x</option>
                  <option value={1}>1x</option>
                  <option value={2}>2x</option>
                  <option value={5}>5x</option>
                  <option value={10}>10x</option>
                </select>
              </label>
              <button onClick={beginReplay} className="rounded bg-violet-600 px-2 py-1 text-[10px] font-black text-white hover:bg-violet-700">START</button>
              <button onClick={() => setReplaySelecting(false)} className="rounded border border-slate-200 px-2 py-1 text-[10px] font-black text-slate-500 hover:bg-slate-100">CANCEL</button>
            </div>
          )}
          <div data-journal-exclude="true" className={`pointer-events-auto absolute left-3 top-3 z-20 flex max-h-[calc(100%_-_24px)] max-w-[calc(100%_-_24px)] flex-col overflow-hidden rounded-md border border-slate-300 bg-white/95 shadow-sm ${showZoneTable ? 'w-fit' : 'w-auto'}`}>
            <div className="flex shrink-0 items-center justify-between gap-3 border-b border-slate-200 bg-violet-50 px-2 py-1 text-[9px] font-black uppercase tracking-wide text-violet-700">
              <span>{showZoneTable ? 'Zone table' : 'Zone table minimized'}</span>
              <button
                type="button"
                onClick={toggleZoneTable}
                aria-expanded={showZoneTable}
                className="rounded border border-violet-200 bg-white px-1.5 py-0.5 text-[8px] font-black text-violet-700 hover:bg-violet-100"
                title={showZoneTable ? 'Minimize zone table' : 'Show zone table'}
              >
                {showZoneTable ? '− MINIMIZE' : '+ SHOW TABLE'}
              </button>
            </div>
            {showZoneTable && <div className="min-h-0 overflow-auto">
            <table className="table-auto border-collapse text-left text-[10px]">
              <thead className="bg-slate-100 text-[9px] uppercase text-slate-500">
                <tr>
                  <th className="whitespace-nowrap px-2 py-1 font-bold">Zone</th>
                  <th className="whitespace-nowrap px-2 py-1 font-bold">Type</th>
                  <th className="whitespace-nowrap px-2 py-1 font-bold">Price range</th>
                  <th className="whitespace-nowrap px-2 py-1 text-center font-bold">Engulf</th>
                  <th className="whitespace-nowrap px-2 py-1 text-right font-bold">Tap / Trade</th>
                </tr>
              </thead>
              <tbody>
                {zoneTableContent}
                {!hasZoneTableContent && (
                  <tr>
                    <td colSpan={5} className="px-2 py-2 text-center text-slate-400">No active zone rows</td>
                  </tr>
                )}
              </tbody>
            </table>
            </div>}
          </div>
          {marketSymbol === 'XAUUSD' && (showAccuracyTable || showJournal) && scalpOneToOneHistoryStatus && (
            <div role="status" className="px-2 py-1 text-[9px] font-semibold text-emerald-800">{scalpOneToOneHistoryStatus}</div>
          )}
          {showAccuracyTable && (
            <EngulfingAccuracyTable
              canViewMt5={canAdmin}
              records={timeframeAccuracyRecords.filter(record => matchesTradeStrategies(record.tradeStyle, arrowStrategies))}
              allRecords={replayVisibleAccuracyRecords}
              mt5Records={executedMt5Trades.filter((trade) => (
                (trade.symbol ?? 'XAUUSD') === marketSymbol
                && !blockedGoldHistoricalTrade(trade)
                && (replayResultCutoff === undefined || (trade.openedAt ?? trade.completedAt) <= replayResultCutoff)
              ))}
              timeframe={granularity}
              showAllTrades={showAllAccuracyTrades}
              historyAsOf={replayResultCutoff ?? Math.floor(Date.now() / 1000)}
              timeZone={chartTimeZone}
              marketSymbol={marketSymbol}
              entryArrowsVisible={showEntryArrows}
              selectedStrategies={accuracyStrategies}
              onStrategiesChange={setAccuracyStrategies}
              onClose={() => {
                setShowAccuracyTable(false);
                setShowAccuracyOptions(false);
              }}
            />
          )}
          {showJournal && (
            <TradeJournal
              selectedStrategies={journalStrategies}
              onStrategiesChange={setJournalStrategies}
              canManageCapital={canAdmin}
              terminalId={terminalId}
              records={visibleCanonicalTradeRecords}
              timeframe={granularity}
              marketSymbol={marketSymbol}
              historyAsOf={replayResultCutoff ?? Math.floor(Date.now() / 1000)}
              timeZone={chartTimeZone}
              onClose={() => setShowJournal(false)}
            />
          )}
          <MultiTimeframeEntryTable rows={mtfRows} liveTrades={liveMtfTableTrades} intradayPullbacks={marketSymbol === 'XAUUSD'} fillEvidence={pullbackFillEvidence}
            records={recordedMtfTrades} timeZone={chartTimeZone}
            entryCandles={Object.fromEntries(TIMEFRAMES.map(({ value }) => [value, tableTimeframeData[value]?.candles ?? []]))}
            requiredTimeframes={[granularity, ...mtfLowerGranularities]}
            candleErrors={{ ...mtfCandleErrors, ...(error ? { [granularity]: error } : {}) }}
            onRetry={() => setRefreshKey(value => value + 1)}
            asOf={tradeDisplayAsOf} />
          <MultiTimeframeTrendTable rows={trendTableRows} replayActive={replayIndex !== null} />
          {isLoading && candles.length === 0 && !error && (
            <div className="absolute inset-0 z-20 grid place-items-center bg-white/85">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                <RefreshCw className="h-4 w-4 animate-spin text-indigo-600" />
                Loading {marketSymbol} market candles…
              </div>
            </div>
          )}

          {error && candles.length === 0 && (
            <div className="absolute inset-0 z-20 grid place-items-center bg-white/95 p-6">
              <div className="max-w-xl rounded-xl border border-rose-200 bg-rose-50 p-5 text-center shadow-sm">
                <AlertTriangle className="mx-auto mb-2 h-7 w-7 text-rose-600" />
                <h2 className="font-black text-rose-900">{marketSymbol} candle feed is unavailable</h2>
                <p className="mt-2 text-sm text-rose-800">{error}</p>
                <p className="mt-3 text-xs leading-relaxed text-slate-600">
                  The selected chart feed is unavailable. Automatic execution remains independent and always uses candles from the connected MT5 broker.
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-1 break-words rounded-b-xl border-t border-slate-200 bg-slate-50 px-4 py-1.5 text-[10px] font-bold text-slate-500">
          <span className={`flex items-center gap-1 ${source.startsWith('MetaTrader 5') ? 'text-emerald-700' : 'text-amber-700'}`}>
            {source.startsWith('MetaTrader 5')
              ? <CheckCircle2 className="h-3 w-3" /> : <AlertTriangle className="h-3 w-3" />}
            {source.startsWith('MetaTrader 5')
              ? 'MT5 broker chart data'
              : replayIndex !== null ? 'TradingView replay data' : 'OANDA live chart data'}
          </span>
          <span className="flex items-center gap-1 text-emerald-700"><CheckCircle2 className="h-3 w-3" /> Symbol: {marketConfig.shortName}</span>
          <span>OHLC source: {source}</span>
          <span>Structure: HH · HL · LH · LL · BOS · CHoCH</span>
          <span>Genesis Low: {formatPrice(structure.genesis?.price)}</span>
          <span>Active zones: {displayZones.filter((zone) => zone.category === 'mg' && zone.active).length}</span>
          <span>Invalid zones: {displayZones.filter((zone) => !zone.active).length}</span>
          <span>S/D: {['H1', 'H4', 'D', 'W'].includes(granularity) ? displayZones.filter((zone) => zone.category === 'supplyDemand').length : 'H1+ ONLY'}</span>
          <span>Last candle: {latestCandle?.complete === false ? 'FORMING' : 'COMPLETE'}</span>
          <span className="ml-auto">Updated: {lastUpdated ? new Date(lastUpdated).toLocaleTimeString() : '—'}</span>
        </div>
      </div>
    </section>
  );
};
