import React, { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Download,
  History,
  ImagePlus,
  LayoutDashboard,
  Save,
  X,
} from 'lucide-react';
import type { ChartTimeZone } from '../services/chartTime';
import { mergeTradeRecordAnnotations } from '../services/tradeRecordDeduplication';
import type { OandaMarketSymbol } from '../services/marketSymbols';
import {
  filterAccuracyTradeRecords,
  selectTwoMonthJournalRecords,
  twoMonthAccuracyWindow,
  tradeRecordDatePeriodKey,
  tradeRecordPeriodLabel,
  type TradeRecordFilters,
  type TradeStrategy,
  TRADE_STRATEGIES,
} from '../services/tradeRecordFilters';
import {
  calculateHalfAtOneRResult,
  type EngulfingVolumeStatus,
  type MarketTrend,
  type TradeResult,
  type TradeTimeframe,
} from '../services/tradeLevels';
import { TradeMultiSelect, TradeStrategyCheckboxes } from './TradeMultiSelect';
import { Mt5CapitalPanel } from './Mt5CapitalPanel';

export interface JournalTradeRecord {
  pullbackFallback?: 'SECOND_ONLY';
  mtfContext?: import('../services/mtf').MtfRow;
  id: string;
  zoneId?: string;
  setupId?: string;
  symbol?: OandaMarketSymbol;
  zoneName: string;
  zoneTimeframe: TradeTimeframe;
  result: TradeResult | 'open' | 'risk-free';
  completedAt: number;
  source: 'ENGULFING' | 'MTF' | 'BOLLINGER';
  tradeStyle?: 'SCALPING' | 'INTRADAY' | 'SCALP_1_1' | 'BOLLINGER_M5';
  scalpEntry?: import('../services/mt5Automation').ScalpPullbackEntry;
  intradayEntry?: import('../services/intradayPullback').IntradayPullbackEntry;
  direction: 'bullish' | 'bearish';
  signalTimeframe: TradeTimeframe;
  engulfingType: string;
  engulfingCandleCount?: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  rewardRisk: number;
  riskPips: number;
  signalAt?: number;
  outsideTradingTime?: boolean;
  volumeLogicStatus?: EngulfingVolumeStatus;
  volume1?: number;
  volume2?: number;
  volume3?: number;
  fibSource?: string;
  fibBand?: string;
  fibLevels?: Array<{ label: string; price: number }>;
  snapshotCandles?: Array<{
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
  }>;
  session?: string;
  reason?: string;
  mistake?: string;
  lesson?: string;
  screenshotDataUrl?: string;
  entryScreenshotDataUrl?: string;
  exitScreenshotDataUrl?: string;
  entrySnapshotCandles?: SnapshotCandle[];
  exitSnapshotCandles?: SnapshotCandle[];
  openedAt?: number;
  closedAt?: number;
  lifecycleStatus?: 'open' | 'risk-free' | 'closed';
  mt5Managed?: boolean;
  mt5SignalId?: string;
  brokerTicket?: number;
  volume?: number;
  partialClosedVolume?: number;
  remainingVolume?: number;
  partialClosePrice?: number;
  partialClosedAt?: number;
  closePrice?: number;
  realizedProfit?: number;
  autoReason?: string;
  biasAtEntry?: Partial<Record<TradeTimeframe, MarketTrend>>;
  lifecycleEvents?: Array<Record<string, unknown> & { status: string; at: number }>;
}

interface SnapshotCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

interface JournalResponse {
  ok: boolean;
  trades?: JournalTradeRecord[];
  error?: string;
}

interface TradeJournalProps {
  selectedStrategies?: TradeStrategy[];
  onStrategiesChange?: (selected: TradeStrategy[]) => void;
  canManageCapital?: boolean;
  terminalId?: 'primary' | 'secondary';
  records: JournalTradeRecord[];
  timeframe: TradeTimeframe;
  marketSymbol: OandaMarketSymbol;
  historyAsOf: number;
  timeZone: ChartTimeZone;
  onClose: () => void;
}

const RESULT_LABELS: Record<JournalTradeRecord['result'], string> = {
  tp: 'TP', sl: 'SL', rf: 'RISK FREE', open: 'OPEN', 'risk-free': 'RF DONE',
};
const VOLUME_STATUS_LABELS: Record<EngulfingVolumeStatus, string> = {
  'not-applicable': 'N/A',
  unavailable: 'UNAVAILABLE',
  failed: 'FAILED',
  valid: 'VALID',
  best: 'BEST',
};

function volumeStatus(trade: JournalTradeRecord): EngulfingVolumeStatus {
  return trade.volumeLogicStatus ?? 'unavailable';
}

function volumeValues(trade: JournalTradeRecord): string {
  return [trade.volume1, trade.volume2, trade.volume3]
    .map((volume, index) => volume === undefined ? undefined : `V${index + 1} ${volume}`)
    .filter(Boolean)
    .join(' · ') || 'No saved volume values';
}

function displayTimeframe(timeframe: string): string {
  if (timeframe === 'D') return 'D1';
  return timeframe.startsWith('M') ? `${timeframe.slice(1)}M` : timeframe;
}

function formatPrice(value: number): string {
  return value.toLocaleString('en-US', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
}

const BIAS_TIMEFRAMES: TradeTimeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D'];

function trendLabel(trend: MarketTrend | undefined): string {
  if (trend === 'bullish') return 'BULLISH';
  if (trend === 'bearish') return 'BEARISH';
  return 'NEUTRAL';
}

function formatJournalDate(time: number, timeZone: ChartTimeZone): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone,
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(time * 1000));
}

function formatJournalTime(time: number, timeZone: ChartTimeZone): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone,
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(time * 1000));
}

export function inferTradingSession(time: number): string {
  const hour = Number(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kathmandu',
    hour: '2-digit',
    hourCycle: 'h23',
  }).format(new Date(time * 1000)));
  if (hour >= 5 && hour < 12) return 'ASIAN';
  if (hour >= 12 && hour < 18) return 'LONDON';
  if (hour >= 18 && hour < 21) return 'LON + NYC';
  return 'NEW YORK';
}

function calculateTotalR(trades: JournalTradeRecord[]): number {
  return trades.reduce((total, trade) => (
    total + (tradeResultR(trade) ?? 0)
  ), 0);
}

type JournalView = 'overview' | 'calendar' | 'history' | 'withdrawals';

interface JournalPerformance {
  completed: number;
  winRate: number;
  profitFactor: number | undefined;
  averageWinLoss: number | undefined;
  totalR: number;
  realizedProfit: number;
  realizedTradeCount: number;
}

export interface JournalCashSummary {
  tradeCount: number;
  realizedProfit: number;
}

export function calculateJournalCashSummary(trades: JournalTradeRecord[]): JournalCashSummary {
  const realizedTrades = trades.filter((trade) => (
    ['tp', 'sl', 'rf'].includes(trade.result)
    && Number.isFinite(trade.realizedProfit)
  ));
  return {
    tradeCount: realizedTrades.length,
    realizedProfit: realizedTrades.reduce((total, trade) => total + (trade.realizedProfit ?? 0), 0),
  };
}

function tradeResultR(trade: JournalTradeRecord): number | undefined {
  if (!['tp', 'sl', 'rf'].includes(trade.result)) return undefined;
  if (trade.tradeStyle === 'BOLLINGER_M5' && Number.isFinite(trade.closePrice)
    && Math.abs(trade.entry - trade.stopLoss) > 0) return (trade.closePrice! - trade.entry)
      * (trade.direction === 'bullish' ? 1 : -1) / Math.abs(trade.entry - trade.stopLoss);
  const share = trade.pullbackFallback === 'SECOND_ONLY' ? 1
    : trade.tradeStyle === 'SCALP_1_1' ? trade.scalpEntry?.riskShare ?? 1 : trade.intradayEntry?.riskShare ?? 1;
  if ((trade.tradeStyle === 'INTRADAY' || trade.tradeStyle === 'SCALP_1_1' || trade.tradeStyle === 'BOLLINGER_M5') && !trade.partialClosedAt) {
    if (trade.result === 'tp') return trade.rewardRisk * share;
    if (trade.result === 'sl') return -share;
  }
  return calculateHalfAtOneRResult(trade.result as TradeResult, trade.rewardRisk) * share;
}

export function calculateJournalPerformance(trades: JournalTradeRecord[]): JournalPerformance {
  const completed = trades.filter((trade) => tradeResultR(trade) !== undefined);
  const values = completed.map((trade) => tradeResultR(trade) ?? 0);
  const wins = values.filter((value) => value > 0);
  const losses = values.filter((value) => value < 0);
  const grossWin = wins.reduce((total, value) => total + value, 0);
  const grossLoss = Math.abs(losses.reduce((total, value) => total + value, 0));
  const realized = completed.filter((trade) => Number.isFinite(trade.realizedProfit));
  return {
    completed: completed.length,
    winRate: completed.length > 0 ? (wins.length / completed.length) * 100 : 0,
    profitFactor: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : undefined,
    averageWinLoss: wins.length > 0 && losses.length > 0
      ? (grossWin / wins.length) / (grossLoss / losses.length)
      : undefined,
    totalR: values.reduce((total, value) => total + value, 0),
    realizedProfit: realized.reduce((total, trade) => total + (trade.realizedProfit ?? 0), 0),
    realizedTradeCount: realized.length,
  };
}

export function journalDateKey(time: number, timeZone: ChartTimeZone): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(time * 1000));
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? '';
  return `${value('year')}-${value('month')}-${value('day')}`;
}

function formatMoney(value: number): string {
  return `${value >= 0 ? '+' : '-'}$${Math.abs(value).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function formatMetric(value: number | undefined): string {
  if (value === undefined) return '—';
  if (value === Infinity) return '∞';
  return value.toFixed(2);
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function signalTimeFromRecord(trade: JournalTradeRecord): number {
  if (trade.signalAt) return trade.signalAt;
  const segments = trade.id.split(':');
  const parsed = Number(segments[segments.length - 2]);
  return Number.isFinite(parsed) ? parsed : trade.completedAt;
}

export function renderHistoricalTradeSnapshot(
  trade: JournalTradeRecord,
  sourceCandles: SnapshotCandle[],
): string | undefined {
  if (sourceCandles.length < 2) return undefined;
  const signalAt = signalTimeFromRecord(trade);
  const signalIndex = sourceCandles.findIndex((candle) => candle.time === signalAt);
  const containingIndex = signalIndex >= 0 ? signalIndex : sourceCandles.findIndex((candle, index) => (
    signalAt >= candle.time && (index === sourceCandles.length - 1 || signalAt < sourceCandles[index + 1].time)
  ));
  const centerIndex = containingIndex >= 0 ? containingIndex : Math.max(0, sourceCandles.length - 30);
  const outcomeIndex = sourceCandles.findIndex((candle) => candle.time >= trade.completedAt);
  const start = Math.max(0, centerIndex - 14);
  const end = Math.min(
    sourceCandles.length,
    Math.max(centerIndex + 28, outcomeIndex >= 0 ? outcomeIndex + 5 : 0),
  );
  const candles = sourceCandles.slice(start, Math.min(end, start + 90));
  if (candles.length < 2) return undefined;

  const canvas = document.createElement('canvas');
  canvas.width = 1100;
  canvas.height = 590;
  const context = canvas.getContext('2d');
  if (!context) return undefined;
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, canvas.width, canvas.height);

  context.fillStyle = '#312e81';
  context.font = 'bold 20px Arial';
  context.fillText(`${displayTimeframe(trade.zoneTimeframe)} ${trade.zoneName} · ${trade.direction === 'bullish' ? 'BUY' : 'SELL'}`, 54, 32);
  context.fillStyle = '#475569';
  context.font = 'bold 13px Arial';
  context.fillText(
    `${displayTimeframe(trade.signalTimeframe)} ${trade.engulfingType} · ${formatJournalDate(trade.completedAt, 'Asia/Kathmandu')} · ${RESULT_LABELS[trade.result]}`,
    54,
    54,
  );
  const fibDescription = [trade.fibSource || 'FIB-qualified setup', trade.fibBand].filter(Boolean).join(' · ');
  context.fillStyle = '#b45309';
  context.fillText(trade.tradeStyle === 'BOLLINGER_M5' ? 'Bollinger M5 (no Fib filter)' : `FIB: ${fibDescription}`, 690, 32);

  const chartLeft = 62;
  const chartTop = 82;
  const chartWidth = 910;
  const chartHeight = 430;
  const prices = candles.flatMap((candle) => [candle.high, candle.low]);
  prices.push(trade.entry, trade.stopLoss, trade.takeProfit);
  for (const level of trade.fibLevels || []) prices.push(level.price);
  let minimum = Math.min(...prices);
  let maximum = Math.max(...prices);
  const padding = Math.max((maximum - minimum) * 0.08, 0.5);
  minimum -= padding;
  maximum += padding;
  const priceToY = (price: number) => chartTop + ((maximum - price) / (maximum - minimum)) * chartHeight;

  context.strokeStyle = '#e2e8f0';
  context.lineWidth = 1;
  context.font = '11px Arial';
  context.fillStyle = '#64748b';
  for (let row = 0; row <= 5; row += 1) {
    const y = chartTop + (chartHeight * row) / 5;
    context.beginPath();
    context.moveTo(chartLeft, y);
    context.lineTo(chartLeft + chartWidth, y);
    context.stroke();
    const price = maximum - ((maximum - minimum) * row) / 5;
    context.fillText(formatPrice(price), chartLeft + chartWidth + 8, y + 4);
  }

  const candleSlot = chartWidth / candles.length;
  const candleWidth = Math.max(2, Math.min(9, candleSlot * 0.58));
  candles.forEach((candle, index) => {
    const x = chartLeft + candleSlot * index + candleSlot / 2;
    const bullish = candle.close >= candle.open;
    context.strokeStyle = bullish ? '#059669' : '#e11d48';
    context.fillStyle = bullish ? '#10b981' : '#f43f5e';
    context.lineWidth = 1.2;
    context.beginPath();
    context.moveTo(x, priceToY(candle.high));
    context.lineTo(x, priceToY(candle.low));
    context.stroke();
    const bodyTop = priceToY(Math.max(candle.open, candle.close));
    const bodyBottom = priceToY(Math.min(candle.open, candle.close));
    context.fillRect(x - candleWidth / 2, bodyTop, candleWidth, Math.max(2, bodyBottom - bodyTop));
    if (candle.time === signalAt) {
      context.strokeStyle = '#7c3aed';
      context.lineWidth = 2;
      context.strokeRect(x - candleSlot / 2, chartTop, candleSlot, chartHeight);
      context.fillStyle = '#7c3aed';
      context.font = 'bold 11px Arial';
      context.fillText(trade.tradeStyle === 'BOLLINGER_M5' ? 'BOLLINGER' : 'ENGULFING', Math.max(chartLeft, x - 32), chartTop + 15);
    }
  });

  const drawLevel = (price: number, label: string, color: string, dashed = false) => {
    const y = priceToY(price);
    context.save();
    context.strokeStyle = color;
    context.fillStyle = color;
    context.lineWidth = 2;
    context.setLineDash(dashed ? [7, 5] : []);
    context.beginPath();
    context.moveTo(chartLeft, y);
    context.lineTo(chartLeft + chartWidth, y);
    context.stroke();
    context.setLineDash([]);
    context.font = 'bold 12px Arial';
    context.fillText(`${label} ${formatPrice(price)}`, chartLeft + 8, y - 5);
    context.restore();
  };
  for (const level of trade.fibLevels || []) drawLevel(level.price, `FIB ${level.label}`, '#d97706', true);
  drawLevel(trade.takeProfit, 'TP', '#059669');
  drawLevel(trade.entry, 'ENTRY', '#2563eb');
  drawLevel(trade.stopLoss, 'SL', '#e11d48');

  context.fillStyle = '#334155';
  context.font = 'bold 13px Arial';
  context.fillText(
    `Risk ${trade.riskPips} pips · R:R 1:${trade.rewardRisk} · Session ${trade.session || inferTradingSession(trade.completedAt)}`,
    62,
    552,
  );
  context.fillStyle = trade.result === 'tp' ? '#047857' : trade.result === 'sl' ? '#be123c' : '#b45309';
  context.font = 'bold 16px Arial';
  context.fillText(`RESULT: ${RESULT_LABELS[trade.result]}`, 850, 552);
  return canvas.toDataURL('image/jpeg', 0.78);
}

export const TradeJournal: React.FC<TradeJournalProps> = ({ records, timeframe, marketSymbol, historyAsOf, timeZone, onClose, terminalId = 'primary', canManageCapital = false, selectedStrategies, onStrategiesChange }) => {
  const terminalFetch = (url: string, options?: RequestInit) => fetch(
    url.startsWith('/api/journal/') ? `${url}${url.includes('?') ? '&' : '?'}terminal=${terminalId}` : url, options);

  const screenshotBackfillAttemptedRef = React.useRef(new Set<string>());
  const screenshotBackfillRunningRef = React.useRef(false);
  const calendarInitializedRef = React.useRef(false);
  const [storedTrades, setTrades] = useState<JournalTradeRecord[]>(records);
  const trades = useMemo(() => mergeTradeRecordAnnotations(records, storedTrades), [records, storedTrades]);
  const [activeView, setActiveView] = useState<JournalView>('overview');
  const [calendarMonth, setCalendarMonth] = useState(() => {
    const now = new Date();
    return { year: now.getUTCFullYear(), month: now.getUTCMonth() + 1 };
  });
  const [selectedId, setSelectedId] = useState<string | null>(records[0]?.id ?? null);
  const [resultFilter, setResultFilter] = useState<'ALL' | JournalTradeRecord['result']>('ALL');
  const [timeframeFilter, setTimeframeFilter] = useState<TradeRecordFilters['timeframes']>([timeframe]);
  useEffect(() => {
    setTimeframeFilter([timeframe]);
  }, [timeframe]);
  const historyWindow = twoMonthAccuracyWindow(historyAsOf);
  const formatHistoryDate = (time: number) => new Date(time * 1000).toLocaleDateString('en-GB', {
    timeZone, day: '2-digit', month: 'short', year: 'numeric',
  });
  const [datePeriod, setDatePeriod] = useState<TradeRecordFilters['datePeriod']>('DAY');
  const [dateFilter, setDateFilter] = useState('ALL');
  const [sourceFilter, setSourceFilter] = useState<TradeRecordFilters['source']>('ALL');
  const [localStrategies, setLocalStrategies] = useState<TradeStrategy[]>([...TRADE_STRATEGIES]);
  const tradeStyleFilter = selectedStrategies ?? localStrategies;
  const setTradeStyleFilter = onStrategiesChange ?? setLocalStrategies;
  const [tradingTimeFilter, setTradingTimeFilter] = useState<TradeRecordFilters['tradingTime']>('ALL');
  const [sideFilter, setSideFilter] = useState<TradeRecordFilters['side']>('ALL');
  const [zoneFilter, setZoneFilter] = useState<TradeRecordFilters['zones']>('ALL');
  const [volumeFilter, setVolumeFilter] = useState<'ALL' | EngulfingVolumeStatus>('ALL');
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState<'excel' | 'word' | null>(null);
  const [preparingScreenshots, setPreparingScreenshots] = useState(false);
  const [message, setMessage] = useState('Loading saved journal…');
  const [journalLoaded, setJournalLoaded] = useState(false);
  const [draft, setDraft] = useState({ session: '', reason: '', mistake: '', lesson: '', screenshotDataUrl: '' });

  useEffect(() => {
    let cancelled = false;
    const loadAndMerge = async () => {
      try {
        const storedResponse = await terminalFetch('/api/journal/trades', { cache: 'no-store' });
        const storedPayload = await storedResponse.json() as JournalResponse;
        if (!storedResponse.ok || !storedPayload.ok) throw new Error(storedPayload.error || 'Unable to load journal.');
        const saved = storedPayload.trades ?? [];
        const storedById = new Map(saved.map((trade) => [trade.id, trade]));
        const mergedRecords = mergeTradeRecordAnnotations(records, saved);
        const missingRecords = records.filter((record) => !storedById.has(record.id));
        let finalTrades = mergedRecords;
        if (missingRecords.length > 0) {
          const saveResponse = await terminalFetch('/api/journal/trades', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ trades: missingRecords }),
          });
          const savePayload = await saveResponse.json() as JournalResponse;
          if (!saveResponse.ok || !savePayload.ok) throw new Error(savePayload.error || 'Unable to save new trades.');
          finalTrades = mergeTradeRecordAnnotations(records, savePayload.trades ?? finalTrades);
        }
        if (cancelled) return;
        setTrades(finalTrades);
        setSelectedId((current) => current ?? finalTrades[0]?.id ?? null);
        setMessage(`${finalTrades.length} journal trade${finalTrades.length === 1 ? '' : 's'} saved`);
      } catch (error) {
        if (!cancelled) setMessage(error instanceof Error ? error.message : 'Unable to load journal.');
      } finally {
        if (!cancelled) setJournalLoaded(true);
      }
    };
    void loadAndMerge();
    return () => { cancelled = true; };
  }, [records]);

  useEffect(() => {
    if (!journalLoaded || screenshotBackfillRunningRef.current) return undefined;
    const candidates = trades.filter((trade) => {
      const needsImage = trade.mt5Managed && (
        !trade.entryScreenshotDataUrl
        || (trade.lifecycleStatus === 'closed' && !trade.exitScreenshotDataUrl)
      );
      return needsImage
        && !screenshotBackfillAttemptedRef.current.has(`${trade.id}:${trade.lifecycleStatus || 'legacy'}`);
    });
    if (candidates.length === 0) return undefined;
    screenshotBackfillRunningRef.current = true;
    for (const trade of candidates) {
      screenshotBackfillAttemptedRef.current.add(`${trade.id}:${trade.lifecycleStatus || 'legacy'}`);
    }
    const backfill = async () => {
      setPreparingScreenshots(true);
      const timeframeSeconds: Record<TradeTimeframe, number> = {
        M1: 60, M5: 300, M15: 900, M30: 1800, H1: 3600, H4: 14400, D: 86400,
      };
      const byTimeframe = new Map<TradeTimeframe, JournalTradeRecord[]>();
      for (const trade of candidates) {
        const group = byTimeframe.get(trade.signalTimeframe) ?? [];
        group.push(trade);
        byTimeframe.set(trade.signalTimeframe, group);
      }
      const generated: JournalTradeRecord[] = [];
      setMessage(`Preparing ${candidates.length} missing trade screenshot${candidates.length === 1 ? '' : 's'}…`);
      for (const [timeframe, timeframeTrades] of byTimeframe) {
        const needingHistory: JournalTradeRecord[] = [];
        for (const trade of timeframeTrades) {
          const entryScreenshotDataUrl = trade.entryScreenshotDataUrl
            || (trade.entrySnapshotCandles?.length
              ? renderHistoricalTradeSnapshot(trade, trade.entrySnapshotCandles) : undefined);
          const exitScreenshotDataUrl = trade.lifecycleStatus === 'closed'
            ? trade.exitScreenshotDataUrl || (trade.exitSnapshotCandles?.length
              ? renderHistoricalTradeSnapshot(trade, trade.exitSnapshotCandles) : undefined)
            : undefined;
          if (entryScreenshotDataUrl
            && (trade.lifecycleStatus !== 'closed' || exitScreenshotDataUrl)) {
            generated.push({
              ...trade,
              entryScreenshotDataUrl,
              exitScreenshotDataUrl,
              screenshotDataUrl: trade.screenshotDataUrl || exitScreenshotDataUrl || entryScreenshotDataUrl,
            });
          } else needingHistory.push(trade);
        }
        if (needingHistory.length === 0) continue;
        try {
          const latestCompletion = Math.max(...needingHistory.map((trade) => trade.completedAt));
          const query = new URLSearchParams({
            granularity: timeframe,
            count: '5000',
            endTime: String(latestCompletion + timeframeSeconds[timeframe] * 20),
          });
          const response = await terminalFetch(`/api/tradingview/market-data?${query}`, { cache: 'no-store' });
          const payload = await response.json() as { ok?: boolean; candles?: SnapshotCandle[] };
          if (!response.ok || !payload.ok || !Array.isArray(payload.candles)) continue;
          for (const trade of needingHistory) {
            const entryCandles = trade.entrySnapshotCandles || trade.snapshotCandles || payload.candles;
            const exitCandles = trade.exitSnapshotCandles || payload.candles;
            const entryScreenshotDataUrl = trade.entryScreenshotDataUrl
              || renderHistoricalTradeSnapshot(trade, entryCandles);
            const exitScreenshotDataUrl = trade.lifecycleStatus === 'closed'
              ? trade.exitScreenshotDataUrl || renderHistoricalTradeSnapshot(trade, exitCandles)
              : undefined;
            if (entryScreenshotDataUrl || exitScreenshotDataUrl) generated.push({
              ...trade,
              entryScreenshotDataUrl,
              exitScreenshotDataUrl,
              screenshotDataUrl: trade.screenshotDataUrl || exitScreenshotDataUrl || entryScreenshotDataUrl,
            });
          }
        } catch {
          // A missing timeframe feed must not block the rest of the journal.
        }
      }
      if (generated.length === 0) {
        setMessage('No historical candles were available for screenshot backfill.');
        return;
      }
      let savedTrades = trades;
      for (let index = 0; index < generated.length; index += 5) {
        const response = await terminalFetch('/api/journal/trades', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ trades: generated.slice(index, index + 5) }),
        });
        const payload = await response.json() as JournalResponse;
        if (!response.ok || !payload.ok) throw new Error(payload.error || 'Unable to save generated screenshots.');
        savedTrades = payload.trades ?? savedTrades;
      }
      setTrades(mergeTradeRecordAnnotations(records, savedTrades));
      setMessage(`${generated.length} historical trade screenshot${generated.length === 1 ? '' : 's'} saved`);
    };
    void backfill()
      .catch((error) => {
        setMessage(error instanceof Error ? error.message : 'Unable to prepare trade screenshots.');
      })
      .finally(() => {
        screenshotBackfillRunningRef.current = false;
        setPreparingScreenshots(false);
      });
    return undefined;
  }, [journalLoaded, records, trades]);

  useEffect(() => {
    if (!journalLoaded) return undefined;
    const refresh = async () => {
      try {
        const response = await terminalFetch('/api/journal/trades', { cache: 'no-store' });
        const payload = await response.json() as JournalResponse;
        if (response.ok && payload.ok && Array.isArray(payload.trades)) {
          setTrades(mergeTradeRecordAnnotations(records, payload.trades));
        }
      } catch {
        // Keep the currently loaded journal visible during a temporary server interruption.
      }
    };
    const timer = window.setInterval(() => void refresh(), 5_000);
    return () => window.clearInterval(timer);
  }, [journalLoaded, records]);

  const selectedTrade = trades.find((trade) => trade.id === selectedId);
  useEffect(() => {
    if (!selectedTrade) return;
    setDraft({
      session: selectedTrade.session || inferTradingSession(selectedTrade.completedAt),
      reason: selectedTrade.reason || '',
      mistake: selectedTrade.mistake || '',
      lesson: selectedTrade.lesson || '',
      screenshotDataUrl: selectedTrade.screenshotDataUrl || '',
    });
  }, [selectedTrade?.id]);

  const availableTimeframes = useMemo(() => {
    const order: TradeTimeframe[] = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D'];
    return Array.from(new Set<TradeTimeframe>([...order, ...trades.map((trade) => trade.signalTimeframe)]))
      .sort((first, second) => order.indexOf(first) - order.indexOf(second));
  }, [trades]);
  const availableZones = useMemo(() => Array.from(new Set(
    trades.map((trade) => trade.zoneName),
  )).sort(), [trades]);
  const filteredTrades = useMemo(() => {
    const query = search.trim().toLowerCase();
    const coreFiltered = filterAccuracyTradeRecords<JournalTradeRecord>(selectTwoMonthJournalRecords<JournalTradeRecord>(trades, historyAsOf), {
      timeframes: timeframeFilter,
      datePeriod,
      date: dateFilter,
      source: sourceFilter,
      tradeStyle: tradeStyleFilter,
      tradingTime: tradingTimeFilter,
      side: sideFilter,
      result: 'ALL',
      zones: zoneFilter,
    }, timeZone, marketSymbol);
    return coreFiltered.filter((trade) => (
      (volumeFilter === 'ALL' || volumeStatus(trade) === volumeFilter)
      && (resultFilter === 'ALL' || trade.result === resultFilter)
      && (!query || [trade.zoneName, trade.engulfingType, volumeStatus(trade), trade.session, trade.reason, trade.autoReason, trade.mistake, trade.lesson]
        .some((value) => value?.toLowerCase().includes(query)))
    ));
  }, [dateFilter, datePeriod, resultFilter, search, sideFilter, sourceFilter, timeframeFilter, timeZone, trades, tradeStyleFilter, tradingTimeFilter, volumeFilter, zoneFilter, historyAsOf, marketSymbol]);

  useEffect(() => {
    if (filteredTrades.some((trade) => trade.id === selectedId)) return;
    setSelectedId(filteredTrades[0]?.id ?? null);
  }, [filteredTrades, selectedId]);

  const completedTrades = useMemo(
    () => filteredTrades.filter((trade) => ['tp', 'sl', 'rf'].includes(trade.result)),
    [filteredTrades],
  );
  const counts = useMemo(() => ({
    tp: filteredTrades.filter((trade) => trade.result === 'tp').length,
    sl: filteredTrades.filter((trade) => trade.result === 'sl').length,
    rf: filteredTrades.filter((trade) => trade.result === 'rf').length,
  }), [filteredTrades]);
  const accuracy = completedTrades.length > 0 ? Math.round((counts.tp * 10_000) / completedTrades.length) / 100 : 0;
  const totalR = calculateTotalR(completedTrades);
  const performance = useMemo(() => calculateJournalPerformance(filteredTrades), [filteredTrades]);
  const runningTrades = useMemo(
    () => filteredTrades.filter((trade) => trade.result === 'open' || trade.result === 'risk-free'),
    [filteredTrades],
  );
  const tradesByDate = useMemo(() => {
    const grouped = new Map<string, JournalTradeRecord[]>();
    for (const trade of filteredTrades) {
      const key = journalDateKey(trade.completedAt, timeZone);
      const group = grouped.get(key) ?? [];
      group.push(trade);
      grouped.set(key, group);
    }
    return grouped;
  }, [filteredTrades, timeZone]);
  const calendarCashTradesByDate = useMemo(() => {
    const grouped = new Map<string, JournalTradeRecord[]>();
    for (const trade of filteredTrades) {
      if (!['tp', 'sl', 'rf'].includes(trade.result) || !Number.isFinite(trade.realizedProfit)) continue;
      const key = journalDateKey(trade.completedAt, timeZone);
      const group = grouped.get(key) ?? [];
      group.push(trade);
      grouped.set(key, group);
    }
    return grouped;
  }, [filteredTrades, timeZone]);
  const calendarCells = useMemo(() => {
    const firstWeekday = (new Date(Date.UTC(calendarMonth.year, calendarMonth.month - 1, 1)).getUTCDay() + 6) % 7;
    const dayCount = new Date(Date.UTC(calendarMonth.year, calendarMonth.month, 0)).getUTCDate();
    return [
      ...Array.from({ length: firstWeekday }, () => undefined),
      ...Array.from({ length: dayCount }, (_, index) => index + 1),
    ];
  }, [calendarMonth]);
  const calendarMonthLabel = useMemo(() => new Intl.DateTimeFormat('en-US', {
    month: 'long', year: 'numeric', timeZone: 'UTC',
  }).format(new Date(Date.UTC(calendarMonth.year, calendarMonth.month - 1, 1))), [calendarMonth]);

  useEffect(() => {
    if (calendarInitializedRef.current || trades.length === 0) return;
    const latestKey = journalDateKey(trades[0].completedAt, timeZone);
    const [year, month] = latestKey.split('-').map(Number);
    if (Number.isFinite(year) && Number.isFinite(month)) setCalendarMonth({ year, month });
    calendarInitializedRef.current = true;
  }, [timeZone, trades]);

  const saveTrade = async () => {
    if (!selectedTrade) return;
    setSaving(true);
    try {
      const updated = { ...selectedTrade, ...draft };
      const response = await terminalFetch('/api/journal/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trades: [updated] }),
      });
      const payload = await response.json() as JournalResponse;
      if (!response.ok || !payload.ok) throw new Error(payload.error || 'Unable to save journal notes.');
      setTrades(mergeTradeRecordAnnotations(records,
        payload.trades ?? trades.map((trade) => trade.id === updated.id ? updated : trade)));
      setMessage('Trade review saved');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to save journal notes.');
    } finally {
      setSaving(false);
    }
  };

  const attachScreenshot = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setMessage('Please select an image file.');
      return;
    }
    if (file.size > 3_000_000) {
      setMessage('Screenshot must be smaller than 3 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setDraft((current) => ({ ...current, screenshotDataUrl: String(reader.result || '') }));
    reader.readAsDataURL(file);
  };

  const exportExcel = async () => {
    setExporting('excel');
    try {
      const XLSX = await import('xlsx');
      const workbook = XLSX.utils.book_new();
      const summary = [{
        'Total Trades': filteredTrades.length,
        TP: counts.tp,
        SL: counts.sl,
        'Risk Free': counts.rf,
        'Accuracy %': accuracy,
        'Total R': totalR,
      }];
      const rows = filteredTrades.map((trade, index) => ({
        No: index + 1,
        Date: formatJournalDate(trade.completedAt, timeZone),
        Time: formatJournalTime(trade.completedAt, timeZone),
        Session: trade.session || inferTradingSession(trade.completedAt),
        'Zone TF': displayTimeframe(trade.zoneTimeframe),
        Zone: trade.zoneName,
        Side: trade.direction === 'bullish' ? 'BUY' : 'SELL',
        Source: trade.source,
        'Engulfing TF': displayTimeframe(trade.signalTimeframe),
        'Engulfing Type': trade.engulfingType,
        'Volume Logic': VOLUME_STATUS_LABELS[volumeStatus(trade)],
        'Volume 1': trade.volume1 ?? '',
        'Volume 2': trade.volume2 ?? '',
        'Volume 3': trade.volume3 ?? '',
        Entry: trade.entry,
        SL: trade.stopLoss,
        TP: trade.takeProfit,
        'Risk Pips': trade.riskPips,
        'R:R': `1:${trade.rewardRisk}`,
        Result: RESULT_LABELS[trade.result],
        'Bias M1': trendLabel(trade.biasAtEntry?.M1),
        'Bias M5': trendLabel(trade.biasAtEntry?.M5),
        'Bias M15': trendLabel(trade.biasAtEntry?.M15),
        'Bias M30': trendLabel(trade.biasAtEntry?.M30),
        'Bias H1': trendLabel(trade.biasAtEntry?.H1),
        'Bias H4': trendLabel(trade.biasAtEntry?.H4),
        'Bias D1': trendLabel(trade.biasAtEntry?.D),
        'MT5 Ticket': trade.brokerTicket ?? '',
        'Lot Size': trade.volume ?? '',
        'Realized P/L': trade.realizedProfit ?? '',
        'Screenshot Available': trade.screenshotDataUrl ? 'YES' : 'NO',
        Reason: trade.reason || trade.autoReason || '',
        Mistake: trade.mistake || '',
        Lesson: trade.lesson || '',
      }));
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(summary), 'Dashboard');
      const tradeSheet = XLSX.utils.json_to_sheet(rows);
      tradeSheet['!cols'] = [5, 13, 8, 13, 9, 18, 8, 12, 12, 14, 12, 12, 12, 12, 12, 12, 12, 10, 8, 12, 20, 38, 38, 38]
        .map((wch) => ({ wch }));
      XLSX.utils.book_append_sheet(workbook, tradeSheet, 'Trade Journal');
      XLSX.writeFile(workbook, `Trade-Journal-${new Date().toISOString().slice(0, 10)}.xlsx`);
      setMessage('Excel journal exported');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to export Excel journal.');
    } finally {
      setExporting(null);
    }
  };

  const exportWord = async () => {
    setExporting('word');
    try {
      const {
        AlignmentType, Document, HeadingLevel, ImageRun, Packer, Paragraph, Table, TableCell, TableRow,
        TextRun, WidthType,
      } = await import('docx');
      const summaryTable = new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          new TableRow({ children: ['Total Trades', 'TP', 'SL', 'Risk Free', 'Accuracy', 'Total R'].map((text) => (
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text, bold: true })] })] })
          )) }),
          new TableRow({ children: [filteredTrades.length, counts.tp, counts.sl, counts.rf, `${accuracy}%`, totalR]
            .map((value) => new TableCell({ children: [new Paragraph(String(value))] })) }),
        ],
      });
      const children: Array<InstanceType<typeof Paragraph> | InstanceType<typeof Table>> = [
        new Paragraph({ text: 'Radhe Radhe', alignment: AlignmentType.CENTER, heading: HeadingLevel.TITLE }),
        new Paragraph({ text: 'Trading Journal Report', alignment: AlignmentType.CENTER, heading: HeadingLevel.HEADING_1 }),
        new Paragraph({ text: `Generated ${new Date().toLocaleString('en-GB')}`, alignment: AlignmentType.CENTER }),
        summaryTable,
      ];
      for (const [index, trade] of filteredTrades.entries()) {
        children.push(
          new Paragraph({ text: `Trade ${index + 1}`, heading: HeadingLevel.HEADING_1, pageBreakBefore: true }),
          new Paragraph(`Date: ${formatJournalDate(trade.completedAt, timeZone)}    Time: ${formatJournalTime(trade.completedAt, timeZone)}    Session: ${trade.session || inferTradingSession(trade.completedAt)}`),
          new Paragraph(`Setup: ${displayTimeframe(trade.zoneTimeframe)} ${trade.zoneName} · ${trade.direction === 'bullish' ? 'BUY' : 'SELL'}`),
          new Paragraph(`Confirmation: ${displayTimeframe(trade.signalTimeframe)} ${trade.engulfingType} · Source: ${trade.source}`),
          new Paragraph(`Volume logic: ${VOLUME_STATUS_LABELS[volumeStatus(trade)]} · ${volumeValues(trade)}`),
          ...(trade.biasAtEntry ? [new Paragraph(`Bias at entry: ${BIAS_TIMEFRAMES.map((timeframe) => `${displayTimeframe(timeframe)} ${trendLabel(trade.biasAtEntry?.[timeframe])}`).join(' · ')}`)] : []),
          new Paragraph(`Entry: ${formatPrice(trade.entry)}    SL: ${formatPrice(trade.stopLoss)}    TP: ${formatPrice(trade.takeProfit)}    Risk: ${trade.riskPips} pips    R:R 1:${trade.rewardRisk}`),
          new Paragraph({ children: [new TextRun({ text: `Outcome: ${RESULT_LABELS[trade.result]}`, bold: true })] }),
          new Paragraph({ children: [new TextRun({ text: 'Reason: ', bold: true }), new TextRun(trade.reason || trade.autoReason || '—')] }),
          new Paragraph({ children: [new TextRun({ text: 'Mistake / Important observation: ', bold: true }), new TextRun(trade.mistake || '—')] }),
          new Paragraph({ children: [new TextRun({ text: 'Lesson learned: ', bold: true }), new TextRun(trade.lesson || '—')] }),
        );
        if (trade.screenshotDataUrl) {
          try {
            const imageResponse = await terminalFetch(trade.screenshotDataUrl);
            const imageData = new Uint8Array(await imageResponse.arrayBuffer());
            const imageType = trade.screenshotDataUrl.startsWith('data:image/png') ? 'png' : 'jpg';
            children.push(new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new ImageRun({ data: imageData, transformation: { width: 620, height: 350 }, type: imageType })],
            }));
          } catch {
            children.push(new Paragraph('Screenshot could not be embedded.'));
          }
        }
      }
      const document = new Document({ sections: [{ children }] });
      downloadBlob(await Packer.toBlob(document), `Trade-Journal-${new Date().toISOString().slice(0, 10)}.docx`);
      setMessage('Word journal exported');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to export Word journal.');
    } finally {
      setExporting(null);
    }
  };

  return (
    <div data-journal-exclude="true" className="pointer-events-auto absolute inset-3 z-40 flex min-h-0 flex-col overflow-hidden rounded-lg border border-slate-300 bg-slate-50 shadow-2xl">
      <div className="flex shrink-0 items-center gap-2 border-b border-slate-300 bg-white px-3 py-2">
        <BookOpen className="h-4 w-4 text-indigo-700" />
        <div>
          <div className="text-xs font-black uppercase tracking-wide text-indigo-800">Trading Journal</div>
          <div className="text-[9px] font-semibold text-slate-500">{message}</div>
        </div>
        <div className="ml-auto flex items-center gap-1.5">
          {activeView !== 'withdrawals' && <>
          <button type="button" onClick={() => void exportExcel()} disabled={exporting !== null || preparingScreenshots}
            className="flex items-center gap-1 rounded border border-emerald-200 bg-emerald-50 px-2 py-1 text-[9px] font-black text-emerald-700 disabled:opacity-50">
            <Download className="h-3 w-3" /> {exporting === 'excel' ? 'EXPORTING…' : 'EXPORT EXCEL'}
          </button>
          <button type="button" onClick={() => void exportWord()} disabled={exporting !== null || preparingScreenshots}
            className="flex items-center gap-1 rounded border border-blue-200 bg-blue-50 px-2 py-1 text-[9px] font-black text-blue-700 disabled:opacity-50">
            <Download className="h-3 w-3" /> {preparingScreenshots ? 'PREPARING IMAGES…' : exporting === 'word' ? 'EXPORTING…' : 'EXPORT WORD'}
          </button>
          </>}
          <button type="button" onClick={onClose} className="rounded border border-slate-200 p-1 text-slate-600 hover:bg-slate-100" title="Close journal">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-1 border-b border-slate-200 bg-white px-3 pt-1.5">
        {([
          ['overview', 'OVERVIEW', LayoutDashboard],
          ['calendar', 'CALENDAR', CalendarDays],
          ['history', 'HISTORY', History],
        ] as const).map(([view, label, Icon]) => (
          <button key={view} type="button" onClick={() => setActiveView(view)}
            className={`flex items-center gap-1 border-b-2 px-3 py-1.5 text-[9px] font-black transition ${
              activeView === view
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}>
            <Icon className="h-3 w-3" /> {label}
          </button>
        ))}
        {canManageCapital && <button type="button" onClick={() => setActiveView('withdrawals')}
          className={`border-b-2 px-3 py-1.5 text-[9px] font-black ${activeView === 'withdrawals' ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500'}`}>WITHDRAWALS</button>}
      </div>

      {activeView === 'withdrawals' && canManageCapital && <Mt5CapitalPanel terminalId={terminalId === 'secondary' ? 'secondary' : 'primary'} timeZone={timeZone} />}
      {activeView !== 'withdrawals' && <>
      <div className="shrink-0 border-b border-indigo-100 bg-white px-3 py-1 text-[9px] font-bold text-indigo-700">
        {formatHistoryDate(historyWindow.from)} – {formatHistoryDate(historyWindow.to)}
      </div>
      <div className="flex shrink-0 flex-wrap items-center gap-1.5 border-b border-slate-200 bg-white px-2 py-1.5">
        <TradeMultiSelect
          allLabel="ALL TIMEFRAMES"
          emptyLabel="NO TIMEFRAMES"
          selected={timeframeFilter}
          options={availableTimeframes.map((timeframe) => ({ value: timeframe, label: displayTimeframe(timeframe) }))}
          onChange={(timeframes) => setTimeframeFilter(timeframes as TradeRecordFilters['timeframes'])}
        />
        <select value={datePeriod} onChange={(event) => {
          setDatePeriod(event.target.value as TradeRecordFilters['datePeriod']);
        }} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="DAY">DAILY</option><option value="WEEK">WEEKLY</option><option value="MONTH">MONTHLY</option>
        </select>
        <input type="date" value={dateFilter === 'ALL' ? '' : dateFilter} onChange={(event) => setDateFilter(event.target.value || 'ALL')}
          className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold" title="Choose any date" />
        {dateFilter !== 'ALL' && datePeriod !== 'DAY' && (
          <span className="whitespace-nowrap text-[8px] font-bold text-indigo-700">
            {tradeRecordPeriodLabel(tradeRecordDatePeriodKey(dateFilter, datePeriod), datePeriod)}
          </span>
        )}
        {dateFilter !== 'ALL' && <button type="button" onClick={() => setDateFilter('ALL')} className="rounded border border-slate-200 bg-white px-2 py-1 text-[8px] font-black text-slate-500">ALL DATES</button>}
        <select value={sourceFilter} onChange={(event) => setSourceFilter(event.target.value as TradeRecordFilters['source'])} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="ALL">ALL SOURCES</option><option value="ENGULFING">ENGULFING</option><option value="MTF">MTF</option><option value="BOLLINGER">BOLLINGER</option>
        </select>
        <select value={sideFilter} onChange={(event) => setSideFilter(event.target.value as TradeRecordFilters['side'])} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="ALL">ALL SIDES</option><option value="BUY">BUY</option><option value="SELL">SELL</option>
        </select>
        <TradeStrategyCheckboxes label="Journal strategies" selected={tradeStyleFilter} onChange={setTradeStyleFilter} />
        <select aria-label="Trading time" value={tradingTimeFilter} onChange={(event) => setTradingTimeFilter(event.target.value as TradeRecordFilters['tradingTime'])} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="ALL">ALL TRADING TIMES</option><option value="TRADING">IN SESSION</option><option value="NON_TRADING">OUTSIDE TIME</option>
        </select>
        <select value={resultFilter} onChange={(event) => setResultFilter(event.target.value as 'ALL' | JournalTradeRecord['result'])} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="ALL">ALL RESULTS</option><option value="open">OPEN</option><option value="risk-free">RF DONE</option><option value="tp">TP</option><option value="sl">SL</option><option value="rf">RISK FREE</option>
        </select>
        <TradeMultiSelect
          allLabel="ALL ZONES"
          emptyLabel="NO ZONES"
          selected={zoneFilter}
          options={availableZones.map((zone) => ({ value: zone, label: zone }))}
          onChange={setZoneFilter}
        />
        <select value={volumeFilter} onChange={(event) => setVolumeFilter(event.target.value as 'ALL' | EngulfingVolumeStatus)} className="rounded border border-slate-200 px-2 py-1 text-[9px] font-bold">
          <option value="ALL">ALL VOLUME LOGIC</option><option value="best">BEST</option><option value="valid">VALID</option><option value="failed">FAILED</option><option value="unavailable">UNAVAILABLE</option><option value="not-applicable">N/A</option>
        </select>
        <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search zone, reason, mistake or lesson"
          className="min-w-48 flex-1 rounded border border-slate-200 px-2 py-1 text-[9px] font-semibold outline-none focus:border-indigo-300" />
        <button type="button" onClick={() => {
          setTimeframeFilter([timeframe]); setDatePeriod('DAY'); setDateFilter('ALL'); setSourceFilter('ALL');
          setSideFilter('ALL'); setResultFilter('ALL'); setZoneFilter('ALL');
          setTradeStyleFilter([...TRADE_STRATEGIES]); setTradingTimeFilter('ALL');
          setVolumeFilter('ALL'); setSearch('');
        }} className="rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[9px] font-black text-slate-600 hover:bg-slate-100">RESET</button>
      </div>

      </>}
      {activeView === 'overview' && (
        <div className="min-h-0 flex-1 overflow-auto bg-slate-100 p-3">
          <section className="mb-3">
            <div className="mb-1.5 flex items-center justify-between">
              <h3 className="text-[11px] font-black uppercase text-slate-800">Running trades</h3>
              <button type="button" onClick={() => setActiveView('history')}
                className="rounded border border-indigo-200 bg-indigo-50 px-2 py-1 text-[8px] font-black text-indigo-700">
                VIEW ALL
              </button>
            </div>
            {runningTrades.length > 0 ? (
              <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
                {runningTrades.map((trade) => (
                  <button key={trade.id} type="button" onClick={() => { setSelectedId(trade.id); setActiveView('history'); }}
                    className="rounded-lg border border-slate-200 bg-slate-900 p-3 text-left text-white shadow-sm">
                    <div className="flex items-center justify-between gap-2">
                      <span className={`rounded px-1.5 py-0.5 text-[8px] font-black ${
                        trade.direction === 'bullish' ? 'bg-emerald-600' : 'bg-rose-600'
                      }`}>{trade.direction === 'bullish' ? 'BUY' : 'SELL'}</span>
                      <span className="text-[8px] font-bold text-slate-400">{trade.result === 'risk-free' ? 'RF ACTIVE' : 'OPEN'}</span>
                    </div>
                    <div className="mt-2 text-xs font-black">XAUUSD · {trade.zoneName}</div>
                    <div className="mt-1 text-[8px] text-slate-400">
                      Entry {formatPrice(trade.entry)}{trade.volume ? ` · ${trade.volume} lot` : ''}
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="rounded-lg border border-dashed border-slate-300 bg-white p-4 text-center text-[9px] font-semibold text-slate-400">
                No running trades match the current filters.
              </div>
            )}
          </section>

          <section className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
            {[
              ['REALIZED P/L', performance.realizedTradeCount > 0 ? formatMoney(performance.realizedProfit) : '—', performance.realizedProfit >= 0 ? 'text-emerald-700' : 'text-rose-700', performance.realizedTradeCount > 0 ? `${performance.realizedTradeCount} MT5 trades` : 'Broker cash data unavailable'],
              ['PROFIT FACTOR', formatMetric(performance.profitFactor), 'text-slate-900', 'Calculated from normalized R'],
              ['WIN RATE', `${performance.winRate.toFixed(2)}%`, 'text-indigo-700', `${performance.completed} completed trades`],
              ['AVG WIN / AVG LOSS', formatMetric(performance.averageWinLoss), 'text-slate-900', 'Calculated from normalized R'],
              ['TOTAL TRADES', String(filteredTrades.length), 'text-slate-900', `${runningTrades.length} currently running`],
            ].map(([label, value, color, hint]) => (
              <div key={label} className="rounded-lg border border-slate-200 bg-white p-3 shadow-sm">
                <div className="text-[8px] font-black uppercase tracking-wide text-slate-500">{label}</div>
                <div className={`mt-2 text-xl font-black ${color}`}>{value}</div>
                <div className="mt-1 text-[7px] font-semibold text-slate-400">{hint}</div>
              </div>
            ))}
          </section>

          <section className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-5">
            {[
              ['TP', counts.tp, 'text-emerald-700', 'bg-emerald-50 border-emerald-200'],
              ['SL', counts.sl, 'text-rose-700', 'bg-rose-50 border-rose-200'],
              ['RISK FREE', counts.rf, 'text-amber-700', 'bg-amber-50 border-amber-200'],
              ['TOTAL R', `${performance.totalR >= 0 ? '+' : ''}${performance.totalR.toFixed(2)}R`, performance.totalR >= 0 ? 'text-emerald-700' : 'text-rose-700', 'bg-white border-slate-200'],
              ['ACCURACY', `${accuracy}%`, 'text-indigo-700', 'bg-indigo-50 border-indigo-200'],
            ].map(([label, value, color, background]) => (
              <div key={label} className={`rounded-lg border p-2 text-center ${background}`}>
                <div className="text-[7px] font-black uppercase text-slate-500">{label}</div>
                <div className={`mt-1 text-base font-black ${color}`}>{value}</div>
              </div>
            ))}
          </section>

          <section className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-200 px-3 py-2 text-[9px] font-black uppercase text-slate-700">Recent trades</div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-[9px]">
                <thead className="bg-slate-50 uppercase text-slate-500"><tr>
                  {['Date', 'Setup', 'Side', 'Lots', 'Entry', 'Exit', 'Net result'].map((heading) => <th key={heading} className="px-3 py-2">{heading}</th>)}
                </tr></thead>
                <tbody>{filteredTrades.slice(0, 8).map((trade) => {
                  const resultR = tradeResultR(trade);
                  return <tr key={trade.id} onClick={() => { setSelectedId(trade.id); setActiveView('history'); }} className="cursor-pointer border-t border-slate-100 hover:bg-indigo-50">
                    <td className="whitespace-nowrap px-3 py-2">{formatJournalDate(trade.completedAt, timeZone)}</td>
                    <td className="px-3 py-2 font-black">{displayTimeframe(trade.zoneTimeframe)} {trade.zoneName}</td>
                    <td className={`px-3 py-2 font-black ${trade.direction === 'bullish' ? 'text-emerald-700' : 'text-rose-700'}`}>{trade.direction === 'bullish' ? 'BUY' : 'SELL'}</td>
                    <td className="px-3 py-2">{trade.volume ?? '—'}</td>
                    <td className="px-3 py-2">{formatPrice(trade.entry)}</td>
                    <td className="px-3 py-2">{trade.closePrice === undefined ? '—' : formatPrice(trade.closePrice)}</td>
                    <td className={`px-3 py-2 font-black ${(trade.realizedProfit ?? resultR ?? 0) >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {Number.isFinite(trade.realizedProfit) ? formatMoney(trade.realizedProfit ?? 0) : resultR === undefined ? RESULT_LABELS[trade.result] : `${resultR >= 0 ? '+' : ''}${resultR}R`}
                    </td>
                  </tr>;
                })}</tbody>
              </table>
            </div>
          </section>
        </div>
      )}

      {activeView === 'calendar' && (
        <div className="min-h-0 flex-1 overflow-auto bg-slate-100 p-3">
          <div className="mb-2 flex items-center justify-between">
            <div>
              <h3 className="text-[11px] font-black uppercase text-slate-800">Trading calendar</h3>
              <div className="text-[8px] font-semibold text-slate-500">Closed MT5 trades · actual broker P/L in USD</div>
            </div>
            <div className="flex items-center rounded border border-slate-200 bg-white">
              <button type="button" onClick={() => setCalendarMonth((current) => current.month === 1
                ? { year: current.year - 1, month: 12 } : { ...current, month: current.month - 1 })}
                className="p-1.5 text-slate-500 hover:text-indigo-700"><ChevronLeft className="h-3.5 w-3.5" /></button>
              <span className="min-w-28 px-2 text-center text-[9px] font-black text-slate-700">{calendarMonthLabel}</span>
              <button type="button" onClick={() => setCalendarMonth((current) => current.month === 12
                ? { year: current.year + 1, month: 1 } : { ...current, month: current.month + 1 })}
                className="p-1.5 text-slate-500 hover:text-indigo-700"><ChevronRight className="h-3.5 w-3.5" /></button>
            </div>
          </div>
          <div className="min-w-[720px] overflow-hidden rounded-lg border border-slate-300 bg-white shadow-sm">
            <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => (
                <div key={day} className="px-2 py-2 text-center text-[8px] font-black uppercase text-slate-600">{day}</div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {calendarCells.map((day, index) => {
                if (day === undefined) return <div key={`empty-${index}`} className="min-h-24 border-b border-r border-slate-100 bg-slate-50/70" />;
                const key = `${calendarMonth.year}-${String(calendarMonth.month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const cashTrades = calendarCashTradesByDate.get(key) ?? [];
                const cashSummary = calculateJournalCashSummary(cashTrades);
                const positive = cashSummary.realizedProfit > 0;
                const negative = cashSummary.realizedProfit < 0;
                return <button key={key} type="button" disabled={cashSummary.tradeCount === 0}
                  onClick={() => { setDatePeriod('DAY'); setDateFilter(key); setActiveView('history'); }}
                  className={`min-h-24 border-b border-r p-2 text-left transition ${
                    positive ? 'border-emerald-200 bg-emerald-50 hover:bg-emerald-100'
                      : negative ? 'border-rose-200 bg-rose-50 hover:bg-rose-100'
                        : 'border-slate-100 bg-white disabled:bg-slate-50/40'
                  }`}>
                  <div className="text-[10px] font-black text-slate-700">{String(day).padStart(2, '0')}</div>
                  {cashSummary.tradeCount > 0 && <div className="mt-8">
                    <div className={`text-[10px] font-black ${positive ? 'text-emerald-700' : negative ? 'text-rose-700' : 'text-slate-600'}`}>
                      {formatMoney(cashSummary.realizedProfit)}
                    </div>
                    <div className="mt-1 text-[8px] font-semibold text-slate-500">{cashSummary.tradeCount} MT5 trade{cashSummary.tradeCount === 1 ? '' : 's'}</div>
                  </div>}
                </button>;
              })}
            </div>
          </div>
        </div>
      )}

      {activeView === 'history' && <div className="flex min-h-0 flex-1">
        <div className="min-w-0 flex-1 overflow-auto border-r border-slate-300 bg-white">
          <table className="min-w-[1540px] w-full border-collapse text-center text-[9px]">
            <thead className="sticky top-0 z-10 bg-slate-600 uppercase text-white">
              <tr>{['#', 'Date', 'Time', 'Session', 'Zone TF', 'Zone', 'Side', 'Engulfing', 'Volume logic', 'Lots', 'Entry', 'Exit', 'SL', 'TP', 'R:R', 'Net P/L', 'Result'].map((heading) => <th key={heading} className="whitespace-nowrap px-2 py-1.5">{heading}</th>)}</tr>
            </thead>
            <tbody>
              {filteredTrades.map((trade, index) => <React.Fragment key={trade.id}>
                {(index === 0 || journalDateKey(filteredTrades[index - 1].completedAt, timeZone) !== journalDateKey(trade.completedAt, timeZone)) && (
                  <tr className="border-t-2 border-slate-300 bg-slate-100 text-left text-slate-700">
                    <td colSpan={17} className="px-3 py-1.5 font-black">
                      {formatJournalDate(trade.completedAt, timeZone)} · {tradesByDate.get(journalDateKey(trade.completedAt, timeZone))?.length ?? 0} trade{(tradesByDate.get(journalDateKey(trade.completedAt, timeZone))?.length ?? 0) === 1 ? '' : 's'}
                    </td>
                  </tr>
                )}
                <tr key={trade.id} onClick={() => setSelectedId(trade.id)} className={`cursor-pointer border-t border-slate-200 ${selectedId === trade.id ? 'bg-indigo-100' : 'odd:bg-white even:bg-slate-50 hover:bg-indigo-50'}`}>
                  <td className="px-2 py-1.5 text-slate-500">{index + 1}</td>
                  <td className="whitespace-nowrap px-2 py-1.5">{formatJournalDate(trade.completedAt, timeZone)}</td>
                  <td className="px-2 py-1.5">{formatJournalTime(trade.completedAt, timeZone)}</td>
                  <td className="whitespace-nowrap px-2 py-1.5 font-bold">{trade.session || inferTradingSession(trade.completedAt)}</td>
                  <td className="px-2 py-1.5 font-bold">{displayTimeframe(trade.zoneTimeframe)}</td>
                  <td className="whitespace-nowrap px-2 py-1.5 text-left font-bold">{trade.zoneName}
                    {trade.intradayEntry && <div className="text-[8px] text-slate-500">
                      {trade.intradayEntry.leg}% pullback / {Math.round(trade.intradayEntry.riskShare * 100)}% setup risk
                    </div>}
                    {(trade.tradeStyle === 'SCALP_1_1' || trade.tradeStyle === 'BOLLINGER_M5') && <div className="text-[8px] text-slate-500">
                      {trade.mt5Managed || trade.brokerTicket !== undefined ? 'MT5' : 'CHART ONLY'}
                      {trade.scalpEntry && ` · ${trade.scalpEntry.leg}% pullback / ${trade.pullbackFallback === 'SECOND_ONLY' ? 100 : Math.round(trade.scalpEntry.riskShare * 100)}% risk`}
                    </div>}
                  </td>
                  <td className={`px-2 py-1.5 font-black ${trade.direction === 'bullish' ? 'text-emerald-700' : 'text-rose-700'}`}>{trade.direction === 'bullish' ? 'BUY' : 'SELL'}</td>
                  <td className="whitespace-nowrap px-2 py-1.5">{displayTimeframe(trade.signalTimeframe)} {trade.engulfingType}</td>
                  <td title={volumeValues(trade)} className={`whitespace-nowrap px-2 py-1.5 font-black ${volumeStatus(trade) === 'best' ? 'text-emerald-700' : volumeStatus(trade) === 'valid' ? 'text-blue-700' : volumeStatus(trade) === 'failed' ? 'text-rose-700' : 'text-slate-500'}`}>{VOLUME_STATUS_LABELS[volumeStatus(trade)]}</td>
                  <td className="px-2 py-1.5">{trade.volume ?? '—'}</td>
                  <td className="px-2 py-1.5">{formatPrice(trade.entry)}</td>
                  <td className="px-2 py-1.5">{trade.closePrice === undefined ? '—' : formatPrice(trade.closePrice)}</td>
                  <td className="px-2 py-1.5">{formatPrice(trade.stopLoss)}</td><td className="px-2 py-1.5">{formatPrice(trade.takeProfit)}</td>
                  <td className="px-2 py-1.5 font-bold">1:{trade.rewardRisk}</td>
                  <td className={`px-2 py-1.5 font-black ${(trade.realizedProfit ?? tradeResultR(trade) ?? 0) >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {Number.isFinite(trade.realizedProfit) ? formatMoney(trade.realizedProfit ?? 0) : tradeResultR(trade) === undefined ? '—' : `${(tradeResultR(trade) ?? 0) >= 0 ? '+' : ''}${tradeResultR(trade)}R`}
                  </td>
                  <td className={`px-2 py-1.5 font-black ${trade.result === 'tp' ? 'text-emerald-700' : trade.result === 'sl' ? 'text-rose-700' : trade.result === 'open' ? 'text-blue-700' : 'text-amber-600'}`}>{RESULT_LABELS[trade.result]}</td>
                </tr>
              </React.Fragment>)}
              {filteredTrades.length === 0 && <tr><td colSpan={17} className="p-6 text-slate-400">No journal trades match these filters.</td></tr>}
            </tbody>
          </table>
        </div>

        <aside className="w-[330px] shrink-0 overflow-auto bg-slate-50 p-3">
          {selectedTrade ? <>
            <div className="mb-2 text-[10px] font-black uppercase text-indigo-800">Trade review</div>
            <div className="mb-2 rounded border border-slate-200 bg-white p-2 text-[9px] leading-relaxed text-slate-600">
              <strong className="text-slate-800">{displayTimeframe(selectedTrade.zoneTimeframe)} {selectedTrade.zoneName}</strong> · {selectedTrade.direction === 'bullish' ? 'BUY' : 'SELL'}<br />
              {displayTimeframe(selectedTrade.signalTimeframe)} {selectedTrade.engulfingType} · 1:{selectedTrade.rewardRisk} · {RESULT_LABELS[selectedTrade.result]}
              <br />Volume logic: <strong>{VOLUME_STATUS_LABELS[volumeStatus(selectedTrade)]}</strong> · {volumeValues(selectedTrade)}
              {selectedTrade.brokerTicket && <><br />MT5 ticket: <strong>#{selectedTrade.brokerTicket}</strong>{selectedTrade.volume ? ` · ${selectedTrade.volume} lot` : ''}</>}
            </div>
            {selectedTrade.biasAtEntry && (
              <div className="mb-2 rounded border border-indigo-200 bg-indigo-50 p-2">
                <div className="mb-1 text-[8px] font-black uppercase text-indigo-800">Bias at entry</div>
                <div className="grid grid-cols-4 gap-1">
                  {BIAS_TIMEFRAMES.map((timeframe) => {
                    const trend = selectedTrade.biasAtEntry?.[timeframe];
                    return <div key={timeframe} className="rounded bg-white px-1 py-1 text-center text-[7px] font-black">
                      <div className="text-slate-500">{displayTimeframe(timeframe)}</div>
                      <div className={trend === 'bullish' ? 'text-emerald-700' : trend === 'bearish' ? 'text-rose-700' : 'text-slate-500'}>{trendLabel(trend)}</div>
                    </div>;
                  })}
                </div>
              </div>
            )}
            {(selectedTrade.reason || selectedTrade.autoReason) && (
              <div className="mb-2 rounded border border-emerald-200 bg-emerald-50 p-2 text-[8px] leading-relaxed text-slate-700">
                <div className="mb-1 font-black uppercase text-emerald-800">{selectedTrade.reason ? 'Manual entry reason' : 'Automatic entry reason'}</div>
                {selectedTrade.reason || selectedTrade.autoReason}
              </div>
            )}
            <label className="mb-2 block text-[8px] font-black uppercase text-slate-500">Session
              <select value={draft.session} onChange={(event) => setDraft((current) => ({ ...current, session: event.target.value }))} className="mt-1 w-full rounded border border-slate-200 bg-white px-2 py-1.5 text-[9px] font-bold text-slate-700">
                {['ASIAN', 'LONDON', 'LON + NYC', 'NEW YORK', 'OTHER'].map((session) => <option key={session}>{session}</option>)}
              </select>
            </label>
            {[['reason', 'Manual reason (automatic reason used when empty)'], ['mistake', 'Mistake / important observation'], ['lesson', 'Lesson learned']].map(([key, label]) => (
              <label key={key} className="mb-2 block text-[8px] font-black uppercase text-slate-500">{label}
                <textarea value={draft[key as 'reason' | 'mistake' | 'lesson']} onChange={(event) => setDraft((current) => ({ ...current, [key]: event.target.value }))} rows={3}
                  className="mt-1 w-full resize-y rounded border border-slate-200 bg-white px-2 py-1.5 text-[9px] font-medium normal-case text-slate-700 outline-none focus:border-indigo-300" />
              </label>
            ))}
            <label className="mb-2 flex cursor-pointer items-center justify-center gap-1 rounded border border-dashed border-slate-300 bg-white px-2 py-2 text-[9px] font-black text-slate-600 hover:border-indigo-300 hover:text-indigo-700">
              <ImagePlus className="h-3.5 w-3.5" /> ATTACH SCREENSHOT
              <input type="file" accept="image/*" className="hidden" onChange={(event) => attachScreenshot(event.target.files?.[0])} />
            </label>
            {draft.screenshotDataUrl && <img src={draft.screenshotDataUrl} alt="Trade screenshot" className="mb-2 max-h-40 w-full rounded border border-slate-200 object-contain" />}
            {selectedTrade.entryScreenshotDataUrl && <div className="mb-2">
              <div className="mb-1 text-[8px] font-black uppercase text-slate-500">Entry snapshot</div>
              <img src={selectedTrade.entryScreenshotDataUrl} alt="Entry snapshot" className="max-h-40 w-full rounded border border-slate-200 object-contain" />
            </div>}
            {selectedTrade.exitScreenshotDataUrl && <div className="mb-2">
              <div className="mb-1 text-[8px] font-black uppercase text-slate-500">Final outcome snapshot</div>
              <img src={selectedTrade.exitScreenshotDataUrl} alt="Final outcome snapshot" className="max-h-40 w-full rounded border border-slate-200 object-contain" />
            </div>}
            <button type="button" onClick={() => void saveTrade()} disabled={saving} className="flex w-full items-center justify-center gap-1 rounded bg-indigo-700 px-2 py-2 text-[9px] font-black text-white hover:bg-indigo-800 disabled:opacity-50">
              <Save className="h-3.5 w-3.5" /> {saving ? 'SAVING…' : 'SAVE TRADE REVIEW'}
            </button>
          </> : <div className="grid h-full place-items-center text-center text-xs text-slate-400">Select a trade to add your review.</div>}
        </aside>
      </div>}
    </div>
  );
};
